<template>
  <div class="bottom-nav">
    <div 
      class="bottom-nav-item" 
      :class="{ active: activeTab === 'home' }"
      @click="navigateTo('/')">
      <i class="el-icon-menu bottom-nav-icon"></i>
      首页
    </div>
    <div 
      class="bottom-nav-item" 
      :class="{ active: activeTab === 'tasks' }"
      @click="navigateTo('/tasks')">
      <i class="el-icon-plus bottom-nav-icon"></i>
      任务
    </div>
    <div 
      class="bottom-nav-item" 
      :class="{ active: activeTab === 'profile' }"
      @click="navigateTo('/profile')">
      <i class="el-icon-user bottom-nav-icon"></i>
      我的
    </div>
  </div>
</template>

<script>
export default {
  name: 'BottomNav',
  props: {
    activeTab: {
      type: String,
      default: 'home'
    }
  },
  methods: {
    navigateTo(path) {
      this.$router.push(path)
    }
  }
}
</script>

<style scoped>
.bottom-nav {
  position: fixed;
  left: 0;
  right: 0;
  bottom: 0;
  height: 56px;
  background: #fff;
  border-top: 1px solid #eee;
  display: flex;
  justify-content: space-around;
  align-items: center;
  z-index: 10;
}

.bottom-nav-item {
  flex: 1;
  text-align: center;
  color: #888;
  font-size: 13px;
  padding-top: 4px;
  cursor: pointer;
}

.bottom-nav-item.active {
  color: #409EFF;
  font-weight: bold;
}

.bottom-nav-icon {
  font-size: 22px;
  display: block;
  margin-bottom: 2px;
}
</style>
