<template>
  <div style="display: flex; justify-content: center; align-items: center; min-height: 100vh; background: #f6f8fa;">
    <el-card style="width: 420px; box-shadow: 0 2px 12px #0001; border-radius: 18px;">
      <div style="text-align: center; margin-bottom: 18px;">
        <el-tag type="warning" size="medium" style="font-size: 16px;">
          抖音一键回关配置
        </el-tag>
      </div>

      <el-form :rules="rules" ref="form" :model="form" label-width="120px" size="medium" style="margin-top: 10px;">
        <el-form-item label="互关模式" prop="deleteMode">
          <el-radio-group v-model="form.deleteMode">
            <el-radio label="all">回关所有账号</el-radio>
            <el-radio label="selective">选择性回关</el-radio>
          </el-radio-group>
        </el-form-item>

        <el-form-item label="互关数量" prop="deleteCount" v-if="form.deleteMode === 'selective'">
          <el-input-number
            v-model="form.deleteCount"
            :min="1"
            :max="100"
            controls-position="right"
            style="width: 100%;">
          </el-input-number>
        </el-form-item>

        <el-form-item label="等待时间(ms)" prop="waitTime">
          <el-input-number
            v-model="form.waitTime"
            :min="1000"
            :max="10000"
            :step="500"
            controls-position="right"
            style="width: 100%;">
          </el-input-number>
        </el-form-item>

        <el-divider></el-divider>
      </el-form>

      <el-button
        type="primary"
        icon="el-icon-document"
        style="width: 45%; margin-right: 5%;"
        @click="save">
        保存配置
      </el-button>

      <el-button
        type="danger"
        icon="el-icon-delete"
        style="width: 45%;"
        @click="runScript">
        运行脚本
      </el-button>

      <!-- 底部导航 -->
      <BottomNav activeTab="tasks" />
    </el-card>
  </div>
</template>

<script>
import BottomNav from '@/components/BottomNav.vue'

export default {
  name: 'DouyinFollow',
  components: {
    BottomNav
  },
  data() {
    return {
      form: {
        deleteMode: 'all',
        deleteCount: 10,
        waitTime: 2000
      },
      rules: {
        deleteMode: [
          { required: true, message: '请选择删除模式', trigger: 'change' }
        ],
        deleteCount: [
          { required: true, message: '请输入删除数量', trigger: 'blur' }
        ],
        waitTime: [
          { required: true, message: '请输入等待时间', trigger: 'blur' }
        ]
      }
    }
  },
  created() {
    this.resetValue()
  },
  methods: {
    resetValue() {
      window.ec.hideStartBtn()
      let config = window.ec.getConfig("config");
      if (config) {
        config = JSON.parse(config)
        this.form.deleteMode = config.deleteMode || 'all'
        this.form.deleteCount = config.deleteCount || 10
        this.form.waitTime = config.waitTime || 2000
        // this.form.confirmDelete = config.confirmDelete !== undefined ? config.confirmDelete : true
        // this.form.filterKeywords = config.filterKeywords || ''
      }
      // 重置表单值的方法
      console.log('删除配置已重置');
    },
    save() {
      let config = {
        deleteMode: this.form.deleteMode,
        deleteCount: this.form.deleteCount,
        waitTime: this.form.waitTime,
        // confirmDelete: this.form.confirmDelete,
        // filterKeywords: this.form.filterKeywords
      }
      window.ec.saveConfig("config", JSON.stringify(config));

      this.$notify.info({
        title: '消息',
        duration: 2000,
        message: '保存删除配置成功'
      });
      // 保存配置的方法
      console.log('删除配置已保存');
    },
    runScript() {
      // 确认对话框
      this.$confirm('确定要运行删除评论脚本吗？此操作不可撤销！', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        center: true
      }).then(() => {
        // 设置当前页面为删除模式
        this.save()
        window.ec.saveConfig("currentPage", "follow");
        window.ec.start()
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除操作'
        });
      });

    },
    navigateTo(path) {
      this.$router.push(path)
    }
  }
}
</script>

<style scoped>
</style>
