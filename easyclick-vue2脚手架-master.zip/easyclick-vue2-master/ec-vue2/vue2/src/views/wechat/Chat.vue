<template>
  <div style="display: flex; justify-content: center; align-items: center; min-height: 100vh; background: #f6f8fa;">
    <el-card style="width: 420px; box-shadow: 0 2px 12px #0001; border-radius: 18px;">
      <div style="text-align: center;">
        <el-tag type="success" size="medium" style="font-size: 16px;">
          Ai回复配置
        </el-tag>
      </div>

      <el-form :rules="rules" ref="form" :model="form" label-width="100px" size="medium" style="margin-top: 10px;">
        <el-form-item label="等待时间(ms)" prop="waitTime">
          <el-input-number
            v-model="form.waitTime"
            :min="1000"
            :max="10000"
            :step="500"
            controls-position="right"
            style="width: 100%;">
          </el-input-number>
        </el-form-item>

        <el-form-item label="AI模型选择">
          <div style="background: #f5f7fa; border-radius: 8px; padding: 12px 16px;">
            <el-radio-group v-model="form.model" style="display: flex; flex-direction: column;">
              <el-radio label="doubao-seed-1-6-250615" style="margin-bottom: 8px;">豆包-基础版</el-radio>
              <el-radio label="doubao-seed-1-6-thinking-250615" style="margin-bottom: 8px;">豆包-思考版</el-radio>
              <el-radio label="moonshot-v1-8k-vision-preview" style="margin-bottom: 8px;">kimi-基础版</el-radio>
              <el-radio label="moonshot-v1-32k-vision-preview" style="margin-bottom: 8px;">kimi-高级版</el-radio>
            </el-radio-group>
          </div>
        </el-form-item>

        <el-divider></el-divider>
      </el-form>

      <el-button
        type="primary"
        icon="el-icon-document"
        style="width: 45%; margin-right: 5%;"
        @click="save">
        保存配置
      </el-button>

      <el-button
        type="success"
        icon="el-icon-video-play"
        style="width: 45%;"
        @click="runScript">
        运行脚本
      </el-button>

      <!-- 底部导航 -->
      <BottomNav activeTab="tasks" />
    </el-card>
  </div>
</template>

<script>
import BottomNav from '@/components/BottomNav.vue'

export default {
  name: 'WechatChat',
  components: {
    BottomNav
  },
  data() {
    return {
      form: {
        videoCount: 10,
        waitTime: 1000,
        enableLike: false,
        enableComment: false,
        commentText: '点点关注，不迷路',
        model: 'doubao-seed-1-6-250615'
      },
      rules: {
        videoCount: [
          { required: true, message: '请输入视频数量', trigger: 'blur' }
        ],
        waitTime: [
          { required: true, message: '请输入等待时间', trigger: 'blur' }
        ],
        commentText: [
          { required: true, message: '请输入评论内容', trigger: 'blur' }
        ]
      }
    }
  },
  created() {
    this.resetValue()
  },
  methods: {
    resetValue() {
      // 隐藏启动按钮
      if (window.ec && window.ec.hideStartBtn) {
        window.ec.hideStartBtn()
      }

      // 加载配置
      let config = null
      if (window.ec && window.ec.getConfig) {
        config = window.ec.getConfig("config")
      }

      if (config) {
        try {
          config = JSON.parse(config)
          this.form.videoCount = config.videoCount || 10
          this.form.waitTime = config.waitTime || 1000
          this.form.enableLike = config.enableLike !== undefined ? config.enableLike : false
          this.form.enableComment = config.enableComment !== undefined ? config.enableComment : false
          this.form.commentText = config.commentText || '点点关注，不迷路'
          this.form.model = config.model || 'doubao-seed-1-6-250615'
        } catch (e) {
          console.error('配置解析失败:', e)
        }
      }

      console.log('配置已重置')
    },
    save() {
      const config = {
        videoCount: this.form.videoCount,
        waitTime: this.form.waitTime,
        enableLike: this.form.enableLike,
        enableComment: this.form.enableComment,
        commentText: this.form.commentText,
        model: this.form.model
      }

      if (window.ec && window.ec.saveConfig) {
        window.ec.saveConfig("config", JSON.stringify(config))
      }

      this.$notify.info({
        title: '消息',
        duration: 2000,
        message: '保存配置成功'
      })

      console.log('配置已保存')
    },
    runScript() {
      this.save()
      if (window.ec && window.ec.saveConfig) {
        window.ec.saveConfig("currentPage", "chat")
      }
      if (window.ec && window.ec.start) {
        window.ec.start()
      }
    }
  }
}
</script>

<style scoped>
</style>
