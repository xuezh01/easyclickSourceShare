<template>
  <div style="display: flex; justify-content: center; align-items: center; min-height: 100vh; background: #f6f8fa;">
    <el-card style="width: 420px; box-shadow: 0 2px 12px #0001; border-radius: 18px;">
      <div style="text-align: center;">
        <el-tag type="success" size="medium" style="font-size: 16px;">
          微信智能养号配置
        </el-tag>
      </div>

      <el-form :rules="rules" ref="form" :model="form" label-width="100px" size="medium" style="margin-top: 10px;">
        <el-form-item label="视频数量" prop="videoCount">
          <el-input-number
            v-model="form.videoCount"
            :min="1"
            :max="100"
            controls-position="right"
            style="width: 100%;">
          </el-input-number>
        </el-form-item>

        <el-form-item label="等待时间(ms)" prop="waitTime">
          <el-input-number
            v-model="form.waitTime"
            :min="2000"
            :max="10000"
            :step="500"
            controls-position="right"
            style="width: 100%;">
          </el-input-number>
        </el-form-item>

        <el-form-item label="是否点赞">
          <el-switch
            v-model="form.enableLike"
            active-color="#13ce66"
            inactive-color="#dcdfe6">
          </el-switch>
        </el-form-item>

        <el-form-item label="是否评论">
          <el-switch
            v-model="form.enableComment"
            active-color="#409EFF"
            inactive-color="#dcdfe6">
          </el-switch>
        </el-form-item>

        <el-form-item label="评论内容" prop="commentText" v-if="form.enableComment">
          <el-input
            v-model="form.commentText"
            type="textarea"
            :rows="3"
            placeholder="请输入评论内容"
            style="width: 100%;">
          </el-input>
        </el-form-item>

        <el-divider></el-divider>
      </el-form>

      <el-button
        type="primary"
        icon="el-icon-document"
        style="width: 45%; margin-right: 5%;"
        @click="save">
        保存配置
      </el-button>

      <el-button
        type="success"
        icon="el-icon-video-play"
        style="width: 45%;"
        @click="runScript">
        运行脚本
      </el-button>

      <!-- 底部导航 -->
      <BottomNav activeTab="tasks" />
    </el-card>
  </div>
</template>

<script>
import BottomNav from '@/components/BottomNav.vue'

export default {
  name: 'WechatNurtureAccount',
  components: {
    BottomNav
  },
  data() {
    return {
      form: {
        videoCount: 10,
        waitTime: 1000,
        enableLike: false,
        enableComment: false,
        commentText: '点点关注，不迷路'
      },
      rules: {
        videoCount: [
          { required: true, message: '请输入视频数量', trigger: 'blur' },
          { type: 'number', min: 1, max: 100, message: '视频数量必须在1-100之间', trigger: 'blur' }
        ],
        waitTime: [
          { required: true, message: '请输入等待时间', trigger: 'blur' },
          { type: 'number', min: 1000, max: 10000, message: '等待时间必须在1000-10000ms之间', trigger: 'blur' }
        ],
        commentText: [
          { required: true, message: '请输入评论内容', trigger: 'blur' }
        ]
      }
    }
  },
  created() {
    this.resetValue()
  },
  methods: {
    resetValue() {
      window.ec.hideStartBtn()
      let config = window.ec.getConfig("config");
      config = JSON.parse(config)
      this.form.videoCount = config.videoCount || 10
      this.form.waitTime = config.waitTime || 1000
      this.form.enableLike = config.enableLike || false
      this.form.enableComment = config.enableComment || false
      this.form.commentText = config.commentText || '点点关注，不迷路'
      // 重置表单值的方法
      console.log('配置已重置');
    },
    save() {
      let config = {
        videoCount: this.form.videoCount,
        waitTime: this.form.waitTime,
        enableLike: this.form.enableLike,
        enableComment: this.form.enableComment,
        commentText: this.form.commentText
      }
      window.ec.saveConfig("config", JSON.stringify(config));

      this.$notify.info({
        title: '消息',
        duration: 2000,
        message: '保存参数成功'
      });
      // 保存配置的方法
      console.log('配置已保存');
    },
    runScript() {
      // 设置当前页面为发评论模式
      this.save()
      window.ec.saveConfig("currentPage", "comment");
      window.ec.start()
    }
  }
}
</script>

<style scoped>

</style>
