<template>
  <div style="background: #f6f8fa; min-height: 100vh; padding-bottom: 60px;">
    <div class="main-container">
      <!-- 标题 -->
      <div style="text-align: center; margin-bottom: 18px;">
        <el-tag type="warning" size="medium" style="font-size: 16px;">
          步数修改器
        </el-tag>
      </div>

      <!-- 表单区域 -->
      <div class="form-section">
        <el-form label-width="80px" size="medium">
          <!-- 邮箱输入 -->
          <el-form-item label="邮箱:">
            <el-input v-model="formData.email" placeholder="请输入邮箱"></el-input>
          </el-form-item>

          <!-- 密码输入 -->
          <el-form-item label="密码:">
            <el-input v-model="formData.password" type="password" placeholder="请输入密码"></el-input>
          </el-form-item>

          <!-- 步数输入 -->
          <el-form-item label="步数:">
            <el-input-number
              v-model="formData.steps"
              :min="1"
              :max="100000"
              controls-position="right"
              style="width: 100%;">
            </el-input-number>
          </el-form-item>

          <!-- 自动递增设置 -->
          <div class="auto-increment-section">
            <el-form-item label="启用自动递增:" label-width="120px">
              <el-switch v-model="autoIncrement.enabled" @change="onAutoIncrementChange"></el-switch>
            </el-form-item>

            <div v-if="autoIncrement.enabled">
              <el-form-item label="间隔时间:" label-width="120px">
                <el-input-number
                  v-model="autoIncrement.interval"
                  :min="1"
                  :max="1440"
                  controls-position="right"
                  style="width: 120px;">
                </el-input-number>
                <el-select v-model="autoIncrement.timeUnitIndex" style="width: 80px; margin-left: 10px;">
                  <el-option label="秒" :value="0"></el-option>
                  <el-option label="分钟" :value="1"></el-option>
                </el-select>
              </el-form-item>

              <!-- 步数范围设置 -->
              <el-form-item label="步数增加范围:" label-width="120px">
                <div class="range-inputs">
                  <el-input-number
                    v-model="autoIncrement.minSteps"
                    :min="1"
                    :max="10000"
                    controls-position="right"
                    style="width: 100px;"
                    @change="onMinStepsChange">
                  </el-input-number>
                  <span>到</span>
                  <el-input-number
                    v-model="autoIncrement.maxSteps"
                    :min="1"
                    :max="10000"
                    controls-position="right"
                    style="width: 100px;"
                    @change="onMaxStepsChange">
                  </el-input-number>
                </div>
              </el-form-item>
            </div>
          </div>
        </el-form>

        <!-- 控制按钮 -->
        <div class="button-group">
          <el-button
            type="primary"
            :disabled="!autoIncrement.enabled"
            @click="startAutoIncrement"
            v-if="!isRunning">
            开始自动递增
          </el-button>
          <el-button
            type="danger"
            @click="stopAutoIncrement"
            v-else>
            停止自动递增
          </el-button>
          <el-button
            type="success"
            @click="submitRequest">
            手动提交
          </el-button>
        </div>
      </div>

      <!-- 状态显示区域 -->
      <div class="status-section">
        <div class="status-item">
          <span class="status-label">状态:</span>
          <span class="status-text">{{ statusText }}</span>
        </div>
        <div class="status-item">
          <span class="status-label">下次提交时间:</span>
          <span class="status-text">{{ nextSubmitTime }}</span>
        </div>
        <div class="status-item">
          <span class="status-label">已提交次数:</span>
          <span class="status-text">{{ submitCount }}</span>
        </div>
      </div>

      <!-- 响应信息显示 -->
      <div class="response-section">
        <div style="margin-bottom: 10px; font-size: 14px; color: #666;">响应信息:</div>
        <div class="response-content">{{ responseText }}</div>
      </div>
    </div>

    <!-- 底部导航 -->
    <BottomNav activeTab="tasks" />
  </div>
</template>

<script>
import BottomNav from '@/components/BottomNav.vue'

export default {
  name: 'WechatWxkeep2',
  components: {
    BottomNav
  },
  data() {
    return {
      formData: {
        email: '',
        password: '',
        steps: 10000
      },
      autoIncrement: {
        enabled: false,
        interval: 60,
        timeUnitIndex: 1,
        minSteps: 100,
        maxSteps: 500
      },
      isRunning: false,
      timer: null,
      statusText: '等待操作',
      nextSubmitTime: '',
      submitCount: 0,
      responseText: '',
      lastSubmitTime: null
    }
  },
  methods: {
    // 自动递增开关变化
    onAutoIncrementChange(enabled) {
      if (!enabled && this.isRunning) {
        this.stopAutoIncrement()
      }
    },

    // 最小步数变化
    onMinStepsChange(value) {
      if (value >= this.autoIncrement.maxSteps) {
        this.autoIncrement.maxSteps = value + 1
      }
    },

    // 最大步数变化
    onMaxStepsChange(value) {
      if (value <= this.autoIncrement.minSteps) {
        this.autoIncrement.minSteps = value - 1
      }
    },

    // 获取随机递增步数
    getRandomIncrement() {
      const min = this.autoIncrement.minSteps
      const max = this.autoIncrement.maxSteps
      return Math.floor(Math.random() * (max - min + 1)) + min
    },

    // 开始自动递增
    startAutoIncrement() {
      if (!this.autoIncrement.enabled) {
        this.$message.warning('请先启用自动递增')
        return
      }

      this.isRunning = true
      this.statusText = '自动递增运行中'
      this.restartTimer()
    },

    // 停止自动递增
    stopAutoIncrement() {
      this.isRunning = false
      this.statusText = '自动递增已停止'
      this.nextSubmitTime = ''
      if (this.timer) {
        clearTimeout(this.timer)
        this.timer = null
      }
    },

    // 重启定时器
    restartTimer() {
      if (this.timer) {
        clearTimeout(this.timer)
      }

      const interval = this.autoIncrement.timeUnitIndex === 0 ?
        this.autoIncrement.interval * 1000 :
        this.autoIncrement.interval * 60 * 1000

      this.timer = setTimeout(() => {
        this.autoSubmit()
      }, interval)

      // 更新下次执行时间
      const now = new Date()
      const next = new Date(now.getTime() + interval)
      this.nextSubmitTime = next.toTimeString().split(' ')[0]
    },

    // 自动提交
    async autoSubmit() {
      try {
        if (this.lastSubmitTime) {
          const now = new Date()
          const diff = now - this.lastSubmitTime
          if (diff < 10000) { // 10秒内不重复提交
            return
          }
        }

        const increment = this.getRandomIncrement()
        this.formData.steps = Math.min(
          parseInt(this.formData.steps) + increment,
          100000
        )

        this.lastSubmitTime = new Date()
        const success = await this.submitRequest()

        if (success) {
          this.submitCount++
          this.statusText = `自动递增运行中 (本次增加${increment}步)`
          if (this.isRunning) {
            this.restartTimer()
          }
        } else {
          this.stopAutoIncrement()
          this.statusText = '自动递增已停止(提交失败)'
        }
      } catch (e) {
        console.error(e)
        this.responseText += '\n自动提交时发生错误: ' + e.message
        this.stopAutoIncrement()
      }
    },

    // 提交请求
    async submitRequest() {
      try {
        const url = 'http://yanwan.store/run4/mi20241027.php';

        // 使用fetch API
        const response = await fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: `user=${encodeURIComponent(this.formData.email)}&password=${encodeURIComponent(this.formData.password)}&step=${encodeURIComponent(this.formData.steps.toString())}`
        });

        const now = new Date();
        const timeStr = now.toTimeString().split(' ')[0];
        const responseText = await response.text();

        this.responseText = `[${timeStr}] 状态码: ${response.status}\n响应内容: ${responseText}\n请求URL: ${url}`;
        console.log('请求响应:', {status: response.status, responseText});

        if (response.status === 200) {
          if (responseText.includes('success') || responseText.includes('成功')) {
            if (!this.isRunning) {
              this.$message.success(`步数修改成功！当前步数：${this.formData.steps}`);
            }
            return true;
          }
        }

        if (!this.isRunning) {
          this.$message.error('提交失败');
        }
        return false;

      } catch (e) {
        console.error('请求错误:', e);
        const errorMessage = e.message || '网络请求失败';
        this.responseText = `[${new Date().toTimeString().split(' ')[0]}] 请求错误: ${errorMessage}`;
        if (!this.isRunning) {
          this.$message.error(errorMessage);
        }
        return false;
      }
    }
  },

  beforeDestroy() {
    if (this.timer) {
      clearTimeout(this.timer)
    }
  }
}
</script>

<style scoped>
.main-container {
  max-width: 480px;
  margin: 0 auto;
  padding: 20px;
}

.form-section {
  background: #fff;
  padding: 20px;
  border-radius: 10px;
  margin-bottom: 20px;
  box-shadow: 0 2px 12px #0001;
}

.auto-increment-section {
  margin: 20px 0;
  padding: 20px;
  background: #f8f8f8;
  border-radius: 6px;
}

.range-inputs {
  display: flex;
  align-items: center;
  gap: 10px;
}

.button-group {
  display: flex;
  justify-content: space-around;
  margin-top: 30px;
}

.status-section {
  background: #fff;
  padding: 20px;
  border-radius: 10px;
  margin-bottom: 20px;
  box-shadow: 0 2px 12px #0001;
}

.status-item {
  display: flex;
  margin-bottom: 10px;
}

.status-label {
  font-size: 14px;
  color: #666;
  width: 120px;
}

.status-text {
  font-size: 14px;
  color: #333;
}

.response-section {
  background: #fff;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 2px 12px #0001;
}

.response-content {
  height: 200px;
  font-size: 12px;
  color: #666;
  background: #f8f8f8;
  padding: 10px;
  border-radius: 6px;
  overflow-y: auto;
  white-space: pre-wrap;
}
</style>
