<template>
  <div style="display: flex; justify-content: center; align-items: center; min-height: 100vh; background: #f6f8fa;">
    <el-card style="width: 420px; box-shadow: 0 2px 12px #0001; border-radius: 18px;">
      <div style="text-align: center;">
        <el-tag type="info" size="medium" style="font-size: 16px;">
          任务中心
        </el-tag>
      </div>

      <div style="text-align: center; margin: 40px 0;">
        <i class="el-icon-s-order" style="font-size: 48px; color: #409EFF;"></i>
        <p style="margin-top: 20px; color: #666;">暂无运行中的任务</p>
        <el-button type="primary" @click="navigateTo('/timer')" style="margin-top: 15px;">
          创建定时任务
        </el-button>
      </div>

      <!-- 底部导航 -->
      <BottomNav activeTab="tasks" />
    </el-card>
  </div>
</template>

<script>
import BottomNav from '@/components/BottomNav.vue'

export default {
  name: 'TasksView',
  components: {
    BottomNav
  },
  methods: {
    navigateTo(path) {
      this.$router.push(path)
    }
  }
}
</script>

<style scoped>
</style>
