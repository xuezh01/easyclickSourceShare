<template>
  <div style="margin-top: 50px; min-height: 100vh; background: #f6f8fa;">

    <el-card style="width: 380px; box-shadow: 0 2px 12px #0001; border-radius: 18px;">
      <div style="text-align: center; margin-bottom: 18px;">
        <el-tag type="info" size="medium" style="font-size: 16px; padding: 8px 24px; border-radius: 8px;">
          {{ serviceMode }}
        </el-tag>
      </div>

      <!-- 服务管理区域 -->
      <div class="service-section">
        <div class="service-item">
          <div class="service-info">
            <span class="service-label">服务状态</span>
            <el-switch
              v-model="form.serviceOk"
              @change="handleServiceChange"
              active-color="#13ce66"
              inactive-color="#ff4949">
            </el-switch>
          </div>
          <el-button
            type="primary"
            icon="el-icon-caret-right"
            size="small"
            @click="openEnv">
            启动环境
          </el-button>
        </div>

        <el-divider style="margin: 20px 0;"></el-divider>

        <div class="service-item">
          <div class="service-info">
            <span class="service-label">悬浮窗权限</span>
            <el-switch
              v-model="form.floatView"
              @change="handleFloatViewChange"
              active-color="#409EFF"
              inactive-color="#dcdfe6">
            </el-switch>
          </div>
          <el-button
            type="success"
            icon="el-icon-unlock"
            size="small"
            @click="floatViewPermission">
            开启权限
          </el-button>
        </div>
      </div>

      <el-divider style="margin: 25px 0;"></el-divider>

      <!-- 使用说明部分 -->
      <div class="intro-section">
        <div class="section-header">
          <i class="el-icon-document" style="margin-right: 8px; color: #409EFF;"></i>
          <span class="section-title">使用说明</span>
        </div>

        <el-collapse v-model="activeNames" class="custom-collapse">
          <el-collapse-item name="douyin">
            <template slot="title">
              <i class="el-icon-video-camera" style="margin-right: 8px; color: #FF6B6B;"></i>
              <span>抖音功能说明</span>
            </template>
            <div class="intro-content">
              <div class="feature-group">
                <h4><i class="el-icon-star-on"></i>智能养号</h4>
                <p>• 自动浏览推荐视频并进行点赞、评论、收藏等操作</p>
                <p>• 可设置浏览数量和操作间隔时间</p>
                <p>• 支持自定义评论内容</p>
              </div>

              <div class="feature-group">
                <h4><i class="el-icon-chat-line-round"></i>删除评论</h4>
                <p>• 批量删除历史评论记录</p>
                <p>• 支持删除所有评论或选择性删除</p>
                <p>• 可设置删除数量和等待时间</p>
              </div>

              <div class="feature-group">
                <h4><i class="el-icon-star-off"></i>删除点赞</h4>
                <p>• 批量删除历史点赞记录</p>
                <p>• 支持删除所有点赞或选择性删除</p>
                <p>• 可设置删除数量和等待时间</p>
              </div>

              <div class="feature-group">
                <h4><i class="el-icon-collection"></i>删除收藏</h4>
                <p>• 批量删除历史收藏记录</p>
                <p>• 支持删除所有收藏或选择性删除</p>
                <p>• 可设置删除数量和等待时间</p>
              </div>

              <div class="feature-group">
                <h4><i class="el-icon-user-solid"></i>一键取关</h4>
                <p>• 批量取消关注用户</p>
                <p>• 支持白名单功能，保留特定用户</p>
                <p>• 可设置取关数量和等待时间</p>
              </div>

              <div class="feature-group">
                <h4><i class="el-icon-plus"></i>一键互关</h4>
                <p>• 批量关注推荐用户</p>
                <p>• 支持从不同来源获取关注列表</p>
                <p>• 可设置关注数量和等待时间</p>
              </div>
            </div>
          </el-collapse-item>

          <el-collapse-item name="wechat">
            <template slot="title">
              <i class="el-icon-chat-dot-round" style="margin-right: 8px; color: #4ECDC4;"></i>
              <span>微信功能说明</span>
            </template>
            <div class="intro-content">
              <div class="feature-group">
                <h4><i class="el-icon-star-on"></i>智能养号</h4>
                <p>• 自动浏览推荐视频并进行点赞、评论等操作</p>
                <p>• 可设置浏览数量和操作间隔时间</p>
                <p>• 支持自定义评论内容</p>
              </div>

              <div class="feature-group">
                <h4><i class="el-icon-chat-line-round"></i>删除评论</h4>
                <p>• 批量删除历史评论记录</p>
                <p>• 支持删除所有评论或选择性删除</p>
                <p>• 可设置删除数量和等待时间</p>
              </div>

              <div class="feature-group">
                <h4><i class="el-icon-star-off"></i>删除点赞</h4>
                <p>• 批量删除历史点赞记录</p>
                <p>• 支持删除所有点赞或选择性删除</p>
                <p>• 可设置删除数量和等待时间</p>
              </div>

              <div class="feature-group">
                <h4><i class="el-icon-position"></i>微信运动</h4>
                <p>• 删除微信运动相关配置</p>
                <p>• 支持删除所有记录或选择性删除</p>
                <p>• 可设置删除数量和等待时间</p>
              </div>

              <div class="feature-group">
                <h4><i class="el-icon-edit"></i>步数修改器</h4>
                <p>• 修改微信运动步数数据</p>
                <p>• 支持邮箱密码登录验证</p>
                <p>• 可设置自动递增和时间间隔</p>
                <p>• 支持手动提交和自动提交模式</p>
              </div>

              <div class="feature-group">
                <h4><i class="el-icon-chat-round"></i>AI聊天</h4>
                <p>• 智能回复聊天消息</p>
                <p>• 支持多种AI模型选择（豆包、kimi等）</p>
                <p>• 可设置等待时间和回复策略</p>
              </div>
            </div>
          </el-collapse-item>

          <el-collapse-item name="other">
            <template slot="title">
              <i class="el-icon-time" style="margin-right: 8px; color: #2196F3;"></i>
              <span>其他功能说明</span>
            </template>
            <div class="intro-content">
              <div class="feature-group">
                <h4><i class="el-icon-timer"></i>定时任务</h4>
                <p>• 设置定时执行各种自动化任务</p>
                <p>• 支持多种时间间隔设置</p>
                <p>• 可管理和监控任务执行状态</p>
              </div>

              <div class="feature-group">
                <h4><i class="el-icon-document"></i>使用说明</h4>
                <p>• 查看详细的功能使用教程</p>
                <p>• 了解各功能的操作步骤</p>
                <p>• 获取最新的功能更新信息</p>
              </div>
            </div>
          </el-collapse-item>

          <el-collapse-item name="notice">
            <template slot="title">
              <i class="el-icon-warning" style="margin-right: 8px; color: #FFB74D;"></i>
              <span>注意事项</span>
            </template>
            <div class="intro-content">
              <div class="feature-group">
                <h4><i class="el-icon-info"></i>使用建议</h4>
                <p>• 请合理设置操作间隔，避免频繁操作</p>
                <p>• 建议在网络稳定的环境下使用</p>
                <p>• 使用前请先开启无障碍服务和悬浮窗权限</p>
                <p>• 定期清理应用缓存以保持最佳性能</p>
              </div>

              <div class="feature-group">
                <h4><i class="el-icon-lock"></i>安全提醒</h4>
                <p>• 请勿在公共网络环境下使用</p>
                <p>• 建议定期更新应用版本</p>
                <p>• 如遇异常请及时停止操作</p>
                <p>• 请妥善保管账号密码等敏感信息</p>
              </div>

              <div class="feature-group">
                <h4><i class="el-icon-service"></i>技术支持</h4>
                <p>• 如有问题请联系技术支持</p>
                <p>• 建议反馈使用中的问题和建议</p>
                <p>• 关注更新公告获取最新功能</p>
                <p>• 遇到问题可查看使用说明页面</p>
              </div>
            </div>
          </el-collapse-item>
        </el-collapse>
      </div>

      <!-- 底部导航 -->
      <BottomNav activeTab="profile" />
    </el-card>
  </div>
</template>

<script>
import BottomNav from '@/components/BottomNav.vue'

export default {
  name: 'ProfileView',
  components: {
    BottomNav
  },
  data() {
    return {
      serviceMode: '运行模式',
      form: {
        serviceOk: false,
        floatView: false
      },
      activeNames: []
    }
  },
  created() {
    this.initData()
  },
  methods: {
    initData() {
      if (window.ec && window.ec.isAccMode) {
        var serviceMode = window.ec.isAccMode() ? "无障碍服务" : "代理服务";
        this.serviceMode = "运行模式: " + serviceMode;

        var serviceOk = false;
        if (window.ec.isAccMode()) {
          serviceOk = window.ec.isAccServiceOk();
        } else {
          serviceOk = window.ec.isAgentServiceOk();
        }
        this.form.serviceOk = serviceOk;

        var r2 = window.ec.hasFloatViewPermission();
        this.form.floatView = r2;
      }
    },
    handleServiceChange(val) {
      console.log('服务状态变更:', val);
    },
    handleFloatViewChange(val) {
      console.log('悬浮窗权限变更:', val);
    },
    openEnv() {
      if (window.ec && window.ec.startEnv) {
        var r = window.ec.startEnv();
        this.form.serviceOk = r;
        this.$notify({
          title: '消息',
          duration: 2000,
          message: '启动环境: ' + (r ? '成功' : '失败')
        });
      } else {
        this.$message.warning('环境API不可用');
      }
    },
    floatViewPermission() {
      if (window.ec && window.ec.requestFloatViewPermission) {
        var r = window.ec.requestFloatViewPermission(10);
        this.form.floatView = r;
        this.$notify({
          title: '消息',
          duration: 2000,
          message: '开启悬浮窗权限: ' + (r ? '成功' : '失败')
        });
      } else {
        this.$message.warning('悬浮窗API不可用');
      }
    },
    navigateTo(path) {
      this.$router.push(path)
    }
  }
}
</script>

<style scoped>
/* 服务管理区域样式 */
.service-section {
  padding: 10px 0;
}

.service-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px 0;
}

.service-info {
  display: flex;
  align-items: center;
  flex: 1;
}

.service-label {
  font-size: 14px;
  color: #333;
  margin-right: 15px;
  min-width: 80px;
}

/* 使用说明区域样式 */
.intro-section {
  margin-top: 10px;
}

.section-header {
  display: flex;
  align-items: center;
  margin-bottom: 15px;
  padding: 10px 0;
  border-bottom: 1px solid #f0f0f0;
}

.section-title {
  font-size: 15px;
  font-weight: 500;
  color: #333;
}

.custom-collapse {
  border: none;
}

.custom-collapse >>> .el-collapse-item__header {
  background: #fafafa;
  border: 1px solid #e8e8e8;
  border-radius: 6px;
  margin-bottom: 8px;
  padding: 0 15px;
  font-size: 14px;
  font-weight: 500;
}

.custom-collapse >>> .el-collapse-item__wrap {
  border: none;
  background: #fff;
}

.custom-collapse >>> .el-collapse-item__content {
  padding: 15px;
  background: #fff;
  border: 1px solid #e8e8e8;
  border-top: none;
  border-radius: 0 0 6px 6px;
  margin-top: -8px;
}

.intro-content {
  line-height: 1.6;
}

.feature-group {
  margin-bottom: 20px;
}

.feature-group:last-child {
  margin-bottom: 0;
}

.intro-content h4 {
  color: #409EFF;
  margin: 0 0 10px 0;
  font-size: 14px;
  font-weight: 500;
  display: flex;
  align-items: center;
  text-align: left;
}

.intro-content h4 i {
  margin-right: 6px;
  font-size: 16px;
}

.intro-content p {
  margin: 4px 0;
  font-size: 13px;
  color: #666;
  padding-left: 0;
  text-align: left;
}
</style>
