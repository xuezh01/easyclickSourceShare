<template>
  <div style="display: flex; justify-content: center; align-items: center; min-height: 100vh; background: #f6f8fa;">
    <el-card style="width: 420px; box-shadow: 0 2px 12px #0001; border-radius: 18px;">
      <div style="text-align: center;">
        <el-tag type="primary" size="medium" style="font-size: 16px;">
          定时任务配置
        </el-tag>
      </div>

      <el-form :rules="rules" ref="form" :model="form" label-width="100px" size="medium" style="margin-top: 10px;">
        <el-form-item label="任务类型" prop="taskType">
          <el-select v-model="form.taskType" placeholder="请选择任务类型" style="width: 100%;">
            <el-option label="抖音智能养号" value="douyin_nurture"></el-option>
            <el-option label="抖音删除评论" value="douyin_delete_comment"></el-option>
            <el-option label="抖音删除点赞" value="douyin_delete_like"></el-option>
            <el-option label="微信智能养号" value="wechat_nurture"></el-option>
            <el-option label="微信运动" value="wechat_sport"></el-option>
          </el-select>
        </el-form-item>

        <el-form-item label="执行时间" prop="executeTime">
          <el-time-picker
            v-model="form.executeTime"
            format="HH:mm:ss"
            placeholder="选择执行时间"
            style="width: 100%;">
          </el-time-picker>
        </el-form-item>

        <el-form-item label="重复模式" prop="repeatMode">
          <el-radio-group v-model="form.repeatMode">
            <el-radio label="once">仅执行一次</el-radio>
            <el-radio label="daily">每天重复</el-radio>
            <el-radio label="weekly">每周重复</el-radio>
          </el-radio-group>
        </el-form-item>

        <el-form-item label="任务状态">
          <el-switch
            v-model="form.enabled"
            active-color="#13ce66"
            inactive-color="#dcdfe6"
            active-text="启用"
            inactive-text="禁用">
          </el-switch>
        </el-form-item>

        <el-form-item label="任务描述" prop="description">
          <el-input
            v-model="form.description"
            type="textarea"
            :rows="2"
            placeholder="请输入任务描述"
            style="width: 100%;">
          </el-input>
        </el-form-item>

        <el-divider></el-divider>
      </el-form>

      <el-button
        type="primary"
        icon="el-icon-plus"
        style="width: 45%; margin-right: 5%;"
        @click="addTask">
        添加任务
      </el-button>

      <el-button
        type="info"
        icon="el-icon-view"
        style="width: 45%;"
        @click="viewTasks">
        查看任务
      </el-button>

      <!-- 任务列表 -->
      <div v-if="showTaskList" style="margin-top: 20px;">
        <el-divider>任务列表</el-divider>
        <el-table :data="taskList" style="width: 100%;" size="mini">
          <el-table-column prop="taskType" label="任务类型" width="120">
            <template slot-scope="scope">
              {{ getTaskTypeName(scope.row.taskType) }}
            </template>
          </el-table-column>
          <el-table-column prop="executeTime" label="执行时间" width="100">
            <template slot-scope="scope">
              {{ formatTime(scope.row.executeTime) }}
            </template>
          </el-table-column>
          <el-table-column prop="enabled" label="状态" width="60">
            <template slot-scope="scope">
              <el-tag :type="scope.row.enabled ? 'success' : 'info'" size="mini">
                {{ scope.row.enabled ? '启用' : '禁用' }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column label="操作" width="80">
            <template slot-scope="scope">
              <el-button @click="deleteTask(scope.$index)" type="text" size="mini">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>

      <!-- 底部导航 -->
      <BottomNav activeTab="tasks" />
    </el-card>
  </div>
</template>

<script>
import BottomNav from '@/components/BottomNav.vue'

export default {
  name: 'TimerView',
  components: {
    BottomNav
  },
  data() {
    return {
      form: {
        taskType: '',
        executeTime: null,
        repeatMode: 'once',
        enabled: true,
        description: ''
      },
      rules: {
        taskType: [
          { required: true, message: '请选择任务类型', trigger: 'change' }
        ],
        executeTime: [
          { required: true, message: '请选择执行时间', trigger: 'change' }
        ]
      },
      taskList: [],
      showTaskList: false
    }
  },
  created() {
    this.loadTasks()
  },
  methods: {
    loadTasks() {
      const savedTasks = localStorage.getItem('timerTasks')
      if (savedTasks) {
        this.taskList = JSON.parse(savedTasks)
      }
    },
    addTask() {
      this.$refs.form.validate((valid) => {
        if (valid) {
          const newTask = {
            id: Date.now(),
            ...this.form,
            executeTime: this.form.executeTime
          }
          this.taskList.push(newTask)
          localStorage.setItem('timerTasks', JSON.stringify(this.taskList))
          this.$message.success('任务添加成功')
          this.resetForm()
        } else {
          this.$message.error('请检查输入内容')
        }
      })
    },
    viewTasks() {
      this.showTaskList = !this.showTaskList
    },
    deleteTask(index) {
      this.$confirm('确认删除此任务?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.taskList.splice(index, 1)
        localStorage.setItem('timerTasks', JSON.stringify(this.taskList))
        this.$message.success('删除成功')
      }).catch(() => {
        this.$message.info('已取消删除')
      })
    },
    resetForm() {
      this.form = {
        taskType: '',
        executeTime: null,
        repeatMode: 'once',
        enabled: true,
        description: ''
      }
    },
    getTaskTypeName(type) {
      const typeMap = {
        'douyin_nurture': '抖音智能养号',
        'douyin_delete_comment': '抖音删除评论',
        'douyin_delete_like': '抖音删除点赞',
        'wechat_nurture': '微信智能养号',
        'wechat_sport': '微信运动'
      }
      return typeMap[type] || type
    },
    formatTime(time) {
      if (!time) return ''
      const date = new Date(time)
      return `${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}`
    },
    navigateTo(path) {
      this.$router.push(path)
    }
  }
}
</script>

<style scoped>

</style>
