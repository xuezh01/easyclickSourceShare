<!--/**-->
<!--* @author 程序员小风 QQ:1843978049 抖音：chengxuyuanx82-->
<!--* @date 20250728-->
<!--*/-->
<template>
  <div id="app" style="min-height: 100vh; padding-bottom: 60px; display: flex; justify-content: center;">
    <div class="main-container" style="width: 420px; min-width: 320px;">
      <!-- 抖音功能区 -->
      <div class="nav-group-title">
        <span>抖音</span>
        <el-divider></el-divider>
      </div>
      <el-card class="nav-card">
        <div class="nav-grid">
          <div class="nav-item" @click="navigateTo('/douyin/nurture-account')">
            <i class="iconfont icon-zidongyanghao nav-icon" style="color:#ff9800;"></i>
            <span class="nav-label">智能养号</span>
          </div>
          <div class="nav-item" @click="navigateTo('/douyin/delete-comment')">
            <i class="iconfont icon-douyin-pinglun nav-icon" style="color:#e91e63;"></i>
            <span class="nav-label">删除评论</span>
          </div>
          <div class="nav-item" @click="navigateTo('/douyin/delete-like')">
            <i class="iconfont icon-aixin nav-icon" style="color:red"></i>
            <span class="nav-label">删除点赞</span>
          </div>
          <div class="nav-item" @click="navigateTo('/douyin/delete-follow')">
            <i class="iconfont icon-quxiaoguanzhu-02 nav-icon" style="color:#9c27b0;"></i>
            <span class="nav-label">一键取关</span>
          </div>
          <div class="nav-item" @click="navigateTo('/douyin/follow')">
            <i class="iconfont icon-tianjiaguanzhu nav-icon" style="color:#9c27b0;"></i>
            <span class="nav-label">一键互关</span>
          </div>
          <div class="nav-item" @click="navigateTo('/douyin/delete-collection')">
            <i class="el-icon-star-off nav-icon" style="color:#9c27b0;"></i>
            <span class="nav-label">删除收藏</span>
          </div>
          <div class="nav-item" @click="navigateTo('/timer')">
            <i class="el-icon-time nav-icon" style="color:#2196f3;"></i>
            <span class="nav-label">定时任务</span>
          </div>
          <div class="nav-item" @click="navigateTo('/profile')">
            <i class="el-icon-info nav-icon" style="color:#4caf50;"></i>
            <span class="nav-label">使用说明</span>
          </div>
        </div>
      </el-card>

      <!-- 微信功能区 -->
      <div class="nav-group-title">
        <span>微信</span>
        <el-divider></el-divider>
      </div>
      <el-card class="nav-card">
        <div class="nav-grid">
          <div class="nav-item" @click="navigateTo('/wechat/nurture-account')">
            <i class="iconfont icon-zidongyanghao nav-icon" style="color:#2196f3;"></i>
            <span class="nav-label">智能养号</span>
          </div>
          <div class="nav-item" @click="navigateTo('/wechat/delete-comment')">
            <i class="iconfont icon-douyin-pinglun nav-icon" style="color:#e91e63;"></i>
            <span class="nav-label">删除评论</span>
          </div>
          <div class="nav-item" @click="navigateTo('/douyin/delete-like')">
            <i class="iconfont icon-aixin nav-icon" style="color:red"></i>
            <span class="nav-label">删除点赞</span>
          </div>
          <div class="nav-item" @click="navigateTo('/wechat/wxkeep')">
            <i class="iconfont icon-paobu nav-icon" style="color:#2196f3;"></i>
            <span class="nav-label">微信运动</span>
          </div>
          <div class="nav-item" @click="navigateTo('/wechat/wxkeep2')">
            <i class="iconfont icon-paobu nav-icon" style="color:rgb(242,197,92);"></i>
            <span class="nav-label">步数修改器</span>
          </div>
          <div class="nav-item" @click="navigateTo('/wechat/chat')">
            <i class="iconfont icon-AIhebaoshi nav-icon" style="color:#2196f3;"></i>
            <span class="nav-label">Ai聊天</span>
          </div>
          <div class="nav-item" @click="navigateTo('/timer')">
            <i class="el-icon-time nav-icon" style="color:#2196f3;"></i>
            <span class="nav-label">定时任务</span>
          </div>
          <div class="nav-item" @click="navigateTo('/profile')">
            <i class="el-icon-info nav-icon" style="color:#4caf50;"></i>
            <span class="nav-label">使用说明</span>
          </div>
        </div>
      </el-card>
    </div>

    <!-- 底部导航 -->
    <BottomNav activeTab="home" />
  </div>
</template>

<script>
import BottomNav from '@/components/BottomNav.vue'

export default {
  name: 'MainView',
  components: {
    BottomNav
  },
  created() {
    // 隐藏启动按钮的功能需要根据实际环境调整
    if (window.ec && window.ec.hideStartBtn) {
      window.ec.hideStartBtn()
    }
  },
  methods: {
    navigateTo(path) {
      this.$router.push(path)
    }
  }
}
</script>

<style scoped>
body {
  background: #f6f8fa;
}

.nav-card {
  border-radius: 18px;
  margin-bottom: 18px;
}

.nav-group-title {
  font-weight: bold;
  font-size: 16px;
  margin: 12px 0 8px 0;
  display: flex;
  align-items: center;
}

.nav-group-title .el-divider {
  flex: 1;
  margin-left: 8px;
}

.nav-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 18px 0;
}

.nav-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  cursor: pointer;
  padding: 8px 0;
  border-radius: 10px;
  transition: background 0.2s;
}

.nav-item:hover {
  background: #f0f7ff;
}

.nav-icon {
  font-size: 32px;
  margin-bottom: 6px;
}

.nav-label {
  font-size: 13px;
  color: #333;
}



@media (max-width: 600px) {
  .main-container {
    width: 100vw !important;
    min-width: 0 !important;
  }
}
</style>
