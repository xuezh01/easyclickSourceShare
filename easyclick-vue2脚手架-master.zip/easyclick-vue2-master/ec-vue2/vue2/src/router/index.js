import Vue from 'vue'
import VueRouter from 'vue-router'
import MainView from '../views/MainView.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'main',
    component: MainView
  },
  {
    path: '/douyin/nurture-account',
    name: 'douyinNurtureAccount',
    component: () => import('../views/douyin/NurtureAccount.vue')
  },
  {
    path: '/douyin/delete-comment',
    name: 'douyinDeleteComment',
    component: () => import('../views/douyin/DeleteComment.vue')
  },
  {
    path: '/douyin/delete-like',
    name: 'douyinDeleteLike',
    component: () => import('../views/douyin/DeleteLike.vue')
  },
  {
    path: '/douyin/delete-follow',
    name: 'douyinDeleteFollow',
    component: () => import('../views/douyin/DeleteFollow.vue')
  },
  {
    path: '/douyin/follow',
    name: 'douyinFollow',
    component: () => import('../views/douyin/Follow.vue')
  },
  {
    path: '/douyin/delete-collection',
    name: 'douyinDeleteCollection',
    component: () => import('../views/douyin/DeleteCollection.vue')
  },
  {
    path: '/wechat/nurture-account',
    name: 'wechatNurtureAccount',
    component: () => import('../views/wechat/NurtureAccount.vue')
  },
  {
    path: '/wechat/delete-comment',
    name: 'wechatDeleteComment',
    component: () => import('../views/wechat/DeleteComment.vue')
  },

  {
    path: '/wechat/wxkeep',
    name: 'wechatWxkeep',
    component: () => import('../views/wechat/Wxkeep.vue')
  },
  {
    path: '/wechat/wxkeep2',
    name: 'wechatWxkeep2',
    component: () => import('../views/wechat/Wxkeep2.vue')
  },
  {
    path: '/wechat/chat',
    name: 'wechatChat',
    component: () => import('../views/wechat/Chat.vue')
  },
  {
    path: '/timer',
    name: 'timer',
    component: () => import('../views/Timer.vue')
  },

  {
    path: '/tasks',
    name: 'tasks',
    component: () => import('../views/Tasks.vue')
  },
  {
    path: '/profile',
    name: 'profile',
    component: () => import('../views/Profile.vue')
  }
]

const router = new VueRouter({
  routes
})

export default router
