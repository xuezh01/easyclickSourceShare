function 抖音发评论() {
    setFloatDisplayLineNumber(false);
    let config = readConfigString("config")
    logd("开始启动配置" + config)
    config = JSON.parse(config)
    utils.openApp("com.ss.android.ugc.aweme");
    sleep(5000);
    if (findNode(id("com.android.systemui:id/status_bar_container"))) {
        logi("顶部状态栏获取到");
    }
    let y2 = g_ret.bounds.bottom + 200;
    let x = device.getScreenWidth() / 2 + random(-80, 80);
    for (let i = 0; i < config.videoCount; i++) {
        logd("执行第" + (i + 1) + "次");

        swipeToPoint(x, device.getScreenHeight() - 200, x, y2, 50);
        // swipeToPoint(350, 1200, 350, 200, 50);
        sleep(config.waitTime || 1000);

        // 点赞功能
        if (config.enableLike) {
            if (findNode(descMatch("未点赞.*"), true)) {
                logd("点赞成功");
            } else {
                logd("跳过直播 ");
            }


        }

        if (config.enableComment && findNode(descMatch("评论.*"))) {
            findClickEx(g_ret)
            // sleep(config.waitTime);
            // id("com.ss.android.ugc.aweme:id/iv_image").getOneNodeInfo(1000).previousSiblings()[0].clickEx()
            // sleep(config.waitTime);
            let img = desc("插入图片").getOneNodeInfo(3000)
            let input = img.previousSiblings()[0]
            if(input){
                input.clickEx()
                sleep(1000);
                logd("点击输入框");
            }

            if (findNode(xpath("//node[@clz='com.bytedance.highperformanceview.layout.MeasureOnceRelativeLayout2']/node[@clz='com.bytedance.highperformanceview.layout.MeasureOnceRelativeLayout2']/node[@clz='android.view.ViewGroup']/node[@clz='android.view.ViewGroup']/node[@clz='android.view.ViewGroup']/node[@clz='android.widget.EditText' and @index=0 ]"))) {
                logd("输入文字");
                g_ret.inputText(config.commentText)
            }
            // sleep(config.waitTime);
            if (findNode(text("发送"), true)) {
                logd("发送");
            }
            // sleep(config.waitTime);
            if (findNode(id("com.ss.android.ugc.aweme:id/back_btn"), true)) {
                logd("退出X");
            }
        }
        if (config.enableCollection) {
            findNode(descMatch("未选中，收藏.*"), true) && logd("点击收藏");
        }
        sleep(random(500, 800));
    }
    logd("发评论脚本执行完成，共执行 " + config.videoCount + " 次");
}

module.exports = 抖音发评论
