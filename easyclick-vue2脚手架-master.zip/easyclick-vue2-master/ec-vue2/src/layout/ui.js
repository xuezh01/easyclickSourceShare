function main() {


    let url = "http://192.168.1.6:8080";
    let url2 = "dist/index.html"

    // 显示布局
    ui.layout("Web视图", "main.xml");

    let isDevelopment = true; // 开发环境为true，生产环境为false

    // 获取WebView组件并加载URL
    let webView = ui.findViewByTag("web");
    if (isDevelopment) {
        webView.loadUrl(url);
        logd("WebView已加载URL: " + url);
    } else {
        webView.loadUrl(url2)
        logd("WebView已加载URL: " + url2);
    }
}



main();
