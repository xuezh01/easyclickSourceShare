/**
 * @author 程序员小风 QQ:1843978049 抖音：chengxuyuanx82
 * @date 20250728
 */
function main() {

    setFloatDisplayLineNumber(false);


    let currentPage = readConfigString("currentPage") || "comment";
    logd("当前页面模式: " + currentPage);

    if (currentPage === "delete") {
        // 运行删除评论脚本
        logd("启动删除评论脚本");
        let Script = require("slib/抖音/抖音评论删除.js");
        Script()
    } else if (currentPage === "comment") {
        // 默认运行发评论脚本
        logd("启动发评论脚本");
        let Script = require("slib/抖音/智能养号.js");
        Script()
    } else if (currentPage === "like") {
        logd("启动取消点赞脚本");
        let Script = require("slib/抖音/抖音删点赞.js");
        Script()
    } else if (currentPage === "clone") {
        logd("启动一键取关脚本");
        let Script = require("slib/抖音/一键取关.js");
        Script()
    } else if (currentPage === "follow") {
        logd("启动一键互关脚本");
        let Script = require("slib/抖音/一键互关.js");
        Script()
    } else if (currentPage === "collection") {
        logd("启动一键取收藏脚本");
        let Script = require("slib/抖音/一键删收藏.js");
        Script()
    } else if (currentPage === "wxkeep") {
        logd("微信运动脚本");
        let Script = require("slib/微信/微信运动.js");
        Script()
    } else if (currentPage === "wxmain") {
        logd("微信刷视频");
        let Script = require("slib/微信/刷视频.js");
        Script()
    } else if (currentPage === "comments") {
        let Script = require("slib/微信/删评论.js");
        Script()
    } else if (currentPage === "chat") {
        let Script = require("slib/微信/微信聊天.js");
        Script()
    }



}

main();
