# EC-Vue2 懒人工具箱

基于 Vue2 + Element UI 的移动端自动化工具集合，专为 EasyClick 环境设计。

## 📱 项目简介

移动端自动化工具应用，支持抖音和微信平台的各种自动化操作。

## ✨ 主要功能
![img.png](assert/img.png)
### 🎵 抖音工具
- 智能养号、删除评论/点赞/收藏、一键取关/互关

![img_1.png](assert/img_1.png)![img_2.png](assert/img_2.png)![img_3.png](assert/img_3.png)![img_4.png](assert/img_4.png)![img_5.png](assert/img_5.png)![img_6.png](assert/img_6.png)
### 💬 微信工具
- 智能养号、删除评论、微信运动、步数修改器、AI聊天

![img_7.png](assert/img_7.png)![img_8.png](assert/img_8.png)![img_9.png](assert/img_9.png)![img_10.png](assert/img_10.png)![img_11.png](assert/img_11.png)!![img.png](assert/img13.png)[img.png](assert/img13.png)![img_12.png](assert/img_12.png)


## 🛠️ 技术栈

- Vue 2.6.14 + Element UI 2.15.14
- Vue Router 3.5.1 + Vue CLI 5.0
- ESLint + 自定义iconfont

## 📦 项目结构

```
src/
├── views/
│   ├── douyin/          # 抖音功能模块
│   ├── wechat/          # 微信功能模块
│   ├── MainView.vue     # 主页面
│   ├── Profile.vue      # 个人中心
│   └── Timer.vue        # 定时任务
├── components/
│   └── BottomNav.vue    # 底部导航
├── router/
└── assets/
```

## 🚀 快速开始

```bash
# 克隆项目
git clone https://github.com:YXKxk/easyclick-vue2.git
cd ec-vue

# 安装依赖
node >= 18.16.1
npm install

# 开发环境
npm run serve

# 生产构建
npm run build
```

### EasyClick部署

1. 构建项目：`npm run build` 自动输出到 src/layout/dist/` 目录
2. let isDevelopment = false; // 开发环境为true，生产环境为false
3. 启用无障碍服务和悬浮窗权限


##  许可证

MIT License - 查看 [LICENSE](LICENSE) 文件了解详情

## 📞 联系方式

- 抖音搜:程序员小风


## ⚠️ 免责声明

本项目仅供学习研究使用，请遵守相关平台使用条款和法律法规。

---

**⭐ 如果这个项目对您有帮助，请给我们一个Star！⭐**
