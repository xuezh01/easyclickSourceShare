/*let qqa = "6F:4E:3B:51:1F:65\n" +
    "08:DF:86:6E:0B:93\n" +
    "60:82:D6:0F:27:D5\n" +
    "4D:F4:3E:BB:05:39\n" +
    "FD:1C:B4:10:B6:FF\n" +
    "2A:8F:AC:A6:38:3F\n" +
    "F2:01:E8:C9:13:9D\n" +
    "77:5C:BF:15:7B:6B\n" +
    "9D:85:8D:00:DC:34\n" +
    "A0:BE:10:04:39:2D\n" +
    "B2:E4:A7:FB:58:A6\n" +
    "31:82:45:B1:AB:E1\n" +
    "9F:5C:6A:22:19:01\n" +
    "36:0A:6E:87:D5:2F\n" +
    "06:AC:4B:EC:3E:31\n" +
    "97:0C:B4:D2:C5:3B\n" +
    "09:25:69:38:EB:3F\n" +
    "3F:51:30:80:5D:7E\n" +
    "8D:FB:33:26:97:D2\n" +
    "66:F1:05:E2:61:0B\n" +
    "45:F4:43:DB:E7:90\n" +
    "55:EE:53:83:71:25\n" +
    "A8:96:D1:64:18:62\n" +
    "CD:4A:40:20:1A:7A\n" +
    "64:53:3B:F5:D0:3F\n" +
    "2C:F8:97:4C:2C:1D\n" +
    "F1:66:51:46:7D:ED\n" +
    "17:09:7B:0D:23:43\n" +
    "D7:E6:54:4C:89:4A\n" +
    "F8:7A:71:EF:0A:C6\n" +
    "69:D2:6B:40:57:30\n" +
    "C6:D4:1C:69:4C:D1\n" +
    "6D:83:9D:5B:5B:12\n" +
    "C7:F7:DA:D6:93:1D\n" +
    "E6:83:CB:DB:A4:80\n" +
    "54:08:9B:C0:35:09\n" +
    "AD:52:F3:A2:FD:03\n" +
    "B7:D5:51:9A:13:F3\n" +
    "A7:1C:CD:8F:02:18\n" +
    "FF:51:D1:BC:C0:A7\n" +
    "EB:BE:EA:41:28:5C\n" +
    "4F:46:91:C7:A0:60\n" +
    "E7:A6:7B:84:32:42\n" +
    "5E:F2:F6:8F:66:A7\n" +
    "8E:D4:68:DB:19:79\n" +
    "66:86:DE:8C:E6:18\n" +
    "4A:8A:D8:41:02:C9\n" +
    "2E:4B:3B:23:42:21\n" +
    "5F:7B:EE:0F:20:43\n" +
    "BE:42:6A:7F:56:99\n" +
    "19:3B:D4:56:69:15\n" +
    "98:0D:92:75:DD:80\n" +
    "A3:2E:06:DE:48:FF\n" +
    "07:61:8C:73:B7:FB\n" +
    "51:5C:E2:B8:D4:E9\n" +
    "50:70:72:4D:20:7B\n" +
    "4C:F9:54:E3:EE:CA\n" +
    "87:E3:99:A3:6D:6F\n" +
    "13:90:40:65:A6:E2\n" +
    "E5:A3:36:EC:48:F2\n" +
    "CE:98:4F:DD:89:1B\n" +
    "11:CD:97:36:46:6F\n" +
    "B0:86:83:29:19:F2\n" +
    "77:0D:EC:80:70:B8\n" +
    "EC:77:A2:71:13:7A\n" +
    "FF:77:62:27:59:37\n" +
    "A5:93:06:42:9E:46\n" +
    "60:45:44:02:9A:45\n" +
    "B4:C8:A7:0B:E0:2F\n" +
    "E2:B6:00:2D:E0:B7\n" +
    "B2:C0:06:DA:E7:97\n" +
    "8A:18:EC:95:CA:B2\n" +
    "4F:43:0D:2B:97:5C\n" +
    "30:CD:22:4E:D0:61\n" +
    "8C:E1:AF:01:AF:02\n" +
    "54:CD:9D:82:AD:A3\n" +
    "CC:23:E7:70:ED:D6\n" +
    "79:00:B4:C2:61:2C\n" +
    "D1:4A:02:6E:26:D6\n" +
    "97:91:62:3A:8A:B7\n" +
    "AD:B9:99:B4:D1:4D\n" +
    "78:B3:B2:C4:1D:60\n" +
    "C3:B8:69:22:FC:EF\n" +
    "C7:9C:74:81:1A:27\n" +
    "EF:78:5A:AA:67:AB\n" +
    "14:8F:33:50:A8:74\n" +
    "6C:29:B4:E1:F9:DE\n" +
    "86:20:DD:ED:49:E8\n" +
    "1A:A9:02:D8:D2:00\n" +
    "94:3E:46:E6:1E:2F\n" +
    "0A:D9:42:EF:57:5E\n" +
    "A7:D1:06:50:BA:D0\n" +
    "02:31:68:BD:46:DE\n" +
    "4E:44:C5:2E:19:07\n" +
    "C5:91:F9:D8:84:D0\n" +
    "E8:2A:A7:F9:B7:EA\n" +
    "C8:E7:CF:BD:8A:A1\n" +
    "A4:FF:63:CF:C2:99\n" +
    "E5:5A:AA:9E:28:FF\n" +
    "98:0D:13:EC:98:F8\n" +
    "37:40:05:80:85:0D\n" +
    "3C:40:1E:95:AF:32\n" +
    "55:C8:05:D2:6B:FB\n" +
    "6D:40:6F:32:E3:18\n" +
    "56:41:A6:17:49:6F\n" +
    "A4:67:3E:2F:1B:70\n" +
    "25:ED:10:60:F5:06\n" +
    "95:4A:47:1E:74:BB\n" +
    "66:BE:A6:2F:BF:21\n" +
    "FB:26:88:A5:78:4E\n" +
    "E2:CC:7D:C9:39:9E\n" +
    "33:F5:96:D6:FF:14\n" +
    "EE:68:D6:46:CB:23\n" +
    "35:BF:14:57:14:53\n" +
    "7B:0C:69:FD:1F:3F\n" +
    "03:F5:A7:5C:FF:67\n" +
    "90:57:84:D2:74:8C\n" +
    "87:BA:A9:F2:BA:01\n" +
    "A5:F3:82:97:46:BC\n" +
    "90:C3:AD:44:EF:CF\n" +
    "37:09:90:CE:FD:6A\n" +
    "81:6F:71:7E:9D:FB\n" +
    "7F:A5:50:E5:DD:D3\n" +
    "79:25:5B:F0:5D:03\n" +
    "A0:1E:7A:03:FB:E2\n" +
    "9B:AD:FA:DB:66:FA\n" +
    "75:AE:43:0B:81:B8\n" +
    "1D:CC:21:83:43:73\n" +
    "57:19:E8:C4:DD:EE\n" +
    "03:C4:32:A6:EB:0D\n" +
    "7A:E3:BD:86:43:6C\n" +
    "7D:4C:2D:59:86:DE\n" +
    "83:F9:4D:2E:FB:8F\n" +
    "98:CF:F6:BB:D7:CD\n" +
    "4E:B8:64:B5:7B:94\n" +
    "A2:05:EE:D0:CA:34\n" +
    "A9:60:D7:89:D6:86\n" +
    "08:48:90:33:75:67\n" +
    "60:69:4E:0F:51:EB\n" +
    "9F:E4:BA:D3:1E:5C\n" +
    "3D:32:E7:CE:50:16\n" +
    "96:46:3F:5D:F9:AB\n" +
    "CE:44:41:ED:0F:B2\n" +
    "1F:D8:D4:9D:97:00\n" +
    "4C:04:15:D4:7E:AA\n" +
    "C1:03:00:B3:A1:7E\n" +
    "3D:7C:E2:19:B7:91\n" +
    "63:8D:4C:2A:D5:55\n" +
    "0C:50:88:83:95:96\n" +
    "9B:80:93:9D:E3:0F\n" +
    "D0:98:38:AB:03:EC\n" +
    "D9:A0:D2:C8:11:59\n" +
    "24:7D:3F:AF:84:F0\n" +
    "C1:77:25:F5:00:F3\n" +
    "08:81:8E:46:4C:61\n" +
    "1E:67:CB:20:7C:D5\n" +
    "A2:B9:4B:14:BE:08\n" +
    "84:55:6A:43:D6:B9\n" +
    "E1:D9:5E:02:3B:10\n" +
    "A2:0C:9D:EC:F5:19\n" +
    "52:8F:D6:19:89:A6\n" +
    "9C:38:9C:E8:25:B3\n" +
    "1E:4E:50:4D:44:90\n" +
    "E3:36:7B:C6:EE:FD\n" +
    "1F:F5:AA:42:32:1C\n" +
    "47:F7:58:02:85:7F\n" +
    "89:06:07:47:0B:A2\n" +
    "00:52:16:F2:8E:C9\n" +
    "09:37:47:B5:33:CC\n" +
    "94:9B:8D:72:37:46\n" +
    "7E:10:EE:54:85:DF\n" +
    "4B:A7:34:3E:82:F0\n" +
    "AE:B6:D8:51:7A:4E\n" +
    "88:0A:3C:40:F8:B1\n" +
    "81:3D:4C:6F:5D:A0\n" +
    "C9:89:CA:BA:7A:E9\n" +
    "83:5F:B8:65:4B:15\n" +
    "82:A3:78:BA:69:E6\n" +
    "00:DF:C0:F4:E3:E5\n" +
    "33:12:38:B7:B5:AD\n" +
    "3C:74:8B:29:66:58\n" +
    "4C:81:28:C0:7C:89\n" +
    "8C:74:ED:E6:11:E9\n" +
    "B4:51:5A:84:3D:F7\n" +
    "0D:40:75:7C:FB:7E\n" +
    "09:91:0C:9F:0E:6E\n" +
    "EB:8D:99:68:93:58\n" +
    "AA:30:61:73:D6:35\n" +
    "13:EB:F2:C0:79:17\n" +
    "A5:08:F1:87:46:97\n" +
    "AB:81:9C:4B:B9:89\n" +
    "33:AE:17:CF:2F:26\n" +
    "92:E0:FB:B1:06:1F\n" +
    "67:FA:F2:BF:88:FD\n" +
    "BE:C9:48:3E:D2:3A\n" +
    "6F:6C:4D:87:55:B8\n" +
    "C9:88:4B:1E:62:AC\n" +
    "03:F9:87:06:12:C8\n" +
    "4C:2F:CB:B4:6E:10\n" +
    "B4:CA:61:BE:CF:84\n" +
    "FC:73:71:99:52:C7\n" +
    "A0:33:B5:85:EB:9B\n" +
    "20:C3:FF:21:0D:EA\n" +
    "FD:0A:BB:A2:77:84\n" +
    "76:FE:BA:93:E5:AE\n" +
    "36:D0:F2:EB:25:38\n" +
    "91:00:1A:4B:43:8B\n" +
    "6F:CB:EB:AC:9B:EA\n" +
    "78:D1:8F:8B:32:66\n" +
    "18:4B:95:B5:39:68\n" +
    "F5:08:BC:43:4C:B0\n" +
    "41:FB:14:62:0F:C3\n" +
    "5F:91:79:F1:AB:3C\n" +
    "74:0D:93:9D:D4:60\n" +
    "5F:EF:4C:36:9A:18\n" +
    "41:37:56:EF:E5:67\n" +
    "FE:50:FE:E5:D5:09\n" +
    "26:10:16:E3:F5:48\n" +
    "1F:37:69:F1:D6:AF\n" +
    "E6:24:2C:B3:37:A1\n" +
    "4F:D8:3B:5E:43:45\n" +
    "3E:2B:2C:A3:01:B8\n" +
    "01:86:8A:EE:56:8F\n" +
    "79:81:09:86:DC:FF\n" +
    "F7:3F:61:2D:BB:7F\n" +
    "64:81:DD:64:FB:15\n" +
    "91:D7:66:42:0A:2D\n" +
    "18:70:9A:FA:8D:6A\n" +
    "2B:A7:00:31:7C:58\n" +
    "79:78:D6:25:38:C6\n" +
    "C3:46:FC:AA:91:F7\n" +
    "18:0D:C5:4D:E8:DE\n" +
    "DA:8D:7C:12:16:7B\n" +
    "AF:DF:78:8D:5A:60\n" +
    "25:F9:46:D9:E3:57\n" +
    "67:D5:1D:B4:54:2A\n" +
    "C8:69:45:BD:B3:14\n" +
    "6A:BB:D4:F8:4B:9A\n" +
    "59:70:20:86:85:BC\n" +
    "71:F9:BA:86:5C:86\n" +
    "2A:C0:BC:2A:42:F7\n" +
    "4C:E4:F3:04:B4:0D\n" +
    "B5:01:66:98:EB:BC\n" +
    "60:9A:06:D0:74:49\n" +
    "CA:46:2A:7A:09:E9\n" +
    "D4:06:52:42:B7:86\n" +
    "A8:D8:28:38:BB:FA\n" +
    "B6:FA:40:4E:A4:52\n" +
    "51:74:5F:75:18:AD\n" +
    "A7:9D:EC:47:3D:86\n" +
    "20:ED:69:7F:C2:B2\n" +
    "1A:AF:42:FF:76:5F\n" +
    "43:92:1A:3F:FE:E0\n" +
    "9C:04:73:7C:C5:AA\n" +
    "EC:CF:C9:74:28:B2\n" +
    "24:86:94:3F:A5:FC\n" +
    "04:60:B3:37:A5:B9\n" +
    "96:FA:04:5C:BF:F2\n" +
    "36:D8:84:75:C3:9D\n" +
    "3E:BC:5B:B9:DC:A9\n" +
    "CA:DD:9A:EC:E7:D1\n" +
    "7D:1F:0B:67:0B:D8\n" +
    "FD:06:03:68:35:09\n" +
    "C3:52:85:A7:20:8A\n" +
    "18:53:4B:3F:C9:10\n" +
    "53:2C:CF:F4:45:13\n" +
    "07:7F:21:EB:A9:5B\n" +
    "99:4F:0D:EA:6F:D9\n" +
    "57:05:90:16:3E:37\n" +
    "15:1A:B3:A1:94:50\n" +
    "D2:17:BD:5D:98:34\n" +
    "B5:71:ED:71:83:AF\n" +
    "9F:A3:5F:22:21:1B\n" +
    "56:1C:5D:E7:D0:E9\n" +
    "BB:C2:81:02:7B:97\n" +
    "EB:A0:8B:DD:9A:8A\n" +
    "76:2A:0C:B6:65:BE\n" +
    "3B:DF:A7:A8:C2:AB\n" +
    "80:99:D1:C1:97:30\n" +
    "39:E3:04:0B:3C:DD\n" +
    "EA:F2:1B:EB:AB:4E\n" +
    "E5:5F:BB:3A:03:92\n" +
    "19:B7:99:D3:CD:CA\n" +
    "0D:FC:55:E1:09:11\n" +
    "06:1A:6B:43:17:9C\n" +
    "3D:E4:5D:B7:AF:E6\n" +
    "CB:88:88:4F:3B:3C\n" +
    "D0:69:F4:89:C2:81\n" +
    "32:B0:19:7B:E9:05\n" +
    "9B:E9:0A:92:CC:4F\n" +
    "8C:1E:DC:84:78:1F\n" +
    "E0:A4:A4:39:78:EE\n" +
    "D5:56:17:25:2A:EB\n" +
    "A0:4C:3E:F3:4F:6F\n" +
    "6B:C2:97:3E:79:32\n" +
    "01:2B:9D:0C:78:30\n" +
    "76:9F:89:9A:FE:F6\n" +
    "2A:90:2E:9E:0F:FE\n" +
    "39:95:C4:0E:52:BD\n" +
    "6F:82:BE:65:D2:79\n" +
    "83:36:70:60:DA:4F\n" +
    "09:DA:9D:CA:FE:6D\n" +
    "E5:0D:50:8C:C6:DA\n" +
    "A0:31:C2:8C:D1:78\n" +
    "52:96:28:A5:B0:DA\n" +
    "5C:30:CF:B2:0B:A3\n" +
    "11:10:59:C7:91:4A\n" +
    "54:F1:53:97:5C:65\n" +
    "78:3C:88:27:6E:44\n" +
    "5D:DC:FF:81:77:AE\n" +
    "08:16:C4:53:98:E6\n" +
    "C5:2A:A3:29:D0:48\n" +
    "6C:E0:50:32:DA:7A\n" +
    "85:39:BB:A2:78:D1\n" +
    "2F:51:71:63:90:DF\n" +
    "FF:D9:63:60:96:BB\n" +
    "61:0E:B4:48:01:D7\n" +
    "15:5E:79:16:5A:95\n" +
    "82:D2:F5:D7:50:E5\n" +
    "5F:A6:D5:E1:CE:7B\n" +
    "59:32:0B:93:A3:71\n" +
    "90:A2:95:6A:8D:C7\n" +
    "E2:6B:C5:59:D4:27\n" +
    "73:9B:D8:A8:1A:AD\n" +
    "45:A3:F3:A0:52:C0\n" +
    "3E:DD:82:6A:5E:9C\n" +
    "91:20:C2:10:0A:0C\n" +
    "1F:10:2C:DD:7B:8F\n" +
    "03:3C:9C:FD:44:85\n" +
    "5B:4F:89:84:85:CA\n" +
    "B4:FB:1C:78:11:AB\n" +
    "96:8E:16:0A:53:D9\n" +
    "CD:BB:2A:7B:B5:85\n" +
    "DC:6C:0F:BC:F9:8F\n" +
    "D8:9D:6E:3A:29:D3\n" +
    "88:AC:98:2F:94:87\n" +
    "A4:D8:E0:0F:BD:81\n" +
    "37:B4:EC:96:9A:23\n" +
    "10:B6:22:1E:A8:F8\n" +
    "FA:D1:A3:0F:3D:F0\n" +
    "69:25:B8:C3:6A:B7\n" +
    "A7:28:E0:17:B2:D6\n" +
    "F0:52:8B:40:0A:C4\n" +
    "4C:8F:4F:09:D7:B7\n" +
    "84:92:CF:08:53:2B\n" +
    "11:45:CB:6A:53:CF\n" +
    "7E:69:3C:B3:A2:B2\n" +
    "70:E2:9E:3C:FD:22\n" +
    "66:A2:63:1E:5B:71\n" +
    "4A:8C:EE:66:E4:8B\n" +
    "73:3E:88:07:38:23\n" +
    "BD:E5:63:85:07:3B\n" +
    "7E:70:F8:A4:E4:F9\n" +
    "5D:3D:33:18:AF:A3\n" +
    "E1:68:1F:12:A9:09\n" +
    "A7:4E:BB:28:D3:73\n" +
    "3D:93:99:AD:24:FE\n" +
    "F8:14:BA:6D:BA:D6\n" +
    "16:5D:A8:83:33:56\n" +
    "CF:D4:0A:94:3A:95\n" +
    "B6:4A:52:A3:09:E0\n" +
    "F6:75:CE:E5:E3:A0\n" +
    "C4:E4:8C:60:95:49\n" +
    "4F:17:2A:D1:0B:BB\n" +
    "A5:7E:99:2B:BB:FF\n" +
    "B1:EA:AF:B8:3D:5B\n" +
    "51:6A:8C:97:96:27\n" +
    "72:A2:15:E6:98:23\n" +
    "89:80:65:6C:98:5D\n" +
    "E6:F1:C6:9B:8E:87\n" +
    "8E:F4:AD:E8:C8:B2\n" +
    "4C:BF:7B:69:37:CA\n" +
    "A5:3B:A0:A2:99:21\n" +
    "E5:40:31:7A:EF:F4\n" +
    "A3:50:F8:F4:A0:83\n" +
    "BA:74:6B:20:F2:1F\n" +
    "F5:B5:23:F9:44:CE\n" +
    "CB:3F:D7:6F:62:51\n" +
    "22:8E:3B:23:DB:9A\n" +
    "37:81:B2:CD:68:54\n" +
    "2B:49:47:6A:D0:7F\n" +
    "52:67:3A:6D:1A:A8\n" +
    "B7:31:A5:C8:D5:41\n" +
    "0B:9E:7C:76:26:DA\n" +
    "AF:39:FD:64:CD:16\n" +
    "FB:83:03:6A:DA:EE\n" +
    "47:14:44:65:B2:1E\n" +
    "8D:C5:40:44:EE:D1\n" +
    "4D:6D:C2:BF:D6:8D\n" +
    "F7:60:B2:5D:62:65\n" +
    "D6:C5:9D:9A:85:C3\n" +
    "04:44:63:F4:4A:35\n" +
    "EA:08:47:B3:AA:9A\n" +
    "A5:EF:16:64:82:E2\n" +
    "1A:5C:32:A7:0E:BD\n" +
    "7F:E9:4A:43:30:CA\n" +
    "9B:11:3C:51:CB:00\n" +
    "E6:FA:45:06:B5:BA\n" +
    "13:55:FA:86:3B:C0\n" +
    "4E:70:44:07:82:43\n" +
    "97:10:20:75:A4:28\n" +
    "0B:33:54:A3:4C:E6\n" +
    "3C:7B:D9:C0:5F:B9\n" +
    "FC:EF:01:B0:AD:E8\n" +
    "20:BE:70:CA:C0:59\n" +
    "CF:2B:88:5E:00:EF\n" +
    "06:C6:0C:B0:53:14\n" +
    "B9:B8:A5:F4:76:3C\n" +
    "72:7F:3E:CE:04:EB\n" +
    "BC:CA:88:67:31:02\n" +
    "79:83:28:B6:6B:6E\n" +
    "1C:7B:2B:CB:96:76\n" +
    "98:7A:26:2D:8C:D3\n" +
    "7D:51:BB:19:86:4E\n" +
    "C9:9A:5E:CA:BE:E1\n" +
    "F7:D4:F7:52:58:7D\n" +
    "73:32:A9:5A:B0:87\n" +
    "F8:3B:1D:7F:AF:6A\n" +
    "9F:D4:9D:79:34:77\n" +
    "9E:7B:FD:F8:C4:76\n" +
    "59:2D:38:A4:5E:44\n" +
    "8C:7A:5D:BC:3C:B7\n" +
    "1E:CA:58:A8:E4:6D\n" +
    "1C:00:99:E5:72:9B\n" +
    "EF:F4:04:B5:DD:85\n" +
    "61:7A:54:6F:E3:6D\n" +
    "FD:BE:94:A9:8B:8E\n" +
    "2D:D6:76:E7:D7:C4\n" +
    "A5:1C:A6:1D:75:E9\n" +
    "40:DF:D2:5C:78:91\n" +
    "AD:33:21:24:40:44\n" +
    "E4:19:4E:10:34:5C\n" +
    "94:07:F0:87:16:91\n" +
    "93:45:7A:24:24:28\n" +
    "D7:CA:72:C9:AF:6D\n" +
    "11:B6:B2:72:E0:18\n" +
    "70:21:DF:A0:05:F1\n" +
    "44:7D:BE:4A:0C:90\n" +
    "85:5A:AA:E9:DA:7A\n" +
    "0F:F7:8D:59:D0:62\n" +
    "C1:3E:4B:83:A5:9B\n" +
    "EF:27:94:30:C6:44\n" +
    "05:F1:24:B0:D6:BC\n" +
    "DA:9B:78:5E:01:DB\n" +
    "D1:D5:84:00:B2:BF\n" +
    "1D:FC:E5:44:DA:AF\n" +
    "A3:D8:38:BA:6C:DA\n" +
    "47:F3:62:B6:3C:B1\n" +
    "56:D3:E5:4C:4E:42\n" +
    "8F:09:C1:B5:98:37\n" +
    "3B:6E:F5:71:0A:33\n" +
    "8E:01:4A:1B:CF:3A\n" +
    "F6:B3:FE:87:15:64\n" +
    "C8:4C:E6:F4:8D:43\n" +
    "CA:30:BD:11:8E:A3\n" +
    "20:3A:02:52:50:24\n" +
    "84:15:9E:0C:97:4D\n" +
    "A5:C5:C0:F5:32:4A\n" +
    "FE:90:E9:4D:66:30\n" +
    "A7:68:9E:19:C5:81\n" +
    "8E:61:95:4F:B7:E5\n" +
    "DA:14:1F:F1:33:88\n" +
    "7C:AA:EC:1A:0D:EF\n" +
    "87:B8:25:1B:18:63\n" +
    "59:10:49:17:34:A6\n" +
    "98:2F:95:90:A7:24\n" +
    "98:93:11:11:63:37\n" +
    "3A:52:85:DE:AC:6C\n" +
    "86:EF:E8:D7:AC:31\n" +
    "CB:B5:E0:4C:83:ED\n" +
    "FF:F7:3E:19:C8:11\n" +
    "CF:71:FE:49:97:83\n" +
    "0F:BB:3E:A4:69:06\n" +
    "8F:1C:6B:B1:01:03\n" +
    "5E:57:2C:C3:0A:22\n" +
    "46:59:F6:CF:F4:79\n" +
    "68:73:68:16:5A:47\n" +
    "B9:59:FF:1A:34:4C\n" +
    "A0:A6:D3:6F:30:8C\n" +
    "DC:38:44:CB:24:24\n" +
    "3B:AB:D1:1A:07:29\n" +
    "11:31:F9:00:61:3C\n" +
    "72:A7:47:ED:3B:64\n" +
    "C0:98:35:06:17:2A\n" +
    "BC:D2:56:81:E1:72\n" +
    "0E:63:64:23:07:49\n" +
    "1E:12:C2:CA:AE:38\n" +
    "C1:E9:B0:CB:10:67\n" +
    "81:30:0F:DB:5A:5F\n" +
    "8A:03:31:8C:12:4C\n" +
    "07:E5:80:F5:6A:D9\n" +
    "D2:E4:64:1B:63:10\n" +
    "5D:DC:F5:C5:99:4C\n" +
    "1D:A2:93:63:78:66\n" +
    "3A:EB:4A:10:74:A1\n" +
    "DC:ED:9D:83:77:AB\n" +
    "97:C6:15:59:35:9C\n" +
    "53:7E:6F:6D:93:E3\n" +
    "07:0B:34:35:F9:89\n" +
    "A6:C5:E5:57:64:AF\n" +
    "E2:9D:91:DC:21:D0\n" +
    "7D:26:58:7E:65:DD\n" +
    "2A:97:D0:45:C5:AE\n" +
    "49:CF:8D:CE:63:00\n" +
    "00:08:D3:E1:02:E6\n" +
    "0F:E6:EF:7B:1D:E1\n" +
    "BC:C6:6A:94:4F:EF\n" +
    "DE:09:C9:16:97:70\n" +
    "31:D1:7E:E4:BD:37\n" +
    "D4:C9:1B:7D:B1:A2\n" +
    "CA:95:79:60:BA:5C\n" +
    "94:5D:79:8C:DA:D5\n" +
    "06:49:05:C9:70:F5\n" +
    "C5:55:CC:0A:33:E5\n" +
    "B6:EA:9A:55:03:D7\n" +
    "8F:9D:69:4A:6A:30\n" +
    "A6:0C:43:4B:D6:77\n" +
    "AF:6A:41:4B:20:60\n" +
    "24:51:22:95:42:DA\n" +
    "C1:BE:97:F0:FC:8E\n" +
    "E2:85:92:B6:D8:D4\n" +
    "FC:F2:F5:42:19:DD\n" +
    "AD:6E:34:99:D1:31\n" +
    "4A:9E:A0:7A:B3:03\n" +
    "79:8C:EF:4A:8F:D0\n" +
    "DB:B1:1C:8B:0F:DA\n" +
    "0C:1E:50:38:C0:52\n" +
    "29:DC:C8:54:F6:41\n" +
    "0D:66:01:CB:24:66\n" +
    "7C:04:95:FE:12:C5\n" +
    "A4:5F:75:40:BA:44\n" +
    "AA:7D:62:77:85:F3\n" +
    "30:2C:ED:48:10:F4\n" +
    "AC:88:FE:B7:7D:8C\n" +
    "D1:97:C8:87:A9:BD\n" +
    "CF:C6:51:E6:31:65\n" +
    "38:9A:59:02:B4:D5\n" +
    "A0:42:B4:CA:1B:22\n" +
    "9B:73:BC:29:5A:0E\n" +
    "17:02:19:D8:56:64\n" +
    "A1:81:0F:E0:2E:87\n" +
    "DE:31:7B:64:E1:5D\n" +
    "B9:C7:FB:43:E2:FD\n" +
    "4E:DE:52:BB:C0:F9\n" +
    "A1:1C:5E:DE:08:B1\n" +
    "1F:FD:B4:7F:0A:6B\n" +
    "C1:D5:67:97:1C:82\n" +
    "E0:0B:81:C4:FA:E4\n" +
    "04:90:42:1C:4F:F1\n" +
    "7E:E0:CC:15:7D:76\n" +
    "C8:72:B4:BA:3B:E2\n" +
    "6D:ED:10:E8:3E:53\n" +
    "08:86:79:D6:32:63\n" +
    "F4:9F:43:EB:7C:CA\n" +
    "78:3E:16:12:D0:24\n" +
    "57:C2:08:8E:CF:50\n" +
    "02:A4:B3:29:1E:D4\n" +
    "D7:D4:D3:CE:D7:38\n" +
    "FA:90:4A:5A:7A:3C\n" +
    "26:7B:7B:C0:3F:21\n" +
    "86:50:9A:BC:18:8C\n" +
    "C4:68:2F:7A:69:69\n" +
    "B4:8C:A3:42:02:C2\n" +
    "37:19:3A:FA:7B:CC\n" +
    "31:5B:2A:63:CF:99\n" +
    "22:44:4E:BD:9F:39\n" +
    "2A:D3:58:76:5F:3F\n" +
    "4A:42:86:0C:91:35\n" +
    "30:3C:9E:03:6E:CF\n" +
    "F1:34:B2:25:CB:8A\n" +
    "4B:9A:9F:69:FC:CC\n" +
    "E1:8D:D2:71:B7:E5\n" +
    "F5:8E:CD:0D:9A:EC\n" +
    "89:C2:0C:EC:89:E0\n" +
    "67:32:0E:46:14:E9\n" +
    "81:8C:14:73:5C:8E\n" +
    "52:18:73:70:E5:64\n" +
    "53:A7:06:72:C0:9E\n" +
    "72:F8:E4:69:AB:C2\n" +
    "F4:EB:21:BE:B2:B0\n" +
    "CB:1C:9F:C6:61:19\n" +
    "8C:CC:B4:0B:A7:A3\n" +
    "23:4E:4F:0E:60:3B\n" +
    "06:B1:94:0C:D4:29\n" +
    "C0:E4:80:7B:3C:17\n" +
    "A4:D8:AF:F3:E9:31\n" +
    "33:2A:FA:88:0A:37\n" +
    "05:31:E4:4A:5B:0A\n" +
    "64:6E:C9:E9:9E:28\n" +
    "AF:3A:6B:C6:07:B7\n" +
    "30:57:49:73:6D:C6\n" +
    "27:7B:04:EB:14:DA\n" +
    "09:A9:94:6C:95:AC\n" +
    "F9:FB:A8:7E:5F:8A\n" +
    "07:99:C4:AE:8F:65\n" +
    "43:21:F9:CD:78:F6\n" +
    "E3:27:84:01:B5:6C\n" +
    "39:3F:0B:7C:55:A1\n" +
    "71:C2:B4:85:31:72\n" +
    "75:10:1E:96:5F:75\n" +
    "10:E9:C1:95:FA:C4\n" +
    "23:5E:25:81:BD:D6\n" +
    "DE:1E:2C:A2:5E:23\n" +
    "B9:1B:20:A4:AB:9A\n" +
    "58:48:6C:22:B2:5C\n" +
    "E3:3A:AE:75:83:11\n" +
    "71:3B:52:12:E2:9E\n" +
    "84:FF:D4:31:0D:2D\n" +
    "B9:90:6F:AB:9F:EE\n" +
    "BF:1D:28:D4:E2:34\n" +
    "AE:60:C2:21:CE:8D\n" +
    "B6:4D:0C:B4:48:75\n" +
    "3C:C2:B7:51:33:08\n" +
    "CA:FD:53:F0:28:32\n" +
    "E3:14:FE:1E:0C:3C\n" +
    "F9:1A:B4:08:59:5A\n" +
    "A7:27:D5:0E:E6:46\n" +
    "95:87:97:8F:33:DD\n" +
    "D1:30:28:05:A8:97\n" +
    "BA:21:B7:07:F6:7D\n" +
    "92:CC:F9:F0:4B:EE\n" +
    "57:BC:4B:62:3B:E5\n" +
    "9C:D5:CA:E7:15:E2\n" +
    "68:75:39:F2:0A:8B\n" +
    "41:D3:64:E5:6E:04\n" +
    "AE:D6:37:A0:3E:91\n" +
    "F7:E3:23:F0:93:0F\n" +
    "7F:D8:3D:A5:9C:96\n" +
    "4E:B4:1C:90:D9:7E\n" +
    "23:95:47:60:BE:D3\n" +
    "4F:3B:8A:DB:91:27\n" +
    "28:A1:7F:42:48:B3\n" +
    "E0:38:DC:33:E7:54\n" +
    "9C:A3:87:57:AB:90\n" +
    "9E:4F:0E:3F:25:A9\n" +
    "14:94:43:28:05:63\n" +
    "69:AB:6B:06:A3:3E\n" +
    "FC:9F:10:D9:C7:E9\n" +
    "F8:C1:54:4A:A3:BF\n" +
    "D2:B7:4B:58:AD:C0\n" +
    "2F:F9:0F:D2:05:9E\n" +
    "85:88:7B:1F:30:EA\n" +
    "C9:6D:CA:2C:FE:C1\n" +
    "9E:D8:7A:47:42:66\n" +
    "3E:BC:48:3C:68:17\n" +
    "64:8B:E6:2B:8A:CF\n" +
    "B9:30:69:B1:BF:51\n" +
    "8A:2A:13:7B:B6:93\n" +
    "6D:3A:79:D9:A1:7F\n" +
    "34:3C:1F:57:B2:B4\n" +
    "3D:96:B2:31:F3:3C\n" +
    "1A:C7:83:9E:63:46\n" +
    "01:CD:63:9A:B2:15\n" +
    "28:A8:42:D9:80:0A\n" +
    "C5:FA:16:08:D0:E2\n" +
    "A0:AC:97:5B:84:C5\n" +
    "BE:26:A0:AA:3C:54\n" +
    "CE:61:2D:65:E7:99\n" +
    "EC:10:55:F6:B4:38\n" +
    "23:C8:0A:89:77:08\n" +
    "EC:C7:CB:A6:62:4A\n" +
    "B9:5C:48:91:16:78\n" +
    "24:07:EF:40:18:C0\n" +
    "4C:35:70:AA:7B:05\n" +
    "79:A5:2A:85:7E:D1\n" +
    "37:01:98:A5:34:12\n" +
    "75:50:B5:F5:BA:8D\n" +
    "21:54:50:21:91:08\n" +
    "43:9D:7C:66:C1:EA\n" +
    "E1:6E:33:92:4A:6B\n" +
    "70:1C:51:EF:BE:E7\n" +
    "37:8C:A3:F0:B2:38\n" +
    "54:17:7A:2A:8F:A9\n" +
    "AF:79:9F:66:E6:29\n" +
    "2A:0F:49:E5:2C:A1\n" +
    "09:D0:47:3A:E2:9A\n" +
    "AD:71:6D:EC:2E:72\n" +
    "C7:78:27:C2:D9:FC\n" +
    "3A:B9:DF:39:1D:37\n" +
    "3A:14:02:11:70:2F\n" +
    "6E:FA:0F:FB:FF:44\n" +
    "24:3D:77:0F:A4:D4\n" +
    "F3:18:FD:B6:F5:33\n" +
    "44:BC:46:86:33:3C\n" +
    "87:17:0B:A2:E2:11\n" +
    "40:0B:14:F9:1C:DF\n" +
    "F5:B3:25:83:2C:20\n" +
    "E1:C5:8D:9A:2D:6C\n" +
    "AB:D5:12:EC:5E:9D\n" +
    "DD:75:C4:76:E7:7A\n" +
    "EB:D8:EC:18:01:8A\n" +
    "97:2C:78:CD:0B:9E\n" +
    "1E:AD:E5:01:BA:2C\n" +
    "CA:B3:29:A0:82:70\n" +
    "90:4C:9D:C4:E1:58\n" +
    "94:35:64:83:18:22\n" +
    "AB:F0:FC:EA:12:2C\n" +
    "0D:58:CC:4E:CF:15\n" +
    "AF:4A:A3:54:42:30\n" +
    "DD:BD:91:93:DB:E3\n" +
    "4C:0A:8C:9F:2B:F3\n" +
    "F8:BB:44:64:04:02\n" +
    "5B:75:02:71:9E:2E\n" +
    "3F:A0:6E:CF:23:A1\n" +
    "C9:64:78:57:4E:7D\n" +
    "45:59:22:B2:C3:D3\n" +
    "CD:D6:09:A5:88:6B\n" +
    "BC:9A:4D:8F:0D:0A\n" +
    "05:5F:15:56:32:A2\n" +
    "F9:7E:B3:BD:7A:D7\n" +
    "0C:A6:54:3B:80:40\n" +
    "90:AF:C9:78:A6:E5\n" +
    "E9:3F:04:18:E3:5E\n" +
    "36:C7:56:8E:31:2A\n" +
    "85:C5:0A:95:0F:B3\n" +
    "1B:1D:73:FF:DE:ED\n" +
    "E2:B9:6D:2D:DE:2B\n" +
    "72:82:C1:EC:0A:84\n" +
    "9E:CA:3D:54:98:A3\n" +
    "C7:9D:B3:51:02:14\n" +
    "71:01:59:9F:53:90\n" +
    "E3:08:6F:37:15:DA\n" +
    "AF:F1:A5:91:BA:A1\n" +
    "16:53:09:7C:7A:CD\n" +
    "68:11:90:8D:CB:54\n" +
    "53:0B:48:E5:10:B5\n" +
    "D5:6D:96:91:C7:CE\n" +
    "60:91:12:F2:76:51\n" +
    "7A:1E:4D:2D:DC:09\n" +
    "B5:31:80:3C:06:2C\n" +
    "86:A2:91:A8:11:81\n" +
    "94:82:8F:59:10:E1\n" +
    "78:7C:80:06:B1:35\n" +
    "24:2E:15:94:14:96\n" +
    "81:D4:58:CB:12:DF\n" +
    "A1:EC:0E:53:58:10\n" +
    "DB:95:AD:B3:11:D6\n" +
    "E1:30:08:31:D8:79\n" +
    "AB:67:61:01:EF:78\n" +
    "25:D1:4A:FE:C4:3D\n" +
    "4D:9D:4C:38:5D:49\n" +
    "98:A2:56:05:74:44\n" +
    "B8:B9:A7:6A:19:72\n" +
    "42:3D:5E:52:A4:96\n" +
    "55:60:0B:F2:DC:EC\n" +
    "D2:7B:9B:66:51:22\n" +
    "9E:56:B2:F0:DF:F3\n" +
    "EE:47:4F:05:95:FF\n" +
    "96:0F:E4:40:57:77\n" +
    "A1:49:01:9A:21:AD\n" +
    "DA:F7:EA:89:0E:9A\n" +
    "4F:B4:6A:29:31:CA\n" +
    "E7:5B:E4:C4:8A:02\n" +
    "37:97:04:E2:CD:1C\n" +
    "5C:9C:B3:8D:D5:BD\n" +
    "14:13:0E:F3:1E:2F\n" +
    "A6:EE:9A:DE:D1:77\n" +
    "12:9D:CF:84:31:58\n" +
    "AE:79:46:4F:84:B7\n" +
    "88:A0:3E:36:7F:97\n" +
    "2F:21:97:FB:44:21\n" +
    "3E:B5:3D:51:86:B7\n" +
    "3A:B2:9A:70:5D:E0\n" +
    "BC:26:78:BA:96:61\n" +
    "FD:18:F8:1C:9B:3E\n" +
    "83:38:E3:7E:6E:91\n" +
    "8C:7F:DF:4A:D4:21\n" +
    "36:AB:FD:CC:E3:A3\n" +
    "90:34:45:39:95:E4\n" +
    "11:2C:06:35:AF:01\n" +
    "8E:A1:13:34:4B:6A\n" +
    "49:DC:C9:FE:BE:C8\n" +
    "78:9F:76:F8:96:6B\n" +
    "E0:F4:51:F2:09:9F\n" +
    "CA:B0:BD:EC:54:77\n" +
    "A1:22:65:BE:FE:B0\n" +
    "E7:1E:5B:96:67:04\n" +
    "DA:87:4E:85:8D:70\n" +
    "79:FF:A9:61:61:E1\n" +
    "41:8A:9E:8B:26:B5\n" +
    "75:10:AA:D1:DA:7F\n" +
    "6F:EA:25:B7:5D:4F\n" +
    "AA:25:F4:D1:D8:9C\n" +
    "31:D9:45:B3:5B:DE\n" +
    "DE:B6:55:F3:A7:96\n" +
    "01:7C:60:16:01:7D\n" +
    "CD:BC:FA:F2:B7:E2\n" +
    "55:AB:4E:16:99:77\n" +
    "AB:F7:91:32:4F:0E\n" +
    "60:D8:9A:98:A8:34\n" +
    "85:2F:31:E6:A4:CD\n" +
    "3A:65:4B:24:96:77\n" +
    "3E:0F:7F:F7:94:E4\n" +
    "78:A7:4E:B7:84:D3\n" +
    "36:0C:1E:F4:E5:D8\n" +
    "D4:F3:A3:39:6A:83\n" +
    "1F:CA:40:C7:72:F4\n" +
    "21:6C:C9:21:31:66\n" +
    "3C:F3:83:A9:EF:E8\n" +
    "04:6D:48:DC:55:13\n" +
    "0F:AD:39:64:FD:0B\n" +
    "F4:CF:3B:42:1C:82\n" +
    "60:E5:71:72:2C:DE\n" +
    "EF:61:D7:E2:A3:FF\n" +
    "6E:0B:12:F2:63:8B\n" +
    "F9:9B:5B:54:A1:2A\n" +
    "B6:64:E6:0F:77:6A\n" +
    "53:87:0A:FB:0A:79\n" +
    "F4:6A:7B:84:D4:AF\n" +
    "1E:40:EE:35:1E:AA\n" +
    "5B:01:44:BC:BC:F7\n" +
    "CA:27:0E:3C:1F:57\n" +
    "BF:AF:D1:07:10:F4\n" +
    "FC:79:CF:6E:73:DF\n" +
    "48:85:2D:5F:0E:7F\n" +
    "2B:C7:47:08:A6:34\n" +
    "BB:3C:46:EB:AF:A2\n" +
    "ED:55:D1:FB:F0:28\n" +
    "8A:15:94:05:88:9A\n" +
    "BA:D3:BB:79:45:D0\n" +
    "3B:0F:FE:5E:CE:77\n" +
    "34:C0:E9:09:4F:C4\n" +
    "65:D4:E0:6F:3C:9B\n" +
    "17:1F:67:17:67:40\n" +
    "B8:5C:6A:B7:4B:05\n" +
    "F8:8F:7A:4A:4B:84\n" +
    "A4:C8:6A:13:FA:45\n" +
    "DA:27:1B:2E:69:24\n" +
    "1F:2C:2A:FC:1D:DE\n" +
    "8F:B4:C8:15:29:7A\n" +
    "B6:A3:78:63:DB:3D\n" +
    "73:8B:AB:68:B3:6F\n" +
    "75:78:E7:4C:14:FA\n" +
    "C7:FF:D5:0B:B8:0C\n" +
    "A0:88:C4:8B:95:0C\n" +
    "E3:AC:C0:51:19:38\n" +
    "1C:C7:88:E6:89:40\n" +
    "91:AC:A3:A0:73:81\n" +
    "06:35:0C:BA:A1:7B\n" +
    "28:30:84:D0:B4:82\n" +
    "A9:ED:75:22:76:F8\n" +
    "6A:FE:AE:D9:C3:A6\n" +
    "E1:61:8E:D6:0D:B1\n" +
    "74:FD:87:8F:C9:5C\n" +
    "3F:A8:16:DC:D2:32\n" +
    "2C:37:B1:40:76:6F\n" +
    "4F:94:5A:DB:E8:C6\n" +
    "8D:D3:FF:7A:CD:6F\n" +
    "DC:F6:32:89:3C:48\n" +
    "C5:0D:FE:4C:6D:FC\n" +
    "99:C5:11:D6:EF:8B\n" +
    "90:7A:EF:7C:43:EF\n" +
    "00:48:39:24:26:69\n" +
    "29:26:3F:5F:D7:0C\n" +
    "27:71:20:46:7B:AF\n" +
    "52:67:E4:96:A0:33\n" +
    "0F:97:67:AE:DF:CC\n" +
    "CF:39:6C:BA:40:6D\n" +
    "D8:3D:E1:40:EC:BA\n" +
    "48:09:00:9E:58:8F\n" +
    "A1:AA:28:28:6B:15\n" +
    "14:F1:A8:E3:3A:EF\n" +
    "13:81:F0:1A:CD:43\n" +
    "80:7D:27:81:6A:4B\n" +
    "72:F9:04:9F:BA:F8\n" +
    "59:F8:F4:E3:BE:23\n" +
    "E3:DB:88:C7:BB:55\n" +
    "D9:1A:B5:3A:A4:45\n" +
    "F1:E6:9B:59:DF:EF\n" +
    "DC:5B:A2:85:0A:44\n" +
    "4B:E0:E4:78:FF:79\n" +
    "15:3E:B7:8B:2D:B0\n" +
    "70:80:4A:59:EE:82\n" +
    "D5:66:A4:7F:56:AD\n" +
    "F7:77:D9:66:1C:AD\n" +
    "F7:86:35:52:AB:FC\n" +
    "1D:0D:44:34:F9:95\n" +
    "16:D0:B5:33:79:AE\n" +
    "22:D0:DF:FF:1A:B5\n" +
    "43:ED:49:D0:2E:1F\n" +
    "D6:A1:CB:17:60:A7\n" +
    "A0:AD:AB:F8:32:31\n" +
    "AB:AF:2D:EA:4E:CF\n" +
    "3B:7A:FD:A0:4D:86\n" +
    "5E:CB:BE:D1:E2:BF\n" +
    "57:EE:51:0D:43:F3\n" +
    "6B:31:A0:C5:E2:E2\n" +
    "E9:18:70:E4:9F:87\n" +
    "49:E6:48:7B:E4:6D\n" +
    "F6:B7:CA:2A:B5:52\n" +
    "79:EF:CE:D3:52:01\n" +
    "77:87:D7:AB:9D:1F\n" +
    "E8:00:0D:D5:FA:C9\n" +
    "4E:BB:B1:EC:19:1B\n" +
    "8D:7E:3C:18:68:40\n" +
    "A0:BC:92:8A:2B:32\n" +
    "88:56:E5:CE:AC:75\n" +
    "0A:F1:6A:79:5A:D0\n" +
    "0A:56:9B:E9:FA:B9\n" +
    "19:C3:68:C7:6F:A8\n" +
    "98:A7:7D:65:4D:A7\n" +
    "65:27:FA:BB:88:78\n" +
    "DE:D3:AE:FD:E1:17\n" +
    "C2:D2:FA:09:DA:8B\n" +
    "F5:BC:62:1B:64:6F\n" +
    "18:7E:FE:6E:A8:7E\n" +
    "29:9A:EE:77:EF:7C\n" +
    "0D:A0:BA:61:87:80\n" +
    "EB:0D:95:8F:B8:A7\n" +
    "75:42:51:84:D7:4B\n" +
    "9E:AF:73:3C:58:10\n" +
    "6E:6A:5B:77:55:4A\n" +
    "F1:4C:30:F7:06:C2\n" +
    "39:39:6A:F0:08:6F\n" +
    "92:00:F8:1B:2A:55\n" +
    "69:2F:2B:A8:A9:E8\n" +
    "36:4C:87:23:64:E6\n" +
    "99:DB:D5:81:17:79\n" +
    "12:30:14:60:E6:8F\n" +
    "AB:25:59:45:21:FC\n" +
    "AF:6B:CF:25:7B:9A\n" +
    "8A:56:2E:07:7B:5B\n" +
    "F4:01:52:8F:7E:3B\n" +
    "BC:68:5B:F2:E0:DE\n" +
    "63:B9:58:92:B8:E6\n" +
    "74:4E:DB:F4:33:21\n" +
    "6E:CD:64:84:13:E8\n" +
    "41:DF:48:8D:36:76\n" +
    "3B:67:C5:D7:71:6F\n" +
    "41:12:40:6C:AA:06\n" +
    "05:4C:E6:9F:8A:05\n" +
    "52:6B:A7:4F:65:81\n" +
    "CC:02:F7:8C:83:24\n" +
    "9A:4F:22:CC:DC:51\n" +
    "16:CC:2A:77:2B:9F\n" +
    "34:69:06:59:51:A2\n" +
    "F3:56:6F:69:AE:D2\n" +
    "4D:17:B2:0C:72:A7\n" +
    "8B:D0:C4:90:DC:93\n" +
    "A8:EA:70:15:00:38\n" +
    "E9:65:20:17:5D:DA\n" +
    "0C:02:2F:D0:22:BA\n" +
    "6F:10:33:2B:66:2A\n" +
    "07:14:7E:80:87:4C\n" +
    "8C:04:1E:85:78:38\n" +
    "6C:DF:97:05:1C:71\n" +
    "6D:E5:AF:97:F6:8E\n" +
    "42:0F:48:FC:1E:4F\n" +
    "F4:ED:80:28:E0:BC\n" +
    "F8:42:3D:A8:3C:3F\n" +
    "00:0B:51:D0:36:46\n" +
    "7E:13:F0:7F:1B:6B\n" +
    "52:84:72:82:B7:08\n" +
    "D8:3E:76:19:5D:6A\n" +
    "9A:50:D0:AF:EE:74\n" +
    "A5:F8:EF:A9:31:77\n" +
    "BC:AB:C6:AF:E7:71\n" +
    "D7:0F:5A:8B:FD:1F\n" +
    "F5:21:EE:50:3A:CB\n" +
    "3B:26:91:3A:DA:28\n" +
    "AB:D7:F1:4C:15:0D\n" +
    "76:84:A4:BD:5B:7C\n" +
    "4F:C8:15:CE:39:C2\n" +
    "37:3D:1B:A0:04:93\n" +
    "B8:95:8B:33:C0:50\n" +
    "17:30:19:19:19:8E\n" +
    "02:26:42:D9:8B:8B\n" +
    "94:7D:47:D4:6A:65\n" +
    "75:94:39:F0:ED:A4\n" +
    "A1:8A:47:57:FD:3D\n" +
    "03:6C:52:0F:65:22\n" +
    "77:05:D1:15:99:A7\n" +
    "53:0D:68:D6:FB:91\n" +
    "3C:93:FA:CA:03:9B\n" +
    "CE:AA:22:76:50:39\n" +
    "EA:66:DA:D5:67:27\n" +
    "FE:4D:5D:68:B4:AB\n" +
    "64:5B:DD:9A:48:E1\n" +
    "3C:BA:CB:73:32:53\n" +
    "D7:13:A3:48:40:9B\n" +
    "EE:6C:D8:42:59:39\n" +
    "67:35:BF:0D:4A:9A\n" +
    "51:9C:E7:57:FD:29\n" +
    "DE:B6:68:E1:46:BC\n" +
    "58:F6:D1:CF:88:3A\n" +
    "14:7D:B2:ED:E5:E2\n" +
    "ED:27:B5:A1:E9:7C\n" +
    "D2:97:5C:13:F1:98\n" +
    "08:A5:39:10:81:A6\n" +
    "D5:33:2C:19:F4:C9\n" +
    "97:0A:E1:4A:10:F5\n" +
    "B4:CD:46:78:F4:4D\n" +
    "2A:65:BC:BC:AE:2F\n" +
    "0E:28:3E:87:7A:81\n" +
    "63:34:DE:21:DC:28\n" +
    "A6:AD:C2:7A:D1:9A\n" +
    "60:3B:6A:0D:48:1A\n" +
    "B8:6D:F2:BE:55:2E\n" +
    "27:D7:C8:F4:5A:48\n" +
    "C6:2B:BF:61:44:68"


// qqa



var create=file.create("/sdcard/atest.txt");
logd(create);


let dda = qqa.split("\n")
for (let i = 0; i < dda.length; i++) {
    let add = dda[i].split(":")
    let cadd = "00" + ":" + add[1] + ":" + add[2] + ":" + add[3] + ":" + add[4] + ":" + add[5] + "\n"

    file.appendLine(cadd,"/sdcard/atest.txt");
    //logd(cadd);
}


exit()*/


/*let shuzu=[]
let aaa = "adsl_2"
let bbb = "_"


for (let ji = 1; ji < 11; ji++) {
    aaa = "adsl_2"
    let bba = ""
    if (ji < 10) {
        bba = bba + "0" + ji + "_"

    } else {

        bba = bba + "12"  + "_"
       // bba = bba + ji + "_"

    }
    for (let i = 1; i < 5; i++) {
        aaa = "adsl_2"
        aaa = aaa + bba + i + "\n"

        shuzu.push(aaa)
      //  file.appendLine(aaa,"/sdcard/atest.txt");
    }





}
var r = utils.setClipboardText(shuzu);
toast("设置结果:"+r);
exit()*/
var er_tongyong_times = {


    //这一轮 最后的名字
    last_name: "",


    //正在执行的名字
    now_which: "",


    //单次的 课程 所有名字
    ci_all_name: [],

    //单次的 目录 所有名字
    ci_all_leimu_name: []


}
//刚开始运行的时间
var atime = time()


let ui_zhi = JSON.parse(ui.getConfigJSON())

//总时间
let all_time = ui_zhi.runtime


ui.toast("总运行时长 ： " + all_time + "   分钟");


//点击方式选择
function main_clickfs(clicknr, aclick_fangshi) {
    if (clicknr != null) {
        let clickfanhui = false

        clickfanhui = kuaishou_huoquexdianji(clicknr)
        if (clickfanhui != false && clickfanhui != null) {
            let qa = clickfanhui.clickEx()
            if (qa) {
//		  logd ("通用的点击Ex：true");
                return true
            } else {
                logd("通用的点击Ex：false");
                return false
            }
        } else {
            return false
        }

    }


}

function kuaishou_huoquexdianji(jied) {
    if (jied != null) {
        if (!jied.clickable) {
            let a = jied.parent()
            if (a != null && !a.clickable) {
                let b = a.parent()
                if (b != null && !b.clickable) {
                    let c = b.parent()
                    if (c != null && !c.clickable) {
                        let d = c.parent()
                        if (d != null && !d.clickable) {
                            logd("click all  false");
                            return false
                        } else {
                            //	  logd ("d  true");
                            return d
                        }
                    } else {
                        //	logd ("c  true");
                        return c
                    }
                } else {
                    //	  logd ("b  true");
                    return b
                }
            } else {
                //	logd ("a  true");
                return a
            }
        } else {
//	  logd ("jied  true");
            return jied
        }
    }
}

//启动运行 app
function open_apk() {
    while (true) {
        let apk_name = "com.xuaner.edu"
        let panduan_apk = pkg(apk_name).getOneNodeInfo(0)
        if (panduan_apk) {
            return
        } else {
            utils.openApp(apk_name);
            sleep(5500);
        }
    }
}


//线程点击
function xiancheng_click() {
    let node = text("目录").getOneNodeInfo(0)
    if (node) {
        node.clickEx()
    }

    let anode = text("我的课程").getOneNodeInfo(0)
    if (anode) {
        main_clickfs(anode)
    }

    let bnode = text("全部").getOneNodeInfo(0)
    if (bnode) {
        main_clickfs(bnode)
    }


    let cnode = text("跳过").id("com.xuaner.edu:id/btn_skip").getOneNodeInfo(0)
    if (cnode) {
        main_clickfs(cnode)
    }


    jiance_is_time_to_finish()

    open_apk()


}


//查找是否存在  类目  指定名字
function tong_find_isis_sub(name) {
    let ci = er_tongyong_times.ci_all_leimu_name.length
    for (let i = 0; i < ci; i++) {
        if (name == er_tongyong_times.ci_all_leimu_name[i]) {
            return true
        } else {
            if (i === ci - 1) {
                return false
            }
        }
    }
}


//查找是否存在  课程  指定名字
function tong_find_isis_sub_kecheng(name) {
    let ci = er_tongyong_times.ci_all_name.length
    for (let i = 0; i < ci; i++) {
        if (name == er_tongyong_times.ci_all_name[i]) {
            return true
        } else {
            if (i === ci - 1) {
                return false
            }
        }
    }
}


//是否到时间结束了
function jiance_is_time_to_finish() {
    let restime = (time() - atime) / 1000
    if (restime > (all_time * 60)) {
        logd("时间 --->> 到了 《  结束今日学习  》");
        toast("时间 --->> 到了 《  结束今日学习  》");
        exit()
    } else {
//        logd(" 《   继续学习   》  " + restime);
        //  toast(" 《   继续学习   》 " + restime);
    }

}

//滑动主界面
function er_swip_jiemian() {


}


//是否在学习的 视频 界面吗
function er_is_in_true_viedow() {

    let anode = text("内容详情").getOneNodeInfo(0)
    let bnode = id("com.xuaner.edu:id/superplayer_cloud_video_view").getOneNodeInfo(0);
    if (anode && bnode) {
        return true
    } else {
        return true
    }
}


//返回上一级
function er_back_last() {
    while (true) {
        let node = text("课程详情").getOneNodeInfo(0);
        if (node) {
            return true
        } else {
            back()
            sleep(random(2500, 3500));
        }
    }
}


//进入学习
function er_join_study(node) {
    for (let i = 0; i < 210; i++) {
        let andie = text("课程详情").getOneNodeInfo(0);
        let bndie = text("目录").getOneNodeInfo(0);
        let cnode = false

        if (node != null && node != "") {
            cnode = true
        }
        if (cnode) {
            main_clickfs(node)
            sleep(random(2000, 3500));
        }

        let allnode = id("com.xuaner.edu:id/tv_title").getNodeInfo(2000)

        if (andie) {
            logd("在 课程列表");
        }
        if (bndie) {
            main_clickfs(bndie)
        }
        if (allnode) {
            let qci = allnode.length
            for (let j = 0; j < qci; j++) {

                if (j == j - 1) {
                    break
                }

                let ci_name = allnode[i].text
                if (tong_find_isis_sub_kecheng(ci_name)) {

                } else {

                    while (true) {
                        main_clickfs(allnode[i])
                        sleep(random(2500, 3000));

                        if (er_is_in_true_viedow()) {
                            sleep(random(1000, 3000));
                            logd("正在  ---》》  学习");
                            toast("正在  ---》》  学习");
                            let finshnode = id("com.xuaner.edu:id/superplayer_iv_replay").getOneNodeInfo(0)
                            if (finshnode) {
                                er_back_last()
                                break
                            }
                        } else {
                            let finshnode = id("com.xuaner.edu:id/superplayer_iv_replay").getOneNodeInfo(0)
                            if (finshnode) {
                                er_back_last()
                                break
                            }
                        }

                    }
                    er_tongyong_times.ci_all_leimu_name.push(ci_name)
                }
            }
            back()
            sleep(random(2000, 3500));
            return
        }
    }
}


//主执行线程
function er_run_do() {
    let node = id("com.xuaner.edu:id/tv_title").getNodeInfo(2000)
    if (node) {
        /*logd(node.length);
        */
        let nodelength = node.length
        if (nodelength != null && nodelength != undefined && nodelength != "" && nodelength > 1) {
            for (let i = 0; i < nodelength; i++) {
                // logd(node[i].text);
                er_tongyong_times.last_name = node[i].text;
            }
            for (let i = 0; i < nodelength; i++) {
                // logd(node[i].text);
                let ci_name = node[i].text
                er_tongyong_times.now_which = ci_name;


                if (tong_find_isis_sub(ci_name)) {
                } else {
                    main_clickfs(node[i])
                    sleep(random(3500, 5500));
                    er_join_study(node[i])

                    er_tongyong_times.ci_all_name.push(ci_name)

                }
            }
        }
    }
}


function main_run() {
    open_apk()
    let t = setInterval(function () {
        xiancheng_click()
    }, 10);

    logd(t);

    sleep(random(10000, 20000));


    while (true) {

        er_run_do()


    }
}


main_run()





