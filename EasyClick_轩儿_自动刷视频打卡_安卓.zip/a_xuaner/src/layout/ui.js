ui.resetUIVar()
ui.layout("配置", "main.xml");
ui.resetUIVar()
let aaoperationStoppedView = ui.bi_run_btn;
aaoperationStoppedView.setText("运  行")

ui.setEvent(ui.bi_run_btn, "click", function (view) {
    let operationStoppedView = ui.bi_run_btn;
    if (operationStoppedView.getText() + "" === "运  行") {
        operationStoppedView.setText("停  止")
        ui.start();// 启动脚本
        ui.saveAllConfig()
    } else {
        operationStoppedView.setText("运  行")
        ui.stopTask();// 停止脚本
        ui.saveAllConfig()
    }
    sleep(1000);
})
ui.setEvent(ui.bi_save_btn, "click", function (view) {
    ui.saveAllConfig()
    ui.toast("保存成功")
})
