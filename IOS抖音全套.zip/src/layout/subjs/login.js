
// """
// 登录成功                LOGIN_SUCCESS = 1
// 用户或密码不存在错误      LOGIN_NOT_EXITS_ERROR = 2
// 异地登录                LOGIN_MUTI_USER_ERROR = 3
// 用户名错误              LOGIN_USERNAME_ERROR = 4
// 密码错误                LOGIN_PASSWORD_ERROR = 5
// 未登录就请求方法错误      LOGIN_NOTLOGIN_REQUEST_ERROR = 6
// 后台错误                LOGIN_ERROR = 100
// 账号可用日期已归零        LOGIN_NOLEFTTIME_ERROR = 7
// 后台日期存储错误          LOGIN_DATE_TRANSFORM_ERROR = 8
// """

function login(data) {
    const url = 'http://47.108.92.250:8888/login';
    let error_msg = '登录异常'
    for(let i=0; i<3; i++){
        const login_result = http.httpPost(url, data, '', 10000,{'Content-Type': 'application/json'})
        logi(`登录请求结果： ${login_result}`)
        try{
            const login_state = JSON.parse(login_result);
            if(login_state.code === 200){
                //登录成功
                const r = 设备uid绑定(JSON.parse(data).username);
                if(r){
                    return '账号绑定成功'
                }else {
                    return '账号绑定异常'
                }
            }
            else {
                if(login_state.hasOwnProperty('msg')){ return login_state.msg }
                return login_result
            }
        }catch (e) {
            loge(`【error】login: ${e}`)
            error_msg = `登录异常: ${e}`
            return error_msg
        }
    }
    return error_msg
}

function 设备uid查询() {
    const device_id = device.getDeviceId()
    const queryUrl = `http://47.108.92.250:8888/get_device_bind_uid?device_id=${encodeURI(device_id)}`
    logi(`【设备uid查询】：${queryUrl}`)
    for(let i=0; i<3; i++){
        const r = http.httpGet(queryUrl, {}, 30 * 1000, {'Content-Type': 'application/json'});
        if(r){
            try {
                logi(`【设备uid查询】：${r}`)
                const response = JSON.parse(r);
                if (response.code === 200) {
                    return response.uid;
                }
                else if (response.state === -1){
                    return null
                }
            }catch (e) {
                loge(`【error】设备uid查询: ${e}`)
            }
        }
    }
    return null
}

function 设备uid绑定(uid) {
    const bindUrl = `http://47.108.92.250:8888/device_bind_uid`
    const device_id = device.getDeviceId()
    const data = {
        "device_id": device_id,
        "device_name": device.getDeviceName(),
        "device_os_version": device.getOSVersion(),
        "device_expiration_time": getDeviceExpTime(),
        "uid":uid
    }
    logi(JSON.stringify(data))
    for(let i=0; i<3; i++){
        const bind_result = http.postJSON(bindUrl, data, 100000, {'Content-Type': 'application/json'})
        try{
            logi(`【设备uid绑定】：${bind_result}`)
            const bind_state = JSON.parse(bind_result);
            if(bind_state.code === 200){
                //绑定成功
                return true
            }
        }catch (e) {
            loge(`【error】设备uid绑定: ${e}`)
            return false
        }
    }
    return false
}
