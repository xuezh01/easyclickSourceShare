/* 【关键词搜索】*/




/**
 * @description  插入关键词搜索记录
 */
function 查询关键词搜索记录(data) {
    logi('开始执行 -- 【查询关键词搜索记录】')
    const start_time = time();
    const JSData = JSON.parse(data);
    const queryUrl = `${JSData.url}/get_kw_search?uid=${encodeURI(JSData.uid)}`;
    const r = http.httpGet(queryUrl, {}, 30 * 1000, {"key-word": "test"});
    logw(`【查询关键词搜索记录】：${r}`);
    logw(`【查询关键词搜索记录 耗时】：${time()-start_time}`);
    return r
}

function 置顶关键词搜索记录(data) {
    logi('开始执行 -- 【关键词搜索记录置顶】')
    const start_time = time();
    const JSData = JSON.parse(data);

    const postData = {
        zhiding: JSData.zhiding,
        keywordSid: JSData.keywordSid
    }
    logw(JSON.stringify(postData));
    const url = `${JSData.url}/zhiding_kw_search`;
    const r = http.postJSON(url, postData,  30 * 1000, {"key-word": "test"});
    logw(`【关键词搜索记录置顶】：${r}`);
    logw(`【关键词搜索记录置顶 耗时】：${time()-start_time}`);
    return r
}

function 删除关键词搜索记录(data) {
    logi('开始执行 -- 【删除关键词搜索记录】')
    const start_time = time();
    const JSData = JSON.parse(data);
    const url = `${JSData.url}/delete_kw_search`;
    const postData = {
        keywordSid: JSData.keywordSid,
    }
    const r = http.postJSON(url, postData,  30 * 1000, {"key-word": "test"});
    logw(`【删除关键词搜索记录】：${r}`);
    logw(`【删除关键词搜索记录 耗时】：${time()-start_time}`);
    return r
}

function 查询关键词搜索记录用户记录(data) {
    logi('开始执行 -- 【查询关键词搜索记录用户记录】')
    const start_time = time();
    const JSData = JSON.parse(data);
    const url = `${JSData.url}/get_kw_search_all_comment?keywordSid=${encodeURI(JSData.keywordSid)}`;
    const r = http.httpGet(url, {},  30 * 1000, {"key-word": "test"});
    logw(`【查询关键词搜索记录用户记录】：${r}`);
    logw(`【查询关键词搜索记录用户记录 耗时】：${time()-start_time}`);
    return r
}

function 批量关键词用户记录关注(data) {
    logi('开始执行 -- 【批量关键词用户记录关注】')
    const start_time = time();
    const JSData = JSON.parse(data);
    const url = `${JSData.url}/update_kw_focus_str`;
    const postData = {
        isFollow: JSData.isFollow,
        commentSid: JSData.commentSid,
    }
    logw(JSON.stringify(postData))
    const r = http.postJSON(url, postData,  30 * 1000, {"key-word": "test"});
    logw(`【批量关键词用户记录关注】：${r}`);
    logw(`【批量关键词用户记录关注 耗时】：${time()-start_time}`);
    return r
}

function 自动回复信息配置查询(data) {
    logi('开始执行 -- 【自动回复信息配置查询】')
    const start_time = time();
    const JSData = JSON.parse(data);
    const queryUrl = `${JSData.url}/get_agiConfig?uid=${encodeURI(JSData.uid)}`;
    const r = http.httpGet(queryUrl, {}, 30 * 1000, {"key-word": "test"});
    logw(`【自动回复信息配置查询】：${r}`);
    logw(`【自动回复信息配置查询 耗时】：${time()-start_time}`);
    return r
}

function 自动回复信息配置保存(data) {
    logi('开始执行 -- 【自动回复信息配置保存】')
    const start_time = time();
    const JSData = JSON.parse(data);
    const url = `${JSData.url}/insert_agiConfig`;
    const postData = {
        uid: JSData.uid,
        agiConfig : JSON.stringify(JSData.agiConfig),
    }
    const r = http.postJSON(url, JSON.stringify(postData),  30 * 1000, {"key-word": "test"});
    logw(`【自动回复信息配置保存】：${r}`);
    logw(`【自动回复信息配置保存 耗时】：${time()-start_time}`);
    return r
}

