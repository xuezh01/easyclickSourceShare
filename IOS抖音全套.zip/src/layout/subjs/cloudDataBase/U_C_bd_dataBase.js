

function 查询榜单搜索记录(data) {
    logi('开始执行 -- 【查询榜单搜索记录】')
    const start_time = time();
    const JSData = JSON.parse(data);
    const queryUrl = `${JSData.url}/get_bd_search?uid=${encodeURI(JSData.uid)}`;
    const r = http.httpGet(queryUrl, {}, 30 * 1000, {"key-word": "test"});
    logw(`【查询榜单搜索记录】：${r}`);
    logw(`【查询榜单搜索记录 耗时】：${time()-start_time}`);
    return r
}

function 置顶榜单搜索记录(data) {
    logi('开始执行 -- 【置顶榜单搜索记录】')
    const start_time = time();
    const JSData = JSON.parse(data);

    const postData = {
        zhiding: JSData.zhiding,
        bangdanSid: JSData.bangdanSid
    }
    logw(JSON.stringify(postData));
    const url = `${JSData.url}/zhiding_bd_search`;
    const r = http.postJSON(url, postData,  30 * 1000, {"key-word": "test"});
    logw(`【置顶榜单搜索记录】：${r}`);
    logw(`【置顶榜单搜索记录 耗时】：${time()-start_time}`);
    return r
}

function 删除榜单搜索记录(data) {
    logi('开始执行 -- 【删除榜单搜索记录】')
    logw(data)
    const start_time = time();
    const JSData = JSON.parse(data);
    const url = `${JSData.url}/delete_bd_search`;
    const postData = {
        bangdanSid: JSData.bangdanSid,
    }
    const r = http.postJSON(url, postData,  30 * 1000, {"key-word": "test"});
    logw(`【删除榜单搜索记录】：${r}`);
    logw(`【删除榜单搜索记录 耗时】：${time()-start_time}`);
    return r
}

function 查询榜单搜索记录用户记录(data) {
    logi('开始执行 -- 【查询榜单搜索记录用户记录】')
    const start_time = time();
    const JSData = JSON.parse(data);
    const url = `${JSData.url}/get_bd_search_all_comment?bangdanSid=${encodeURI(JSData.bangdanSid)}`;
    const r = http.httpGet(url, {},  30 * 1000, {"key-word": "test"});
    logw(`【查询榜单搜索记录用户记录】：${r}`);
    logw(`【查询榜单搜索记录用户记录 耗时】：${time()-start_time}`);
    return r
}

function 批量榜单用户记录关注(data) {
    logi('开始执行 -- 【批量榜单用户记录关注】')
    const start_time = time();
    const JSData = JSON.parse(data);
    const url = `${JSData.url}/update_bd_focus_str`;
    const postData = {
        isFollow: JSData.isFollow,
        commentSid: JSData.commentSid,
    }
    logw(JSON.stringify(postData))
    const r = http.postJSON(url, postData,  30 * 1000, {"key-word": "test"});
    logw(`【批量榜单用户记录关注】：${r}`);
    logw(`【批量榜单用户记录关注 耗时】：${time()-start_time}`);
    return r
}