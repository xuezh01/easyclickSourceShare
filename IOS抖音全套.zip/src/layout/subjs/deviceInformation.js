


function 获取设备基础信息() {
    return JSON.stringify({
        device_id: device.getDeviceId(),
        device_server_ok: isServiceOk(),
        device_name: device.getDeviceName(),
        device_version: device.getOSVersion(),
        device_expiration_time: getDeviceExpTime()
    })
}


function 获取设备实时状态() {
    return JSON.stringify({
        device_battery: device.getBattery(),
        device_isCharging: device.isCharging(),
    })
}