
function main() {
    // ui.registeH5Function("queryKWSearchHistory", function (data) {
    //     return 查询关键词搜索记录(data);});
    // ui.registeH5Function("queryBDSearchHistory", function (data) {
    //     return 查询榜单搜索记录(data);});
    //
    // ui.registeH5Function("kwZhiding", function (data) {
    //     return 置顶关键词搜索记录(data)});
    // ui.registeH5Function("kwDeleteSearch", function (data) {
    //     return 删除关键词搜索记录(data)});
    // ui.registeH5Function("queryKWCustomerList", function (data) {
    //     return 查询关键词搜索记录用户记录(data);});
    //
    // ui.registeH5Function("bdZhiding", function (data) {
    //     return 置顶榜单搜索记录(data)});
    // ui.registeH5Function("bdDeleteSearch", function (data) {
    //     return 删除榜单搜索记录(data)});
    // ui.registeH5Function("queryBDCustomerList", function (data) {
    //     return 查询榜单搜索记录用户记录(data);});
    //
    // ui.registeH5Function("followKWCustomer", function (data) {
    //     return 批量关键词用户记录关注(data)
    // });
    //
    // ui.registeH5Function("followBDCustomer", function (data) {
    //     return 批量榜单用户记录关注(data)
    // });
    //
    // ui.registeH5Function("queryAGIConfig", function (data) {
    //     return 自动回复信息配置查询(data)
    // });
    // ui.registeH5Function("saveAGIConfig", function (data) {
    //     return 自动回复信息配置保存(data)
    // });
    //
    // ui.registeH5Function("closeLogWindow", function (data) {
    //     return 日志框关闭()
    // });
    //
    // ui.registeH5Function("getDeviceInformation", function (data) {
    //     return 获取设备基础信息()
    // });
    //
    // ui.registeH5Function("getDeviceNowState", function (data) {
    //     return 获取设备实时状态()
    // });

    ui.registeH5Function("login", function (data) { return login(data) });
    ui.registeH5Function("queryUid", function (data) { return 设备uid查询() });

    ui.layout("登录", "login.html");
}
main();

/* 【关键词搜索】*/



function 日志框关闭(){

    let 关闭结果 = closeLogWindow();
    let tryCount = 3;
    while(!关闭结果 && tryCount>0){
        关闭结果 = closeLogWindow();
        tryCount--;
    }
    logw(`日志框关闭结果: ${关闭结果}`)
    return String(关闭结果);
}


