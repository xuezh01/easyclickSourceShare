
KuaiShou.prototype.ks_用户快手号匹配 = function (快手ID){
    logi('开始执行 - 【ks_用户快手号匹配】')

    const 用户快手号匹配 = {
        name: '用户快手号匹配',
        textArray: ['用户', 快手ID, '快手号', '关注'],
        x: 0,
        y: 210,
        ex: ScreenWidth,
        ey: 450,
        binaryzation: false,
        matchCount: 3
    }
    const 搜索结果 = ocr文本数组匹配(用户快手号匹配);

    return 搜索结果
}

KuaiShou.prototype.ks_进入搜索用户私信页面 = function (){
    logi('开始执行 - 【ks_进入搜索用户私信页面】')

    const 搜索用户位置 = { name: '搜索用户位置', x: random(166,496), y:random(310,410)};
    logi('进入用户作品主页')
    const 进入用户作品主页 = 点击后ocr检测(搜索用户位置, ks.搜索页_搜索结果标签, ks.用户作品主页);
    if(进入用户作品主页 !== 1){
        loge(`【ks_进入搜索用户私信页面】 进入用户作品主页 失败 ${JSON.stringify(搜索用户位置)}`)
        scriptError(`【ks_进入搜索用户私信页面】 进入用户作品主页 失败 ${JSON.stringify(搜索用户位置)}`)
    }

    logi('更多按钮弹出窗')
    const 用户作品主页更多按钮 = { name: '用户作品主页更多按钮', x: random(670,700), y:random(73,93)};
    const 更多按钮弹出窗 = 点击后ocr检测(用户作品主页更多按钮, ks.用户作品主页, ks.更多按钮弹出窗);
    if(更多按钮弹出窗 !== 1){
        loge(`【ks_进入搜索用户私信页面】 更多按钮弹出窗 失败 ${JSON.stringify(用户作品主页更多按钮)}`)
        scriptError(`【ks_进入搜索用户私信页面】 更多按钮弹出窗 失败 ${JSON.stringify(用户作品主页更多按钮)}`)
    }

    const 快手发私信按钮 = findColor(ks.快手发私信按钮);
    if(!快手发私信按钮){
        loge(`【ks_进入搜索用户私信页面】 快手发私信按钮 失败 `)
        scriptError(`【ks_进入搜索用户私信页面】 快手发私信按钮 失败 `)
    }

    const 进入私信页面 = 点击后ocr_图色检测(快手发私信按钮, ks.更多按钮弹出窗, ks.私信页笑脸标识)
    if(进入私信页面 !== 1){
        loge(`【ks_进入搜索用户私信页面】 进入私信页面 失败 ${JSON.stringify(快手发私信按钮)}`)
        scriptError(`【ks_进入搜索用户私信页面】 进入私信页面 失败 ${JSON.stringify(快手发私信按钮)}`)
    }
}


KuaiShou.prototype.ks_退出私信页面 = function () {
    logi('开始执行 - 【ks_退出私信页面】')

    const 退出按钮 = {name: 'ks_退出私信页面', x: random(43,55), y:random(79,97)}
    const 退出私信页结果 = 点击后图色_ocr检测(退出按钮, ks.私信页笑脸标识, ks.用户作品主页);
    if(退出私信页结果 !== 1){
        loge(`【ks_退出私信页面】 退出私信页结果 失败 `)
        scriptError(`【ks_退出私信页面】 退出私信页结果 失败 `)
    }
    const 返回搜索页按钮 = {name: '返回搜索页按钮', x: random(46, 68), y:random(72,95)}
    const 返回搜索页结果 = 点击后ocr检测(返回搜索页按钮, ks.用户作品主页, ks.搜索页_搜索结果标签)
    if(返回搜索页结果 !== 1){
        loge(`【ks_退出私信页面】 返回搜索页结果 失败 `)
        scriptError(`【ks_退出私信页面】 返回搜索页结果 失败 `)
    }
}