KuaiShou.prototype.ks_跟进客户 = function (){
    api_记录风控日志('快手', 快手_获取当前账号的快手ID(), '操作', '跟进客户')
    ks.ks_当前账号_跟进客户()
    ks.ks_切换账号_跟进客户()
}

KuaiShou.prototype.ks_账号统计_切换_初始化 = function (跟进){
    当前执行模块 = 'ks_账号统计_切换_初始化';
    日志打印_warning('开始执行-【ks_账号统计_切换_初始化】')
    ks.初始化()
    while (true){
        if(isScriptExit()) { break }
        if (!ks.ks_首页导航_切换(4)) {
            ks.ks_启动快手()
            continue
        }
        const 当前_账号_快手号_昵称_私信 = ks.ks_我_页面_当前账号信息()
        if(!当前_账号_快手号_昵称_私信) { continue }

        const 当前账号 = {
            choose: true,
            account_id:当前_账号_快手号_昵称_私信.快手号,
            account_name: 当前_账号_快手号_昵称_私信.快手昵称,
            belong_uid: uid,
            account_type: '快手',
            account_state:当前_账号_快手号_昵称_私信.私信功能,
            send_count: 0,
            send_failed_count: 0,
            send_pinfan_count: 0,
            belong_device_id: device_id,
            account_information: '',
        }
        设备账号信息.ks.length = 0
        设备账号信息.ks.push(当前账号)
        if(跟进){
            ks.ks_消息列表统计(3)
            if (!ks.ks_首页导航_切换(4)) { continue }
        }
        let 主页_账号切换_按钮 = findColor(ks.主页_我_切换账号_标识)
        if(!主页_账号切换_按钮) {
            主页_账号切换_按钮 = findColor(ks.主页_我_切换账号_标识_two)
            if(!主页_账号切换_按钮){
                日志打印_information('当前只有一个快手账号！')
                break
            }
        }
        const 弹出切换账号 = 点击后检测(主页_账号切换_按钮, ks.主页_我_页面, [ks.切换账号_底部弹窗, ks.切换账号弹窗_快手账号已选择标识])
        if(弹出切换账号 !== 0 && 弹出切换账号 !== 1){
            日志打印_error('[主页_账号切换_按钮] 寻找失败')
            continue
        }
        if(!ks.ks_切换账号()){ continue }
        const 切换后_账号_抖音号_私信 = ks.ks_我_页面_当前账号信息()
        if(!切换后_账号_抖音号_私信) { continue }
        当前账号.choose = false
        const 切换后账号 = {
            choose: true,
            account_id:切换后_账号_抖音号_私信.快手号,
            account_name: 切换后_账号_抖音号_私信.快手昵称,
            belong_uid: uid,
            account_type: '快手',
            account_state:切换后_账号_抖音号_私信.私信功能,
            send_count: 0,
            send_failed_count: 0,
            send_pinfan_count: 0,
            belong_device_id: device_id,
            account_information: '',
        }
        设备账号信息.ks.length = 0
        设备账号信息.ks.push(当前账号)
        设备账号信息.ks.push(切换后账号)
        break
    }
    日志打印_warning(JSON.stringify(设备账号信息.ks))
    快手_更新账号今日私信()
    return
}

KuaiShou.prototype.ks_当前账号_跟进客户 = function (){
    当前执行模块 = 'ks_当前账号_跟进客户';
    日志打印_warning('开始执行-【ks_当前账号_跟进客户】')
    while (true){
        if(isScriptExit()) { break }
        if (!ks.ks_首页导航_切换(3)) {
            ks.ks_启动快手()
            continue
        }
        ks.ks_消息列表统计(3)
        break
    }
}

KuaiShou.prototype.ks_切换账号_跟进客户 = function (){
    当前执行模块 = 'ks_切换账号_跟进客户';
    日志打印_warning('开始执行-【ks_切换账号_跟进客户】')
    if(设备账号信息.ks.length <= 1){
        日志打印_warning('【快手账号数量不够，无需切换账号】')
        return;
    }
    ks.ks_账号统计_切换_初始化(false)
}

KuaiShou.prototype.ks_消息列表统计 = function (无消息次数=3){
    当前执行模块 = 'ks_消息列表统计';
    日志打印_warning('开始执行-【ks_消息列表统计】')

    function 快手消息列表统计() {
        while (true){
            if(isScriptExit()) {break}
            if (!ks.ks_首页导航_切换(3)) {
                ks.ks_启动快手()
                continue
            }
            ks.ks_消息页_回复私信消息()
            let 消息页截图 = 区域截图base64(0, 1100, ScreenWidth, 800)
            let tryCount = 无消息次数
            while (tryCount > 0){
                if(isScriptExit()) {break}
                ks.ks_消息列表轮询()
                ks.ks_返回_设定页面(ks.消息页_右上角_说说_搜索_标识)
                点击(ks.底部导航_消息_按钮)
                iSleep(1000)
                const 点击后_消息页截图 = 区域截图base64(0, 1100, ScreenWidth, 800)
                if(点击后_消息页截图 !== 消息页截图){
                    消息页截图 = 点击后_消息页截图
                    tryCount = 无消息次数
                }else {
                    tryCount--
                }
                if(tryCount <= 0 ){
                    break
                }
            }
            break
        }
    }
    抖音_更新当前账号跟进列表()
    快手消息列表统计()
}

KuaiShou.prototype.ks_消息列表轮询 = function () {
    当前执行模块 = 'ks_消息列表轮询';
    日志打印_warning('开始执行-【ks_消息列表轮询】')

    const 消息列表_未读标识_数字 = findColor(ks.消息列表_未读标识_数字)
    if(消息列表_未读标识_数字){
        const 进入页面 = 点击后检测(消息列表_未读标识_数字, ks.消息页_右上角_说说_搜索_标识, [ks.私信页笑脸标识, ks.消息页_新增粉丝_title, ks.消息页_互动消息_title])
        switch (进入页面) {
            case -1:
                return
            case -100:
                return
            case 0:
                return ks.ks_消息列表_私信消息_记录()
            case 1:
                return ks.ks_消息列表_新增粉丝_记录()
            case 2:
                return ks.ks_消息列表_互动消息_记录()

        }
    }
}

KuaiShou.prototype.ks_页面右滑 = function () {
    日志打印_warning('开始执行-【ks_页面右滑】')
    滑动(random(4, 15), random(460,600), ScreenWidth, random(460,600), 200);
}

KuaiShou.prototype.ks_返回_设定页面 = function (设定页面) {
    function 返回结果判定() {
        if (设定页面.hasOwnProperty('textArray')){
            if(ocr文本数组匹配(设定页面)) {
                日志打印_information(`成功 返回_设定页面: ${设定页面.name}`)
                return true
            }
        }else {
            if(findColor(设定页面)) {
                日志打印_information(`成功 返回_设定页面: ${设定页面.name}`)
                return true
            }
        }
        if(ocr文本数组匹配(ks.首页_底部导航) && !findColor(ks.私信页笑脸标识)){
            return true
        }
        if(ocr文本数组匹配(ks.账号左侧弹窗)){
            return true
        }
        return false
    }
    while (true){
        if(isScriptExit()) {break}
        日志打印_information('正在执行- 【返回_互动消息页面】')

        if(返回结果判定()){ return  }
        else {
            const 滑动前 = 区域截图base64(0, 800, ScreenWidth, ScreenHeight)
            ks.ks_页面右滑()
            iSleep(300)
            if(返回结果判定()){ return  }
            const 滑动后 = 区域截图base64(0, 800, ScreenWidth, ScreenHeight)
            if(滑动前 === 滑动后){
                if(返回结果判定()){ return  }
                点击(ks.用户主页_返回按钮)
            }
            iSleep(300)
            if(返回结果判定()){ return  }
        }


    }
}

KuaiShou.prototype.ks_消息列表_私信消息_记录 = function () {
    日志打印_warning('开始执行-【ks_消息列表_私信_消息记录】')

    const 用户信息 = ks.ks_获取聊天页用户昵称()
    if(!用户信息) { return }
    const 进入私信用户主页 = 点击后检测(用户信息, ks.私信页笑脸标识, [ks.用户作品主页])
    if(进入私信用户主页 !== 0){ return }
    const 用户主页信息 = ks.ks_用户主页_信息()
    if(!用户主页信息){ return }
    const 返回私信页面 = 点击后检测(ks.用户主页_返回按钮, ks.用户作品主页, [ks.私信页笑脸标识]);
    if(返回私信页面 !== 0){ return }
    logw(`${用户信息.name} -- ${用户主页信息.快手ID}`)
    let 记录数据 = null
    if (脚本运行配置.ai_config.state){
        // 接入ai自动回复
        const 聊天记录 = ks.ks_节点获取聊天记录(用户信息.name)
        const replay = 请求AI回复(快手_获取当前账号的快手ID(), 用户主页信息.快手ID, 用户信息.name, 聊天记录)
        if (replay){
            ks.ks_发送私信(replay)
            记录数据 = {
                "belong_uid": uid,
                "belong_device_id": device_id,
                "belong_app_account_id": 快手_获取当前账号的快手ID(),
                "belong_app_account_type": "快手",
                "follow_type": 'AI 自动回复',
                "follow_customer_name": 用户信息.name,
                "follow_customer_id": 用户主页信息.快手ID,
                "follow_customer_comment": '',
                "follow_img": 区域截图base64()
            }
        }
    }
    if(!记录数据){
        记录数据 = {
            "belong_uid": uid,
            "belong_device_id": device_id,
            "belong_app_account_id": 快手_获取当前账号的快手ID(),
            "belong_app_account_type": "快手",
            "follow_type": '消息列表私信',
            "follow_customer_name": 用户信息.name,
            "follow_customer_id": 用户主页信息.快手ID,
            "follow_customer_comment": '',
            "follow_img": 区域截图base64()
        }
    }

    api_记录跟进用户(记录数据)
    return
}

KuaiShou.prototype.ks_消息列表_新增粉丝_记录 = function () {
    日志打印_warning('开始执行-【ks_消息列表_新增粉丝_记录】')

    let 检测次数 = 3
    while (检测次数 > 0){
        if(isScriptExit()) { break }
        ks.ks_返回_设定页面(ks.消息页_新增粉丝_title)
        const 新增粉丝 = findColor(ks.新增粉丝_左侧_未读小圆点)
        if (新增粉丝){
            检测次数 = 3
            const y = 新增粉丝.min_y - 80
            const ey = 新增粉丝.max_y + 80
            const 新增粉丝截图 = 区域截图base64(0, y, ScreenWidth, ey)
            新增粉丝.x = 新增粉丝.x + 80
            const 进入新增粉丝主页 = 点击后检测(新增粉丝, ks.消息页_新增粉丝_title, [ks.用户作品主页])
            if(进入新增粉丝主页 !== 0) { continue }
            const 粉丝信息 = ks.ks_用户主页_信息()
            if(!粉丝信息) { continue }
            const 记录数据 = {
                "belong_uid": uid,
                "belong_device_id": device_id,
                "belong_app_account_id": 快手_获取当前账号的快手ID(),
                "belong_app_account_type": "快手",
                "follow_type": '关注我的用户',
                "follow_customer_name": 粉丝信息.名称,
                "follow_customer_id": 粉丝信息.快手ID,
                "follow_img": 新增粉丝截图,
            }
            // api_记录跟进用户(记录数据)
        }else {
            const startY = random(400, 700)
            滑动(random(6,30), startY, random(6,30), startY-250, 1200)
            检测次数--
        }
    }
}

KuaiShou.prototype.ks_消息列表_互动消息_记录 = function () {
    日志打印_warning('开始执行-【ks_消息列表_互动消息_记录】')

    let 检测次数 = 3
    while (检测次数 > 0){
        if(isScriptExit()) { break }
        ks.ks_返回_设定页面(ks.消息页_互动消息_title)
        const 互动消息 = findColor(ks.新增粉丝_左侧_未读小圆点)
        if (互动消息){
            检测次数 = 3
            const y = 互动消息.min_y - 80
            const ey = 互动消息.max_y + 80
            const 互动消息截图 = 区域截图base64(0, y, ScreenWidth, ey)
            互动消息.x = 互动消息.x + 80
            const 进入互动消息用户主页 = 点击后检测(互动消息, ks.消息页_互动消息_title, [ks.用户作品主页])
            if(进入互动消息用户主页 !== 0) { continue }
            const 互动消息用户信息 = ks.ks_用户主页_信息()
            if(!互动消息用户信息) { continue }
            const 记录数据 = {
                "belong_uid": uid,
                "belong_device_id": device_id,
                "belong_app_account_id": 快手_获取当前账号的快手ID(),
                "belong_app_account_type": "快手",
                "follow_type": '互动消息',
                "follow_customer_name": 互动消息用户信息.名称,
                "follow_customer_id": 互动消息用户信息.快手ID,
                "follow_img": 互动消息截图,
            }
            // api_记录跟进用户(记录数据)
        }else {
            const startY = random(400, 700)
            滑动(random(6,30), startY, random(6,30), startY-250, 1200)
            检测次数--
        }
    }
}

KuaiShou.prototype.ks_消息页_回复私信消息 = function () {
    日志打印_warning('开始执行-【ks_消息页_回复私信消息】')

    if(ks.当前账号_私信跟进列表.length > 0){
        let 消息页_右上角搜索_放大镜 = findColor(ks.消息页_右上角_搜索按钮)
        while (!消息页_右上角搜索_放大镜){
            if(isScriptExit()) {break}
            if (!ks.ks_首页导航_切换(3)) {
                ks.ks_启动快手()
                continue
            }
            消息页_右上角搜索_放大镜 = findColor(ks.消息页_右上角_搜索按钮)
            if(!消息页_右上角搜索_放大镜 ){
                setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
                let 搜索_节点 = type("Button").label('查找').getOneNodeInfo(10000)
                if(搜索_节点){
                    消息页_右上角搜索_放大镜 = { name: '消息页_右上角搜索_放大镜', x: 搜索_节点.bounds.left/2+搜索_节点.bounds.right/2, y:搜索_节点.bounds.bottom/2+搜索_节点.bounds.top/2}
                }
            }
        }
        const 进入消息搜索 = 点击后检测(消息页_右上角搜索_放大镜, ks.消息页_顶部标题, [ks.消息页_左上角_搜索输入框标识])
        if(进入消息搜索 !== 0) { return ks.ks_消息页_回复私信消息() }

        while (ks.当前账号_私信跟进列表.length > 0){
            if(isScriptExit()) {break}
            ks.ks_返回_设定页面(ks.消息页_左上角_搜索输入框标识)

            const 打开键盘 = 点击后检测(ks.消息列表_搜索页_顶部输入框, ks.消息页_左上角_搜索输入框标识, [ios.键盘弹出])
            if(打开键盘 !== 0) { return ks.ks_消息页_回复私信消息() }
            const 回复内容 = ks.当前账号_私信跟进列表[0]
            ks.当前账号_私信跟进列表.shift()
            文本内容输入(回复内容.customer_name, ks.消息列表_搜索页_顶部输入框)
            键盘发送()
            // 只能单点找色
            const 搜索结果_红色 = {
                name: `${回复内容.customer_name}`,
                firstColor: ["#FD3865","#101010"],
                x: 140,
                y: 240,
                ex: 450,
                ey: 400,
                orz: 1
            }
            const 用户位置 = 单点找色(搜索结果_红色)
            if(!用户位置){ continue }
            const 进入用户私信 = 点击后检测(用户位置, ks.消息页_左上角_搜索输入框标识, [ks.私信页笑脸标识])
            if(进入用户私信 !== 0) { return ks.ks_消息页_回复私信消息() }
            ks.ks_发送私信(回复内容.replay_msg)
            const 回复截图 = 区域截图base64()
            const 任务执行成功 = {
                "task_id": 回复内容.id,
                "focus_customer_record_id":回复内容.focus_customer_record_id,
                "task_state": 2
            }
            api_跟进任务执行成功(任务执行成功)
            const 记录数据 = {
                "belong_uid": uid,
                "belong_device_id": device_id,
                "belong_app_account_id": 快手_获取当前账号的快手ID(),
                "belong_app_account_type": "快手",
                "follow_type": '人工回复私信',
                "follow_customer_name": 回复内容.customer_name,
                "follow_customer_id": 回复内容.customer_id,
                "follow_customer_comment": 回复内容.customer_comment,
                "lats_id": 回复内容.focus_customer_record_id,
                "follow_img": 回复截图,
            }
            api_记录跟进用户(记录数据)
        }
        ks.ks_返回_设定页面(ks.消息页_左上角_搜索输入框标识)
    }
}
