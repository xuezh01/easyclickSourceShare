/**
 * @description  快手弹窗处理
 */

KuaiShou.prototype.快手弹窗检测 = function (ocr内容,start_time){
    if(快手新人福利弹窗(ocr内容)){
        logw(`====【ocr处理弹窗】耗时：${time()-start_time} =========`)
        return true
    }
    if(快手新人签到(ocr内容)){
        logw(`====【ocr处理弹窗】耗时：${time()-start_time} =========`)
        return true
    }
    if(快手红包任务中心(ocr内容)){
        logw(`====【ocr处理弹窗】耗时：${time()-start_time} =========`)
        return true
    }
    if (快手推送通知弹窗(ocr内容)){
        logw(`====【ocr处理弹窗】耗时：${time()-start_time} =========`)
        return true
    }
    if (快手看视频限时弹窗(ocr内容)){
        logw(`====【ocr处理弹窗】耗时：${time()-start_time} =========`)
        return true
    }
    if (快手默认静音弹窗(ocr内容)){
        logw(`====【ocr处理弹窗】耗时：${time()-start_time} =========`)
        return true
    }
    if (快手朋友推荐弹窗(ocr内容)){
        logw(`====【ocr处理弹窗】耗时：${time()-start_time} =========`)
        return true
    }
    if (挂件功能弹窗(ocr内容)){
        logw(`====【ocr处理弹窗】耗时：${time()-start_time} =========`)
        return true
    }
    if (ks客服聊天弹窗(ocr内容)){
        logw(`====【ocr处理弹窗】耗时：${time()-start_time} =========`)
        return true
    }
    return false
}


快手挂件功能 = {
    name: '挂件功能',
    textArray: ['挂件功能', '去领取', '挑选喜欢的挂件'],
    matchCount: 2
}
function 挂件功能弹窗(ocr内容) {
    let 出现挂件功能弹窗 = 弹窗匹配结果(ocr内容, 快手挂件功能)
    if (出现挂件功能弹窗) {
        logd('【处理弹窗】 ====挂件功能弹窗=========')
        const 关闭出现挂件功能弹窗 = {name: '关闭出现挂件功能弹窗', x: random(660, 670), y: random(860, 870)};
        点击(关闭出现挂件功能弹窗);
        return true
    }
    return false
}



快手新人福利 = {
    name: '快手新人福利弹窗',
    textArray: ['新人福利', '立即领取'],
    matchCount: 2
}
function 快手新人福利弹窗(ocr内容) {
    let 出现快手新人福利弹窗 = 弹窗匹配结果(ocr内容, 快手新人福利)
    if (出现快手新人福利弹窗) {
        logd('【处理弹窗】 ====快手新人福利弹窗=========')
        const 关闭快手新人福利弹窗 = {name: '关闭快手新人福利弹窗', x: random(654, 676), y: random(164, 186)};
        点击(关闭快手新人福利弹窗);
        return true
    }
    return false
}

ks新人签到 = {
    name: '快手新人签到',
    textArray: ['立即签到', '今日签到可领','第2天'],
    matchCount: 3
}
function 快手新人签到(ocr内容) {
    let 出现快手新人签到弹窗 = 弹窗匹配结果(ocr内容, ks新人签到)
    if (出现快手新人签到弹窗) {
        logd('【处理弹窗】 ====快手新人签到弹窗=========')
        const 关闭快手新人签到弹窗 = {name: '关闭快手新人签到弹窗', x: random(676, 712), y: random(150, 177)};
        点击(关闭快手新人签到弹窗);
        return true
    }
    return false
}
ks客服 = {
    name: 'ks客服',
    textArray: ['快手客服', '系统自动提醒', '在线对话', '服务进行评价', '解决您的问题', '本次服务已结束', '智能客服'],
    matchCount: 4
}
function ks客服聊天弹窗(ocr内容) {
    let 出现ks客服聊天弹窗 = 弹窗匹配结果(ocr内容, ks客服)
    if (出现ks客服聊天弹窗) {
        logd('【处理弹窗】 ====ks客服聊天弹窗=========')
        const 关闭出现ks客服聊天弹窗 = {name: '关闭出现ks客服聊天弹窗', x: random(40, 55), y: random(105, 128)};
        点击(关闭出现ks客服聊天弹窗);
        return true
    }
    return false
}

ks朋友推荐 = {
    name: '朋友推荐',
    textArray: ['朋友推荐', '可能认识', '共同朋友'],
    matchCount: 2
}
function 快手朋友推荐弹窗(ocr内容) {
    let 出现快手朋友推荐弹窗 = 弹窗匹配结果(ocr内容, ks朋友推荐)
    if (出现快手朋友推荐弹窗) {
        logd('【处理弹窗】 ====快手朋友推荐弹窗=========')
        const 关闭快手新人签到弹窗 = {name: '关闭快手朋友推荐弹窗', x: random(636, 656), y: random(272, 292)};
        点击(关闭快手新人签到弹窗);
        return true
    }
    return false
}

ks红包任务中心 = {
    name: 'ks红包任务中心',
    textArray: ['任务中心','我的金币','我的现金','日常任务'],
    matchCount: 3
}
function 快手红包任务中心(ocr内容) {
    let 出现快手红包任务中心误触 = 弹窗匹配结果(ocr内容, ks红包任务中心)
    if (出现快手红包任务中心误触) {
        logd('【处理弹窗】 ====出现快手红包任务中心误触=========')
        const 关闭出现快手红包任务中心误触 = {name: '关闭出现快手红包任务中心误触', x: random(30, 45), y: random(62, 94)};
        点击(关闭出现快手红包任务中心误触);
        var 快手红包按钮 = findColor(ks.快手红包按钮左半屏)
        if (!快手红包按钮){
            快手红包按钮 = findColor(ks.快手红包按钮右半屏)
            if (快手红包按钮){
                滑动(快手红包按钮.x,快手红包按钮.y,0,快手红包按钮.y,500)
            }
        }else {
            滑动(快手红包按钮.x,快手红包按钮.y,750,快手红包按钮.y,500)
        }
        return true
    }
    return false
}

ks推送通知 = {
    name: 'ks推送通知',
    textArray: ['推送通知', '开启通知'],
    matchCount: 2
}
function 快手推送通知弹窗(ocr内容) {
    let 出现快手推送通知弹窗 = 弹窗匹配结果(ocr内容, ks推送通知)
    if (出现快手推送通知弹窗) {
        logd('【处理弹窗】 ====快手推送通知弹窗=========')
        const 关闭快手推送通知弹窗 = {name: '关闭快手新人签到弹窗', x: random(118, 145), y: random(400, 428)};
        点击(关闭快手推送通知弹窗);
        return true
    }
    return false
}

ks限时奖励 = {
    name: 'ks限时奖励',
    textArray: ['看视频领取', '限时','可提现'],
    matchCount: 2
}
function 快手看视频限时弹窗(ocr内容) {
    let 出现快手看视频限时弹窗 = 弹窗匹配结果(ocr内容, ks限时奖励)
    if (出现快手看视频限时弹窗) {
        logd('【处理弹窗】 ====快手看视频限时弹窗=========')
        const 关闭快手看视频限时弹窗 = {name: '关闭快手看视频限时弹窗', x: random(666, 689), y: random(180, 201)};
        点击(关闭快手看视频限时弹窗);
        return true
    }
    return false
}

ks开启快手时默认静音弹窗 = {
    name: 'ks开启快手时默认静音弹窗',
    textArray: ['默认静音', '设置','无声进入'],
    matchCount: 2
}
function 快手默认静音弹窗(ocr内容) {
    let 出现快手默认静音弹窗 = 弹窗匹配结果(ocr内容, ks开启快手时默认静音弹窗)
    if (出现快手默认静音弹窗) {
        logd('【处理弹窗】 ====快手快手默认静音弹窗=========')
        const 关闭快手默认静音弹窗 = {name: '关闭快手默认静音弹窗', x: random(126, 310), y: random(1150, 1222)};
        点击(关闭快手默认静音弹窗);
        return true
    }
    return false
}
