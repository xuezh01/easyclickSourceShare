

KuaiShou.prototype.ks_右上角搜索按钮点击 = function (){
    logi('开始执行 - 【右上角搜索按钮点击】');

    const 首页右上角搜索按钮 = {name: '右上角搜索按钮点击', x: random(678, 700), y:random(69, 92)}
    const 进入搜索页面 = 点击后ocr检测(首页右上角搜索按钮, ks.首页_底部导航, ks.搜索页_搜索);
    if(进入搜索页面 !== 1){
        loge('【右上角搜索按钮点击】进入搜索页面失败！')
        scriptError('【右上角搜索按钮点击】进入搜索页面失败！')
    }
}

KuaiShou.prototype.ks_话题播放量排序 = function (){
    logi(`开始执行 - 【ks_话题播放量排序】`);
    iSleep(1000);
    const node = type("CollectionView").getOneNodeInfo(10000)
    if(!node){
        return this.ks_话题播放量排序()
    }
    const 话题排序 = []
    const cells = node.allChildren()
    for (const i in cells){
        if(isScriptExit()){ break }

        const cell = cells[i];
        if (cell.type !== 'Cell'){
            continue;
        }
        if(cell.bounds.top < node.bounds.top || cell.bounds.bottom > node.bounds.bottom){
            continue;
        }
        const 话题 = cell.child(0).child(1).name;
        const 播放量 = cell.child(0).child(3).name;

        const js = {name: 话题, '播放量': 播放量, x: cell.bounds.left/2 + cell.bounds.right/2, y: cell.bounds.top/2 + cell.bounds.bottom/2};
        话题排序.push(js);
        logi(JSON.stringify(js))
    }
    话题排序.sort((a, b) => {
        const parsePlayCount = (str) => {
            if (str.includes('亿次播放')) {
                return parseFloat(str.replace('亿次播放', '')) * 100000000;
            } else if (str.includes('万次播放')) {
                return parseFloat(str.replace('万次播放', '')) * 10000;
            } else {
                return parseFloat(str) || 0;
            }
        };
        const playCountA = parsePlayCount(a['播放量']);
        const playCountB = parsePlayCount(b['播放量']);
        return playCountB - playCountA;
    });
    return 话题排序
}

KuaiShou.prototype.ks_话题栏上滑刷新话题 = function () {
    滑动(random(212,458), 1200, random(212,458), 450, 500);
    while(!屏幕区域变化检测(200, 212, 450, 458, 1200)){
        if(isScriptExit()){break }
        sleep(100);
    }
}

KuaiShou.prototype.ks_进入话题详情页 = function (话题) {
    logi(`开始执行 - 【ks_进入话题视频播放页面】`);

    const 进入结果 = 点击后ocr检测(话题, ks.搜索页_话题收藏, ks.话题页_话题导航)
    if(进入结果 !== 1){
        loge(`【ks_进入话题视频播放页面】 进入失败- ${JSON.stringify(话题)}`)
        return false
    }
    return true
}

KuaiShou.prototype.ks_返回话题搜索页 = function () {
    logi(`开始执行 - 【ks_返回话题搜索页】`);

    const 视频播放关闭按钮 = {name: '视频播放关闭按钮', x:random(42,49), y:random(80, 90)}
    const 关闭视频播放 = 点击后图色_ocr检测(视频播放关闭按钮, ks.快手视频关注按钮, ks.话题页_话题导航)
    if(关闭视频播放 !== 1){
        loge(`【ks_返回话题搜索页】 关闭视频播放失败- ${JSON.stringify(视频播放关闭按钮)}`)
        scriptError(`【ks_返回话题搜索页】 关闭视频播放失败- ${JSON.stringify(视频播放关闭按钮)}`)
    }
    const 返回话题导航 = 点击后ocr检测(视频播放关闭按钮, ks.话题页_话题导航, ks.搜索页_话题收藏)
    if(返回话题导航 !== 1){
        loge(`【ks_返回话题搜索页】 返回话题导航失败- ${JSON.stringify(视频播放关闭按钮)}`)
        scriptError(`【ks_返回话题搜索页】 返回话题导航失败- ${JSON.stringify(视频播放关闭按钮)}`)
    }
}

KuaiShou.prototype.ks_选择最新 = function () {
    logi(`开始执行 - 【ks_进入话题视频播放页面】`);
    iSleep(1000)
    let node = type("Button").label('最新').getOneNodeInfo(10000)
    if(!node){
        return this.ks_选择最新()
    }
    const 最新按钮 = {name: '话题最新按钮',  x: node.bounds.left/2 + node.bounds.right/2, y: node.bounds.top/2 + node.bounds.bottom/2};
    const 最新按钮点击结果 = 点击屏幕检测(最新按钮, 2000,20, 750, 650, 1000)
    if(!最新按钮点击结果){
        loge(`【ks_选择最新】 最新按钮点击 失败- ${JSON.stringify(最新按钮)}`)
        scriptError(`【ks_选择最新】 最新按钮点击 失败- ${JSON.stringify(最新按钮)}`)
    }
    const 话题页_最新_无相关内容 = ocr文本数组匹配(ks.话题页_最新_无相关内容);
    if(话题页_最新_无相关内容){
        const 话题关闭按钮 = {name: '视频播放关闭按钮', x:random(42,49), y:random(80, 90)}
        const 返回话题导航 = 点击后ocr检测(话题关闭按钮, ks.话题页_话题导航, ks.搜索页_话题收藏)
        if(返回话题导航 !== 1){
            loge(`【ks_返回话题搜索页】 返回话题导航失败- ${JSON.stringify(话题关闭按钮)}`)
            scriptError(`【ks_返回话题搜索页】 返回话题导航失败- ${JSON.stringify(话题关闭按钮)}`)
        }
        return false
    }
    const 第一个视频位置 = {name: '话题最新第一个视频位置', x: node.bounds.left, y: node.bounds.bottom+150};
    const 进入视频播放页面 = 点击后ocr_图色检测(第一个视频位置, ks.话题页_话题导航, ks.快手视频关注按钮)
    if(进入视频播放页面 !== 1){
        loge(`【ks_选择最新】 进入视频播放页面 失败- ${JSON.stringify(第一个视频位置)}`)
        scriptError(`【ks_选择最新】 进入视频播放页面 失败- ${JSON.stringify(第一个视频位置)}`)
    }
    return true
}












KuaiShou.prototype.ks_节点获取快手ID = function (maxTry = 5){
    logi('开始执行 - 【ks_节点获取快手ID】')
    if(maxTry <= 0){
        return null
    }
    iSleep(500);
    const node = type('Button').name("快手号：").getOneNodeInfo(10000);
    if(!node){
        loge(`【ks_节点获取快手ID】-[快手号：] 获取失败`)
        return this.ks_节点获取快手ID(maxTry-1)
    }
    const id_node = node.previousSiblings()[0];
    if(!id_node){
        loge(`【ks_节点获取快手ID】-${JSON.stringify(node)}`)
        return this.ks_节点获取快手ID(maxTry-1)
    }
    logd(`快手号: ${id_node.name}`)
    logd(`快手号: ${JSON.stringify(id_node)}`)
    return id_node.label
}

let count = 0
KuaiShou.prototype.ks_视频精准度判断 = function (视频标题,关键词){
    if (count > 3){return}
    logi('视频标题:{},关键词:{}',JSON.stringify(视频标题),关键词)
    var params = {
        "api_key":"",
        "api_base":"",
        "videoContent": 视频标题['name'],
        "keyword": 关键词,
        "hangye": "债务重组"
    }
    var return_shipin = 视频判断(params)
    let 视频结果 = ''
    if (return_shipin !== null && !视频结果){
        视频结果 = return_shipin['job']['videoFilte']
        logi('[视频为结果:{}]视频标题为:{}',JSON.stringify(视频结果),JSON.stringify(视频标题))
        if (视频结果 !== undefined && 视频结果 !== 'true' && 视频结果 !== true){
            this.ks_上滑切换视频();
            iSleep(2000);
            return this.ks_视频精准度判断(视频标题,关键词, count+1)
        }else if (视频结果 === 'true' || 视频结果 === true) {
            return true
        }
    }else {
        logi('服务器请求失败或视频不精准,视频内容为:{},服务器请求为:{}',视频标题,return_shipin)
        return false
    }
}

