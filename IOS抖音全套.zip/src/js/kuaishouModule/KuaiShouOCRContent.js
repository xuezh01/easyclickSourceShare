KuaiShou.prototype.ocr内容初始化 = function () {
    KuaiShou.prototype.首页_底部导航 = {
        name: '首页_底部导航',
        textArray: ['首页', '精选', '消息', '茸页'],
        x: 0,
        y: 1200,
        ex: ScreenWidth,
        ey: ScreenHeight,
        binaryzation: false,
        matchCount: 1
    }
    KuaiShou.prototype.首页_底部导航_二值化 = {
        name: '首页_底部导航_二值化',
        textArray: ['首页','精选', '消息', '茸页'],
        x: 0,
        y: 1200,
        ex: ScreenWidth,
        ey: ScreenHeight,
        binaryzation: true,
        matchCount: 1
    }
    KuaiShou.prototype.首页_底部导航_首页选中_二值化 = {
        name: '首页_底部导航_首页选中_二值化',
        textArray: ['首页', '茸页'],
        x: 0,
        y: 1200,
        ex: 150,
        ey: ScreenHeight,
        binaryzation: true,
        matchCount: 1
    }
    KuaiShou.prototype.首页_顶部导航 = {
        name: '首页_顶部导航',
        textArray: ['商城','关注', '发现', '同城', '探索'],
        x: 0,
        y: 40,
        ex: ScreenWidth,
        ey: 140,
        binaryzation: true,
        matchCount: 2
    }
    KuaiShou.prototype.消息页_顶部标题 = {
        name: '首页_顶部导航',
        textArray: ['消息'],
        x: 280,
        y: 40,
        ex: 480,
        ey: 120,
        binaryzation: false,
        matchCount: 1
    }
    KuaiShou.prototype.主页_我_页面 = {
        name: '主页_我_页面',
        textArray: ['快手小店', '添加朋友', '私密', '常访问的人', '购物团', '完善资料', '勋章', '添加年龄标签', '添加亲密关系', '编辑资料'],
        x: 0,
        y: 310,
        ex: ScreenWidth,
        ey: 1240,
        binaryzation: false,
        matchCount: 3
    }
    KuaiShou.prototype.切换账号_底部弹窗 = {
        name: '切换账号_底部弹窗',
        textArray: ['切换账号', '粉丝', '朋友'],
        x: 140,
        y: 940,
        ex: 480,
        ey: ScreenHeight,
        binaryzation: false,
        matchCount: 2
    }

    KuaiShou.prototype.搜索页_搜索 = {
        name: '搜索页_搜索',
        textArray: ['搜索'],
        x: 500,
        y: 40,
        ex: ScreenWidth,
        ey: 130,
        binaryzation: false,
        matchCount: 1
    }

    KuaiShou.prototype.搜索页_搜索结果标签 = {
        name: '搜索页_搜索结果标签',
        textArray: ['综合', '群聊', '用户', '直播','商品','视频','图片','用户','话题','团购','音乐'],
        x: 0,
        y: 40,
        ex: ScreenWidth,
        ey: 250,
        binaryzation: false,
        matchCount: 2
    }
    KuaiShou.prototype.评论区_title = {
        name: '评论区_title',
        textArray: ['条评论'],
        x: 210,
        y: 40,
        ex: 570,
        ey: 480,
        binaryzation: false,
        matchCount: 1
    }
    KuaiShou.prototype.视频评论区_误触内容 = {
        name: '视频评论区_误触内容',
        textArray: ['123', '空格', '搜索', 'space', 'search', '分享给朋友', '复制评论', '举报评论', '分享到微信', '智能配梗图'],
        x: 0,
        y: 40,
        ex: ScreenWidth,
        ey: ScreenHeight,
        binaryzation: false,
        matchCount: 1
    }

    KuaiShou.prototype.搜索页_话题收藏 = {
        name: '搜索页_话题收藏',
        textArray: ['收藏'],
        x: 580,
        y: 220,
        ex: ScreenWidth,
        ey:ScreenHeight,
        binaryzation: false,
        matchCount: 1
    }

    KuaiShou.prototype.话题页_话题导航 = {
        name: '搜索页_话题收藏',
        textArray: ['大家都在搜', '热门','最新','图片','直播', '执门'],
        x: 0,
        y: 136,
        ex: ScreenWidth,
        ey:700,
        binaryzation: false,
        matchCount: 2
    }
    KuaiShou.prototype.话题页_最新_无相关内容 = {
        name: '话题页_最新_无相关内容',
        textArray: ['无相关内容', '无相关'],
        x: 0,
        y: 650,
        ex: ScreenWidth,
        ey:ScreenHeight,
        binaryzation: false,
        matchCount: 1
    }

    KuaiShou.prototype.用户作品主页 = {
        name: '用户作品主页',
        textArray: ['获赞', '粉丝', '关注', '快手号'],
        x: 0,
        y: 220,
        ex: ScreenWidth,
        ey: 600,
        binaryzation: false,
        matchCount: 2
    }

    KuaiShou.prototype.视频评论区_误触内容 = {
        name: '视频评论区_误触内容',
        textArray: ['123', '空格', '搜索', 'space', 'search', '回复给', '发送', '发条有爱', '发图片评论', '举报评论', '复制评论', '分享给朋友'],
        x: 0,
        y: 40,
        ex: ScreenWidth,
        ey: ScreenHeight,
        binaryzation: false,
        matchCount: 1
    }

    KuaiShou.prototype.更多按钮弹出窗 = {
        name: '更多按钮弹出窗',
        textArray: ['快手号', '分享主页', '发私信', '举报', '拉黑'],
        x: 0,
        y: 700,
        ex: ScreenWidth,
        ey: ScreenHeight,
        binaryzation: true,
        matchCount: 4
    }

    KuaiShou.prototype.消息页_新增粉丝_title = {
        name: '消息页_新增粉丝_title',
        textArray: ['新增', '粉丝', '推荐', '朋友'],
        x: 0,
        y: 40,
        ex: ScreenWidth,
        ey: 150,
        binaryzation: false,
        matchCount: 2
    }

    KuaiShou.prototype.消息页_互动消息_title = {
        name: '消息页_互动消息_title',
        textArray: ['互动消息', '全部消息', '我的', '评论', '点赞'],
        x: 0,
        y: 40,
        ex: ScreenWidth,
        ey: 240,
        binaryzation: false,
        matchCount: 2
    }

    KuaiShou.prototype.账号左侧弹窗 = {
        name: '账号左侧弹窗',
        textArray: ['历史记录', '创作者中心', '设置', '草稿箱', '我的钱包', '小程序', '青少年模式', '官方客服', '内容偏好', '离线模式', '稍后再看', '举报中心', '扫一扫', '快手小店', '系统消息', '常用功能'],
        x: 0,
        y: 40,
        ex: ScreenWidth,
        ey: ScreenHeight,
        binaryzation: false,
        matchCount: 4
    }
}