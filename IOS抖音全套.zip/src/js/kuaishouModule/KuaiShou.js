function KuaiShou() {
}

const ks = new KuaiShou()
ks.底部导航_首页_按钮 = {name: '底部导航_首页_按钮', x: random(46, 106), y:random(1272,1306)}
ks.底部导航_消息_按钮 = {name: '底部导航_消息_按钮', x: random(495, 555), y:random(1272,1306)}
ks.底部导航_精选_按钮 = {name: '底部导航_精选_按钮', x: random(196, 252), y:random(1272,1306)}
ks.底部导航_我_按钮 = {name: '底部导航_我_按钮', x: random(658, 690), y:random(1272,1300)}
ks.首页_右上角_搜索按钮 = {name: '首页_右上角_搜索按钮', x: random(679, 696), y:random(72,90)}
ks.搜索页面_搜索输入框_按钮 = {name: '搜索页面_搜索输入框_按钮', x: random(180, 350), y:random(65,95)}
ks.用户主页_返回按钮 = {name: '搜索页面_搜索输入框_按钮', x: random(50, 60), y:random(78,86)}
ks.评论区_输入框 = {name: '评论区_输入框', x: random(200, 400), y:random(1270,1300)}
ks.消息列表_搜索页_顶部输入框 = {name: '消息列表_搜索页_顶部输入框', x: random(200, 400), y:random(88,110)}
ks.关键词已无视频 = false
ks.搜索时间 = null
ks.私信已发送列表 = []
ks.当前账号_私信跟进列表 = []
ks.当前账号_评论跟进列表 = []

KuaiShou.prototype.初始化 = function (){
    ks.图色初始化()   // 初始化预设的图色标识
    ks.ocr内容初始化()   // 初始化预设的ocr内容

    // douyin.初始化ocr()  // ocr 初始化
    laoleng.EC.init(1)
    laoleng.EC.initOcr()
    laoleng.EC.initNode()

    return true
}

KuaiShou.prototype.ks_启动快手 = function (){
    当前执行模块 = 'ks_启动快手';
    日志打印_debug('开始执行 -- 【ks_启动快手】')
    appBundleId = null;
    let 关闭结果 = appKillByBundleId('com.jiangjia.gif', '1');
    let 重试次数 = 3;
    while(关闭结果 && 重试次数>0){
        if(isScriptExit()){break}
        sleep(100);
        关闭结果 = appKillByBundleId('com.jiangjia.gif', '1');
        重试次数--;
    }
    iSleep(100);
    home();  //返回主页面
    iSleep(100);
    let 快手App = findColor(ks.快手App);
    重试次数 = 3;
    while(!快手App && 重试次数 > 0){
        if(isScriptExit()) {break}
        home();  //返回主页面
        iSleep(100);
        快手App = findColor(ks.快手App);
        重试次数--;
    }
    if(!快手App){
        日志打印_error('抖音App 寻找失败！')
        return false
    }
    const 快手启动结果 = 点击后检测(快手App, ks.快手App, [ks.首页_底部导航, ks.快手视频关注按钮], 5000)
    switch (快手启动结果) {
        case -100:
            日志打印_error('快手App 位置点击失败！')
            return false
        case -1:
            return false
        case 0:
            break
        case 1:
            break
        case 2:
            break
        case 3:
            break
    }
    appBundleId = 'com.jiangjia.gif';
    进入实时回复 = false;
    日志打印_debug('   --- 【启动快手】---  执行结束')

    return true
}

KuaiShou.prototype.ks_首页导航_切换 = function (page){
    /*
    *  page 1: 首页
    *  page 2: 精选
    *  page 3: 消息
    *  page 4: 我
    * */
    当前执行模块 = 'ks_首页导航_切换';
    日志打印_debug('开始执行 -- 【ks_首页导航_切换】')
    let 在快手主页可导航 = ocr文本数组匹配(ks.首页_底部导航)
    if(!在快手主页可导航){
        在快手主页可导航 = ocr文本数组匹配(ks.首页_底部导航_二值化)
    }
    if(!在快手主页可导航){
        日志打印_error('未检测到 [首页_底部导航]， 无法进行切换！')
        return false
    }
    if (page === 1){
        const 切换到_首页 = 点击后检测(ks.底部导航_首页_按钮, ks.首页_底部导航, [ks.首页_顶部导航, ks.ks_左上角_菜单按钮, ks.首页_底部导航_首页选中_二值化])
        if(切换到_首页 === 0 || 切换到_首页 === 1 || 切换到_首页 === 2) {
            日志打印_debug('[切换到_首页] 成功！')
            return true
        }
        日志打印_error('[切换到_首页] 失败！')
        return false
    }
    if (page === 2){
        const 切换到_精选 = 点击后检测(ks.底部导航_精选_按钮, ks.首页_底部导航, [ks.快手视频关注按钮])
        if(切换到_精选 === 0 ) {
            日志打印_debug('[切换到_精选] 成功！')
            return true
        }
        else {
            if(ks.ks_视频播放页面判断()){ return true }
            日志打印_error('[切换到_精选] 失败！')
            return false
        }

    }
    if (page === 3){
        const 切换到_消息 = 点击后检测(ks.底部导航_消息_按钮, ks .首页_底部导航, [ks.消息页_顶部标题, ks.消息页_右上角_说说_搜索_标识, ks.消息页_左上角_更多_标识])
        if( 切换到_消息 === 0 || 切换到_消息 === 1 || 切换到_消息 === 2) {
            日志打印_debug('[切换到_消息] 成功！')
            return true
        }
        日志打印_error('[切换到_消息] 失败！')
        return false
    }
    if (page === 4){
        const 切换到_我 = 点击后检测(ks.底部导航_我_按钮, ks.首页_底部导航, [ks.主页_我_页面, ks.主页_我_二维码_标识, ks.主页_我_切换账号_标识])
        if( 切换到_我 === 0 || 切换到_我 === 1 || 切换到_我 === 2) {
            日志打印_debug('[切换到_我] 成功！')
            return true
        }
        日志打印_error('[切换到_我] 失败！')
        return false
    }
}

KuaiShou.prototype.ks_我_页面_当前账号信息 = function () {
    当前执行模块 = 'ks_我_页面_当前账号信息';
    日志打印_debug('开始执行 -- 【ks_我_页面_当前账号信息】')
    setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"1","boundsFilter":"2","excludedAttributes":""})
    let 快手号_节点 = type("Button").label("快手号：").getOneNodeInfo(10000);
    let tryCount = 3;
    while(!快手号_节点 && tryCount>0){
        if(isScriptExit()) {break}
        iSleep(100)
        const 还在预期页面 = ocr文本数组匹配(ks.主页_我_页面)
        if(还在预期页面){
            快手号_节点 = type("Button").label("快手号：").getOneNodeInfo(10000);
        }
        tryCount--;
    }
    if(!快手号_节点){
        日志打印_error('获取 [抖音号_节点] 失败！')
        return
    }
    const 快手号_所有兄弟节点 = 快手号_节点.siblings()
    日志打印_information(JSON.stringify(快手号_所有兄弟节点))
    if(快手号_所有兄弟节点.length === 1){
        const other_parent = 快手号_节点.parent().parent().parent()
        if(!other_parent){
            日志打印_error('获取 [other_parent] 失败！')
            return
        }
        const all_other = bounds(other_parent.bounds.left,other_parent.bounds.top,other_parent.bounds.right,other_parent.bounds.bottom).type('Other').getNodeInfo(10000)
        if(!all_other){
            日志打印_error('获取 [all_other] 失败！')
            return
        }
        const 账号信息 = { 快手号: 快手号_所有兄弟节点[0].label, 快手昵称: '', 私信功能: '正常'}
        all_other.forEach( other => {
            if(other.label && other.label !== ''){
                账号信息.快手昵称 = other.label
            }
        })
        日志打印_warning(JSON.stringify(账号信息))
        return 账号信息
    }
    快手号_所有兄弟节点.push(快手号_节点)
    快手号_所有兄弟节点.sort((a, b) => a.bounds.bottom - b.bounds.bottom);

    const 筛选_所有节点信息 = 快手号_所有兄弟节点.filter(item => item.label && item.label !== "");
    const merge_array = []
    let tempGroup = [筛选_所有节点信息[0]];
    for (let i = 1; i < 筛选_所有节点信息.length; i++) {
        if(isScriptExit()) {break}
        const currentItem = 筛选_所有节点信息[i];
        if (currentItem.bounds.left > 500){
            // 排除右侧  编辑资料按钮
            continue
        }
        const lastItem = tempGroup[tempGroup.length - 1];
        if (Math.abs(currentItem.bounds.top - lastItem.bounds.top) <= 5) {
            tempGroup.push(currentItem);
        } else {
            merge_array.push(tempGroup.length > 1 ? tempGroup : tempGroup[0]);
            tempGroup = [currentItem];  // 重新开始新组
        }
        tempGroup.sort((a, b) => a.bounds.left - b.bounds.left)
    }
    merge_array.push(tempGroup.length > 1 ? tempGroup : tempGroup[0]);

    const 账号信息 = {名称: '', 快手ID: '', 私信功能: '正常'}
    let 快手号_索引 = null
    for(let i in merge_array){
        if(isScriptExit()) {break}
        const cell = merge_array[i]
        // logw(i + '  ' +JSON.stringify(cell))
        if(Array.isArray(cell)){
            const index = cell.findIndex( item => item.label === '快手号：')
            if(index !== -1){
                快手号_索引 = parseInt(i)
                账号信息.快手ID = cell[index+1].label
            }
        }
    }
    if(快手号_索引 && (快手号_索引-1) >= 0){
        const 用户昵称组 = merge_array[快手号_索引-1]
        if(Array.isArray(用户昵称组)){
            账号信息.名称 = 用户昵称组[0].label
        }
        else {
            账号信息.名称 = 用户昵称组.label
        }
    }
    日志打印_warning(JSON.stringify(账号信息))
    return 账号信息
}

KuaiShou.prototype.ks_切换账号 = function (){
    当前执行模块 = 'ks_切换账号';
    日志打印_debug('开始执行 -- 【ks_切换账号】')

    const 主页_我_页面 = JSON.parse(JSON.stringify(ks.主页_我_页面))
    主页_我_页面.binaryzation = true
    const 即将切换的账号 = { name: '即将切换的账号', x: random(165, 450), y: random(1230, 1280)}
    const 切换账号_结果 = 点击后检测(即将切换的账号, ks.切换账号弹窗_快手账号已选择标识, [主页_我_页面, ks.主页_我_二维码_标识], 5000);
    switch (切换账号_结果) {
        case -100:
            return false
        case -1:
            return false
        case 0:
            return true
        case 1:
            return true
    }
}

KuaiShou.prototype.ks_首页搜索按钮点击 = function (search_time_interval){
    当前执行模块 = 'ks_首页搜索按钮点击';
    日志打印_debug('开始执行 -- 【ks_首页搜索按钮点击】')

    while (ks.搜索时间 && (time() -ks.搜索时间) < search_time_interval*60*1000) {
        if (isScriptExit()) { return }
        if (!ks.ks_首页导航_切换(2)) {
            ks.ks_启动快手()
            continue
        }
        while (ks.搜索时间 && (time() -ks.搜索时间) < search_time_interval*60*1000) {
            if (isScriptExit()) { return }
            ks.ks_当前账号_跟进客户()
        }
    }
    if (!ks.ks_首页导航_切换(2)) {
        ks.ks_启动快手()
        return
    }
    const 进入搜索页面 = 点击后检测(ks.首页_右上角_搜索按钮, ks.首页_底部导航, [ks.搜索页_右上角_ai对话标识, ks.搜索页_搜索], 2000);
    switch (进入搜索页面) {
        case -100:
            return false
        case 0:
            return true
        case -1:
            return false
        case 1:
            return true
    }
}

KuaiShou.prototype.ks_搜索页面输入查询 = function (content){
    当前执行模块 = 'ks_搜索页面输入查询';
    日志打印_debug('开始执行 -- 【ks_搜索页面输入查询】')

    const 键盘已弹出 = ocr文本数组匹配(ios.键盘弹出);
    if(!键盘已弹出){
        const 点击_搜索页面的搜索输入框 = 点击后检测(ks.搜索页面_搜索输入框_按钮, ks.搜索页_搜索, [ios.键盘弹出]);
        switch (点击_搜索页面的搜索输入框) {
            case -100:
                return false
            case -1:
                return false
            case 0:
                break;
        }
    }
    文本内容输入(content, ks.搜索页面_搜索输入框_按钮);
    键盘发送()
    iSleep(1000)
    let 搜索成功 = ocr文本数组匹配(ks.搜索页_搜索结果标签)
    let 重试次数 = 3
    while (!搜索成功 && 重试次数>0){
        if(isScriptExit()) {break}
        键盘发送()
        iSleep(1000)
        搜索成功 = ocr文本数组匹配(ks.搜索页_搜索结果标签)
        重试次数--
    }
    ks.搜索时间 = time()
    return !!搜索成功
}

KuaiShou.prototype.ks_搜索结果分类选择 = function (item){
    logi(`开始执行 - 【ks_搜索结果的${item}选择点击】`);

    setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"1","boundsFilter":"2","excludedAttributes":""})
    let 节点_视频 = type("Button").label('视频').getOneNodeInfo(10000)
    let 重试次数 = 3;
    while(!节点_视频 && 重试次数>0){
        if(isScriptExit()){break}
        iSleep(100);
        const 还在预期页面 = ocr文本数组匹配(ks.搜索页_搜索结果标签)
        if(还在预期页面){
            节点_视频 = type("Button").label('视频').getOneNodeInfo(10000)
        }
        重试次数--;
    }
    if(!节点_视频){
        日志打印_error('寻找 [节点_视频] 失败');
        return false
    }
    const 所有分类节点 = 节点_视频.siblings()
    if(!所有分类节点){
        日志打印_error(`寻找 [所有分类节点] 失败: ${JSON.stringify(节点_视频)}`);
        return false
    }
    所有分类节点.push(节点_视频)
    for(let i in 所有分类节点){
        if(isScriptExit()){break}
        const 单个分类_节点 = 所有分类节点[i]
        if(单个分类_节点.label === item && 单个分类_节点.bounds.right <= 740){
            const 单个分类_节点_已选择标识 = JSON.parse(JSON.stringify(ks.搜索页_搜索结果分类_已选择标识))
            单个分类_节点_已选择标识.x = 单个分类_节点.bounds.left
            单个分类_节点_已选择标识.ex = 单个分类_节点.bounds.right
            单个分类_节点_已选择标识.y = 单个分类_节点.bounds.top
            单个分类_节点_已选择标识.ey = 单个分类_节点.bounds.bottom
            const 已选择 = findColor(单个分类_节点_已选择标识)
            if(已选择){
                return true
            }else {
                const 单个分类_节点_位置 = {name: `选择分类：${单个分类_节点.label}`, x: 单个分类_节点.bounds.left/2+单个分类_节点.bounds.right/2, y:单个分类_节点.bounds.top/2+单个分类_节点.bounds.bottom/2}
                点击屏幕检测(单个分类_节点_位置, 1000, 0,120,ScreenWidth, 220)
                return this.ks_搜索结果分类选择(item)
            }
        }
    }

    滑动(190, 节点_视频.bounds.top/2+节点_视频.bounds.bottom/2, 0 , 节点_视频.bounds.top/2+节点_视频.bounds.bottom/2, 300)
    return this.ks_搜索结果分类选择(item)
}

KuaiShou.prototype.ks_搜索结果频繁_养号 = function (search_pinfan_hours) {
    当前执行模块 = 'ks_搜索结果频繁_养号';
    日志打印_debug(`开始执行 -- 【ks_搜索结果频繁_养号】`)
    return false
}

KuaiShou.prototype.ks_搜索结果的视频点击 = function () {
    当前执行模块 = 'ks_搜索结果的视频点击';
    日志打印_debug(`开始执行 -- 【ks_搜索结果的视频点击】`)

    setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"1","boundsFilter":"2","excludedAttributes":""})
    let search_result_nature_videocard = type("Image").getOneNodeInfo(10000)
    let 重试次数 = 3;
    while(!search_result_nature_videocard && 重试次数>0){
        if(isScriptExit()){break}
        iSleep(100);
        const 还在预期页面 = ocr文本数组匹配(ks.搜索页_搜索结果标签)
        if(还在预期页面){
            search_result_nature_videocard = type("Image").getOneNodeInfo(10000)
        }
        重试次数--;
    }
    let 第一个视频位置 = null
    if(!search_result_nature_videocard){
        第一个视频位置 = {name: '搜索结果的视频点击', x: search_result_nature_videocard.bounds.left/2+search_result_nature_videocard.bounds.right/2,
            y: search_result_nature_videocard.bounds.top/2+search_result_nature_videocard.bounds.bottom/2};
    }else {
        第一个视频位置 = {name: '搜索结果的视频点击', x: random(70, 280), y: random(300, 500)};
    }
    while (true){
        if(isScriptExit()) { break }
        点击(第一个视频位置)
        iSleep(500)
        if(ks.ks_视频播放页面判断()){
            return true
        }
        if(!ocr文本数组匹配(ks.搜索页_搜索结果标签)){
            日志打印_error('进入 [视频播放] 失败！')
            return false
        }
    }
    return true
}

KuaiShou.prototype.ks_视频信息采集 = function () {
    logi(`开始执行 - 【ks_视频信息采集】`);
    iSleep(1000);
    const 视频信息 = { '作者': '', '类型': '视频', '发布日期': null, '评论数量': 0, 'name': '无', x: null, y: null}
    const 评论节点 = name("ToolBarGroupComment").type('Other').getOneNodeInfo(10000);
    // logi(JSON.stringify(评论节点))
    if(!评论节点){
        return this.ks_视频信息采集()
    }
    视频信息.x =  评论节点.bounds.left/2 + 评论节点.bounds.right/2;
    视频信息.y = 评论节点.bounds.top/2 + 评论节点.bounds.bottom/2;
    const 评论_nodes = 评论节点.allChildren();
    // logi(JSON.stringify(评论_nodes))
    if(评论_nodes.length === 0){
        return this.ks_视频信息采集()
    }
    for (const i in 评论_nodes){
        if(isScriptExit()){ break }
        const node = 评论_nodes[i];
        if(node.type === 'StaticText'){
            视频信息.评论数量 = 快手_评论数量格式化(node.name);
            break
        }
    }
    const 艾特 = type("Button").label('@').getOneNodeInfo(10000)
    if(!艾特){
        return this.ks_视频信息采集()
    }
    const nodes = 艾特.parent().allChildren()
    if(nodes.length === 0){
        return this.ks_视频信息采集()
    }
    for (const i in nodes){
        if(isScriptExit()){ break }

        const node = nodes[i];
        if (node.type === 'Button' && node.name !== '@' && node.name !== '图文'){
            视频信息.作者 = node.name;
        }
        if(node.name === '图文'){
            视频信息.类型 = '图文';
        }
        if(node.type === 'StaticText'){
            视频信息.发布日期 = 时间格式化(node.name).replace('•', '');
        }
    }
    视频信息.name = ks.ks_获取视频标题();
    logd(JSON.stringify(视频信息))
    return 视频信息
}

KuaiShou.prototype.ks_获取视频标题 = function (){
    logi('执行 【ks_获取视频标题】')
    setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"1","boundsFilter":"2","excludedAttributes":""})
    let PHOTO_FEED = type('Other').label("PHOTO_FEED").getOneNodeInfo(10000)
    let 重试次数 = 3;
    while(!PHOTO_FEED && 重试次数>0){
        if(isScriptExit()){break}
        iSleep(100);
        const 还在预期页面 = findColor(ks.快手视频关注按钮)
        if(还在预期页面){
            PHOTO_FEED = type('Other').label("PHOTO_FEED").getOneNodeInfo(10000)
        }
        重试次数--;
    }
    let area = {x: 0, y: 120, ex:630, ey: 1230}
    if(PHOTO_FEED){
        area.x = PHOTO_FEED.bounds.left
        area.y = PHOTO_FEED.bounds.top
        area.ex = PHOTO_FEED.bounds.right
        area.ey = PHOTO_FEED.bounds.bottom
    }
    const 识别内容 = ocr范围识别(area.x, area.y, area.ex, area.ey, true);
    // logd(JSON.stringify(识别内容))
    let find_Aite_index = 0;
    const 内容Array = [];
    let 最终内容Array = [];
    for(let i in 识别内容){
        const 单行文本 = 识别内容[i];
        if(单行文本.label.endsWith('展开')){
            单行文本.label = 单行文本.label.replace('展开', '');
        }
        内容Array.push(单行文本.label);
        if(单行文本.label.startsWith('@')){
            find_Aite_index = i;
        }
    }
    最终内容Array = 内容Array.slice(find_Aite_index, 内容Array.length);
    const 需要移除的内容 = ['去汽水', '相关搜索', '相关短剧']
    let 视频所有文本内容 = 最终内容Array.filter(item => !需要移除的内容.some(subtext => item.includes(subtext)));
    if(视频所有文本内容 === undefined || 视频所有文本内容 === null || !视频所有文本内容){
        视频所有文本内容 = ''
    }else {
        视频所有文本内容 = 视频所有文本内容.join('')
    }
    logi(`视频所有文本内容: ${视频所有文本内容}`)
    return 视频所有文本内容
}

KuaiShou.prototype.ks_用户主页_信息 = function (){
    当前执行模块 = 'ks_用户主页_信息';
    日志打印_debug(`开始执行 -- 【ks_用户主页_信息】`)
    setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"1","boundsFilter":"2","excludedAttributes":""})
    let Table_节点 = type("Table").getOneNodeInfo(10000)
    let 重试次数 = 3;
    while(!Table_节点 && 重试次数>0){
        if(isScriptExit()){break}
        iSleep(100);
        const 还在预期页面 = ocr文本数组匹配(ks.用户作品主页)
        if(还在预期页面){
            Table_节点 = type("Table").getOneNodeInfo(10000)
        }
        重试次数--;
    }
    if(!Table_节点){
        日志打印_error('[Table_节点] 获取失败！')
        return
    }
    const 所有节点信息 = []
    const allChildren = Table_节点.allChildren()
    allChildren.sort((a, b) => a.bounds.bottom - b.bounds.bottom);
    function getAllLeafChildren(allChildren) {
        let leafChildren = [];
        // 遍历 allChildren
        for (let i in allChildren) {
            if (isScriptExit()) { break }  // 如果退出条件触发则停止
            const child = allChildren[i];
            if (child.type === 'Cell' && child.childCount > 0) {
                // 如果 child 有子节点，则递归获取其所有最底层子节点
                leafChildren = leafChildren.concat(getAllLeafChildren(child.allChildren()));
            } else {
                // 如果没有子节点，则认为它是最底层节点
                leafChildren.push(child);
            }
        }
        return leafChildren;
    }

    // for(let i in allChildren){
    //     if(isScriptExit()){ break }
    //     const child = allChildren[i]
    //     if(child.type === 'Cell' && child.childCount > 0){
    //         Array.prototype.push.apply(所有节点信息, child.allChildren());
    //     }
    // }
    const allLeafChildren = getAllLeafChildren(allChildren);
    Array.prototype.push.apply(所有节点信息, allLeafChildren);
    所有节点信息.sort((a, b) => a.bounds.bottom - b.bounds.bottom);

    const 筛选_所有节点信息 = 所有节点信息.filter(item => item.label && item.label !== "");
    const merge_array = []
    let tempGroup = [筛选_所有节点信息[0]];
    for (let i = 1; i < 筛选_所有节点信息.length; i++) {
        if(isScriptExit()) {break}
        const currentItem = 筛选_所有节点信息[i];
        const lastItem = tempGroup[tempGroup.length - 1];
        if (Math.abs(currentItem.bounds.top - lastItem.bounds.top) <= 5) {
            // 如果top差距不大于5，则合并到当前组
            tempGroup.push(currentItem);
        } else {
            // 如果top差距大于5，则将当前组添加到结果数组，并重新开始一个新组
            merge_array.push(tempGroup.length > 1 ? tempGroup : tempGroup[0]);
            tempGroup = [currentItem];  // 重新开始新组
        }
        tempGroup.sort((a, b) => a.bounds.left - b.bounds.left)
    }
    merge_array.push(tempGroup.length > 1 ? tempGroup : tempGroup[0]);

    const 用户信息 = {名称: '', 快手ID: '', 用户其他信息: '', 用户主页截图: ''}
    let 快手号_索引 = null
    for(let i in merge_array){
        if(isScriptExit()) {break}
        const cell = merge_array[i]
        // logw(i + '  ' +JSON.stringify(cell))
        if(Array.isArray(cell)){
            const index = cell.findIndex( item => item.label === '快手号：')
            if(index !== -1){
                快手号_索引 = parseInt(i)
                用户信息.快手ID = cell[index+1].label

            }
        }
    }
    if(快手号_索引 === null || 快手号_索引 === 0){
        日志打印_error(`[快手号_索引] 获取失败: ${JSON.stringify(merge_array)}`)
        return;
    }
    logw(JSON.stringify(merge_array))
    用户信息.名称 = merge_array[快手号_索引-1].label
    const 排除信息 = ['粉丝团', '她在关注你哦', '他在关注你哦']
    const 其他信息 = merge_array[快手号_索引+1].label
    用户信息.用户其他信息 = 其他信息
    if(排除信息.includes(其他信息) && (快手号_索引+2) < merge_array.length){
        const 再次排除信息 = ['IP：']
        const 文本 = merge_array[快手号_索引+2].label
        let 是否排除 = false
        再次排除信息.forEach( item => {
            if(文本.includes(item)) { 是否排除 = true }
        })
        if(!是否排除){
            用户信息.用户其他信息 =文本
        }
    }
    logi(JSON.stringify(用户信息))
    用户信息.用户主页截图 = 区域截图base64()

    return 用户信息

}

KuaiShou.prototype.ks_上滑切换视频 = function (check=true) {
    日志打印_debug('执行 【dy_上滑切换视频】')
    const startX = random(240, 300);
    const endX = random(300, 390);
    const startY = random(900, 960);
    const endY = random(180, 200);
    let 滑动最大次数 = 10;
    const 当前视频 = ks.ks_获取视频标题()
    while (滑动最大次数 > 0){
        if(isScriptExit()) {break}
        滑动(startX, startY, endX, endY, 200);
        iSleep(100);
        const 滑动后视频 = ks.ks_获取视频标题()
        const 相似度 = 字符串相似度计算(滑动后视频, 当前视频)
        if(相似度 > 0.6){
            滑动最大次数--;
            continue;
        }
        return
    }
    if(check){
        ks.关键词已无视频 = true
    }
}

KuaiShou.prototype.ks_进入评论区 = function (){
    当前执行模块 = 'ks_进入评论区';
    日志打印_debug(`开始执行 -- 【ks_进入评论区】`)

    const 评论按钮 = {name: '快手评论按钮', x:0, y:0}
    const 快手视频关注按钮 = findColor(ks.快手视频关注按钮)
    if(快手视频关注按钮){
        评论按钮.x = 快手视频关注按钮.min_x/2 + 快手视频关注按钮.max_x/2
        评论按钮.y = 快手视频关注按钮.max_y + 240
    }else {
        setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"1","boundsFilter":"2","excludedAttributes":""})
        let 关注按钮_节点 = type('Button').label("feed nasa homepage follow").getOneNodeInfo(10000)
        let 重试次数 = 3;
        while(!关注按钮_节点 && 重试次数>0){
            if(isScriptExit()){break}
            iSleep(100);
            关注按钮_节点 = type('Button').label("feed nasa homepage follow").getOneNodeInfo(10000)
            重试次数--;
        }
        if(关注按钮_节点){
            评论按钮.x = 关注按钮_节点.bounds.left/2 + 关注按钮_节点.bounds.right/2
            评论按钮.y = 关注按钮_节点.bounds.bottom + 220
        }
    }
    if(评论按钮.x ===0 || 评论按钮.y === 0){
        日志打印_error('没有找到关注按钮')
        return -100
    }
    const 打开评论区 = 点击后检测(评论按钮, ks.快手视频关注按钮, [ks.快手评论区放大按钮, ks.快手评论区关闭按钮, ks.评论区_title])
    if(打开评论区 === 0 || 打开评论区 === 1 || 打开评论区 === 2){
        let 快手评论区放大按钮 = findColor(ks.快手评论区放大按钮)
        if(!快手评论区放大按钮){
            快手评论区放大按钮 = {name: '快手评论区放大按钮', x: random(610,630), y:random(424,444)}
        }
        const 放大评论区 = 点击后检测(快手评论区放大按钮, ks.快手评论区放大按钮, [ks.快手评论区缩小按钮])
        return 放大评论区
    }else {
        return 打开评论区
    }

}

KuaiShou.prototype.ks_评论区留痕 = function (留痕内容){
    当前执行模块 = 'ks_评论区留痕';
    日志打印_debug(`开始执行 -- 【ks_评论区留痕】`)

    const 打开输入框 = 点击后检测(ks.评论区_输入框, ks.快手评论区缩小按钮, [ios.键盘弹出])
    if(打开输入框 !== 0){ return false }
    文本内容输入(留痕内容, ks.评论区_输入框)
    键盘发送()
    iSleep(100)
    let 重试次数 = 3
    let 留痕结果 = ocr文本数组匹配(ios.键盘弹出)
    while (留痕结果 && 重试次数>0){
        if(isScriptExit()) { return }
        键盘发送()
        iSleep(100)
        留痕结果 = ocr文本数组匹配(ios.键盘弹出)
        重试次数--
    }
    return !留痕结果
}

KuaiShou.prototype.ks_评论区抓取 = function (video_sid){
    当前执行模块 = 'ks_评论区抓取';
    日志打印_debug('开始执行 - 【ks_评论区抓取】')

    let 评论区顶部 = 100;
    let 评论区底部 = 1200;
    let 是否结束评论区获取 = false;
    setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"1","boundsFilter":"2","excludedAttributes":""})
    let 评论数量节点 =  bounds(0,40, ScreenWidth,150).labelMatch(".*评论.*").getOneNodeInfo(10000)
    let tryCount = 3;
    while (!评论数量节点 && tryCount>0){
        if(isScriptExit()){break}
        iSleep(100);
        const 还在预期页面 = findColor(ks.快手评论区缩小按钮);
        if(还在预期页面){
            评论数量节点 = bounds(0,40, ScreenWidth,150).type("StaticText").labelMatch(".*评论.*").getOneNodeInfo(10000)
        }
        tryCount--
    }
    if(评论数量节点 && 评论数量节点.bounds.bottom > 100 && 评论数量节点.bounds.bottom < 300){
        评论区顶部 = 评论数量节点.bounds.bottom;
    }

    日志打印_debug(`【ks_评论区抓取】评论区范围为 top：${评论区顶部}  bottom：${评论区底部}`)

    function 获取评论的点踩爱心图标(y, ey) {
        const 更新点踩爱心按钮范围 = JSON.parse(JSON.stringify(ks.视频播放页面的评论区点踩爱心图标));
        更新点踩爱心按钮范围.y = y;
        更新点踩爱心按钮范围.ey = ey;
        return findColor(更新点踩爱心按钮范围)
    }
    function 获取ip地址(str) {
        const match = str.trim().match(/[\u4e00-\u9fa5]+$/); // 匹配末尾的连续中文字符
        return match ? match[0] : ''; // 如果有匹配的中文字符，返回，否则返回空字符串
    }
    function 范围评论处理(范围评论内容) {
        if(!范围评论内容 || 范围评论内容.length === 0){
            return null
        }
        范围评论内容.sort((a, b) => {
            return a.y - b.y;
        });
        //排除里面的无效文本
        const 第一次筛选后评论内容 = 范围评论内容.filter((单行文本) => {
            return!(单行文本.label.includes('收起') || 单行文本.label.includes('作者回复过')
                    || 单行文本.label.includes('作者赞过') || 单行文本.label === '' || 单行文本.x > 400
                    || 单行文本.label.includes('评论氛围是否满意') || 单行文本.label.includes('条回复')
                    || 单行文本.label.startsWith('展开')|| (单行文本.label.includes('不满意')  && 单行文本.label.includes('一般'))
                    || (单行文本.label.startsWith('展开') || 单行文本.label.startsWith('展廾')
                    || 单行文本.label.startsWith('一 展开') || 单行文本.label.startsWith('一 展廾')
                    || 单行文本.label.startsWith('— 展开') || 单行文本.label.startsWith('—展开')
                    || 单行文本.label.startsWith('一展廾')) && (单行文本.label.endsWith('凹复V') || 单行文本.label.endsWith('回复丷')
                    || 单行文本.label.endsWith('回复') || 单行文本.label.endsWith('回复V')
                    || 单行文本.label.endsWith('回复 V')));

        });

        let ip = ''
        function 找到评论时间并格式化(arr) {
            let indexOfReply = -1;
            for (let i = arr.length - 1; i >= 0; i--) {
                if (arr[i].label.includes('回复')) {
                    indexOfReply = i;
                    break;
                }
            }
            if (indexOfReply !== -1) {
                arr = arr.slice(0, indexOfReply + 1);
                arr[arr.length-1].label = arr[arr.length-1].label.replace('回复', '')
                var 评论时间 = 时间格式化(arr[arr.length-1].label);
                // 日志打印_warning(arr[arr.length-1].label+ '  评论时间1: ' + 评论时间)
                if(评论时间){
                    ip = 获取ip地址(arr[arr.length-1].label)
                    arr[arr.length-1].label = 评论时间;
                    return arr;
                }
                else if(arr.length > 1){
                    var 评论时间 = 时间格式化(arr[arr.length-2].label);
                    // 日志打印_warning(arr[arr.length-2].label + '  评论时间2: ' + 评论时间)
                    if(评论时间){
                        ip = 获取ip地址(arr[arr.length-2].label)
                        arr[arr.length-2].label = 评论时间;
                        arr = arr.slice(0, arr.length-1);
                        return arr;
                    }
                }
            }
            return null;
        }

        const 筛选后评论内容 = 找到评论时间并格式化(第一次筛选后评论内容);
        日志打印_debug('筛选后评论内容: '+JSON.stringify(筛选后评论内容))
        if(!筛选后评论内容 || 筛选后评论内容.length < 2 || 筛选后评论内容[0].label.endsWith('作者')
            || 筛选后评论内容[0].label.endsWith('互相关注') || 筛选后评论内容[0].label.endsWith('你的关注')){
            return null
        }
        if(筛选后评论内容[筛选后评论内容.length-1].y - 筛选后评论内容[0].y - 筛选后评论内容[0].height < 30){
            return null
        }
        if(筛选后评论内容[0].width > 551){
            return null
        }
        let 头像_x = 66;
        if(筛选后评论内容[筛选后评论内容.length-1].x > 50){
            头像_x = 138;
        }

        const 用户评论信息 = {name: 筛选后评论内容[0].label, 评论内容: null, 评论时间: 筛选后评论内容[筛选后评论内容.length-1].label,
            x: 头像_x, y: 筛选后评论内容[0].y+筛选后评论内容[0].height/2+评论区顶部}
        if(筛选后评论内容.length === 2){
            用户评论信息.评论内容 = '[该用户回复的为表情或者图片消息]'
            logi(筛选后评论内容[筛选后评论内容.length-1].y-筛选后评论内容[0].y)
        }
        else {
            用户评论信息.评论内容 = 筛选后评论内容.slice(1, -1).map(单行文本 => 单行文本.label).join('');
        }
        用户评论信息.ip = ip
        // 日志打印_debug('用户评论信息: ' + JSON.stringify(用户评论信息))
        return 用户评论信息
    }

    function 评论区判断() {
        const 还在评论页面 = findColor(ks.快手评论区缩小按钮);
        if(还在评论页面) { return true }
        const 打开键盘 = ocr文本数组匹配(ios.键盘弹出)
        if(打开键盘){
            const 关闭_弹出键盘 = {name: '【ks_评论区抓取】关闭_弹出键盘', x: random(140, 568), y: random(292, 418)};
            点击(关闭_弹出键盘)
            iSleep(200)
            return 评论区判断()
        }
        const 视频播放页面的评论区点踩爱心图标 = findColor(ks.视频播放页面的评论区点踩爱心图标);
        if(视频播放页面的评论区点踩爱心图标) { return true }

        const 快手评论区关闭按钮 = findColor(ks.快手评论区关闭按钮);
        if(快手评论区关闭按钮) { return true }

        const 评论区_title = ocr文本数组匹配(ks.评论区_title);
        if(评论区_title) { return true }

        const 用户作品主页 = ocr文本数组匹配(ks.用户作品主页);
        if(用户作品主页) {
            点击(ks.用户主页_返回按钮)
            iSleep(200)
            return 评论区判断()
        }

        const 快手评论区放大按钮 = findColor(ks.快手评论区放大按钮);
        if(快手评论区放大按钮) {
            点击(快手评论区放大按钮)
            iSleep(200)
            return 评论区判断()
        }
        const 主页_我_页面 = ocr文本数组匹配(ks.主页_我_页面);
        if(主页_我_页面) {
            点击(ks.用户主页_返回按钮)
            iSleep(200)
            return 评论区判断()
        }
        const 视频评论区_误触内容 = ocr文本数组匹配(ks.视频评论区_误触内容);
        if(视频评论区_误触内容) {
            const 关闭误触的点位 = {name: '【ks_评论区抓取】关闭 视频评论区_误触内容', x: random(250, 520), y: random(100, 200)};
            点击(关闭误触的点位)
            iSleep(200)
            return 评论区判断()
        }
        return false
    }
    const 已经获取快手ID的用户 = []
    let 左侧头像切割 = 100
    while (!是否结束评论区获取){
        if(isScriptExit()){ break }
        if(!评论区判断()){ return }

        const 页面所有文字内容 = ocrMut范围识别(左侧头像切割, 评论区顶部, ScreenWidth, 评论区底部)
        if(!页面所有文字内容){
            日志打印_error('【ks_评论区抓取】 页面评论内容 获取失败， 正在重新获取！ ');
            iSleep(200)
            continue
        }
        页面所有文字内容.sort((a, b) => {
            // 首先按照y值进行排序
            if (Math.abs(a.y - b.y) <= 5) {
                // 如果y值差不超过5，则按照x值排序
                return a.x - b.x;
            } else {
                // 否则按照y值排序
                return a.y - b.y;
            }
        });
        const 点踩爱心图标top = 评论区顶部;
        let 上一个爱心图标 = null;
        const 用户列表 = [];
        const 评论区切片索引 = [];
        for (let i = 0; i < 页面所有文字内容.length; i++) {
            if (isScriptExit()) { return }
            const 单列文字内容 = 页面所有文字内容[i];
            日志打印_debug(JSON.stringify(单列文字内容))
            if (单列文字内容.label.includes('暂时没有更多了')  || 单列文字内容.label.startsWith('已折叠') || 单列文字内容.label.startsWith('哲时没有更多了')
                || 单列文字内容.label.endsWith('没有更多了') || 单列文字内容.label.endsWith('快来发布首条评论')) {
                // 评论页面内容已经获取完了
                日志打印_debug(`【ks_评论区抓取】已到达评论区底部 ：${单列文字内容.label} `)
                是否结束评论区获取 = true;
            }
            if (单列文字内容.label.includes('回复')) {
                /*  用 【回复】 分割用户的评论内容 */
                const 点踩爱心图标bottom = 单列文字内容.y + 单列文字内容.height + 40 + 评论区顶部;
                const 点赞爱心图标 = 获取评论的点踩爱心图标(点踩爱心图标top, 点踩爱心图标bottom);
                if (点赞爱心图标) {
                    if(!上一个爱心图标){
                        评论区切片索引.push({index: i, top: 评论区顶部})
                    }
                    else {
                        评论区切片索引.push({index: i, top: 上一个爱心图标.max_y})
                    }
                    上一个爱心图标 = JSON.parse(JSON.stringify(点赞爱心图标));
                }else {
                    日志打印_debug(`点赞爱心图标 未找到：${单列文字内容.label}`)
                }
            }
        }

        let startIndex = {index: 0, top: 评论区顶部};
        for (let index_ of 评论区切片索引) {
            let 范围评论 = null;
            if(startIndex.index === 0){
                范围评论 = 页面所有文字内容.slice(0, index_.index+1);
            }else {
                范围评论 = 页面所有文字内容.slice(startIndex.index+1, index_.index+1);
            }
            startIndex = JSON.parse(JSON.stringify(index_));
            // 日志打印_debug('提交筛选：' + JSON.stringify(范围评论))
            const 用户信息 = 范围评论处理(范围评论);
            if(用户信息){
                用户列表.push(用户信息)
            }
        }
        // 日志打印_debug('提交筛选：' + JSON.stringify(页面所有文字内容.slice(startIndex.index+1)))
        const 用户信息 = 范围评论处理(页面所有文字内容.slice(startIndex.index+1))
        if(用户信息){
            用户列表.push(用户信息)
        }
        const 评论区截图 = 区域截图base64(150, 150, 600, 1000);
        let 评论区变动_重新抓取 = false;

        for(const i in 用户列表){
            if(isScriptExit()) { break }
            if(!评论区判断()){ return }
            const 评论区用户 = 用户列表[i];
            日志打印_warning('评论区用户： '+ JSON.stringify(评论区用户))
            if (已经获取快手ID的用户.includes(评论区用户.name)){ continue }
            已经获取快手ID的用户.push(评论区用户.name)
            const 进入评论用户主页 = 点击后检测(评论区用户, ks.快手评论区缩小按钮, [ks.用户作品主页], 1000);
            if (进入评论用户主页 === 0){
                const 用户_昵称_id = ks.ks_用户主页_信息()
                if (用户_昵称_id){
                    if(!已经获取快手ID的用户.includes(用户_昵称_id.快手ID) ){
                        const 上传评论数据 = {
                            "video_sid": video_sid,
                            "belong_account_id": uid,
                            "account_type": '快手',
                            "customer_name": 用户_昵称_id.名称,
                            "customer_id":用户_昵称_id.快手ID,
                            "customer_comment_time": 评论区用户.评论时间,
                            "customer_ip_location": 评论区用户.ip,
                            "customer_comment": 评论区用户.评论内容,
                            "customer_homepage_img": 用户_昵称_id.用户主页截图,
                            "customer_other_information": 用户_昵称_id.用户其他信息,
                        }
                        api_插入视频评论用户(上传评论数据)
                        已经获取快手ID的用户.push(用户_昵称_id.快手ID)
                    }
                }
                while (true){
                    if(isScriptExit()){ break }
                    const 在_用户作品主页 = ocr文本数组匹配(ks.用户作品主页)
                    if(在_用户作品主页){
                        点击(ks.用户主页_返回按钮)
                        iSleep(400)
                    }else {
                        break
                    }
                }
            }
            const 点击后_评论区截图 = 区域截图base64(150, 150, 600, 1000);
            if(点击后_评论区截图 !== 评论区截图){
                日志打印_debug('评论区变动_重新抓取')
                评论区变动_重新抓取 = true;
                break
            }
        }
        if(是否结束评论区获取) { break }
        if(评论区变动_重新抓取){ continue }

        const bg_hd = time()
        const startX = random(10,20);
        const endX = random(10,20);
        let startY = 1150;
        let endY = 250;
        日志打印_debug('【ks_评论区抓取】开始执行 评论区滑动')
        滑动(startX, startY, endX, endY, 2000)
        while(!屏幕区域变化检测(200, 0, 300, 90, 1000)){
            if(isScriptExit()){break }
            sleep(100);
        }

        日志打印_warning('滑动耗时： '+ (time()-bg_hd))
        const 滑动后_评论区截图 = 区域截图base64(150, 150, 600, 1000);
        if(滑动后_评论区截图 === 评论区截图){
            break
        }
    }
    日志打印_debug(`【ks_评论区抓取】已结束抓取  `)
    return true
}

KuaiShou.prototype.ks_关闭评论区 = function (){
    当前执行模块 = 'ks_关闭评论区';
    日志打印_debug('开始执行 - 【ks_关闭评论区】')

    let 快手评论区关闭按钮 = findColor(ks.快手评论区关闭按钮);
    if(!快手评论区关闭按钮){
        return false
    }
    const 关闭评论区 = 点击后消失检测(快手评论区关闭按钮, ks.快手评论区关闭按钮, ks.快手评论区关闭按钮)
    if(关闭评论区 !== 0){
        return false
    }
    return true

}

KuaiShou.prototype.ks_视频播放页面判断 = function () {
    当前执行模块 = 'ks_视频播放页面判断';
    日志打印_debug('开始执行 - 【ks_视频播放页面判断】')
    const 寻找_快手视频关注按钮 = findColor(ks.快手视频关注按钮)
    logw(JSON.stringify(寻找_快手视频关注按钮))
    if(!寻找_快手视频关注按钮){
        setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"1","boundsFilter":"2","excludedAttributes":""})
        iSleep(100)
        const 点赞按钮_节点 = type('Button').label("feed nasa homepage likeshape").getOneNodeInfo(10000)
        if(!点赞按钮_节点){
            iSleep(100)
            const 关注按钮_节点 = type('Button').label("feed nasa homepage follow").getOneNodeInfo(10000)
            if(!关注按钮_节点){
                return false
            }
        }
    }
    return true
}

KuaiShou.prototype.ks_选择进入搜索的用户 = function () {
    当前执行模块 = 'ks_选择进入搜索的用户';
    日志打印_debug('开始执行 - 【ks_选择进入搜索的用户】')
    setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
    let 匹配_节点 = bounds(0,220,ScreenWidth,ScreenHeight).labelMatch('.*匹配.*').getOneNodeInfo(10000)
    let 重试次数 = 3;
    while(!匹配_节点 && 重试次数>0){
        if(isScriptExit()){break}
        iSleep(100);
        const 还在预期页面 = ocr文本数组匹配(ks.搜索页_搜索结果标签)
        if(还在预期页面){
            匹配_节点 = bounds(0,220,ScreenWidth,ScreenHeight).labelMatch('.*匹配.*').getOneNodeInfo(10000)
        }
        重试次数--;
    }
    if(!匹配_节点){
        日志打印_error('[匹配_节点] 获取失败！')
        return 0
    }
    日志打印_warning(`匹配_节点：${JSON.stringify(匹配_节点)}`)
    const 匹配类型 = ['快手号匹配','用户ID匹配']
    if(!匹配类型.includes(匹配_节点.label)){
        return 0
    }

    const 匹配用户位置 = {name: '匹配用户位置', x: 匹配_节点.bounds.left/2+匹配_节点.bounds.right/2, y: 匹配_节点.bounds.top/2+匹配_节点.bounds.bottom/2}
    const 进入用户主页 = 点击后检测(匹配用户位置, ks.搜索页_搜索结果标签, [ks.用户作品主页])
    switch (进入用户主页) {
        case -100:
            日志打印_error(`进入用户主页失败：${JSON.stringify(匹配_节点)}`)
            return 0
        case -1:
            return -1
        case 0:
            return 1
    }
}

KuaiShou.prototype.ks_用户主页进入私信页面 = function () {
    当前执行模块 = 'ks_用户主页进入私信页面';
    日志打印_debug('开始执行 - 【ks_用户主页进入私信页面】')

    let 用户主页_私信按钮 = findColor(ks.用户主页_私信按钮)
    let 重试次数 = 3

    if(!用户主页_私信按钮){
        setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"1","boundsFilter":"2","excludedAttributes":""})
        let 用户节点 = bounds(0, 230, ScreenWidth, ScreenHeight).label("发私信").getOneNodeInfo(10000)
        while(!用户节点 &&  重试次数 > 0){
            if(isScriptExit()) {break}
            iSleep(100)
            const 还在用户主页 = ocr文本数组匹配(ks.用户作品主页)
            if(还在用户主页){
                用户节点 = bounds(0, 230, ScreenWidth, ScreenHeight).label("发私信").getOneNodeInfo(10000)
                if(!用户节点){
                    用户节点 = bounds(0, 230, ScreenWidth, ScreenHeight).type('Button').label("B62A27C7 A215 49FF 8225 3A3360").getOneNodeInfo(10000)
                }
            }
            重试次数--
        }
        if(!用户节点){
            日志打印_error('[用户主页_私信按钮] 获取失败！')
            return false
        }
        用户主页_私信按钮 = {name: '用户主页_私信按钮', x: 用户节点.bounds.left/2+用户节点.bounds.right/2, y: 用户节点.bounds.top/2+用户节点.bounds.bottom/2}
    }

    logw(JSON.stringify(用户主页_私信按钮))
    const 进入私信页面 = 点击后检测(用户主页_私信按钮, ks.用户作品主页, [ks.私信页笑脸标识])
    if(进入私信页面 !== 0){ return  false }
    return true
}

KuaiShou.prototype.ks_检测私信未成功 = function () {
    日志打印_debug('开始执行 - 【ks_用户主页进入私信页面】')
    return !!findColor(ks.私信未成功标识)
}

KuaiShou.prototype.ks_退出私信页面_返回用户主页 = function () {
    当前执行模块 = 'ks_退出私信页面_返回用户主页';
    日志打印_debug(`开始执行 - 【ks_退出私信页面_返回用户主页】`);

    const 返回用户主页 = 点击后检测(ks.用户主页_返回按钮, ks.私信页笑脸标识, [ks.用户作品主页]);
    switch (返回用户主页) {
        case -100:
            return false
        case -1:
            return false
        case 0:
            进入实时回复 = false;
            return true;
    }
}

KuaiShou.prototype.ks_用户主页_返回搜索页 = function () {
    当前执行模块 = 'ks_用户主页_返回搜索页';
    日志打印_debug(`开始执行 - 【ks_用户主页_返回搜索页】`);

    const 返回搜索页面 = 点击后检测(ks.用户主页_返回按钮, ks.用户作品主页, [ks.搜索页_搜索结果标签]);
    switch (返回搜索页面) {
        case -100:
            return false
        case -1:
            return false
        case 0:
            return true
    }
}

KuaiShou.prototype.ks_搜索页_返回首页 = function (){
    当前执行模块 = 'ks_搜索页_返回首页';
    日志打印_debug(`开始执行 -- 【ks_搜索页_返回首页】`)

    const 搜索页_返回首页 = 点击后检测(ks.用户主页_返回按钮, ks.搜索页_右上角_ai对话标识, [ks.首页_底部导航, ks.首页_底部导航_二值化, ks.首页_底部导航_首页选中_二值化, ks.首页_顶部导航])
    if(搜索页_返回首页 === -1 || 搜索页_返回首页 === -100){ return false }
    return true
}

KuaiShou.prototype.ks_获取聊天页用户昵称 = function (){
    当前执行模块 = 'ks_获取聊天页用户昵称';
    日志打印_debug(`开始执行 -- 【ks_获取聊天页用户昵称】`)
    setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"1","boundsFilter":"2","excludedAttributes":""})
    let 聊天用户昵称_节点 = bounds(0,40,ScreenWidth,140).type("Button").getOneNodeInfo(10000)
    let 重试次数 = 3;
    while(!聊天用户昵称_节点 && 重试次数>0){
        if(isScriptExit()){break}
        iSleep(100);
        const 还在预期页面 = findColor(ks.私信页笑脸标识)
        if(还在预期页面){
            聊天用户昵称_节点 = bounds(0,40,ScreenWidth,140).type("Button").getOneNodeInfo(10000)
        }
        重试次数--;
    }
    if(!聊天用户昵称_节点){
        日志打印_error('寻找 [节点_视频] 失败');
        return
    }

    return { name: 聊天用户昵称_节点.name, x: 聊天用户昵称_节点.bounds.left/2+聊天用户昵称_节点.bounds.right/2, y: 聊天用户昵称_节点.bounds.top/2+聊天用户昵称_节点.bounds.bottom/2}
}

KuaiShou.prototype.ks_节点获取聊天记录 = function (用户昵称){
    当前执行模块 = 'ks_节点获取聊天记录';
    日志打印_debug(`开始执行 -- 【ks_节点获取聊天记录】`)

    setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"1","boundsFilter":"2","excludedAttributes":""})
    let Table_节点 = type("Table").getOneNodeInfo(10000)
    let 重试次数 = 3;
    while(!Table_节点 && 重试次数>0){
        if(isScriptExit()){break}
        iSleep(100);
        const 还在预期页面 = findColor(ks.私信页笑脸标识)
        if(还在预期页面){
            Table_节点 = type("Table").getOneNodeInfo(10000)
        }
        重试次数--;
    }
    if(!Table_节点){
        日志打印_error('寻找 [Table_节点] 失败');
        return
    }
    const Cells = Table_节点.allChildren()
    const 聊天内容 = []
    Cells.sort((a, b) => a.bounds.bottom - b.bounds.bottom);
    for(let i in Cells){
        if(isScriptExit()){break}
        const cell = Cells[i]
        if(cell.type === 'Cell' && cell.label && cell.label !== ''){
            const 单条聊天内容 = cell.label
            if(单条聊天内容.startsWith(`${用户昵称}`)){
                let 单条聊天内容_修整 = 单条聊天内容.replace(`${用户昵称}`, '')
                if(单条聊天内容_修整.startsWith('说')){
                    单条聊天内容_修整 = 单条聊天内容_修整.replace('说', '')
                }
                if(单条聊天内容_修整 === ''){
                    const allChildren = cell.allChildren()
                    if(allChildren && allChildren.length>0){
                        单条聊天内容_修整 = allChildren[0].label
                    }
                }
                const 客户说 = `客户:${单条聊天内容_修整}`
                聊天内容.push(客户说)
            }
            else if(单条聊天内容.startsWith('我说')){
                let 单条聊天内容_修整 = 单条聊天内容.replace('我说', '')
                const 我说 = `我:${单条聊天内容_修整}`
                聊天内容.push(我说)
            }
        }
    }
    const 聊天记录 = 聊天内容.join('\n')
    logw(JSON.stringify(聊天记录))
    return 聊天记录
}

KuaiShou.prototype.ks_用户主页点关注 = function (follow_probability=0.3){
    const 随机数 = Math.random();
    const 概率 = follow_probability
    if(随机数 < 概率) {
        //点关注
        let 关注按钮 = findColor(ks.用户主页_关注按钮)
        if (!关注按钮) {
            return
        }
        点击(关注按钮);
        日志打印_debug('【私信用户时点关注】点关注成功！')
        return;
    }
}

KuaiShou.prototype.ks_发送私信 = function (私信内容) {
    当前执行模块 = 'ks_发送私信';
    日志打印_debug(`开始执行 - 【ks_发送私信】`);

    const sendText = `${私信置信度增加(私信内容)}${my_msg_end[Math.floor(Math.random() * my_msg_end.length)]}`

    const 私信页面输入框表情按钮 = findColor(ks.私信页笑脸标识);
    if (!私信页面输入框表情按钮) {
        日志打印_error('(私信页面输入框表情按钮) 获取失败！')
        return false
    }

    const 私信输入框 = {name: '私信输入框', x: 私信页面输入框表情按钮.min_x - 250, y: 私信页面输入框表情按钮.min_y / 2 + 私信页面输入框表情按钮.max_y / 2};

    const 输入框点击结果 = 点击后检测(私信输入框, ks.私信页笑脸标识, [ios.键盘弹出]);
    switch (输入框点击结果) {
        case -100:
            return false
        case -1:
            return false
        case 0:
            日志打印_debug('(输入框点击结果) 成功！')
            break
    }

    文本内容输入(sendText, 私信输入框);
    iSleep(100);
    let 私信发送按钮 = findColor(ks.私信页发送私信按钮);
    let 重试次数 = 3;
    while (!私信发送按钮 && 重试次数>0) {
        if (isScriptExit()) {break}
        文本内容输入(sendText, 私信输入框);
        iSleep(100);
        私信发送按钮 = findColor(ks.私信页发送私信按钮);
        重试次数--;
    }
    if(!私信发送按钮){
        日志打印_error('(私信发送按钮) 获取失败！')
        return false
    }
    键盘发送()
    iSleep(100);
    私信发送按钮 = findColor(ks.私信页发送私信按钮);
    重试次数 = 3;
    while (私信发送按钮 && 重试次数>0) {
        if (isScriptExit()) {break}
        键盘发送()
        iSleep(100);
        私信发送按钮 = findColor(ks.私信页发送私信按钮);
        重试次数--;
    }
    const 关闭私信键盘 = {name: '关闭私信键盘', x: random(10, 25), y: random(460, 520)}
    点击(关闭私信键盘)
    iSleep(300);
    return true
}
