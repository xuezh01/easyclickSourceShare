
function 快手关键词检索后私信工作流() {
    if(设备账号信息.ks.length === 0){
        ks.ks_账号统计_切换_初始化()
    }

    while (快手_私信时间()) {
        if (isScriptExit()) { return }
        if (!快手_查询今日私信是否饱和() && 快手_查询今日是否有私信数据() ) {
            快手_关键词私信()
        }else {
            脚本当前运行阶段 = `养号_跟进客户`
            抖音_养号_跟进客户()
        }
    }
    while(快手_关键词检索时间()){
        if (isScriptExit()) { return }
        快手_关键词检索()
    }
}

function 快手_关键词检索() {
    while (ks.关键词已无视频){
        if(isScriptExit()){break}
        脚本当前运行阶段 =`【${脚本运行配置.ks.keyword_search.keyword}】该关键词无更多视频,请重新分配关键词！`
        iSleep(2000)
    }

    脚本当前运行阶段 = `快手关键词检索：【${脚本运行配置.ks.keyword_search.keyword}】`
    ks.初始化()

    if (!ks.ks_首页导航_切换(2)) {
        ks.ks_启动快手()
        return
    }
    ks.ks_跟进客户()
    脚本当前运行阶段 = `快手关键词检索：【${脚本运行配置.ks.keyword_search.keyword}】`

    if (!ks.ks_首页搜索按钮点击(脚本运行配置.ks.search_time_interval)) { return }
    if (!ks.ks_搜索页面输入查询(脚本运行配置.ks.keyword_search.keyword)) { return }
    if (快手_私信时间()){ return }
    if (!ks.ks_搜索结果分类选择('视频')) { return }
    if (ks.ks_搜索结果频繁_养号()){ return }
    if (!ks.ks_搜索结果的视频点击()) { return }

    // 进入视频轮询查看阶段
    while (true){
        if (isScriptExit()) { return }
        if (快手_私信时间()){ return }
        if (ks.关键词已无视频) { return }
        if (!ks.ks_视频播放页面判断()){ return }
        const 视频信息 = ks.ks_视频信息采集()
        if (!视频信息 || 视频信息.评论数量 <= 0 || 视频信息.name.trim() === ''){
            ks.ks_上滑切换视频()
            continue
        }
        const 上传视频信息 = {
            "belong_device_id": device_id,
            "account_id": 快手_获取当前账号的快手ID(),
            "account_type": "快手",
            "belong_uid": uid,
            "video_keyword": 脚本运行配置.ks.keyword_search.keyword,
            "video_up_id": '',
            "video_up_name": 视频信息.作者,
            "video_type":  视频信息.类型,
            "video_comment_count": 视频信息.评论数量,
            "video_title": 视频信息.name,
            "video_up_homepage": 视频信息.homepage,
            "video_release_time ": 视频信息.发布日期,
            "video_up_information": ""
        }
        const 视频指令 = api_获取视频是否已观看(上传视频信息)
        日志打印_information(`视频指令: ${JSON.stringify(视频指令)}`)
        日志打印_information(`视频指令: ${typeof 视频指令.video_sid}`)

        if (!视频指令.catch){
            ks.ks_上滑切换视频()
            continue
        }
        if (!视频信息.name.includes(脚本运行配置.ks.keyword_search.keyword)){
            const params = {
                "videoContent": 视频信息.name,
                "hangye":  脚本运行配置.ks.keyword_search.industry,
                "keyword": 脚本运行配置.ks.keyword_search.keyword,
                "up_name": 视频信息.作者,
                "account_type": "快手",
            }
            const 视频判断结果 = 视频判断(params)
            if (视频指令.video_sid !== null && 视频指令.video_sid){
                const 视频判断结果记录 = {
                    "video_sid": parseInt(视频指令.video_sid),
                    "accuracy": String(视频判断结果),
                    "account_type": "快手",
                }
                api_记录视频精准度(视频判断结果记录)
            }
            if (!视频判断结果){
                ks.ks_上滑切换视频()
                continue
            }
        }
        else {
            if (视频指令.video_sid !== null && 视频指令.video_sid){
                const 视频判断结果记录 = {
                    "video_sid": parseInt(视频指令.video_sid),
                    "accuracy": '包含关键词，不判断',
                    "account_type": "快手",
                }
                api_记录视频精准度(视频判断结果记录)
            }
        }
        const 进入评论区 = ks.ks_进入评论区()
        if (进入评论区 !== 0){ continue }
        if (脚本运行配置.ks.keyword_search.leave_traces.state){
            const 留痕内容 = 脚本运行配置.ks.keyword_search.leave_traces.message
            if (留痕内容 && 留痕内容.trim() !== ''){
                if (!ks.ks_评论区留痕()){ continue }
                const 留痕记录 = {
                    "video_sid": parseInt(视频指令.video_sid),
                    "account_id": 抖音_获取当前账号的抖音ID(),
                    "account_type": "快手"
                }
                api_记录视频留痕(留痕记录)
            }
        }

        if (!ks.ks_评论区抓取(parseInt(视频指令.video_sid))){ continue }
        if (快手_私信时间()){ return }
        if (!ks.ks_关闭评论区()){ continue }
        ks.ks_上滑切换视频()
    }
}

function 快手_关键词私信() {
    ks.初始化()
    // 更新抖音账号今日私信()
    while (true){
        if (isScriptExit()) { return }

        脚本当前运行阶段 = `快手私信：【检索数据】`

        if (快手_查询今日私信是否饱和()) { return }
        if (!快手_私信时间()) { return }

        const data = 快手_获取当前账号私信用户_抖音ID()
        if (!data){
            日志打印_information(`无可发送数据`)
            if(!快手_可切换私信账号()){ return }
            ks.ks_账号统计_切换_初始化()
            continue
        }

        const 当前发送快手ID = data.send_customer_id
        进入实时回复 = false;

        if (ks.私信已发送列表.includes(当前发送快手ID)){
            api_记录账号今日已私信数据(data.aaci_atid, 当前发送快手ID,2)
            continue
        }
        if (!ks.ks_首页导航_切换(2)) {
            ks.ks_启动快手()
            return
        }
        ks.ks_跟进客户()
        if (快手_当前账号私信已饱和()) {
            if(!快手_可切换私信账号()) { return }
            ks.ks_账号统计_切换_初始化(false)
            continue
        }

        脚本当前运行阶段 = `快手私信：【检索数据】`
        if (!ks.ks_首页导航_切换(2)) { return }
        if (!ks.ks_首页搜索按钮点击(脚本运行配置.ks.search_time_interval)) { return }
        if (!ks.ks_搜索页面输入查询(当前发送快手ID)) { return }
        if (!ks.ks_搜索结果分类选择('用户')) { return }
        if (ks.ks_搜索结果频繁_养号()){ return }

        const 进入结果 = ks.ks_选择进入搜索的用户();
        switch (进入结果) {
            case -1:
                return
            case 0:
                api_记录账号今日已私信数据(data.aaci_atid, 当前发送快手ID,3)
                if (!ks.ks_搜索页_返回首页()) { return }
                continue
            case 1:
                break
        }
        ks.ks_用户主页点关注(脚本运行配置.ks.send_msg.follow_probability)
        if (!ks.ks_用户主页进入私信页面()) { return }

        if (ks.ks_检测私信未成功()){
            api_记录账号今日已私信数据(data.aaci_atid, 当前发送快手ID,2)
            ks.私信已发送列表.push(当前发送快手ID)
            ks.搜索时间 = time() - 脚本运行配置.ks.search_time_interval*60*1000

            if (!ks.ks_退出私信页面_返回用户主页()) { return }
            if (!ks.ks_用户主页_返回搜索页()) { return }
            if (!ks.ks_搜索页_返回首页()) { return }
            continue;
        };

        const 聊天用户 = ks.ks_获取聊天页用户昵称()
        if(!聊天用户) { return }

        const 聊天记录 = ks.ks_节点获取聊天记录(聊天用户.name);
        let 执行发送私信 = true
        if (聊天记录 && 聊天记录 !== ''){
            const 聊天记录Array = 聊天记录.split('\n')
            for(let ii in 聊天记录Array){
                if(isScriptExit()){break}
                if(聊天记录Array[ii].startsWith('我:')){
                    执行发送私信 = false
                    break
                }
            }
        }
        if(!执行发送私信){
            api_记录账号今日已私信数据(data.aaci_atid, 当前发送快手ID,2)
            ks.私信已发送列表.push(当前发送快手ID)
        }else {
            ks.ks_发送私信(脚本运行配置.ks.keyword_search.send_msg.first_msg)
            api_记录账号今日已私信数据(data.aaci_atid, 当前发送快手ID,1)
            ks.私信已发送列表.push(当前发送快手ID)
            const 私信未成功 = ks.ks_检测私信未成功();
            快手_私信统计更新(私信未成功, false)
            if (私信未成功) {
                if(快手_可切换私信账号()){
                    ks.ks_账号统计_切换_初始化()
                    continue
                }
            }
        }
        if (!ks.ks_退出私信页面_返回用户主页()) { return }
        if (!ks.ks_用户主页_返回搜索页()) { return }
        if (!ks.ks_搜索页_返回首页()) { return }
    }
}