
function start_抖音话题抓取(uid, 关键词) {
    douyin.初始化();
    douyin.dy_启动抖音();
    开启私信回复 = true;
    douyin.dy_首页搜索按钮点击();
    douyin.dy_搜索页面输入查询(关键词);
    douyin.dy_搜索结果分类选项选择('话题');

    const 已浏览话题 = [];
    let tryCount = 5;
    while (tryCount > 0) {
        if (isScriptExit()) { break }
        logw('【抖音脚本】话题评论抓取时间段')

        if(!huatigetNowTime()){
            break
        }

        let 无新话题 = 0;
        const 话题排序 = douyin.dy_话题播放量排序();
        for( const i in 话题排序){
            if (isScriptExit()) { break }

            const 选择话题 = 话题排序[i];
            if (已浏览话题.includes(选择话题.name)){
                continue;
            }
            已浏览话题.push(选择话题.name);
            无新话题++;
            douyin.dy_话题视频_进入选择最新(选择话题);
            const keywordSid = 插入无人值守关键词搜索记录(选择话题.name, '全国', '不限', 设备ID);
            if (!keywordSid) {
                loge('【插入关键词搜索记录】服务器数据请求失败！');
                scriptWarn('【插入关键词搜索记录】服务器数据请求失败！');
            }
            while (true){
                if (isScriptExit()) { break }

                if(!huatigetNowTime()){
                    break
                }

                const 视频信息 = douyin.dy_视频信息采集();
                logd(`视频信息: ${JSON.stringify(视频信息)}`)
                评论区是否留痕 = true;
                if(评论区是否留痕){
                    // douyin.dy_评论区留痕('不错不错')
                }
                const videoSid = 插入已浏览视频内容(uid, keywordSid, 视频信息.name);
                douyin.dy_评论区抓取(选择话题.name, videoSid, 视频信息.name);
                douyin.dy_关闭评论区();
                douyin.dy_上滑切换视频(false);
            }
            douyin.dy_返回话题搜索页()
        }
        douyin.dy_话题栏上滑刷新话题()
        if(无新话题 === 0){
            tryCount--;
        }
    }
}