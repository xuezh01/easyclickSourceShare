
function 抖音图文获客() {
    脚本当前运行阶段 = `图文流程检索：【${脚本运行配置.dy.keyword_search.keyword}】`
    脚本运行配置.dy.keyword_search.keyword = api_获取检索关键词('抖音',抖音_获取当前账号的抖音ID())
    douyin.初始化()
    if (!douyin.dy_首页导航_切换(1)) {
        douyin.dy_启动抖音()
        iSleep(1000)
        return -8
    }
    // douyin.dy_跟进客户()
    if (!douyin.dy_首页搜索按钮点击(脚本运行配置.dy.search_time_interval)) { return -1}
    if (!douyin.dy_搜索页面输入查询(脚本运行配置.dy.keyword_search.keyword)) { return -2}
    if (!douyin.dy_搜索结果分类选项选择('综合')) { return -3}
    if (douyin.dy_搜索结果频繁_检测()){ return -4}
    if (!douyin.dy_切换单列模式()){ return -5}
    if (!douyin.dy_图文筛选(
                            脚本运行配置.dy.keyword_search.video_filter.video_sort_by,
                            脚本运行配置.dy.keyword_search.video_filter.video_release_time,
                            脚本运行配置.dy.keyword_search.video_filter.video_duration,
                            脚本运行配置.dy.keyword_search.video_filter.video_search_scope
                        )) { return -6}

    let 图文作品_是否获取完成 = false
    let 获取结果返回 = 1
    while (!图文作品_是否获取完成 && 获取结果返回 === 1){
        if (isScriptExit()){return}
        if (!抖音_私信时间()){ return -7}
        获取结果返回 = douyin.dy_图文流_评论抓取()
        logd("图文返回结果：{}",获取结果返回)
        iSleep(2000)
        if (douyin.dy_图文作品_当前数据是否获取完成()){
            图文作品_是否获取完成 = true
        }
    }
    if (图文作品_是否获取完成){
        return 666
    }
    return 1;
}

/**
 * 图文综合页面评论区获取
 * @returns {number} 1正常返回 可继续   负数报错重启
 */
DouYin.prototype.dy_图文流_评论抓取 = function (){
    setFetchNodeParam({"labelFilter":"1","maxDepth":"20","visibleFilter":"1","boundsFilter":"1","excludedAttributes":""})
    let 搜索结果_水平滚动条节点 = labelMatch(".*水平滚动条.*").getOneNodeInfo(10000)
    let 搜索结果_所有节点视图节点 = null
    let 搜索结果_所有节点 = null
    let 搜索结果_所有视频选择节点 = []
    if (!搜索结果_水平滚动条节点){
        return -1
    }
    搜索结果_所有节点视图节点 = 搜索结果_水平滚动条节点.parent()
    logi("搜索结果_所有节点视图节点:{}",JSON.stringify(搜索结果_所有节点视图节点))
    if (!搜索结果_所有节点视图节点){
        return -2
    }
    const 是否有全部导航 = ocr文本不完全匹配('全部',0,212,750,308)
    if (是否有全部导航){
        搜索结果_所有节点视图节点.bounds.top = 308
    }
    搜索结果_所有节点 = 搜索结果_所有节点视图节点.allChildren()
    logi("搜索结果_所有节点:{}",JSON.stringify(搜索结果_所有节点))
    if (!搜索结果_所有节点 || !搜索结果_所有节点.length){
        return -3
    }
    搜索结果_所有节点.forEach(itme =>{
        if(isScriptExit()){return}
        if (itme.type === 'Cell'){
            搜索结果_所有视频选择节点.push(itme)
        }
    })

    if (搜索结果_所有视频选择节点.length >0){
        for (var i = 0;i < 搜索结果_所有视频选择节点.length;i++){
            let 节点 = 搜索结果_所有视频选择节点[i]
            logi("节点数据：{}",JSON.stringify(节点))
            const 节点ocr = ocr范围识别(节点.bounds.left,节点.bounds.top,节点.bounds.right,节点.bounds.bottom>1320 ? 1330: 节点.bounds.bottom)
            logi("节点ocr:{}",JSON.stringify(节点ocr))

            if (节点.bounds.top < 搜索结果_所有节点视图节点.bounds.top && 节点.bounds.bottom - 搜索结果_所有节点视图节点.bounds.top >= 30){
                logi("滑动重启")
                douyin.dy_图文作品滑动切换(节点,搜索结果_所有节点视图节点)
                // let 滑动结果 = 滑动误触检测([douyin.搜索页面的搜索按钮,douyin.图文搜索_滑动作品误触抖音百科,douyin.视频播放页_关注按钮],500,节点.bounds.bottom>1320 ? 1320 : 节点.bounds.bottom,502,搜索结果_所有节点视图节点.bounds.top-15,10000,2500)
                // switch (滑动结果){
                //     case 0:break
                //     case 1:
                //         var 抖音百科_误触返回 = {name: "抖音百科_误触返回",x:random(45,60),y:random(65,100)}
                //         var 误触返回结果 = 点击后检测(抖音百科_误触返回,douyin.图文搜索_滑动作品误触抖音百科,[douyin.搜索页面的搜索按钮])
                //         if (误触返回结果 != 0){
                //             return -4
                //         }
                //         break
                //     case 2:
                //         var 图文作品_误触返回 = {name: "图文作品_误触返回",x:random(40,55),y:random(65,100)}
                //         var 误触返回结果 = 点击后检测(图文作品_误触返回,douyin.视频播放页_关注按钮,[douyin.搜索页面的搜索按钮])
                //         if (误触返回结果 != 0){
                //             return -4
                //         }
                //         break
                //     default:
                //         return -5
                // }
                return 1
            }
            if (!节点ocr){continue}

            // ocr文本数组匹配()
            douyin.图文作品搜索结果作品评论标识.x = 节点.bounds.left
            douyin.图文作品搜索结果作品评论标识.y = 节点.bounds.bottom>1320 ? 1330/10*7 : 节点.bounds.bottom/10*7
            douyin.图文作品搜索结果作品评论标识.ex = 节点.bounds.right
            douyin.图文作品搜索结果作品评论标识.ey = 节点.bounds.bottom>1320 ? 1330 : 节点.bounds.bottom
            logi("图文作品搜索结果作品评论标识:{}",JSON.stringify(douyin.图文作品搜索结果作品评论标识))
            const 是否是图文作品 = findColor(douyin.图文作品搜索结果作品评论标识)
            if (是否是图文作品){
                const 上传视频信息 = {
                    "belong_device_id": device_id,
                    "account_id": 抖音_获取当前账号的抖音ID(),
                    "account_type": "抖音",
                    "belong_uid": uid,
                    "video_keyword": 脚本运行配置.dy.keyword_search.keyword,
                    "video_up_id": '',
                    "video_up_name": '',
                    "video_type":  '图文',
                    "video_comment_count": '',
                    "video_title": '',
                    "video_up_homepage": '',
                    "video_up_information": "",
                    "video_release_time":''
                }
                let 作者信息 = null

                function 是否在直播(x,y,ex,ey) {
                    var 头像截图 = 区域截图base64(x,y,ex,ey)
                    iSleep(100)
                    var 头像截图2 = 区域截图base64(x,y,ex,ey)
                    if (头像截图 === 头像截图2){
                        return false
                    }else {
                        return true
                    }
                }

                let 作者头像按钮 = {name:'图文作品作者头像',x:random(52,102),y:节点.bounds.top + random(44,96)}
                if (是否在直播(30,节点.bounds.top+25,120,节点.bounds.top+115)){
                    作者头像按钮 = {name:'图文作品作者头像',x:random(135,150),y:节点.bounds.top + random(45,50)}
                }
                let 进入结果 = 点击后检测(作者头像按钮,douyin.图文作品搜索结果作品评论标识,[douyin.用户作品主页])
                if (进入结果 === 0){
                    作者信息 = douyin.dy_节点获取抖音ID()
                    const 返回搜索页面 = 点击后检测(douyin.用户主页_返回按钮, douyin.用户作品主页, [douyin.图文作品搜索结果作品评论标识]);
                    if (返回搜索页面 != 0){
                        logd("用户主页返回出错")
                        return -2
                    }
                }
                const 作品信息_时间 = douyin.dy_图文ocr节点_标题切割(节点ocr,作者信息.用户昵称)
                const regex = /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/;
                上传视频信息.video_up_id = 作者信息.抖音ID
                上传视频信息.video_up_name = 作者信息.用户昵称
                上传视频信息.video_title = 作品信息_时间.标题
                上传视频信息.video_release_time = regex.test(作品信息_时间.日期) ? 作品信息_时间.日期 : ''
                const 评论打开结果 = 点击后检测(是否是图文作品,douyin.图文作品搜索结果作品评论标识,[douyin.评论页面艾特标识,ios.键盘弹出])
                switch (评论打开结果) {
                    case 0: // 评论区打开成功
                        break;
                    case 1:
                        // 该视频无评论内容
                        const 关闭_弹出键盘 = {name: '关闭_弹出键盘', x: random(140, 568), y: random(292, 418)};
                        const 关闭_弹出键盘_结果 = 点击后检测(关闭_弹出键盘,ios.键盘弹出 , [douyin.评论页面艾特标识]);
                        if(关闭_弹出键盘_结果 !== 0){
                            日志打印_error('关闭 [弹出键盘]  失败')
                            return -2
                        }
                        break;
                    default:
                        return -2
                }
                let 评论数量 = douyin.dy_节点获取评论数量()
                let 视频判断结果 = true
                上传视频信息.video_comment_count = 评论数量
                const 视频指令 = api_获取视频是否已观看(上传视频信息)
                logd("视频是否已观看-：{}",JSON.stringify(上传视频信息))
                // if (视频指令.catch) {
                //
                // }
                if (!作品信息_时间.标题.includes(脚本运行配置.dy.keyword_search.keyword)) {
                    const params = {
                        "videoContent": 作品信息_时间.标题,
                        "hangye": 脚本运行配置.dy.keyword_search.industry,
                        "keyword": 脚本运行配置.dy.keyword_search.keyword,
                        "up_name": 作者信息.用户昵称,
                        "account_type": "抖音",
                    }
                    视频判断结果 = api_判断视频精准度(uid,'抖音',作者信息.用户昵称,脚本运行配置.dy.keyword_search.keyword,作品信息_时间.标题)
                    logd("视频是否精准：{}",JSON.stringify(视频判断结果))
                    if (视频指令.video_sid && 视频指令.video_sid !== null) {
                        const 视频判断结果记录 = {
                            "video_sid": parseInt(视频指令.video_sid),
                            "accuracy": String(视频判断结果),
                            "account_type": "抖音",
                        }
                        api_记录视频精准度(视频判断结果记录)
                    }
                } else {
                    if (视频指令.video_sid && 视频指令.video_sid !== null) {
                        const 视频判断结果记录 = {
                            "video_sid": parseInt(视频指令.video_sid),
                            "accuracy": '包含关键词，不判断',
                            "account_type": "抖音",
                        }
                        api_记录视频精准度(视频判断结果记录)
                        视频判断结果 = true
                    }
                }
                if (视频判断结果 && 评论数量>0) {
                    douyin.dy_图文评论区抓取(parseInt(视频指令.video_sid))
                }

                logd("上传视频信息:{}",JSON.stringify(上传视频信息))
                douyin.dy_图文关闭评论区(douyin.图文作品搜索结果作品评论标识)
                iSleep(300)
                logd("正常滑动")
                douyin.dy_图文作品滑动切换(节点,搜索结果_所有节点视图节点)
                break
            }else {
                logd('图文作品图标识别失败')
                douyin.dy_图文作品滑动切换(节点,搜索结果_所有节点视图节点)
                break
            }
        }
    }
    return 1
}

DouYin.prototype.dy_图文作品_当前数据是否获取完成 = function () {
    setFetchNodeParam({"labelFilter":"2","maxDepth":"19","visibleFilter":"2","boundsFilter":"1","excludedAttributes":""})
    let 暂无更多 = type('Other').labelMatch(".*暂无更多.*").getOneNodeInfo(10000)
    if (暂无更多){
        return true
    }else {
        return false
    }
}

DouYin.prototype.dy_图文作品滑动切换 = function (节点,搜索结果_所有节点视图节点) {
    // let 滑动结果 = 滑动误触检测([douyin.搜索页面的搜索按钮,douyin.图文搜索_滑动作品误触抖音百科,douyin.视频播放页_关注按钮],500,节点.bounds.bottom>1320 ? 1320 : 节点.bounds.bottom,502,节点.bounds.top+10,1000,2500)
    logd("滑动位置：起点{}，终点:{}",节点.bounds.bottom>1320 ? 1320 : 节点.bounds.bottom,搜索结果_所有节点视图节点.bounds.top)
    let 滑动结果 = 滑动误触检测([douyin.搜索页面的搜索按钮,douyin.图文搜索_滑动作品误触抖音百科,douyin.视频播放页_关注按钮,douyin.图文搜索_滑动作品误触今日头条],500,节点.bounds.bottom>1320 ? 1320 : 节点.bounds.bottom,502,搜索结果_所有节点视图节点.bounds.top,500,3000)
    logd("滑动结果：{}",滑动结果)
    switch (滑动结果){
        case 0:break
        case 1:
            var 抖音百科_误触返回 = {name: "抖音百科_误触返回",x:random(45,60),y:random(65,100)}
            var 误触返回结果 = 点击后检测(抖音百科_误触返回,douyin.图文搜索_滑动作品误触抖音百科,[douyin.搜索页面的搜索按钮])
            if (误触返回结果 != 0){
                return -4
            }
            break
        case 2:
            var 图文作品_误触返回 = {name: "图文作品_误触返回",x:random(40,55),y:random(65,100)}
            var 误触返回结果 = 点击后检测(图文作品_误触返回,douyin.视频播放页_关注按钮,[douyin.搜索页面的搜索按钮])
            if (误触返回结果 != 0){
                return -4
            }
            break
        case 3:
            var 今日头条_误触返回 = {name: "今日头条_误触返回",x:random(680,705),y:random(78,103)}
            var 误触返回结果 = 点击后检测(今日头条_误触返回,douyin.图文搜索_滑动作品误触今日头条,[douyin.搜索页面的搜索按钮])
            if (误触返回结果 != 0){
                return -4
            }
            break
        default:
            return -5
    }
    return 1
}

DouYin.prototype.dy_图文ocr节点_标题切割 = function (ocr所有内容,作者名称) {
    if (!ocr所有内容 || !ocr所有内容.length){return -1}
    const 图文信息 = {作者名称:'',标题:'',日期:''}
    for (var i = 0;i<ocr所有内容.length;i++){
        let 单行 = ocr所有内容[i]
        var date = -1
        if (!图文信息.日期){
            date = parseTimeString(单行.label)
            if (date != -1){
                图文信息.日期 = date
                continue
            }
            continue
        }

        let 下一行 = ocr所有内容[i+1]
        图文信息.标题 += 单行.label
        if (!douyin.dy_标题判断_是否是图文标题(单行,下一行)){
            break
        }
    }
    return 图文信息
}

DouYin.prototype.dy_标题判断_是否是图文标题 = function (单行,下一行) {
    logd("行间距：{}",下一行.y - 单行.y)
    if (下一行.y - 单行.y >= 41 && 下一行.y - 单行.y <= 50){
        return true
    }
    return false
}

DouYin.prototype.dy_图文筛选 = function (排序依据, 发布时间, 视频时长, 搜索范围){
    当前执行模块 = 'dy_图文筛选';

    let 搜索页_右上角_筛选按钮 = findColor(douyin.搜索页_右上角_筛选按钮)
    if(!搜索页_右上角_筛选按钮){
        setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
        let 筛选按钮_节点 = type("Button").label("筛选").getOneNodeInfo(10000)
        let 重试次数 = 3;
        while(!筛选按钮_节点 && 重试次数>0){
            if(isScriptExit()){break}
            iSleep(100);
            const 还在预期页面 = ocr文本数组匹配(douyin.搜索页_搜索结果标签)
            if(还在预期页面){
                筛选按钮_节点 = type('Button').name("筛选").getOneNodeInfo(10000);
            }
            重试次数--;
        }
        if(!筛选按钮_节点){
            日志打印_error('寻找 [筛选按钮_节点] 失败');
            return false
        }
        搜索页_右上角_筛选按钮 = { name: '搜索页_右上角_筛选按钮',  x: 筛选按钮_节点.bounds.left + (筛选按钮_节点.bounds.right-筛选按钮_节点.bounds.left)/3, y:  筛选按钮_节点.bounds.top/2 + 筛选按钮_节点.bounds.bottom/2}
    }

    const 排序展开点击结果 = 点击后检测(搜索页_右上角_筛选按钮, douyin.搜索页_搜索结果标签, [douyin.搜索页_视频筛选依据]);
    if(排序展开点击结果 !== 0){
        return false
    }

    const 有图文选项 = ocr文本不完全匹配('图文', 20, 760, ScreenWidth, 1130)
    if(有图文选项){
        const 图文作品 = {name: '图文作品', x: random(424, 478), y: random(1039, 1070)}
        const 图文作品点击结果 = 点击屏幕检测(图文作品, 1000, 60, 760, 700, 1130);
        if(!图文作品点击结果){
            日志打印_error('（图文作品点击结果）失败！')
            return false
        }
    }

    if (排序依据 === '综合排序' && 发布时间 === '不限' && 视频时长 === '不限' && 搜索范围 === '不限'){
        const 关闭排序页面 = 点击屏幕检测(搜索页_右上角_筛选按钮, 1000, 60, 200, ScreenWidth, 900)
        if(!关闭排序页面){
            日志打印_error('（关闭排序页面）失败！')
            return false
        }
        return true
    }

    if (排序依据 !== '综合排序'){
        switch (排序依据) {
            case '最新发布':
                const 最新发布 = {name: '最新发布', x: random(230, 320), y: random(340, 360)}
                const 选择_最新发布 = 点击屏幕检测(最新发布, 1000, 60, 200, ScreenWidth, 900)
                if(!选择_最新发布) { return false }
                break
            case '最多点赞':
                const 最多点赞 = {name: '最多点赞', x: random(400, 500), y: random(340, 360)}
                const 选择_最多点赞 = 点击屏幕检测(最多点赞, 1000, 60, 200, ScreenWidth, 900)
                if(!选择_最多点赞) { return false }
                break
        }
        iSleep(1000)
    }
    if (发布时间 !== '不限'){
        switch (发布时间) {
            case '一天内':
                const 一天内 = {name: '一天内', x: random(240, 320), y: random(515, 540)}
                const 选择_一天内 = 点击屏幕检测(一天内, 1000, 60, 200, ScreenWidth, 900)
                if(!选择_一天内) { return false }
                break
            case '一周内':
                const 一周内 = {name: '一周内', x: random(410, 480), y: random(515, 540)}
                const 选择_一周内 = 点击屏幕检测(一周内, 1000, 60, 200, ScreenWidth, 900)
                if(!选择_一周内) { return false }
                break
            case '半年内':
                const 半年内 = {name: '半年内', x: random(585, 660), y: random(515, 540)}
                const 选择_半年内 = 点击屏幕检测(半年内, 1000, 60, 200, ScreenWidth, 900)
                if(!选择_半年内) { return false }
                break
        }
        iSleep(1000)
    }
    if (视频时长 !== '不限'){
        switch (视频时长) {
            case '1分钟以下':
                const 一分钟以下 = {name: '一分钟以下', x: random(240, 340), y: random(690, 715)}
                const 选择_一分钟以下 = 点击屏幕检测(一分钟以下, 1000, 60, 200, ScreenWidth, 900)
                if(!选择_一分钟以下) { return false }
                break
            case '1-5分钟':
                const 一五分钟 = {name: '一五分钟', x: random(425, 510), y: random(690, 715)}
                const 选择_一五分钟 = 点击屏幕检测(一五分钟, 1000, 60, 200, ScreenWidth, 900)
                if(!选择_一五分钟) { return false }
                break
            case '5分钟以上':
                const 五分钟以上 = {name: '五分钟以上', x: random(590, 670), y: random(690, 715)}
                const 选择_五分钟以上 = 点击屏幕检测(五分钟以上, 1000, 60, 200, ScreenWidth, 900)
                if(!选择_五分钟以上) { return false }
                break
        }
        iSleep(1000)
    }
    if (搜索范围 !== '不限'){
        switch (搜索范围) {
            case '关注的人':
                const 关注的人 = {name: '关注的人', x: random(235, 320), y: random(865, 890)}
                const 选择_关注的人 = 点击屏幕检测(关注的人, 1000, 60, 200, ScreenWidth, 900)
                if(!选择_关注的人) { return false }
                break
            case '最近看过':
                const 最近看过 = {name: '最近看过', x: random(405, 495), y: random(865, 890)}
                const 选择_最近看过 = 点击屏幕检测(最近看过, 1000, 60, 200, ScreenWidth, 900)
                if(!选择_最近看过) { return false }
                break
            case '还未看过':
                const 还未看过 = {name: '选择_还未看过', x: random(580, 650), y: random(865, 890)}
                const 选择_还未看过 = 点击屏幕检测(还未看过, 1000, 60, 200, ScreenWidth, 900)
                if(!选择_还未看过) { return false }
                break
        }
        iSleep(1000)
    }
    const 关闭排序页面 = 点击屏幕检测(搜索页_右上角_筛选按钮, 1000, 60, 200, ScreenWidth, 900)
    if(!关闭排序页面){
        日志打印_error('（关闭排序页面）失败！')
        return false
    }
    iSleep(2000);
    const 无视频内容 = ocr文本数组匹配(douyin.搜索页_视频筛选结果);
    if(无视频内容){
        douyin.关键词已无视频 = true
        日志打印_error('该搜索条件下无相关视频内容')
        return false
    }
    return true

}

DouYin.prototype.dy_节点获取评论数量 = function () {
    日志打印_debug(`开始执行 - 【dy_节点获取评论数量】`);
    setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
    let 评论数量节点 =  type("StaticText").labelMatch(".*评论.*").getOneNodeInfo(10000)
    let 重试次数 = 3;
    while(!评论数量节点 && 重试次数>0){
        if(isScriptExit()) {break}
        iSleep(100);
        const 还在预期页面 = findColor(douyin.评论页面艾特标识);
        if(还在预期页面){
            评论数量节点 = type("StaticText").labelMatch(".*评论.*").getOneNodeInfo(10000)
        }
        重试次数--;
    }
    if(!评论数量节点){
        return 0
    }
    return douyin.dy_评论数量格式化(评论数量节点.label)
}

DouYin.prototype.dy_评论数量格式化 = function (comment) {
    comment = comment.replace('评论','')
    if (comment.includes('万')){
        comment = comment.replace('万', '0000').replace('.', '')
    }
    else if(comment.includes('抢首评') || comment.includes('暂无评论')){
        comment = '0'
    }
    const parsedValue = parseInt(comment);
    return parsedValue!== undefined && parsedValue!== null &&!isNaN(parsedValue)? parsedValue : 0;
}

DouYin.prototype.dy_图文关闭评论区 = function (图文作品搜索结果作品评论标识){
    当前执行模块 = 'dy_图文关闭评论区';

    const 视频播放页面的评论区关闭按钮 = findColor(douyin.图文作品搜索页面评论关闭按钮)
    if (!视频播放页面的评论区关闭按钮) {
        日志打印_error('【dy_图文关闭评论区】（视频播放页面的评论区关闭按钮）寻找失败！')
        return false
    }
    视频播放页面的评论区关闭按钮.name = '【dy_图文关闭评论区】图文关闭评论区关闭按钮'
    const 关闭评论区_结果 = 点击后检测(视频播放页面的评论区关闭按钮, douyin.图文作品搜索页面评论关闭按钮, [图文作品搜索结果作品评论标识]);
    switch (关闭评论区_结果) {
        case -100:
            日志打印_error('（dy_图文关闭评论区）失败！')
            return false
        case -1:
            return false
        case 0:
            日志打印_debug('（dy_图文关闭评论区）成功！')
            return true
    }
}

DouYin.prototype.dy_图文评论区抓取 = function (video_sid,videoContent){
    当前执行模块 = 'dy_图文评论区抓取';
    日志打印_debug('开始执行 - 【dy_图文评论区抓取】')

    let 评论区顶部 = 300;
    let 评论区底部 = 1222;
    let 是否结束评论区获取 = false;
    let 最后一条评论底部 = null

    setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
    let 评论数量节点 =  type("StaticText").labelMatch(".*评论.*").getOneNodeInfo(10000)
    let tryCount = 3;
    while (!评论数量节点 && tryCount>0){
        if(isScriptExit()){break}
        iSleep(100);
        const 还在预期页面 = findColor(douyin.评论页面艾特标识);
        if(还在预期页面){
            评论数量节点 = type("StaticText").labelMatch(".*评论.*").getOneNodeInfo(10000)
        }
        tryCount--
    }
    if(评论数量节点 && 评论数量节点.bounds.bottom > 100 && 评论数量节点.bounds.bottom < 520){
        评论区顶部 = 评论数量节点.bounds.bottom;
    }

    日志打印_debug(`【dy_评论区抓取】评论区范围为 top：${评论区顶部}  bottom：${评论区底部}`)

    function 获取评论的点踩爱心图标(y, ey) {
        const 更新点踩爱心按钮范围 = JSON.parse(JSON.stringify(douyin.视频播放页面的评论区点踩爱心图标));
        更新点踩爱心按钮范围.y = y;
        更新点踩爱心按钮范围.ey = ey;
        return findColor(更新点踩爱心按钮范围)
    }
    function 获取ip地址(str) {
        const match = str.trim().match(/[\u4e00-\u9fa5]+$/); // 匹配末尾的连续中文字符
        return match ? match[0] : ''; // 如果有匹配的中文字符，返回，否则返回空字符串
    }
    function 范围评论处理(范围评论内容) {
        if(!范围评论内容 || 范围评论内容.length === 0 || 范围评论内容.length === 1){
            return null
        }
        范围评论内容.sort((a, b) => {
            return a.y - b.y;
        });
        if(范围评论内容.length > 3 && (范围评论内容[0].x - 范围评论内容[1].x) > 20){
            范围评论内容.splice(0, 1)
        }
        //排除里面的无效文本
        const 第一次筛选后评论内容 = 范围评论内容.filter((单行文本) => {
            return!(单行文本.label.includes('收起') || 单行文本.label.includes('作者回复过')
                || 单行文本.label.includes('作者赞过') || 单行文本.label === '' || 单行文本.x > 400
                || 单行文本.label.includes('评论氛围是否满意') || 单行文本.label.includes('条回复')
                || 单行文本.label.startsWith('展开')|| (单行文本.label.includes('不满意')  && 单行文本.label.includes('一般'))
                || (单行文本.label.startsWith('展开') || 单行文本.label.startsWith('展廾')
                    || 单行文本.label.startsWith('一 展开') || 单行文本.label.startsWith('一 展廾')
                    || 单行文本.label.startsWith('— 展开') || 单行文本.label.startsWith('—展开')
                    || 单行文本.label.startsWith('一展廾')) && (单行文本.label.endsWith('凹复V') || 单行文本.label.endsWith('回复丷')
                    || 单行文本.label.endsWith('回复') || 单行文本.label.endsWith('回复V')
                    || 单行文本.label.endsWith('回复 V')));

        });

        let ip = ''
        function 找到评论时间并格式化(arr) {
            arr.sort((a, b) => {
                if (Math.abs(a.y - b.y) <= 5) {
                    return a.x - b.x;
                } else {
                    return a.y - b.y;
                }
            });
            let indexOfReply = -1;
            for (let i = arr.length - 1; i >= 0; i--) {
                if (arr[i].label.includes('回复')) {
                    indexOfReply = i;
                    break;
                }
            }
            if (indexOfReply !== -1) {
                const new_arr = arr.slice(0, indexOfReply + 1);
                new_arr[new_arr.length-1].label = new_arr[new_arr.length-1].label.replace('回复', '')
                var 评论时间 = 时间格式化(new_arr[new_arr.length-1].label);
                // 日志打印_warning(new_arr[new_arr.length-1].label+ '  评论时间1: ' + 评论时间)
                if(评论时间 && 评论时间 !== '2024-08-01'){
                    ip = 获取ip地址(new_arr[new_arr.length-1].label)
                    new_arr[new_arr.length-1].label = 评论时间;
                    return new_arr;
                }
                else if(new_arr.length > 1){
                    var 评论时间 = 时间格式化(new_arr[new_arr.length-2].label);
                    日志打印_warning(new_arr[new_arr.length-2].label + '  评论时间2: ' + 评论时间)
                    if(评论时间){
                        ip = 获取ip地址(new_arr[new_arr.length-2].label)
                        new_arr[new_arr.length-2].label = 评论时间;
                        const new_arr_2 = new_arr.slice(0, new_arr.length-1);
                        return new_arr_2;
                    }
                }
            }
            return null;
        }

        const 筛选后评论内容 = 找到评论时间并格式化(第一次筛选后评论内容);
        日志打印_debug('筛选后评论内容: '+JSON.stringify(筛选后评论内容))
        logd('ip3: '+ ip)

        if(!筛选后评论内容 || 筛选后评论内容.length < 2 || 筛选后评论内容[0].label.endsWith('作者')
            || 筛选后评论内容[0].label.endsWith('互相关注') || 筛选后评论内容[0].label.endsWith('你的关注')){
            return null
        }
        if(筛选后评论内容[筛选后评论内容.length-1].y - 筛选后评论内容[0].y - 筛选后评论内容[0].height < 30){
            return null
        }
        if(筛选后评论内容[0].width > 551){
            return null
        }
        let 头像_x = 66;
        if(筛选后评论内容[筛选后评论内容.length-1].x > 50){
            头像_x = 138;
        }

        const 用户评论信息 = {name: 筛选后评论内容[0].label, 评论内容: null, 评论时间: 筛选后评论内容[筛选后评论内容.length-1].label,
            x: 头像_x, y: 筛选后评论内容[0].y+筛选后评论内容[0].height/2+评论区顶部}
        if(筛选后评论内容.length === 2){
            用户评论信息.评论内容 = '[该用户回复的为表情或者图片消息]'
            logi(筛选后评论内容[筛选后评论内容.length-1].y-筛选后评论内容[0].y)
        }
        else {
            用户评论信息.评论内容 = 筛选后评论内容.slice(1, -1).map(单行文本 => 单行文本.label).join('');
        }
        用户评论信息.ip = ip
        // 日志打印_debug('用户评论信息: ' + JSON.stringify(用户评论信息))
        return 用户评论信息
    }
    function 评论区判断() {
        const 判断 = findColor(douyin.评论页面艾特标识)
        if(判断){
            logw(JSON.stringify(判断))
            return true
        }

        let 打开键盘 = ocr文本数组匹配(ios.键盘弹出)
        while (打开键盘){
            if(isScriptExit()){ break }
            const 关闭_弹出键盘 = {name: '【dy_评论区抓取】关闭_弹出键盘', x: random(140, 568), y: random(292, 418)};
            点击(关闭_弹出键盘)
            iSleep(400)
            打开键盘 = ocr文本数组匹配(ios.键盘弹出)

            if(!打开键盘){
                return 评论区判断()
            }
        }

        const 评论区_title = ocr文本数组匹配(douyin.评论区_title);
        if(评论区_title) { return true }

        let 账号已注销 = ocr文本数组匹配(douyin.用户账号已注销);
        while (账号已注销){
            if(isScriptExit()){ break }
            点击(douyin.用户主页_返回按钮)
            iSleep(400)
            账号已注销 = ocr文本数组匹配(douyin.用户账号已注销);
            if(!账号已注销){
                return 评论区判断()
            }
        }

        let 用户作品主页 = ocr文本数组匹配(douyin.用户作品主页);
        while (用户作品主页){
            if(isScriptExit()){ break }
            点击(douyin.用户主页_返回按钮)
            iSleep(400)
            用户作品主页 = ocr文本数组匹配(douyin.用户作品主页)
            if(!用户作品主页){
                return 评论区判断()
            }
        }

        let 主页_我_页面 = ocr文本数组匹配(douyin.主页_我_页面);
        while (主页_我_页面){
            if(isScriptExit()){ break }
            点击(douyin.用户主页_返回按钮)
            iSleep(400)
            主页_我_页面 = ocr文本数组匹配(douyin.主页_我_页面);
            if(!主页_我_页面){
                return 评论区判断()
            }
        }

        let 评论区_图片查看 = ocr文本数组匹配(douyin.评论区_图片查看);
        while (评论区_图片查看){
            if(isScriptExit()){ break }
            点击(douyin.用户主页_返回按钮)
            iSleep(400)
            评论区_图片查看 = ocr文本数组匹配(douyin.评论区_图片查看);
            if(!评论区_图片查看){
                return 评论区判断()
            }
        }
        let 视频评论区_误触内容 = ocr文本数组匹配(douyin.视频评论区_误触内容);
        while (视频评论区_误触内容){
            if(isScriptExit()){ break }
            const 关闭误触的点位 = {name: '【dy_评论区抓取】关闭 视频评论区_误触内容', x: random(250, 520), y: random(100, 200)};
            点击(关闭误触的点位)
            iSleep(400)
            视频评论区_误触内容 = ocr文本数组匹配(douyin.视频评论区_误触内容);
            if(!视频评论区_误触内容){
                return 评论区判断()
            }
        }

        return false
    }

    const 已经获取抖音ID的用户 = []
    let 左侧头像切割 = 100
    while (!是否结束评论区获取){
        if(isScriptExit()){ break }
        if(!评论区判断()){ return }
        const 页面所有文字内容 = ocrMut范围识别(左侧头像切割, 评论区顶部, ScreenWidth, 评论区底部)
        if(!页面所有文字内容){
            日志打印_error('【dy_评论区抓取】 页面评论内容 获取失败， 正在重新获取！ ');
            iSleep(200)
            continue
        }
        // 页面所有文字内容.sort((a, b) => a.y - b.y);
        页面所有文字内容.sort((a, b) => {
            // 首先按照y值进行排序
            if (Math.abs(a.y - b.y) <= 5) {
                // 如果y值差不超过5，则按照x值排序
                return a.x - b.x;
            } else {
                // 否则按照y值排序
                return a.y - b.y;
            }
        });
        const 点踩爱心图标top = 评论区顶部;
        let 上一个爱心图标 = null;
        const 用户列表 = [];
        const 评论区切片索引 = [];
        let 上传评论数据 = null
        let 当前发送抖音ID = null
        for (let i = 0; i < 页面所有文字内容.length; i++) {
            if (isScriptExit()) { return }
            const 单列文字内容 = 页面所有文字内容[i];
            日志打印_debug(JSON.stringify(单列文字内容))
            if (单列文字内容.label.includes('暂时没有更多了')  || 单列文字内容.label.startsWith('已折叠') || 单列文字内容.label.startsWith('哲时没有更多了') || 单列文字内容.label.endsWith('没有更多了')) {
                // 评论页面内容已经获取完了
                日志打印_debug(`【dy_评论区抓取】已到达评论区底部 ：${单列文字内容.label} `)
                是否结束评论区获取 = true;
            }
            if (单列文字内容.label.includes('回复')) {
                /*  用 【回复】 分割用户的评论内容 */
                const 点踩爱心图标bottom = 单列文字内容.y + 单列文字内容.height + 40 + 评论区顶部;
                const 点赞爱心图标 = 获取评论的点踩爱心图标(点踩爱心图标top, 点踩爱心图标bottom);
                if (点赞爱心图标) {
                    最后一条评论底部 = 单列文字内容
                    if(!上一个爱心图标){
                        评论区切片索引.push({index: i, top: 评论区顶部})
                    }
                    else {
                        评论区切片索引.push({index: i, top: 上一个爱心图标.max_y})
                    }
                    上一个爱心图标 = JSON.parse(JSON.stringify(点赞爱心图标));
                }else {
                    日志打印_debug(`点赞爱心图标 未找到：${单列文字内容.label}`)
                }
            }
        }

        let startIndex = {index: 0, top: 评论区顶部};
        for (let index_ of 评论区切片索引) {
            let 范围评论 = null;
            if(startIndex.index === 0){
                范围评论 = 页面所有文字内容.slice(0, index_.index+1);
                if(index_.index === 0){
                    index_.index += 1
                }

            }else {
                范围评论 = 页面所有文字内容.slice(startIndex.index+1, index_.index+1);

            }
            startIndex = JSON.parse(JSON.stringify(index_));
            日志打印_warning('提交筛选：' + JSON.stringify(范围评论))
            const 用户信息 = 范围评论处理(范围评论);
            if(用户信息){
                用户列表.push(用户信息)
            }
        }
        日志打印_warning('提交筛选：' + JSON.stringify(页面所有文字内容.slice(startIndex.index+1)))
        const 用户信息 = 范围评论处理(页面所有文字内容.slice(startIndex.index+1))
        if(用户信息){
            用户列表.push(用户信息)
        }
        const 评论区截图 = 区域截图base64(150, 150, 600, 1000);
        let 评论区变动_重新抓取 = false;

        for(const i in 用户列表){
            if(isScriptExit()) { break }
            if(!评论区判断()){ return }
            const 评论区用户 = 用户列表[i];
            日志打印_information('评论区用户： '+ JSON.stringify(评论区用户))
            if (已经获取抖音ID的用户.includes(评论区用户.name)){ continue }
            已经获取抖音ID的用户.push(评论区用户.name)
            const 进入评论用户主页 = 点击后检测(评论区用户, douyin.视频播放页面的评论区缩小按钮, [douyin.用户作品主页], 1000);
            if(进入评论用户主页 === 0){
                const 简介信息 = douyin.dy_获取用户主页_简介信息()
                // const 用户主页截图 = 区域截图base64(0,0, ScreenWidth, ScreenHeight)
                const 用户_昵称_id = douyin.dy_节点获取抖音ID();
                if (用户_昵称_id){
                    当前发送抖音ID = 用户_昵称_id.抖音ID
                    if(!已经获取抖音ID的用户.includes(用户_昵称_id.douyinID)){
                        const 上传评论数据 = {
                            "video_sid": video_sid,
                            "belong_account_id": uid,
                            "account_type": '抖音',
                            "customer_name": 用户_昵称_id.用户昵称,
                            "customer_id":用户_昵称_id.抖音ID,
                            "customer_comment_time": 评论区用户.评论时间,
                            "customer_ip_location": 评论区用户.ip,
                            "customer_comment": 评论区用户.评论内容,
                            "customer_homepage_img": '',
                            "customer_other_information": 简介信息,
                        }
                        已经获取抖音ID的用户.push(用户_昵称_id.抖音ID)
                        logd("上传评论数据:{}",JSON.stringify(上传评论数据))
                        日志打印_error("评论区抓取完成，开始执行【用户精准度判断】")
                        if (是否执行刺客 && isToday(评论区用户.评论时间)){
                            let 私信结果 = douyin.dy_刺客_是否私信(video_sid,videoContent,评论区用户,用户_昵称_id,简介信息)
                            if (私信结果 === -1 || 私信结果 === -2){
                                return
                            }
                        }else {
                            logd("上传评论数据:{}",JSON.stringify(上传评论数据))
                            api_插入视频评论用户(上传评论数据)
                        }
                    }
                }

                日志打印_error("单用户获取完成，开始执行【用户主页返回评论区】")
                while (true){
                    if(isScriptExit()){ break }
                    const 在_用户作品主页 = ocr文本数组匹配(douyin.用户作品主页)
                    if(在_用户作品主页){
                        点击(douyin.用户主页_返回按钮)
                        iSleep(400)
                    }else {
                        break
                    }
                }
            }

            const 点击后_评论区截图 = 区域截图base64(150, 150, 600, 1000);
            if(点击后_评论区截图 !== 评论区截图){
                日志打印_debug('评论区变动_重新抓取')
                评论区变动_重新抓取 = true;
                break
            }
        }

        if(!评论区判断()){ return }
        if(是否结束评论区获取) { break }
        if(评论区变动_重新抓取){ continue }

        // const bg_hd = time()
        const startX = random(10,20);
        const endX = random(10,20);
        let startY = 最后一条评论底部.y+ 最后一条评论底部.height+10+评论区顶部;
        let endY = 评论区顶部;

        日志打印_debug('【dy_评论区抓取】开始执行 评论区滑动')
        滑动(startX, startY, endX, endY, 2000)

        // 日志打印_warning('滑动耗时： '+ (time()-bg_hd))
        // const 滑动后_评论区截图 = 区域截图base64(150, 150, 600, 1000);
        // if(滑动后_评论区截图 === 评论区截图){
        //     break
        // }
    }
    日志打印_debug(`【dy_评论区抓取】已结束抓取  `)
    return true
}

DouYin.prototype.dy_切换单列模式 = function () {
    const 切换到单列按钮 = findColor(douyin.搜索页面切换到单列按钮_单页模式)
    if (切换到单列按钮){
        return true
    }else {
        const 点击切换到单列按钮 = {name:"点击切换到单列按钮",x:random(600,668),y:random(132,212)}
        const 点击结果 = 点击后检测(点击切换到单列按钮,douyin.搜索页面切换到单列按钮_双页模式,[douyin.搜索页面切换到单列按钮_单页模式])
        if (点击结果 === 0){
            return true
        }
    }
    return false
}