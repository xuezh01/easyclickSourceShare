/**
 * 同行检测流程开始
 * 流程:判断是否寻找同行关注,可以关键词或数据库同行抖音->查看关注同行更新视频->更新视频收藏->收藏夹跟进指定天数
 * **/
function 抖音跟进流程启动(){
    脚本当前运行阶段 = `【抖音】同行持续跟进`
    let 运行配置 = 脚本运行配置.dy.follow_up
    运行配置.is_keyword = true
    是否执行刺客 = true
    douyin.初始化()

    function 流程调度(执行步骤 =0) {
        switch (执行步骤){
            case 0 :
                if (运行配置.is_look_for_peer){
                    const 请求关键词 = api_获取检索关键词('抖音',抖音_获取当前账号的抖音ID())
                    if (!请求关键词){
                        const 请求数据库已有博主 = dy_获取已有精准博主()
                        if (请求数据库已有博主){
                            运行配置.is_keyword = false
                            运行配置.search_data = 请求数据库已有博主
                        }
                    }else {
                        douyin.关键词已无视频 = 请求关键词
                        运行配置.search_data = [请求关键词.key_word]
                    }
                    if (douyin.dy_同行关注(运行配置.search_data,运行配置.single_quantity,运行配置.is_keyword) != 1){
                        break
                    }
                }
                执行步骤 = 1
            case 1:
                if(douyin.dy_同行监控() == 1){
                    执行步骤 = 2
                }else {
                    break
                }
            case 2:
                if (douyin.dy_收藏界面跟进(运行配置.follow_up_days) == 1){
                    执行步骤 = 3
                }else {
                    break
                }
            case 3:
                douyin.dy_当前账号_跟进客户()
                执行步骤 = 1
        }
        return 执行步骤
    }
    let 执行步骤 = 0
    while (抖音_同行跟进时间()){
        if (isScriptExit()){return}
        if (!脚本运行配置.app_type.includes('抖音')){ return }
        if (脚本运行配置.dy.task !== '持续跟进任务'){ return }
        执行步骤 = 流程调度(执行步骤)
    }

}

/**
 * 已关注同行更新视频获客
 * @returns {number}
 */
DouYin.prototype.dy_同行监控 = function () {
    脚本当前运行阶段 = `【同行持续跟进】同行更新视频获客`
    if (!douyin.dy_首页导航_切换(4)) {
        douyin.dy_启动抖音()
        return -1
    }
    const 关注按钮 = findColor(douyin.我的页面关注按钮)
    logd("关注按钮寻找结果:{}",JSON.stringify(关注按钮))
    if (!关注按钮){
        return -1
    }
    const 我的_关注页面 = {
        name: '我的_关注页面',
        textArray: ['有更新','直播中','互关', '粉丝','批量管理'],
        x: 0,
        y: 50,
        ex: ScreenWidth,
        ey: 450,
        binaryzation: false,
        matchCount: 3
    }
    const 关注按钮点击 = 点击后检测(关注按钮,douyin.主页_我_页面,[我的_关注页面])
    logd("关注按钮点击结果:{}",JSON.stringify(关注按钮点击))
    if (关注按钮点击 !== 0){
        return -2
    }
    function 有更新视频位置_数量() {
        const regex = /\((\d+)\)/;
        const 有更新ocr = ocr范围识别(0,50,750,604)
        let 有更新按钮位置 = null
        let 有更新视频数量 = null
        for (var i of 有更新ocr){
            if (i.label.includes("有更新")){
                有更新按钮位置 = {name: i.label, x: i.x + i.width/2, y: i.y + 50 + i.height/2}
                const match = i.label.match(regex);
                if (match){
                    有更新视频数量 = match[1]
                }
            }
        }
        return {按钮位置:有更新按钮位置,视频数量:有更新视频数量}
    }
    const 有更新按钮信息 = 有更新视频位置_数量()
    logd("有更新按钮信息:{}",JSON.stringify(有更新按钮信息))
    if (!有更新按钮信息.视频数量 || 有更新按钮信息.视频数量 == 0){
        return 2
    }
    const 我的_最近更新页面 = {
        name: '我的_最近更新页面',
        textArray: ['最近更新','看更新','未看'],
        x: 0,
        y: 50,
        ex: ScreenWidth,
        ey: ScreenHeight/2,
        binaryzation: false,
        matchCount: 2
    }
    const 有更新按钮点击 = 点击后检测(有更新按钮信息.按钮位置,我的_关注页面,[我的_最近更新页面])
    if (有更新按钮点击 !== 0){
        return -3
    }
    const 未观看按钮 = douyin.dy_获取未观看作品()
    logd("未观看按钮:{}",JSON.stringify(未观看按钮))
    if (未观看按钮){
        douyin.dy_获取未观看作品评论(未观看按钮,有更新按钮信息.视频数量)
        douyin.dy_返回_设定页面(douyin.主页_我_页面)
    }else {
        return -4
    }
    return 1;
}

DouYin.prototype.dy_获取未观看作品 = function () {
    setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"2","boundsFilter":"1","excludedAttributes":""})
    const 未观看位置_数量 = type("StaticText").labelMatch("个作品未看").getNodeInfo(1000*10)
    logd(JSON.stringify(未观看位置_数量))
    if (未观看位置_数量){
        return 未观看位置_数量
    }
    return null
}

DouYin.prototype.dy_获取未观看作品评论 = function (未观看按钮,视频数量) {
    logd("视频数量:{}",视频数量)
    if (!ios_打开_关闭无障碍模式(true)){return -1}
    未观看按钮[0].clickCenter()
    iSleep(2000)
    let 滑动次数 = parseInt(视频数量) + 2
    let 作者出现次数 = {name:'',quantity:0}
    while (滑动次数 >= 0 && !douyin.节点获取暂时没有更多了()){
        if (isScriptExit()){return;}
        logd("滑动次数:{}",滑动次数)
        const 视频信息 = douyin.dy_旁白_获取视频界面信息()
        if (!视频信息){
            if (!ios_打开_关闭无障碍模式(false)){return -1}
            return -4
        }
        logd('***视频信息***:{}',JSON.stringify(视频信息))

        const 上传视频信息 = {
            "belong_device_id": device_id,
            "account_id": 抖音_获取当前账号的抖音ID(),
            "account_type": "抖音",
            "belong_uid": uid,
            "video_keyword": '博主视频更新',
            "video_up_id": 视频信息.作者信息.抖音ID,
            "video_up_name": 视频信息.作者信息.用户昵称,
            "video_type":  视频信息.类型,
            "video_comment_count": 视频信息.评论数量,
            "video_title": 视频信息.标题,
            "video_up_homepage": '',
            "video_up_information": "",
        }

        const 视频指令 = api_获取视频是否已观看(上传视频信息)
        if (!视频指令.catch){
            douyin.dy_上滑切换视频(false)
            滑动次数--
            continue
        }
        // const params = {
        //     "videoContent": 视频信息.标题,
        //     "hangye":  脚本运行配置.dy.follow_up.industry,
        //     "keyword": '',
        //     "up_name": 视频信息.头像节点.label,
        //     "account_type": "抖音",
        // }
        const 视频判断结果 = api_判断视频精准度(uid,'抖音',视频信息.作者信息.用户昵称,'',视频信息.标题)
        logd("判断结果:{}",JSON.stringify(视频判断结果))
        if (视频指令.video_sid && 视频指令.video_sid !== null){
            const 视频判断结果记录 = {
                "video_sid": parseInt(视频指令.video_sid),
                "accuracy": String(视频判断结果),
                "account_type": "抖音",
            }
            api_记录视频精准度(视频判断结果记录)
        }
        日志打印_error("视频判断完成，开始执行【视频判断】")

        if (作者出现次数.name !== 视频信息.头像节点.label){
            作者出现次数.name = 视频信息.头像节点.label
            作者出现次数.quantity = 0
        }else if (!视频判断结果){
            作者出现次数.quantity++
        }
        if (作者出现次数.quantity > 5){
            douyin.dy_收藏播放页面_取消关注(视频信息.头像节点.bounds)
            if (!ios_打开_关闭无障碍模式(false)){return -1}
            return 1
        }

        logd("视频判断结果:{}",JSON.stringify(视频判断结果))
        if (!视频判断结果){
            douyin.dy_上滑切换视频(false)
            滑动次数--
            iSleep(1000)
            continue
        }
        const 收藏按钮位置 = 视频信息.收藏节点.bounds
        const 收藏按钮 = {name:"旁白节点_点击收藏按钮",x:random(收藏按钮位置.left+40,收藏按钮位置.right-40),y:random(收藏按钮位置.top+20,收藏按钮位置.bottom-80)}
        douyin.dy_收藏按钮位置(收藏按钮位置)
        点击后检测(收藏按钮,douyin.未收藏按钮标识,[douyin.已收藏按钮标识])
        if (视频信息.评论数量 === 0){
            douyin.dy_上滑切换视频(false)
            滑动次数--
            // 点击(douyin.搜索页_左上角_返回按钮)
            iSleep(1000)
            continue
        }

        logd("视频信息:{}",JSON.stringify(视频信息))
        const 评论按钮位置 = 视频信息.评论节点.bounds
        const 评论按钮 = {name:"旁白节点_打开评论区按钮",x:random(评论按钮位置.left+40,评论按钮位置.right-50),y:random(评论按钮位置.top+20,评论按钮位置.bottom-55)}

        const 评论按钮点击 = 点击后检测(评论按钮,douyin.已收藏按钮标识,[douyin.评论页面艾特标识])
        if (评论按钮点击 !== 0){
            if (!ios_打开_关闭无障碍模式(false)){return -1}
            return -2
        }
        iSleep(1000)
        // if (!douyin.dy_评论区刺客(脚本运行配置.dy.assassin_process.keyword, parseInt(视频指令.video_sid),视频信息.标题)){
        //     return -3
        // }
        const 评论区获取情况 = douyin.dy_旁白_节点获取评论区信息([],parseInt(视频指令.video_sid),视频信息.标题,true)
        logd("评论区获取情况:{}",评论区获取情况)
        if (评论区获取情况 != 1 && !findColor(douyin.评论页面艾特标识)){
            if (ocr文本数组匹配(douyin.用户作品主页)) {
                const 点击结果 = 点击后检测(douyin.用户主页_返回按钮,douyin.用户作品主页,[douyin.评论页面艾特标识])
                if (点击结果 != 0){
                    if (!ios_打开_关闭无障碍模式(false)){return -1}
                    return -3
                }
            }else {
                if (!ios_打开_关闭无障碍模式(false)){return -1}
                return -3
            }
        }
        douyin.dy_关闭评论区()
        iSleep(1000)
        douyin.dy_上滑切换视频(false)
        滑动次数--
        // 点击(douyin.搜索页_左上角_返回按钮)
        iSleep(1000)

    }
    if (!ios_打开_关闭无障碍模式(false)){return -1}
    return 1
}

DouYin.prototype.节点获取暂时没有更多了 = function () {
    setFetchNodeParam({"labelFilter":"2","maxDepth":"15","visibleFilter":"1","boundsFilter":"1","excludedAttributes":""})
    let 暂时没有更多了 =  type("StaticText").labelMatch(".*暂时没有更多了.*").getOneNodeInfo(10000)
    if (暂时没有更多了){
        return true
    }
    return false
}

DouYin.prototype.dy_旁白_获取视频界面信息 = function () {

    function 头像_点赞_评论_收藏_节点拆分(节点集合) {
        const 节点拆分 = {头像:null,点赞:null,评论:null,收藏:null,分享:null}
        for (var i of 节点集合){
            if (i.name == '点赞'){
                节点拆分.点赞 = i
            }else if (i.name == '评论'){
                节点拆分.评论 = i
            }else if (i.name == '收藏'){
                节点拆分.收藏 = i
            }else if (i.name == '分享'){
                节点拆分.分享 = i
            }else if (!节点拆分.头像){
                节点拆分.头像 = i
            }
        }
        logd("头像节点拆分:{}",JSON.stringify(节点拆分))
        if (节点拆分.头像 && 节点拆分.收藏 && 节点拆分.评论){
            return 节点拆分
        }
        return null
    }

    function parseChineseNumber(input) {
        if (input.includes('万')) {
            return Math.round(parseFloat(input.replace('万', '')) * 10000);
        }
        return parseInt(input, 10);
    }

    setFetchNodeParam({"labelFilter":"2","maxDepth":"26","visibleFilter":"1","boundsFilter":"2","excludedAttributes":""})
    iSleep(100)
    let 头像节点集合 =  bounds(500,120,ScreenWidth, 1120).type("Button").getNodeInfo(10000)
    while (!头像节点集合){
        if (isScriptExit()){return}
        iSleep(100)
        logd("头像节点循环")
        setFetchNodeParam({"labelFilter":"2","maxDepth":"26","visibleFilter":"1","boundsFilter":"2","excludedAttributes":""})
        头像节点集合 =  bounds(500,120,ScreenWidth, 1120).type("Button").getNodeInfo(10000)
    }
    头像节点集合.sort((a, b) => a.bounds.bottom - b.bounds.bottom);
    logd("头像节点集合:{}",JSON.stringify(头像节点集合))
    const 节点合集 = 头像_点赞_评论_收藏_节点拆分(头像节点集合)
    if (!节点合集){
        return null
    }
    let 头像节点 = 节点合集.头像
    let 点赞节点 = 节点合集.点赞
    let 评论节点 = 节点合集.评论
    logd("评论节点:{}",JSON.stringify(评论节点))
    setFetchNodeParam({"labelFilter":"2","maxDepth":"26","visibleFilter":"1","boundsFilter":"2","excludedAttributes":""})
    let 评论数量节点 = bounds(评论节点.bounds.left,评论节点.bounds.top,评论节点.bounds.right,评论节点.bounds.bottom).type("StaticText").getOneNodeInfo(10000)
    var 重试次数 = 3
    while (!评论数量节点 && 重试次数 > 0){
        重试次数--
        setFetchNodeParam({"labelFilter":"2","maxDepth":"26","visibleFilter":"1","boundsFilter":"2","excludedAttributes":""})
        评论数量节点 = bounds(评论节点.bounds.left,评论节点.bounds.top,评论节点.bounds.right,评论节点.bounds.bottom).type("StaticText").getOneNodeInfo(10000)
    }
    let 评论数量 = 评论数量节点 ? 评论数量节点.name:'评论'
    评论数量 = 评论数量 === '评论' ? '0':评论数量
    评论数量 = parseChineseNumber(评论数量)
    logd("评论数量:{}",JSON.stringify(评论数量))
    let 收藏节点 = 节点合集.收藏
    let 分享节点 = 节点合集.分享
    setFetchNodeParam({"labelFilter":"2","maxDepth":"26","visibleFilter":"1","boundsFilter":"2","excludedAttributes":""})
    let 标题节点 =  bounds(0,800,645,1236).getNodeInfo(10000)
    let 标题文本 = ''
    let 发布时间 = ''
    for (var i of 标题节点){
        if (i.type === 'StaticText'){
            发布时间 = 时间格式化(i.name)
            continue
        }
        if (发布时间 && i.type === 'Other' && i.name != '') {
            标题文本 = i.name
        }
        if (标题文本 && 发布时间){
            break
        }
    }
    logd(JSON.stringify(标题节点))
    let 作者信息 = douyin.dy_获取视频作者_无关注按钮(头像节点.bounds)
    if (!作者信息){
        return null
    }
    return {'头像节点':头像节点,'点赞节点':点赞节点,'评论节点':评论节点,'评论数量':评论数量,'收藏节点':收藏节点,'分享节点':分享节点,'标题':标题文本,'发布时间':发布时间,'作者信息':作者信息}
}

/**
 * 通过传入同行id或者关键词检索关注同行
 * @param search_list {list}   搜索列表 可填关键词或同行抖音id
 * @param is_keyword {boolean}     是否是关键词 true是
 * @returns {number}
 */
DouYin.prototype.dy_同行关注 = function (search_list,quantity,is_keyword){
    脚本当前运行阶段 = `【同行持续跟进】同行关注流程`
    if (!douyin.dy_首页导航_切换(1)) {
        douyin.dy_启动抖音()
        return
    }

    function 在预期页面() {
        const 搜索结果_用户选项页面标识 = {
            name: '搜索结果_用户选项页面标识',
            textArray: ['用户', '粉丝', '抖音号','关注','已关注'],
            x: 0,
            y: 128,
            ex: 750,
            ey: 350,
            binaryzation: true,
            matchCount: 2
        }
        const 页面是否正确 = ocr文本数组匹配(搜索结果_用户选项页面标识)
        if (页面是否正确){
            return true
        }else {
            const 用户主页 = ocr文本数组匹配(douyin.用户作品主页)
            if (用户主页){
                点击(douyin.用户主页_返回按钮)
                return 在预期页面()
            }
        }
    }

    function 用户范围切割_节点() {
        setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"2","boundsFilter":"1","excludedAttributes":""})
        let 用户_list = type("CollectionView").bounds(0,210,751,1335).getOneNodeInfo(1000*10).allChildren()
        logd(JSON.stringify(用户_list))
        let 重试次数 = 5
        while (!用户_list && 重试次数>0){
            logd("循环在这:{}",重试次数)
            iSleep(500)
            setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"2","boundsFilter":"1","excludedAttributes":""})
            用户_list = type("CollectionView").bounds(0,210,751,1335).getOneNodeInfo(1000*10).allChildren()
            重试次数--
        }
        return 用户_list
    }

    function 抖音号识别关注_点击(douyinID,radius) {
        const 抖音号存在搜索列表 = {
            name: `抖音号：${douyinID}`,
            firstColor: ["#FE2B54", "#101010"],
            x: 160,
            y: radius.top+50,
            ex: 530,
            ey: radius.bottom,
            orz: 1,
        }

        if (ocr文本不完全匹配('结果为空', 0, 0, ScreenWidth, ScreenHeight)) {
            return 0
        }
        if (ocr文本不完全匹配('已关注',radius.left,radius.top,radius.right,radius.bottom)){
            return true
        }

        if (!dy_博主是否被已被关注({belong_uid:uid,account_type:'抖音',blogger_id:douyinID})){
            // 点击后检测(douyin.用户主页_返回按钮,douyin.用户作品主页,[douyin.搜索页面的搜索按钮])
            return false
        }

        if (单点找色(抖音号存在搜索列表)){
            const 进入同行主页按钮 = {name:'搜索_进入同行主页按钮',x:random(radius.left+20,radius.right-300),y:random(radius.top,radius.bottom)}
            const 点击结果 = 点击后检测(进入同行主页按钮,douyin.搜索页面的搜索按钮,[douyin.用户作品主页])
            if (点击结果 != 0){
                return false
            }

            const 用户信息 = {name:null,intro:null,id:null,video_information:null}
            const name_id = douyin.dy_节点获取抖音ID()
            if (!name_id){
                点击后检测(douyin.用户主页_返回按钮,douyin.用户作品主页,[douyin.搜索页面的搜索按钮])
                return false
            }
            const intro = douyin.dy_节点获取用户简介()
            用户信息.name = name_id.用户昵称
            用户信息.id = name_id.抖音ID
            用户信息.intro = intro
            const 上传数据 = {
                "blogger_id":douyinID,
                "blogger_name":用户信息.name,
                "blogger_main_page":用户信息.intro,
                "filte":1,
                "have_group":0,
                "is_follow":1,
                "is_follow_tm":获取当前时间(),
                "belong_uid":uid,
                "account_type":"抖音",
                "follow_account_ai_id":抖音_获取当前账号的抖音ID()
            }
            if (!dy_插入博主信息(上传数据)){
                点击后检测(douyin.用户主页_返回按钮,douyin.用户作品主页,[douyin.搜索页面的搜索按钮])
                return false
            }
            const 关注按钮 = findColor(douyin.用户主页_关注按钮)
            if (!关注按钮){
                点击后检测(douyin.用户主页_返回按钮,douyin.用户作品主页,[douyin.搜索页面的搜索按钮])
                return false
            }
            const 取消结果 = 点击后检测(关注按钮,douyin.用户主页_关注按钮,[douyin.用户主页_取消关注按钮])
            if (取消结果 == 0){
                点击后检测(douyin.用户主页_返回按钮,douyin.用户作品主页,[douyin.搜索页面的搜索按钮])
                return true
            }
            点击后检测(douyin.用户主页_返回按钮,douyin.用户作品主页,[douyin.搜索页面的搜索按钮])
        }
        return false
    }

    function 关键词识别关注_判断后_点击(radius) {
        if (ocr文本不完全匹配('已关注',radius.left,radius.top,radius.right,radius.bottom)){
            return true
        }
        const 进入同行主页按钮 = {name:'搜索_进入同行主页按钮',x:random(radius.left+20,radius.right-300),y:random(radius.top,radius.bottom)}
        const 点击结果 = 点击后检测(进入同行主页按钮,douyin.搜索页面的搜索按钮,[douyin.用户作品主页])
        if (点击结果 != 0){
            return false
        }

        const 用户信息 = {name:null,intro:null,id:null,video_information:null}
        const name_id = douyin.dy_节点获取抖音ID()
        if (!name_id){
            点击后检测(douyin.用户主页_返回按钮,douyin.用户作品主页,[douyin.搜索页面的搜索按钮])
            return false
        }
        const intro = douyin.dy_节点获取用户简介()
        用户信息.name = name_id.用户昵称
        用户信息.id = name_id.抖音ID
        用户信息.intro = intro

        if (!dy_博主是否被已被关注({belong_uid:uid,account_type:'抖音',blogger_id:用户信息.id})){
            点击后检测(douyin.用户主页_返回按钮,douyin.用户作品主页,[douyin.搜索页面的搜索按钮])
            return false
        }

        const 上传数据 = {
            "blogger_id":用户信息.id ,
            "blogger_name":用户信息.name,
            "blogger_main_page":用户信息.intro,
            "filte":1,
            "have_group":0,
            "is_follow":1,
            "is_follow_tm":获取当前时间(),
            "belong_uid":uid,
            "account_type":"抖音",
            "follow_account_ai_id":抖音_获取当前账号的抖音ID()
        }
        if (!dy_插入博主信息(上传数据)){
            点击后检测(douyin.用户主页_返回按钮,douyin.用户作品主页,[douyin.搜索页面的搜索按钮])
            return false
        }

        const 关注按钮 = findColor(douyin.用户主页_关注按钮)
        if (!关注按钮){
            点击后检测(douyin.用户主页_返回按钮,douyin.用户作品主页,[douyin.搜索页面的搜索按钮])
            return false
        }
        const 取消结果 = 点击后检测(关注按钮,douyin.用户主页_关注按钮,[douyin.用户主页_取消关注按钮])
        if (取消结果 == 0){
            点击后检测(douyin.用户主页_返回按钮,douyin.用户作品主页,[douyin.搜索页面的搜索按钮])
            return true
        }
        点击后检测(douyin.用户主页_返回按钮,douyin.用户作品主页,[douyin.搜索页面的搜索按钮])
        return false
        // if (ocr文本不完全匹配('已关注',radius.left,radius.top,radius.right,radius.bottom)){
        //     return true
        // }
        // const 关注按钮 = {name:"同行页面博主关注按钮",x:random(560,610),y: random(radius.top+50,radius.top+90)}
        // 点击(关注按钮)
        // iSleep(1000)
        // if (ocr文本不完全匹配('已关注',radius.left,radius.top,radius.right,radius.bottom)){
        //     return true
        // }
        // return false
    }

    if (!douyin.dy_首页搜索按钮点击(脚本运行配置.dy.search_time_interval)) { return -1}
    let 关注数量 = 0
    if (!is_keyword && search_list.length >= quantity){
        search_list = search_list.slice(0, quantity)
    }
    logd("搜索列表:{}",JSON.stringify(search_list))
    for (var search of search_list){
        if (!douyin.dy_搜索页面输入查询(search)) { return -2}
        if (!douyin.dy_搜索结果分类选项选择('用户')) { return -3}
        iSleep(1000)
        let 用户_list = 用户范围切割_节点()
        if (!用户_list || 用户_list.length < 1){
            return -6
        }
        if (!is_keyword){
            抖音号识别关注_点击(search,用户_list[0].bounds)
            continue
        }
        logd("q关注数量:{},q上限:{},比较:{},类型:{}",关注数量,quantity,关注数量 < quantity,typeof (quantity))
        while (!ocr文本不完全匹配('告诉我们',0,800,750,1300) && 关注数量 < quantity){
            let 最后一个用户范围 = null
            for (var 用户 of 用户_list){
                logd("关注数量:{},上限:{},比较:{}",关注数量,quantity,关注数量 < quantity)
                if (!(关注数量 < quantity)){
                    break
                }
                if (用户.bounds.bottom > 1320 || 用户.type !== 'Cell'){break}
                if (用户.bounds.top < 212){continue}
                logd("点击位置:{}",JSON.stringify(用户.bounds))
                if (关键词识别关注_判断后_点击(用户.bounds)){
                    logd("关注成功:{}",关注数量)
                    关注数量++
                }
                if (!在预期页面()){return -5}
                最后一个用户范围 = 用户.bounds
            }
            if (最后一个用户范围 && 用户_list[0]){
                滑动(300,最后一个用户范围.bottom,300,用户_list[0].bounds.top,3000)
            }
            iSleep(1500)
            用户_list = 用户范围切割_节点()
        }
    }
    douyin.dy_返回_设定页面(douyin.首页_底部导航)
    return 1
}

function 抖音_同行跟进时间() {
    const [s_hours, s_minutes] = 脚本运行配置.dy.follow_up.start_time.split(':');
    const [e_hours, e_minutes] = 脚本运行配置.dy.follow_up.end_time.split(':');
    const start_time = new Date();
    start_time.setHours(s_hours, s_minutes, 0, 0);

    const end_time = new Date();
    end_time.setHours(e_hours, e_minutes, 0, 0);
    const now = new Date();
    let result = false
    if(start_time < end_time){
        if (start_time <= now && now < end_time){ result = true }
    }else {
        if (start_time <= now || now < end_time){ result = true }
    }
    if(result){
        日志打印_warning(` 当前是-[抖音_同行关注] ${start_time}-${end_time}`)
    }
    return result
}

DouYin.prototype.dy_同行监控时间 = function () {
    logd("脚本运行配置_同行更新视频检索：{}",JSON.stringify(脚本运行配置))
    const [s_hours, s_minutes] = 脚本运行配置.dy.keyword_search.send_msg.start_time.split(':');
    const [e_hours, e_minutes] = 脚本运行配置.dy.keyword_search.send_msg.end_time.split(':');
    const start_time = new Date();
    start_time.setHours(s_hours, s_minutes, 0, 0);

    const end_time = new Date();
    end_time.setHours(e_hours, e_minutes, 0, 0);
    const now = new Date();
    let result = false
    if(start_time < end_time){
        if (start_time <= now && now < end_time){ result = true }
    }else {
        if (start_time <= now || now < end_time){ result = true }
    }
    if(result){
        日志打印_warning(` 当前是-[抖音_同行视频获取时间] ${start_time}-${end_time}`)
    }
    return result
}

DouYin.prototype.dy_获取视频作者_无关注按钮 = function (博主头像){
    当前执行模块 = 'dy_获取视频作者_无关注按钮'
    日志打印_debug(`开始执行 - 【dy_获取视频作者_无关注按钮】`);

    let 进入作者主页 = -1000;
    const 直播中 = !屏幕区域变化检测(500, 博主头像.left+20, 博主头像.top+60, 博主头像.right-20, 博主头像.bottom-20)
    if(直播中){
        日志打印_warning('视频作者正在直播')
        进入作者主页 = 滑动检测(douyin.视频播放页_关注按钮, [douyin.用户作品主页, douyin.私信页面表情标识], 600, random(400,500), 10, random(400,500), 3000)
    }else {
        日志打印_warning('视频作者未直播')
        const 视频头像 = {name: '[dy_获取视频作者]视频头像', x:random(博主头像.left+10,博主头像.right-10), y:random(博主头像.top+60,博主头像.bottom-10)}
        进入作者主页 = 点击后检测(视频头像, douyin.视频播放页_关注按钮, [douyin.用户作品主页, douyin.私信页面表情标识], 3000)
    }

    switch (进入作者主页) {
        case -1000:
            return
        case -100:
            return
        case -1:
            return
        case 0:
            break;
        case 1:
            // 判断是否企业号，弹出私信框
            const 关闭_弹出私信页面_位置 = {name: '关闭_弹出私信页面_位置', x: random(678,705), y:random(114,136)}
            const 关闭作者私信弹窗 = 点击后检测(关闭_弹出私信页面_位置, douyin.私信页面表情标识, [douyin.用户作品主页])
            if(关闭作者私信弹窗 !== 0){
                日志打印_error('关闭作者私信弹窗 失败')
                return
            }
            break;
    }

    const 作者信息 = douyin.dy_节点获取抖音ID();
    if(!作者信息){
        return
    }
    // const 作者主页截图 = 区域截图base64()
    // 作者信息.homepage = 作者主页截图
    // 返回视频播放页面
    const 返回作者视频播放 = 点击(douyin.用户主页_返回按钮);
    return 作者信息
}

DouYin.prototype.dy_主页信息获取 = function (is_blogger){
    if (!ocr文本数组匹配(douyin.用户作品主页)){
        return -1
    }
    let 主页信息 = null

    setFetchNodeParam({"labelFilter":"2","maxDepth":"15","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
    let 开启无障碍 =  type("Button").labelMatch(".*辅助功能快捷键.*").getOneNodeInfo(10000)
}

/**
 * 收藏页面跟进指定天数
 * @param days
 * @returns {number}
 */
DouYin.prototype.dy_收藏界面跟进 = function (days) {
    脚本当前运行阶段 = `【同行持续跟进】收藏视频界面跟进`
    if (!douyin.dy_首页导航_切换(4)) {
        douyin.dy_启动抖音()
        return -1
    }
    let 收藏按钮 = findColor(douyin.我的页面收藏按钮)
    // const 收藏按钮 = ocr文本不完全匹配('收藏',0,360,750,1222)
    if (!收藏按钮){
        收藏按钮 = findColor(douyin.我的页面我的收藏按钮)
        if (!收藏按钮){
            setFetchNodeParam({"labelFilter":"2","maxDepth":"26","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
            let 收藏按钮节点 =  type('StaticText').labelMatch('.*收藏.*').getOneNodeInfo(10000)
            if (!收藏按钮节点){
                return -2
            }
            收藏按钮 = {name:'收藏按钮',x:random(收藏按钮节点.bounds.left+10,收藏按钮节点.bounds.right-10),y:random(收藏按钮节点.bounds.top+10,收藏按钮节点.bounds.bottom-10)}
        }
    }
    logd("收藏按钮位置:{}",JSON.stringify(收藏按钮))
    const 收藏按钮点击结果 = 点击屏幕检测(收藏按钮,500,0,520,750,1330)
    if (!收藏按钮点击结果){
        return -2
    }
    if (!ios_打开_关闭无障碍模式(true)){return -11}
    const 收藏视频_进入按钮 = {name:'收藏视频_进入按钮',x:random(20,180),y:random(1180,1220)}
    if (ocr文本不完全匹配('我的收藏',5,56,740,200)){
        收藏视频_进入按钮.x = random(20,180)
        收藏视频_进入按钮.y = random(230,260)
    }
    const 收藏视频_进入结果 = 点击后检测(收藏视频_进入按钮,douyin.主页_我_页面,[douyin.收藏页面进入视频标识])
    if (收藏视频_进入结果 != 0){
        return -3
    }
    while (!douyin.节点获取暂时没有更多了()){
        if (isScriptExit()){return }

        const 关注按钮 = findColor(douyin.视频播放页_关注按钮)
        if (关注按钮){
            setFetchNodeParam({"labelFilter":"2","maxDepth":"17","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
            iSleep(100)
            let 取消收藏节点 =  type("Button").label('收藏').getOneNodeInfo(10000)
            if (取消收藏节点){
                取消收藏节点.clickCenter()
            }
            douyin.dy_上滑切换视频(false)
            continue
        }

        const 视频信息 = douyin.dy_旁白_获取视频界面信息()
        if (!视频信息){
            douyin.dy_上滑切换视频(false)
            continue
        }
        logd('***视频信息***:{}',JSON.stringify(视频信息))

        const 上传视频信息 = {
            "belong_device_id": device_id,
            "account_id": 抖音_获取当前账号的抖音ID(),
            "account_type": "抖音",
            "belong_uid": uid,
            "video_keyword": '博主视频更新',
            "video_up_id": 视频信息.作者信息.抖音ID,
            "video_up_name": 视频信息.作者信息.用户昵称,
            "video_type":  视频信息.类型,
            "video_comment_count": 视频信息.评论数量,
            "video_title": 视频信息.标题,
            "video_up_homepage": '',
            "video_up_information": "",
        }
        const 视频指令 = api_获取视频是否已观看(上传视频信息)

        if (!视频指令.video_sid){
            douyin.dy_收藏播放页面_取消收藏(视频信息.收藏节点.bounds)
            douyin.dy_上滑切换视频(false)
            continue
        }

        const 视频已获取用户上传信息 = {
            "video_up_id":视频信息.作者信息.抖音ID,
            "video_title": 视频信息.标题,
            "account_type": "抖音"
        }
        const 已获取用户列表 = dy_持续跟进流程_已获取用户筛选(视频已获取用户上传信息)
        if (已获取用户列表.length == 视频信息.评论数量){
            douyin.dy_上滑切换视频(false)
            continue
        }
        douyin.dy_旁白_节点获取评论区信息(已获取用户列表,视频指令.video_sid,视频信息.标题,是否执行刺客)
        if (isCurrentTimeGreaterThan(视频信息.发布时间,days)){
            douyin.dy_收藏播放页面_取消收藏(视频信息.收藏节点.bounds)
        }
        douyin.dy_上滑切换视频(false)
    }
    if (!ios_打开_关闭无障碍模式(false)){return -11}
    douyin.dy_返回_设定页面(douyin.主页_我_页面)
    return 1
}

DouYin.prototype.dy_收藏播放页面_取消收藏 = function (收藏按钮){
    const 收藏按钮点击 = {name:"旁白节点_点击收藏按钮",x:random(收藏按钮.left+40,收藏按钮.right-40),y:random(收藏按钮.top+20,收藏按钮.bottom-50)}
    douyin.dy_收藏按钮位置(收藏按钮)
    logd("点击位置:{}",JSON.stringify(收藏按钮点击))
    const 点击结果 = 点击后检测(收藏按钮点击,douyin.已收藏按钮标识,[douyin.未收藏按钮标识])
    if (点击结果 == 0){
        return true
    }
    return false
}

DouYin.prototype.dy_收藏播放页面_取消关注 = function (博主头像) {
    当前执行模块 = 'dy_收藏播放页面_取消关注'
    日志打印_debug(`开始执行 - 【dy_收藏播放页面_取消关注】`);

    let 进入作者主页 = -1000;
    const 直播中 = !屏幕区域变化检测(500, 博主头像.left+20, 博主头像.top+60, 博主头像.right-20, 博主头像.bottom-20)
    if(直播中){
        日志打印_warning('视频作者正在直播')
        进入作者主页 = 滑动检测(douyin.视频播放页_关注按钮, [douyin.用户作品主页, douyin.私信页面表情标识], 600, random(400,500), 10, random(400,500), 3000)
    }else {
        日志打印_warning('视频作者未直播')
        const 视频头像 = {name: '[dy_获取视频作者]视频头像', x:random(博主头像.left+10,博主头像.right-10), y:random(博主头像.top+60,博主头像.bottom-10)}
        进入作者主页 = 点击后检测(视频头像, douyin.视频播放页_关注按钮, [douyin.用户作品主页, douyin.私信页面表情标识], 3000)
    }

    switch (进入作者主页) {
        case -1000:
            return -1
        case -100:
            return -2
        case -1:
            return -3
        case 0:
            break;
        case 1:
            // 判断是否企业号，弹出私信框
            const 关闭_弹出私信页面_位置 = {name: '关闭_弹出私信页面_位置', x: random(678,705), y:random(114,136)}
            const 关闭作者私信弹窗 = 点击后检测(关闭_弹出私信页面_位置, douyin.私信页面表情标识, [douyin.用户作品主页])
            if(关闭作者私信弹窗 !== 0){
                日志打印_error('关闭作者私信弹窗 失败')
                return -4
            }
            break;
    }

    const 已关注按钮 = findColor(douyin.用户主页_取消关注按钮)
    logd("已关注按钮:{}",JSON.stringify(已关注按钮))
    if (已关注按钮){
        if (点击后检测(已关注按钮,douyin.用户主页_取消关注按钮,[douyin.取消关注按钮]) == 0){
            const 取消关注按钮 = findColor(douyin.取消关注按钮)
            if (取消关注按钮){
                const 取消结果 = 点击后检测(取消关注按钮,douyin.取消关注按钮,[douyin.用户作品主页])
                if (取消结果 != 0){
                    return -5
                }
            }else {
                return -7
            }
        }else {
            return -6
        }
    }else {
        return -8
    }

    点击后检测(douyin.用户主页_返回按钮,douyin.用户作品主页,[douyin.视频播放页_关注按钮]);
    return 1
}

DouYin.prototype.dy_旁白_节点获取评论区信息 = function (已获取用户,video_sid,videoContent,is_assassin=false) {
    当前执行模块 = 'dy_旁白_节点获取评论区信息';
    日志打印_debug('开始执行 - 【dy_旁白_节点获取评论区信息】')
    上次私信时间 = null

    function 评论区判断() {

        const 判断 = findColor(douyin.评论页面艾特标识)
        if(判断){
            logw(JSON.stringify(判断))
            return true
        }

        let 打开键盘 = ocr文本数组匹配(ios.键盘弹出)
        while (打开键盘){
            if(isScriptExit()){ break }
            const 关闭_弹出键盘 = {name: '【dy_评论区抓取】关闭_弹出键盘', x: random(140, 568), y: random(292, 418)};
            点击(关闭_弹出键盘)
            iSleep(400)
            打开键盘 = ocr文本数组匹配(ios.键盘弹出)
            if(!打开键盘){
                return 评论区判断()
            }
        }

        const 评论区_title = ocr文本数组匹配(douyin.评论区_title);
        if(评论区_title) { return true }

        let 账号已注销 = ocr文本数组匹配(douyin.用户账号已注销);
        while (账号已注销){
            if(isScriptExit()){ break }
            点击(douyin.用户主页_返回按钮)
            iSleep(400)
            账号已注销 = ocr文本数组匹配(douyin.用户账号已注销);
            if(!账号已注销){
                return 评论区判断()
            }
        }

        let 用户作品主页 = ocr文本数组匹配(douyin.用户作品主页);
        while (用户作品主页){
            if(isScriptExit()){ break }
            点击(douyin.用户主页_返回按钮)
            iSleep(400)
            用户作品主页 = ocr文本数组匹配(douyin.用户作品主页)
            if(!用户作品主页){
                return 评论区判断()
            }
        }

        let 主页_我_页面 = ocr文本数组匹配(douyin.主页_我_页面);
        while (主页_我_页面){
            if(isScriptExit()){ break }
            点击(douyin.用户主页_返回按钮)
            iSleep(400)
            主页_我_页面 = ocr文本数组匹配(douyin.主页_我_页面);
            if(!主页_我_页面){
                return 评论区判断()
            }
        }

        let 评论区_图片查看 = ocr文本数组匹配(douyin.评论区_图片查看);
        while (评论区_图片查看){
            if(isScriptExit()){ break }
            点击(douyin.用户主页_返回按钮)
            iSleep(400)
            评论区_图片查看 = ocr文本数组匹配(douyin.评论区_图片查看);
            if(!评论区_图片查看){
                return 评论区判断()
            }
        }
        let 视频评论区_误触内容 = ocr文本数组匹配(douyin.视频评论区_误触内容);
        while (视频评论区_误触内容){
            if(isScriptExit()){ break }
            const 关闭误触的点位 = {name: '【dy_评论区抓取】关闭 视频评论区_误触内容', x: random(250, 520), y: random(100, 200)};
            点击(关闭误触的点位)
            iSleep(400)
            视频评论区_误触内容 = ocr文本数组匹配(douyin.视频评论区_误触内容);
            if(!视频评论区_误触内容){
                return 评论区判断()
            }
        }

        let 评论区_发送图片误触 = ocr文本数组匹配(douyin.评论区_发送图片误触返回)
        while (评论区_发送图片误触){
            if (isScriptExit()){return }
            let 评论区_发送图片误触返回 = {name:'【dy_评论区抓取】关闭 评论区_发送图片误触',x:random(42,70),y:random(80,105)}
            点击(评论区_发送图片误触返回)
            iSleep(400)
            评论区_发送图片误触 = ocr文本数组匹配(douyin.视频评论区_误触内容);
            if(!评论区_发送图片误触){
                return 评论区判断()
            }
        }

        return false
    }

    if (!评论区判断()){return -1}
    const 评论区放大按钮 = findColor(douyin.视频播放页面的评论区放大按钮)
    if (评论区放大按钮){
        点击(评论区放大按钮)
    }

    let 评论区顶部 = 176;
    let 评论区底部 = 1222;

    日志打印_error("视频判断完成，开始执行【评论区获取】");
    setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
    let 评论数量节点 =  type("StaticText").labelMatch(".*条评论.*").getOneNodeInfo(10000)
    let tryCount = 3;
    while (!评论数量节点 && tryCount>0){
        if(isScriptExit()){break}
        iSleep(100);
        const 还在预期页面 = findColor(douyin.评论页面艾特标识);
        if(还在预期页面){
            评论数量节点 = type("StaticText").labelMatch(".*评论.*").getOneNodeInfo(10000)
        }
        tryCount--
    }
    if(评论数量节点 && 评论数量节点.bounds.bottom > 100 && 评论数量节点.bounds.bottom < 500){
        评论区顶部 = 评论数量节点.bounds.bottom;
    }

    function 评论是否获取完成() {
        setFetchNodeParam({"labelFilter":"2","maxDepth":"24","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
        let 暂时没有更多了 =  bounds(0,200,750,1222).type("Other").label("暂时没有更多了").getOneNodeInfo(10000)
        if (暂时没有更多了){
            return true
        }else {
            setFetchNodeParam({"labelFilter":"2","maxDepth":"25","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
            let 已折叠评论展开按钮 = bounds(0,200,750,1222).type('Button').name('展开').getOneNodeInfo(10000)
            if (已折叠评论展开按钮){
                已折叠评论展开按钮.clickCenter()
                return true
            }
        }
        return false
    }

    function 获取ip地址(str) {
        const match = str.trim().match(/[\u4e00-\u9fa5]+$/); // 匹配末尾的连续中文字符
        return match ? match[0] : ''; // 如果有匹配的中文字符，返回，否则返回空字符串
    }

    function 评论区内容分割(user) {
        user = user.replace('，作者赞过','')
        user = user.replace('查看图片，图片','[图片]')
        const firstCommaIndex = user.indexOf("，");
        const lastCommaIndex = user.lastIndexOf("，");
        // 按第一个逗号和最后一个逗号分隔
        const part1 = user.slice(0, firstCommaIndex); // 博主名称
        const part2 = user.slice(firstCommaIndex + 1, lastCommaIndex); // 评论内容
        const part3 = user.slice(lastCommaIndex + 1); // 时间_ip
        return {name:part1,content:part2,time:时间格式化(part3),id:null,ip:获取ip地址(part3),intro:null}
    }

    function dy_获取抖音id_intro() {
        const 打开用户主页_更多弹窗 = douyin.dy_打开用户主页_更多弹窗()
        if(!打开用户主页_更多弹窗){
            return
        }
        let 用户_抖音号_节点 =  type('Button').labelMatch("抖音号.*").getOneNodeInfo(10000);
        let tryCount = 3;
        while(!用户_抖音号_节点 && tryCount>0){
            if(isScriptExit()) {break}
            iSleep(100)
            const 还在预期页面 = ocr文本数组匹配(douyin.用户作品主页_更多弹出窗)
            if(还在预期页面){
                用户_抖音号_节点 = type('Button').labelMatch("抖音号.*").getOneNodeInfo(10000);
            }
            tryCount--;
        }
        if(!用户_抖音号_节点){
            return
        }
        const dy_关闭用户主页_更多弹窗 = douyin.dy_关闭用户主页_更多弹窗()
        if(!dy_关闭用户主页_更多弹窗){
            return
        }
        const 简介 =  douyin.dy_节点获取用户简介()
        return {intro: 简介, 抖音ID: douyin.裁剪ocr的抖音号(用户_抖音号_节点.label)}
    }

    let 最后一条评论 = null
    let 评论区是否获取完成 = true
    if (!评论数量节点){
        评论区是否获取完成 = false
    }
    while (评论区是否获取完成){
        评论区是否获取完成 = !评论是否获取完成()
        if (isScriptExit()){return }
        logd("评论区位置:{}",JSON.stringify([0,评论区顶部,ScreenWidth,评论区底部]))
        setFetchNodeParam({"labelFilter":"2","maxDepth":"25","visibleFilter":"1","boundsFilter":"2","excludedAttributes":""})
        const 评论区所有评论_单页 = bounds(0,评论区顶部,ScreenWidth,评论区底部).type("Other").getNodeInfo(10*1000)
        logd("评论区所有评论_单页:{}",JSON.stringify(评论区所有评论_单页))
        for (var i of 评论区所有评论_单页){
            if (!i.name || i.name == '' || i.name.includes('，作者')){
                logd('节点未空')
                continue;
            }
            最后一条评论 = i

            const 用户信息 = 评论区内容分割(i.label)
            if (已获取用户.includes(用户信息.name)){
                continue
            }
            const 评论区_用户头像 = {name:"评论区_用户头像",x:random(42,90),y:random(i.bounds.top+36,i.bounds.top+70)}
            if (!评论区判断()){return -1}
            const 用户头像点击结果 = 点击后检测(评论区_用户头像,douyin.评论页面艾特标识,[douyin.用户作品主页,ios.键盘弹出])
            if (用户头像点击结果 == 1){
                const 关闭_弹出键盘 = {name: '【dy_评论区抓取】关闭_弹出键盘', x: random(140, 568), y: random(292, 418)};
                点击(关闭_弹出键盘)
                continue
                // const 关闭头像误触 = findColor(douyin.头像误触标识)
                // const 头像误触返回 = 点击后检测(关闭头像误触,douyin.头像误触标识,[douyin.用户作品主页])
                // if (头像误触返回 != 0){
                //     return -2
                // }
            }else if (用户头像点击结果 != 0){
                return -1
            }
            const id_intro = dy_获取抖音id_intro()
            if (!id_intro){
                return -6
            }
            用户信息.intro = id_intro.intro
            用户信息.id = id_intro.抖音ID
            logd("用户信息:{}",JSON.stringify(用户信息))
            const 上传评论数据 = {
                "video_sid": video_sid,
                "belong_account_id": uid,
                "account_type": '抖音',
                "customer_name": 用户信息.name,
                "customer_id":用户信息.id,
                "customer_comment_time": 用户信息.time,
                "customer_ip_location": 用户信息.ip,
                "customer_comment": 用户信息.content,
                "customer_homepage_img": '',
                "customer_other_information": 用户信息.intro,
            }
            logd("用户评论时间:{}",用户信息.time)
            if (isToday(用户信息.time) && is_assassin){
                let 私信结果 = douyin.dy_刺客_是否私信(video_sid,videoContent,用户信息,{用户昵称:用户信息.name,抖音ID:用户信息.id},用户信息.intro)
                if (私信结果 === -1 || 私信结果 === -2){
                    return -3
                }
            }else {
                logd("上传评论数据:{}",JSON.stringify(上传评论数据))
                if (上传评论数据){
                    api_插入视频评论用户(上传评论数据)
                }
            }

            const 在_用户作品主页 = ocr文本数组匹配(douyin.用户作品主页)
            if(在_用户作品主页){
                logd("获取完成返回")
                点击(douyin.用户主页_返回按钮)
                iSleep(400)
            }
            if(!评论区判断()){ return -4}
        }
        let 滑动位置_x = random(20,100)
        logd("滑动位置:{}",JSON.stringify([滑动位置_x,最后一条评论.bounds.bottom,滑动位置_x,评论区顶部]))
        if (最后一条评论){
            滑动(滑动位置_x,最后一条评论.bounds.bottom,滑动位置_x,评论区顶部,2500)
        }
        sleep(1000)
    }
    return 1
}

function ios_打开_关闭无障碍模式(开_关 = false) {
    const ios_下拉工具框 = {
        name: 'ios_下拉工具框',
        textArray: ['模式','播放','睡眠','开'],
        x: 0,
        y: 0,
        ex: ScreenWidth,
        ey: 1330,
        binaryzation: false,
        matchCount: 2
    }
    swipeToPointPressure(500,1330,500,1000,500,Math.random(0.2, 0.6))
    sleep(1000);
    while (!ocr文本数组匹配_2(ios_下拉工具框)){
        logd("旁白打开循环")
        if (isScriptExit()){return;}
        swipeToPointPressure(500,1330,500,1000,500,Math.random(0.2, 0.6))
        sleep(1000)
    }
    logd("旁白已打开")
    const 无障碍按钮 = findColor_2(douyin.无障碍模式已开启按钮)
    let 是否点击 = true
    if (开_关){
        if (无障碍按钮){
            是否点击 = false
        }
    }else {
        if (!无障碍按钮){
            是否点击 = false
        }
    }
    if (是否点击){
        setFetchNodeParam({"labelFilter":"2","maxDepth":"15","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
        let 开启无障碍 =  type("Button").labelMatch(".*辅助功能快捷键.*").getOneNodeInfo(10000)
        while (!开启无障碍){
            if (isScriptExit()){return}
            sleep(100)
            setFetchNodeParam({"labelFilter":"2","maxDepth":"15","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
            开启无障碍 =  type("Button").labelMatch(".*辅助功能快捷键.*").getOneNodeInfo(10000)
        }
        开启无障碍.clickCenter()
    }
    sleep(1000)
    swipeToPointPressure(520,58,521,550,500,Math.random(0.2, 0.6))
    while (ocr文本数组匹配_2(ios_下拉工具框)){
        logd("旁白关闭循环")
        if (isScriptExit()){return;}
        sleep(100)
        swipeToPointPressure(520,58,521,550,500,Math.random(0.2, 0.6))
    }
    return true
}

/**
 * @description  范围内的ocr的识别结果匹配文本数组 去除实时启动当前应用
 * @param ocrContent {JSON}
 * @returns {boolean}
 */
function ocr文本数组匹配_2(ocrContent) {
    const {  name, textArray, x, y, ex, ey,binaryzation, matchCount } = ocrContent;
    日志打印_debug(`【ocr文本数组匹配】： ${name}`)
    let filterText = null
    if(ocrContent.hasOwnProperty('filterText')){
        filterText = ocrContent.filterText
    }
    for( let ii=0; ii<2; ii++){
        if(isScriptExit()){break}
        const 识别结果 = ocr范围识别_2(x, y, ex, ey, binaryzation);
        let 匹配成功数量 = 0;
        const findTextArray = JSON.parse(JSON.stringify(textArray))
        logw(`寻找： ${findTextArray}`)
        if(识别结果){
            if(filterText){
                for(let i in 识别结果){
                    if(isScriptExit()){break}
                    const 单行文本 = 识别结果[i];
                    for (let j = 0; j < filterText.length; j++) {
                        if(isScriptExit()){break}
                        const index = 单行文本.label.indexOf(filterText[j])
                        if (index !== -1) {
                            return false
                        }
                    }
                }

            }

            for(let i in 识别结果){
                if(isScriptExit()){break}
                const 单行文本 = 识别结果[i];
                for (let j = 0; j < findTextArray.length; j++) {
                    if(isScriptExit()){break}
                    const index = 单行文本.label.indexOf(findTextArray[j])
                    if (index !== -1) {
                        findTextArray.splice(j, 1)
                        j--;
                        匹配成功数量++;
                        if(匹配成功数量 >= matchCount){
                            logw(`寻找成功： ${findTextArray}`)
                            return true
                        }

                    }
                }
            }
        }
    }
    loge(`寻找失败： ${textArray}`)
    return false
}

/**
 * @description  获取范围内的ocr的识别结果
 * @param x {left}
 * @param y {top}
 * @param ex {right}
 * @param ey {bottom}
 * @param binaryzation {是否二值化}
 * @returns {Object || null}
 */
function ocr范围识别_2(x, y, ex, ey, binaryzation=false, img=null) {
    const params = [x, y, ex, ey];
    if (params.some(param => param === null || param === undefined)) {
        throw new Error(`【ocr范围识别】参数错误：${JSON.stringify({x, y, ex, ey})}` );
    }
    if(ey <= y || ex <= x) {
        throw new Error(`【ocr范围识别】参数错误：${JSON.stringify({x, y, ex, ey})}` );
    }

    let 识别结果 = null;
    let 重试次数 = 3;
    while(!识别结果 && 重试次数 > 0){
        if(isScriptExit()){ break };
        if(!img){
            img = image.captureFullScreenEx();
        }
        重试次数--;
        newImg = image.clip(img, x, y, ex, ey)
        if(binaryzation){
            var binaryzationImage = image.binaryzation(newImg, 200);
            识别结果 = ocr.ocrImage(binaryzationImage, 2000, {});
            image.recycle(binaryzationImage);
        }else {
            识别结果 = ocr.ocrImage(newImg, 2000, {});
        }
    }
    image.recycle(img);
    image.recycle(newImg);
    return 识别结果
}

/**
 * @description  找色
 * @param {图色} mark
 * @param {图片对象} img
 * @param {重试次数} maxCount
 * @returns {{x: *, y: *} || null}
 */
function findColor_2(mark,img=null) {

    function 屏幕截图2(Mat=true){
        while(true){
            if(isScriptExit()){break }
            if(Mat){ image.useOpencvMat(1) }
            else { image.useOpencvMat(0) }
            const 截图 = image.captureFullScreenEx();
            if(!(截图 === null || 截图 === undefined || 截图.uuid === null || 截图.uuid === undefined || 截图.uuid === "" )){
                    return 截图
                }else {
                    sleep(300)
                }
            }
            image.recycle(截图);
    }

    const { name, firstColor, multiColor, x, y, ex, ey, orz } = mark;
    if(multiColor.length < 4){
        scriptError(`${name} -- 节点 属性multiColor 需要最少4个点！`);
    }

    const threshold = 0.95;
    for(let i=0; i<2; i++){
        if(isScriptExit()){break}
        if(!img){
            img = 屏幕截图2();
        }
        const points = image.findMultiColor(img, firstColor, multiColor, threshold, x, y, ex, ey, 1, orz);
        image.recycle(img)
        if(points){
            return 获取图色的随机点(name, points, multiColor)
        }
        sleep(100)
    }
    return null
}

/**
 * 判断日期是否在指定天数内
 * @param dateStr 日期
 * @param days 天数
 */
function isCurrentTimeGreaterThan(dateStr, days) {
    // 将传入的日期字符串转换为 Date 对象
    function normalizeDate(dateStr) {
        // 使用正则表达式匹配年份、月份和日期
        const match = dateStr.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
        if (!match) {
            throw new Error("Invalid date format. Expected format: YYYY-MM-D");
        }

        // 提取年份、月份和日期
        let [_, year, month, day] = match;

        // 补齐月份和日期为两位数
        month = month.padStart(2, '0');
        day = day.padStart(2, '0');

        // 返回规范化的日期
        return `${year}-${month}-${day}`;
    }

    dateStr = normalizeDate(dateStr)
    const targetDate = new Date(dateStr);

    // 在目标日期上加上指定的天数
    targetDate.setDate(targetDate.getDate() + days);

    // 获取当前时间
    const now = new Date();

    // 判断当前时间是否大于目标日期
    return now > targetDate;
}

