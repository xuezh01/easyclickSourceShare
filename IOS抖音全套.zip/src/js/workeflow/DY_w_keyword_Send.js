
function 抖音私信关键词昵称用户工作流() {
    if(设备抖音账号信息.length === 0){
        douyin.dy_账号统计_切换_初始化()
    }
    while (抖音_私信时间()) {
        if (isScriptExit()) { return }
        抖音_更新账号今日私信()
        if (!抖音_查询今日私信是否饱和()) {
            抖音私信_关键词昵称用户()
        }else {
            养号_跟进客户()
        }
    }
    while(抖音_关键词检索时间()){
        if (isScriptExit()) { return }
        抖音_关键词检索()
        日志打印_error('关键词搜索：开始重启')
    }
    while (!抖音_关键词检索时间() && !抖音_私信时间()){
        if(isScriptExit()) {break}
        养号_跟进客户()
        if(抖音_关键词检索时间()){ break }
        if(抖音_私信时间()){ break }
        iSleep(30000);
    }
}

function 抖音私信_关键词昵称用户() {
    脚本当前运行阶段 = `抖音私信：【关键词昵称用户】`

    douyin.初始化()
    抖音_更新账号今日私信()
    if (!douyin.dy_首页导航_切换(1)) {
        douyin.dy_启动抖音()
        return
    }
    douyin.dy_跟进客户(3)
    if (!douyin.dy_首页导航_切换(1)) { return }

    if (!douyin.dy_首页搜索按钮点击(device_timing.search_time_interval)) { return }
    if (!douyin.dy_搜索页面输入查询(device_script_task.keywordsSend.keyword_one)) { return }
    if (!douyin.dy_搜索结果分类选项选择('用户')) { return }
    if (douyin.dy_搜索结果频繁_检测(device_timing.search_pinfan_hours)) { return; }
    if (!douyin.dy_用户筛选(device_script_task.keywordsSend.fansLimit, device_script_task.keywordsSend.customerType)) { return }
    while (true){
        if (isScriptExit()) { return }
        脚本当前运行阶段 = `抖音私信：【关键词昵称用户】`
        if(device_script_task.task !== '关键词昵称任务'){ return }
        if (!抖音_私信时间() || 抖音_查询今日私信是否饱和()) { return }
        if (抖音_当前账号私信已饱和() && 抖音_可切换私信账号()){
            douyin.dy_账号统计_切换_初始化()
            continue
        }
        const 当前列表用户信息 = douyin.dy_获取所有搜索页当前用户()
        if( 当前列表用户信息 && 当前列表用户信息.length>0) {
            for (let i in 当前列表用户信息) {
                if (isScriptExit()) {
                    break
                }
                if (!抖音_私信时间() || 抖音_查询今日私信是否饱和()) {
                    return
                }
                if (抖音_当前账号私信已饱和() && 抖音_可切换私信账号()) {
                    douyin.dy_账号统计_切换_初始化()
                    return;
                }
                脚本当前运行阶段 = `抖音私信：【关键词昵称用户】`
                if (device_script_task.task !== '关键词昵称任务') {
                    return
                }
                const 选择用户 = 当前列表用户信息[i]
                const 抖音ID = douyin.dy_选择用户获取抖音ID(选择用户)
                if (!抖音ID) {
                    return
                }
                if (douyin.私信已发送列表.includes(抖音ID)) {
                    记录用户已私信(抖音ID, device_script_task.keywordsSend.keyword_one)
                    const 记录过往发送 = {
                        "account_id": 抖音_获取当前账号的抖音ID(),
                        "account_type": "抖音",
                        "send_customer_id": "",
                        "last_send_customer_id": 抖音ID,
                    }
                    api_记录当前账号已发送私信id(记录过往发送)
                    if (!douyin.dy_用户主页_更多弹窗_返回用户搜索页面()) {
                        return
                    }
                    continue;
                }
                const 已经私信 = 查询用户是否已私信(抖音ID, device_script_task.keywordsSend.keyword_one);
                if (已经私信) {
                    douyin.私信已发送列表.push(抖音ID)
                    if (!douyin.dy_用户主页_更多弹窗_返回用户搜索页面()) {
                        return
                    }
                    continue;
                }
                进入实时回复 = true;
                if (!douyin.dy_用户作品_进入用户私信页面()) {
                    return
                }
                if (douyin.dy_检测私信频繁() || douyin.dy_检测私信发送未成功()) {
                    douyin.私信已发送列表.push(抖音ID)
                    记录用户已私信(抖音ID, device_script_task.keywordsSend.keyword_one)
                    douyin.搜索时间 = time() - device_timing.search_time_interval * 60 * 1000
                    douyin.dy_用户主页_返回搜索页()
                    continue;
                }
                const 聊天记录 = douyin.dy_节点_获取聊天记录();
                let 执行发送私信 = true
                if (聊天记录 && 聊天记录 !== '') {
                    const 聊天记录Array = 聊天记录.split('\n')
                    for (let ii in 聊天记录Array) {
                        if (isScriptExit()) {
                            break
                        }
                        if (聊天记录Array[ii].startsWith('我:')) {
                            执行发送私信 = false
                            break
                        }
                    }
                }
                if (!执行发送私信) {
                    douyin.私信已发送列表.push(抖音ID)
                    记录用户已私信(抖音ID, device_script_task.keywordsSend.keyword_one)
                    douyin.dy_用户主页_返回搜索页()
                } else {
                    douyin.dy_发送私信(device_script_task.first_replay, device_script_task.follow_probability)
                    douyin.私信已发送列表.push(抖音ID)
                    记录用户已私信(抖音ID, device_script_task.keywordsSend.keyword_one)
                    const 自定义字段 = {
                        type: '正常私信',
                        fiend_douyinID: 抖音ID,
                        my_douyinID: 抖音_获取当前账号的抖音ID(),
                        fiend_name: '无名',
                        comment: '无评论',
                    }
                    const 聊天记录截图 = 区域截图base64(0, 0, ScreenWidth, ScreenHeight)
                    上传私信回复图片(JSON.stringify(自定义字段), 聊天记录截图)
                    const 私信未成功 = douyin.dy_检测私信发送未成功();
                    if (私信未成功) {
                        设备抖音账号信息.forEach(account => {
                            if (isScriptExit()) {
                                return
                            }
                            if (account.choose) {
                                account.sendFailedCount += 1;
                            }
                        })
                    }
                    更新抖音今日已发送私信数量();
                    const 私信频繁 = douyin.dy_检测私信频繁()
                    if (私信频繁) {
                        设备抖音账号信息.forEach(account => {
                            if (isScriptExit()) {
                                return
                            }
                            if (account.choose) {
                                account.pinfanCount += 1;
                            }
                        })
                        更新抖音今日已发送私信数量(false);
                        if (抖音_可切换私信账号()) {
                            douyin.dy_账号统计_切换_初始化()
                            return;
                        }
                    }
                    if (!douyin.dy_退出私信页面_返回用户主页()) {
                        return
                    }
                    ;
                    const 发送成功计时 = time()
                    while ((time() - 发送成功计时) < device_timing.search_time_interval * 60 * 1000) {
                        if (isScriptExit()) {
                            break
                        }
                        if (!关键词私信是否可以发私信()) {
                            return;
                        }
                        当前执行模块 = '私信后等待'
                        日志打印_information('私信后等待')
                        iSleep(random(10000, 50000));
                    }
                }
            }
            douyin.dy_搜索页用户列表上滑()
        }
    }
}

function 更新抖音今日已发送私信数量(add=true) {
    日志打印_information('开始执行 -- 【更新抖音今日已发送私信数量】')
    const start_time = time();
    if(add){
        设备抖音账号信息.forEach(item => {
            if(isScriptExit()){return}
            if(item.choose){
                item.sendCount += 1;
            }
        });
    }
    const data = {
        device_id: device_id,
        text_data: JSON.stringify(设备抖音账号信息),
    }
    const insertUrl = `${DBurl}/update_run_time_data`;
    while (true){
        if(isScriptExit()){break}

        for(let i = 0; i < 5; i++){
            if(isScriptExit()){break}
            const r = http.postJSON(insertUrl, data, 30 * 1000, {"key-word": "test"});
            日志打印_debug(`【更新抖音今日已发送私信数量】 请求结果: ${r}`);
            if(r){
                try {
                    const response = JSON.parse(r);
                    if (response.state === 200) {
                        日志打印_warning(`【更新抖音今日已发送私信数量 耗时】：${time() - start_time}`);
                        return
                    } else {
                        日志打印_error(`【更新抖音今日已发送私信数量】 请求失败: ${r}`);
                    }
                }catch (e) {
                    日志打印_error(`【更新抖音今日已发送私信数量】 请求失败 catch: ${e}`);
                }
            }
        }
        iSleep(2000)
    }
}

function 关键词私信是否可以发私信() {
    if(抖音_私信时间() && !抖音_查询今日私信是否饱和()){
        return true
    }
    return false
}

