
function 实时私信回复() {
    日志打印_debug('开始执行-- 【实时私信回复】')
    const 私信弹出页面放大标识 = findColor(douyin.私信弹出页面放大标识)
    if(私信弹出页面放大标识){
        const 放大结果 = 点击后检测(私信弹出页面放大标识, douyin.私信弹出页面放大标识, [douyin.商家店铺左尖括号返回按钮, douyin.左上角返回按钮])
        if(放大结果 === 0 || 放大结果 === 1){
            const 用户消息 = douyin.dy_私信页面_消息记录()
            if(!用户消息) {
                const 记录数据 = {
                    "belong_uid": uid,
                    "belong_device_id": device_id,
                    "belong_app_account_id": 抖音_获取当前账号的抖音ID(),
                    "belong_app_account_type": "抖音",
                    "follow_type": '实时回复异常截图',
                    "follow_img": 区域截图base64()
                }
                api_记录跟进用户(记录数据)
                douyin.dy_退出_实时私信回复_页面()
                return
            }else {
                const 记录数据 = {
                    "belong_uid": uid,
                    "belong_device_id": device_id,
                    "belong_app_account_id": 用户消息.my_douyinID,
                    "belong_app_account_type": "抖音",
                    "follow_type": '实时弹窗',
                    "follow_customer_name": 用户消息.fiend_name,
                    "follow_customer_id": 用户消息.fiend_douyinID,
                    "follow_img": 区域截图base64()
                }
                api_记录跟进用户(记录数据)
            }
            // const 聊天记录 = douyin.dy_节点_获取聊天记录();
            // if (聊天记录 && 聊天记录 !== '') {
            //     if(聊天记录[聊天记录.length-1].startsWith('我')){
            //         // 不需要回复
            //         douyin.dy_退出_实时私信回复_页面()
            //         return
            //     }
            //     let 回复内容 = get_replay(聊天记录);
            //     if(!回复内容){
            //         日志打印_debug(`【实时私信回复】使用 固定回复话术`);
            //         回复内容 = '您能留下联系方式进一步详聊吗？' || device_script_task.agi_config.fixedReply ;
            //     }
            //     日志打印_information(`【实时私信回复】即将回复消息： ${回复内容}`);
            //     if(回复内容 && 回复内容 !== ''){
            //         const 记录数据 = {
            //             "belong_uid": uid,
            //             "belong_device_id": device_id,
            //             "belong_app_account_id": 用户消息.my_douyinID,
            //             "belong_app_account_type": "抖音",
            //             "follow_type": '实时回复',
            //             "follow_customer_name": 用户消息.fiend_name,
            //             "follow_customer_id": 用户消息.fiend_douyinID,
            //             "follow_img": 区域截图base64()
            //         }
            //         api_记录跟进用户(记录数据)
            //     }
            // }
        }
    }

    douyin.dy_退出_实时私信回复_页面();
}


DouYin.prototype.dy_退出_实时私信回复_页面 = function (){
    日志打印_debug(`开始执行 - 【退出私信回复页面】`);
    const 退出_实时私信_按钮 = {name: '【dy_退出_实时私信回复_页面】退出_实时私信_按钮', x: random(50, 68), y:random(74,93)};
    let 私信页面表情标识 = findColor(douyin.私信页面表情标识)
    while(私信页面表情标识){
        if(isScriptExit()){break}
        点击(退出_实时私信_按钮)
        iSleep(800)
        私信页面表情标识 = findColor(douyin.私信页面表情标识)
    }
}



// DouYin.prototype.获取回复时间 = function (){
//
// }

