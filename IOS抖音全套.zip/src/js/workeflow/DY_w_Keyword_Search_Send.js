
function 抖音关键词检索后私信工作流() {
    if(设备账号信息.dy.length === 0){
        douyin.dy_账号统计_切换_初始化()
    }

    while (抖音_私信时间()) {
        if (isScriptExit()) { return }
        if (!脚本运行配置.app_type.includes('抖音')){ return }
        if (脚本运行配置.dy.task !== '关键词检索任务'){ return }
        if (!抖音_查询今日私信是否饱和() && 抖音_查询今日是否有私信数据() ) {
            抖音私信_关键词检索数据()
        }else {
            脚本当前运行阶段 = `【抖音】养号_跟进客户`
            抖音_养号_跟进客户()
        }
    }

    while(抖音_关键词检索时间()){
        if (isScriptExit()) { return }
        if (!脚本运行配置.app_type.includes('抖音')){ return }
        if (脚本运行配置.dy.task !== '关键词检索任务'){ return }
        if(脚本运行配置.dy.keyword_search.hasOwnProperty('type') && 脚本运行配置.dy.keyword_search.type === '图文'){
            抖音图文获客()
        }else {
            抖音_关键词检索()
        }
    }
}

function 抖音_养号_跟进客户(分钟) {
    douyin.dy_当前账号_跟进客户()
    douyin.dy_首页视频养号(分钟)
    douyin.dy_当前账号_跟进客户()
    douyin.dy_切换账号_跟进客户()
}

function 抖音_关键词检索() {

    while (!douyin.关键词已无视频){
        if(isScriptExit()){break}
        if (!脚本运行配置.app_type.includes('抖音')){ return }
        if (脚本运行配置.dy.task !== '关键词检索任务'){ return }
        if (!抖音_关键词检索时间()){ return }
        const 请求关键词 = api_获取检索关键词('抖音',抖音_获取当前账号的抖音ID())
        if(!请求关键词){
            脚本当前运行阶段 =`【抖音】【${脚本运行配置.dy.keyword_search.keyword}】该关键词无更多视频,请重新分配关键词！`
            iSleep(20000)
        }else {
            douyin.关键词已无视频 = 请求关键词
            脚本运行配置.dy.keyword_search.keyword = 请求关键词.key_word
            break
        }
    }

    脚本当前运行阶段 = `【抖音】关键词搜索：${脚本运行配置.dy.keyword_search.keyword}`
    douyin.初始化()

    if (!douyin.dy_首页导航_切换(1)) {
        douyin.dy_启动抖音()
        return
    }
    douyin.dy_跟进客户()
    脚本当前运行阶段 = `【抖音】关键词搜索：${脚本运行配置.dy.keyword_search.keyword}`
    if (!douyin.dy_首页搜索按钮点击(脚本运行配置.dy.search_time_interval)) { return }
    if (!douyin.dy_搜索页面输入查询(脚本运行配置.dy.keyword_search.keyword)) { return }
    if (!douyin.dy_搜索结果分类选项选择('视频')) { return }
    if (douyin.dy_搜索结果频繁_检测(脚本运行配置.dy.search_pinfan_hours)){ return }
    if (!douyin.dy_视频筛选(
                            脚本运行配置.dy.keyword_search.video_filter.video_sort_by,
                            脚本运行配置.dy.keyword_search.video_filter.video_release_time,
                            脚本运行配置.dy.keyword_search.video_filter.video_duration,
                            脚本运行配置.dy.keyword_search.video_filter.video_search_scope
                        )) { return }

    if (!douyin.dy_搜索结果的视频点击()) { return }

    // 进入视频轮询查看阶段
    while (true){
        if (isScriptExit()) { return }
        if (!脚本运行配置.app_type.includes('抖音')){ return }
        if (脚本运行配置.dy.task !== '关键词检索任务'){ return }
        if (!抖音_关键词检索时间()){ return }

        if (!douyin.关键词已无视频) { return }
        if (!douyin.dy_搜索视频_播放页面判断()) { return }

        const 视频信息 = douyin.dy_视频信息采集()
        if (!视频信息 || 视频信息.评论数量 <= 0 || 视频信息.name.trim() === ''){
            douyin.dy_视频信息采集_后回到视频播放页面()
            douyin.dy_上滑切换视频()
            continue
        }

        const 上传视频信息 = {
            "belong_device_id": device_id,
            "account_id": 抖音_获取当前账号的抖音ID(),
            "account_type": "抖音",
            "belong_uid": uid,
            "video_keyword": 脚本运行配置.dy.keyword_search.keyword,
            "video_up_id": 视频信息.抖音ID,
            "video_up_name": 视频信息.作者,
            "video_type":  视频信息.类型,
            "video_comment_count": 视频信息.评论数量,
            "video_title": 视频信息.name,
            "video_up_homepage": 视频信息.homepage,
            "video_up_information": "",
            "enhance_grip": 脚本运行配置.dy.keyword_search.enhance_grip,
            "min_interval_days": parseInt(脚本运行配置.dy.keyword_search.min_interval_days),
        }
        const 视频指令 = api_获取视频是否已观看(上传视频信息)
        日志打印_information(`视频指令: ${JSON.stringify(视频指令)}`)
        if (!视频指令.leave_traces && 脚本运行配置.dy.keyword_search.leave_traces.state){
            if (脚本运行配置.dy.keyword_search.leave_traces.message && 脚本运行配置.dy.keyword_search.leave_traces.message.trim() !== ''){
                if (!douyin.dy_评论区留痕(脚本运行配置.dy.keyword_search.leave_traces.message)) { return }
                const 留痕记录 = {
                    "video_sid": parseInt(视频指令.video_sid),
                    "account_id": 抖音_获取当前账号的抖音ID(),
                    "account_type": "抖音",
                }
                api_记录视频留痕(留痕记录)
            }
        }
        if (!视频指令.catch){
            douyin.dy_视频信息采集_后回到视频播放页面()
            douyin.dy_上滑切换视频()
            continue
        }

        if(视频指令.video_accuracy === ''){
            if (!视频信息.name.includes(脚本运行配置.dy.keyword_search.keyword)){
                const params = {
                    "videoContent": 视频信息.name,
                    "hangye":  脚本运行配置.dy.keyword_search.industry,
                    "keyword": 脚本运行配置.dy.keyword_search.keyword,
                    "up_name": 视频信息.作者,
                    "account_type": "抖音",
                }
                const 视频判断结果 = api_判断视频精准度(uid, '抖音', 视频信息.作者,脚本运行配置.dy.keyword_search.keyword,视频信息.name)
                if (视频指令.video_sid !== null && 视频指令.video_sid){
                    const 视频判断结果记录 = {
                        "video_sid": parseInt(视频指令.video_sid),
                        "accuracy": String(视频判断结果),
                        "account_type": "抖音",
                    }
                    api_记录视频精准度(视频判断结果记录)
                }

                if (!视频判断结果){
                    douyin.dy_视频信息采集_后回到视频播放页面()
                    douyin.dy_上滑切换视频()
                    continue
                }
            }
            else {
                if (视频指令.video_sid !== null && 视频指令.video_sid){
                    const 视频判断结果记录 = {
                        "video_sid": parseInt(视频指令.video_sid),
                        "accuracy": '包含关键词，不判断',
                        "account_type": "抖音",
                    }
                    api_记录视频精准度(视频判断结果记录)
                }

            }
        }
        if (!douyin.dy_评论区抓取(parseInt(视频指令.video_sid))){ continue }
        douyin.dy_视频信息采集_后回到视频播放页面()
        douyin.dy_上滑切换视频()
    }
}

function 抖音私信_关键词检索数据() {
    douyin.初始化()
    while (true){
        if (isScriptExit()) { return }
        脚本当前运行阶段 = `【抖音】私信用户`

        if (!脚本运行配置.app_type.includes('抖音')) { return }
        if (脚本运行配置.dy.task !== '关键词检索任务'){ return }
        if (!抖音_私信时间()) { return }
        if (抖音_查询今日私信是否饱和()) { return }
        if (!抖音_查询今日是否有私信数据()) { return }

        douyin.dy_跟进客户()

        if (抖音_当前账号私信已饱和() && 抖音_可切换私信账号()){
            douyin.dy_切换账号()
            continue
        }
        while (true){
            if(isScriptExit()) { break}
            if (douyin.dy_首页导航_切换(1)) { break }
            douyin.dy_启动抖音()
        }

        const data = 抖音_获取当前账号私信用户_抖音ID()
        if(data === null || !data){ return }

        const 当前发送抖音ID = data.send_customer_id
        进入实时回复 = false;

        if(douyin.私信已发送列表.includes(当前发送抖音ID)){
            api_记录账号今日已私信数据(data.aaci_atid, 当前发送抖音ID,2)
            continue
        }
        脚本当前运行阶段 = `【抖音】私信用户`
        while (true){
            if(isScriptExit()) { break}
            if (douyin.dy_首页导航_切换(1)) { break }
            douyin.dy_启动抖音()
        }
        if (!douyin.dy_首页搜索按钮点击(脚本运行配置.dy.search_time_interval)) { return }
        if (!douyin.dy_搜索页面输入查询(当前发送抖音ID)) { return }
        if (!douyin.dy_搜索结果分类选项选择('用户')) { return }
        if (douyin.dy_搜索结果频繁_检测(脚本运行配置.dy.search_pinfan_hours)){ return }

        const 进入结果 = douyin.dy_用户列表_用户主页进入(当前发送抖音ID);
        switch (进入结果) {
            case -1:
                return
            case 0:
                douyin.私信已发送列表.push(当前发送抖音ID)
                api_记录账号今日已私信数据(data.aaci_atid, 当前发送抖音ID,3)
                douyin.搜索时间 = time() - 脚本运行配置.dy.search_time_interval*60*1000
                douyin.dy_搜索页_返回首页()
                continue
            case 1:
                break
        }

        if (!douyin.dy_用户作品_进入用户私信页面()) { return }
        if (douyin.dy_检测私信频繁() || douyin.dy_检测私信发送未成功()){
            api_记录账号今日已私信数据(data.aaci_atid, 当前发送抖音ID,2)
            douyin.私信已发送列表.push(当前发送抖音ID)
            douyin.搜索时间 = time() - 脚本运行配置.dy.search_time_interval*60*1000
            if (!douyin.dy_退出私信页面_返回用户主页()) { return }
            if (!douyin.dy_用户主页_返回搜索页()) { return }
            if (!douyin.dy_搜索页_返回首页()) { return }
            continue;
        };

        const 聊天记录 = douyin.dy_节点_获取聊天记录();
        let 执行发送私信 = true
        if (聊天记录 && 聊天记录 !== ''){
            const 聊天记录Array = 聊天记录.split('\n')
            for(let ii in 聊天记录Array){
                if(isScriptExit()){break}
                if(聊天记录Array[ii].startsWith('我:')){
                    执行发送私信 = false
                    break
                }
            }
        }
        if(!执行发送私信){
            api_记录账号今日已私信数据(data.aaci_atid, 当前发送抖音ID,2)
            douyin.私信已发送列表.push(当前发送抖音ID)
        }else {
            const first_msg = api_获取私信话术('抖音', 抖音_获取当前账号的抖音ID())
            douyin.dy_发送私信(first_msg, 脚本运行配置.dy.keyword_search.send_msg.follow_probability)
            api_记录账号今日已私信数据(data.aaci_atid, 当前发送抖音ID,1)
            douyin.私信已发送列表.push(当前发送抖音ID)
            const 私信未成功 = douyin.dy_检测私信发送未成功();
            const 私信频繁 = douyin.dy_检测私信频繁()
            抖音_私信统计更新(私信未成功, 私信频繁)
            if (私信频繁) {
                if(抖音_可切换私信账号()){
                    douyin.dy_返回_设定页面(douyin.首页_底部导航)
                    douyin.dy_切换账号()
                    continue
                }
            }
        }
        if (!douyin.dy_退出私信页面_返回用户主页()) { return }
        if (!douyin.dy_用户主页_返回搜索页()) { return }
        if (!douyin.dy_搜索页_返回首页()) { return }
    }
}







