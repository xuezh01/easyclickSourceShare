


function 抖音_昵称检索() {

    while (!douyin.关键词已无用户){
        if(isScriptExit()){break}
        if (!脚本运行配置.app_type.includes('抖音')){ return }
        if (脚本运行配置.dy.task !== '昵称检索任务'){ return }
        if (!抖音_昵称检索时间()){ return }
        const 请求关键词 = api_获取昵称关键词('抖音',抖音_获取当前账号的抖音ID())
        if(!请求关键词){
            脚本当前运行阶段 =`【抖音】【${脚本运行配置.dy.keyword_name.keyword}】该关键词无更多视频,请重新分配关键词！`
            iSleep(20000)
        }else {
            douyin.关键词已无用户 = 请求关键词
            脚本运行配置.dy.keyword_name.keyword = 请求关键词.key_word
            break
        }
    }

    脚本当前运行阶段 = `【抖音】昵称搜索：${脚本运行配置.dy.keyword_name.keyword}`
    douyin.初始化()

    if (!douyin.dy_首页导航_切换(1)) {
        douyin.dy_启动抖音()
        return
    }
    // douyin.dy_跟进客户()
    脚本当前运行阶段 = `【抖音】昵称搜索：${脚本运行配置.dy.keyword_name.keyword}`
    if (!douyin.dy_首页搜索按钮点击(脚本运行配置.dy.search_time_interval)) { return }
    if (!douyin.dy_搜索页面输入查询(脚本运行配置.dy.keyword_name.keyword)) { return }
    if (!douyin.dy_搜索结果分类选项选择('用户')) { return }
    if (douyin.dy_搜索结果频繁_检测(脚本运行配置.dy.search_pinfan_hours)){ return }
    if (!douyin.dy_用户筛选(
        脚本运行配置.dy.keyword_name.customer_filter.fansLimit,
        脚本运行配置.dy.keyword_name.customer_filter.customerType,
    )) { return }

    function 用户搜索页判断() {
        const 在用户搜索页面 = findMultiColor([douyin.搜索页面的用户列表关注按钮, douyin.搜索页面的用户列表关注按钮2])
        if(在用户搜索页面){ return true }

        let 用户作品主页 = ocr文本数组匹配(douyin.用户作品主页);
        while (用户作品主页){
            if(isScriptExit()){ break }
            点击(douyin.用户主页_返回按钮)
            iSleep(400)
            用户作品主页 = ocr文本数组匹配(douyin.用户作品主页)
            if(!用户作品主页){
                return 用户搜索页判断()
            }
        }

        let 在用户主页_下滑 = findMultiColor([douyin.用户主页_下滑后_右上角标识,douyin.用户主页_下滑后_右上角标识2])
        while (在用户主页_下滑){
            if(isScriptExit()){ break }
            点击(douyin.用户主页_返回按钮)
            iSleep(400)
            在用户主页_下滑 = findMultiColor([douyin.用户主页_下滑后_右上角标识,douyin.用户主页_下滑后_右上角标识2])
            if(!在用户主页_下滑){
                return 用户搜索页判断()
            }
        }
        日志打印_error('不在 [用户搜索页]')
        return false
    }

    let 滑动前截图 = 区域截图base64(160, 400, 550, ScreenHeight)
    let 重复次数 = 3
    while (true){
        if (isScriptExit()) { return }
        if (!脚本运行配置.app_type.includes('抖音')){ return }
        if (脚本运行配置.dy.task !== '昵称检索任务'){ return }
        if (!抖音_昵称检索时间()){ return }

        脚本当前运行阶段 = `【抖音】昵称搜索：${脚本运行配置.dy.keyword_name.keyword}`

        const 当前列表用户信息 = douyin.dy_获取所有搜索页当前用户()
        const 抓取用户列表 = api_昵称检索用户列表识别(当前列表用户信息)
        for( let i in 抓取用户列表){
            if (isScriptExit()) { break }
            if (!用户搜索页判断()) { return }
            const 单个用户 = 抓取用户列表[i]
            const 进入主页 = 点击后检测(单个用户, douyin.搜索页_搜索结果标签, [douyin.主页_我_页面, douyin.用户作品主页])
            if (进入主页 === -1 || 进入主页 === -100){ continue }
            if (进入主页 === 1){
                const 简介信息 = douyin.dy_获取用户主页_简介信息()
                const 用户主页截图 = 区域截图base64(0,0, ScreenWidth, ScreenHeight)
                const 用户_昵称_id = douyin.dy_节点获取抖音ID();
                if (用户_昵称_id){
                    const 上传评论数据 = {
                        "customer_name": 用户_昵称_id.用户昵称,
                        "customer_id": 用户_昵称_id.抖音ID,
                        "customer_ip_location":"",
                        "customer_homepage_img": 用户主页截图,
                        "customer_other_information": 简介信息,
                        "key_word": 脚本运行配置.dy.keyword_name.keyword,
                        "ocr_customer_id": 单个用户.name,
                        "account_type": "抖音",
                        "belong_uid": uid,
                        "account_id": 抖音_获取当前账号的抖音ID(),
                    }
                    api_昵称检索插入用户(上传评论数据)
                }
            }
            douyin.dy_用户主页_返回搜索页()
        }

        if (!用户搜索页判断()) { return }
        douyin.dy_搜索页用户列表上滑()
        iSleep(2000)
        let 滑动后截图 = 区域截图base64(160, 400, 550, ScreenHeight)
        if(滑动后截图 === 滑动前截图){
            重复次数--
        }else {
            重复次数 = 3
        }
        滑动前截图 = 滑动后截图
        if(重复次数 <= 0){
            api_更新昵称关键词状态(douyin.关键词已无用户.katid)
            douyin.关键词已无用户 = null
            return;
        }
    }
}
