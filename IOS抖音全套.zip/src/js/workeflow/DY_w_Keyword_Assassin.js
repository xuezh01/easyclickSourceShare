
function 抖音关键词检索刺客工作流(启动时间) {
    logd("启动刺客工作流1")
    if(设备账号信息.dy.length === 0){
        douyin.dy_账号统计_切换_初始化()
    }
    脚本当前运行阶段 = `抖音私信：【关键词刺客流程】`
    上次私信时间 = null
    while (!douyin.关键词已无视频){
        if(isScriptExit()){break}
        if (!脚本运行配置.app_type.includes('抖音')){ return }
        if (脚本运行配置.dy.task !== '刺客流任务'){ return }
        if (!抖音_刺客时间()){ return }
        const 请求关键词 = api_获取检索关键词('抖音',抖音_获取当前账号的抖音ID())
        if(!请求关键词){
            脚本当前运行阶段 =`【抖音】【${脚本运行配置.dy.assassin_process.keyword}】该关键词无更多视频,请重新分配关键词！`
            iSleep(20000)
        }else {
            douyin.关键词已无视频 = 请求关键词
            脚本运行配置.dy.assassin_process.keyword = 请求关键词.key_word
            break
        }
    }
    douyin.初始化()
    日志打印_error("初始化完成，开始执行【用户消息查看】")
    if (!douyin.dy_首页导航_切换(1)) {
        douyin.dy_启动抖音()
        return
    }
    // 插入关键词搜索记录
    // const keywordSid = 插入无人值守关键词搜索记录(device_script_task.data.keywordsSearch.keywords,
    //     device_script_task.data.keywordsSearch.city, device_script_task.data.keywordsSearch.releaseTime, device_id);
    // if (!douyin.dy_首页导航_切换(1)) {
    //     douyin.dy_启动抖音()
    //
    douyin.dy_跟进客户()


    // while (!脚本运行配置.dy.assassin_process.keyword){
    //     脚本运行配置.dy.assassin_process.keyword = api_获取检索关键词('抖音',抖音_获取当前账号的抖音ID())
    //     iSleep(5000)
    // }

    logd("运行流程:{}",JSON.stringify(脚本运行配置))
    脚本当前运行阶段 = `抖音关键词检索刺客流程：【${脚本运行配置.dy.assassin_process.keyword}】`
    if (!douyin.dy_首页搜索按钮点击(脚本运行配置.dy.search_time_interval)) { return }
    if (!douyin.dy_搜索页面输入查询(脚本运行配置.dy.assassin_process.keyword)) { return }
    if (!douyin.dy_搜索结果分类选项选择('视频')) { return }
    if (douyin.dy_搜索结果频繁_检测()){ return }
    if (!douyin.dy_视频筛选(
        脚本运行配置.dy.assassin_process.screening_condition.video_sort_by,
        脚本运行配置.dy.assassin_process.screening_condition.video_release_time,
        脚本运行配置.dy.assassin_process.screening_condition.video_duration,
        脚本运行配置.dy.assassin_process.screening_condition.video_search_scope)) { return }
    if (!douyin.dy_搜索结果的视频点击()) { return }
    日志打印_error("视频搜索完成，开始执行【视频判断】")
    // 进入视频轮询查看阶段
    while (true){
        if (isScriptExit()) { return }
        if (!douyin.关键词已无视频) { return }
        if (!douyin.dy_搜索视频_播放页面判断()) { return }
        const 视频信息 = douyin.dy_视频信息采集()
        if (!视频信息 || 视频信息.评论数量 <= 0 || 视频信息.name.trim() === ''){
            douyin.dy_视频信息采集_后回到视频播放页面()
            douyin.dy_上滑切换视频()
            continue
        }
        日志打印_error("视频信息获取完成，开始执行【视频判断】")
        const 上传视频信息 = {
            "belong_device_id": device_id,
            "account_id": 抖音_获取当前账号的抖音ID(),
            "account_type": "抖音",
            "belong_uid": uid,
            "video_keyword": 脚本运行配置.dy.assassin_process.keyword,
            "video_up_id": 视频信息.抖音ID,
            "video_up_name": 视频信息.作者,
            "video_type":  视频信息.类型,
            "video_comment_count": 视频信息.评论数量,
            "video_title": 视频信息.name,
            "video_up_homepage": 视频信息.homepage,
            "video_up_information": "",
        }
        const 视频指令 = api_获取视频是否已观看(上传视频信息)

        // if (!视频指令.leave_traces){
        //     if (device_script_task.keywordsSearch.comment && device_script_task.keywordsSearch.comment !== ''){
        //         if (!douyin.dy_评论区留痕(device_script_task.keywordsSearch.comment)) { return }
        //         const 留痕记录 = {
        //             "video_sid": parseInt(视频指令.video_sid),
        //             "account_id": 获取当前账号的抖音ID(),
        //         }
        //         api_记录视频留痕(留痕记录)
        //     }
        // }

        if (!视频指令.video_sid){
            douyin.dy_视频信息采集_后回到视频播放页面()
            douyin.dy_上滑切换视频()
            continue
        }
        // if (!视频指令.catch){
        //     if (!douyin.dy_视频信息采集_后回到视频播放页面()) {
        //         const 视频内容2 = douyin.dy_获取视频标题('视频播放判断');
        //         if(字符串相似度计算(视频内容, 视频内容2) < 0.6){ return }
        //     }
        //     douyin.dy_上滑切换视频()
        //     continue
        // }
        if (!视频信息.name.includes(脚本运行配置.dy.assassin_process.keyword)){
            const params = {
                "videoContent": 视频信息.name,
                "hangye":  脚本运行配置.dy.assassin_process.industry,
                "keyword": 脚本运行配置.dy.assassin_process.keyword,
                "up_name": 视频信息.作者,
                "account_type": "抖音",
            }
            const 视频判断结果 = api_判断视频精准度(uid,'抖音',视频信息.作者,脚本运行配置.dy.assassin_process.keyword, 视频信息.name)
            if (视频指令.video_sid && 视频指令.video_sid !== null){
                const 视频判断结果记录 = {
                    "video_sid": parseInt(视频指令.video_sid),
                    "accuracy": String(视频判断结果),
                    "account_type": "抖音",
                }
                api_记录视频精准度(视频判断结果记录)
            }
            日志打印_error("视频判断完成，开始执行【视频判断】")

            if (!视频判断结果){
                douyin.dy_视频信息采集_后回到视频播放页面()
                douyin.dy_上滑切换视频()
                continue
            }
        }
        else {
            if (视频指令.video_sid && 视频指令.video_sid !== null){
                const 视频判断结果记录 = {
                    "video_sid": parseInt(视频指令.video_sid),
                    "accuracy": '包含关键词，不判断',
                    "account_type": "抖音",
                }
                api_记录视频精准度(视频判断结果记录)
            }
        }

        if (!douyin.dy_评论区刺客(脚本运行配置.dy.assassin_process.keyword, parseInt(视频指令.video_sid),视频信息.name)){
            if(!douyin.dy_搜索视频_播放页面判断()){
                logd("不在视频页面")
                iSleep(5000)
                return;
            }
        }
        if ((启动时间 && (启动时间 - time()) > (15*60*1000))){
            douyin.dy_刺客回到首页_检测消息()
            return;
        }
        if(!抖音_刺客时间()){logd("抖音_关键词检索是否可以发私信:发不了"); return;}

        douyin.dy_视频信息采集_后回到视频播放页面()
        douyin.dy_上滑切换视频()
    }
}

DouYin.prototype.dy_评论区刺客 = function (keywords, videoSid,videoContent){
    当前执行模块 = 'dy_评论区刺客';
    日志打印_debug('开始执行 - 【dy_评论区刺客】')

    function 评论区判断() {

        const 判断 = findColor(douyin.评论页面艾特标识)
        if(判断){
            logw(JSON.stringify(判断))
            return true
        }



        let 打开键盘 = ocr文本数组匹配(ios.键盘弹出)
        while (打开键盘){
            if(isScriptExit()){ break }
            const 关闭_弹出键盘 = {name: '【dy_评论区抓取】关闭_弹出键盘', x: random(140, 568), y: random(292, 418)};
            点击(关闭_弹出键盘)
            iSleep(400)
            打开键盘 = ocr文本数组匹配(ios.键盘弹出)
            if(!打开键盘){
                return 评论区判断()
            }
        }

        const 评论区_title = ocr文本数组匹配(douyin.评论区_title);
        if(评论区_title) { return true }

        let 账号已注销 = ocr文本数组匹配(douyin.用户账号已注销);
        while (账号已注销){
            if(isScriptExit()){ break }
            点击(douyin.用户主页_返回按钮)
            iSleep(400)
            账号已注销 = ocr文本数组匹配(douyin.用户账号已注销);
            if(!账号已注销){
                return 评论区判断()
            }
        }

        let 用户作品主页 = ocr文本数组匹配(douyin.用户作品主页);
        while (用户作品主页){
            if(isScriptExit()){ break }
            点击(douyin.用户主页_返回按钮)
            iSleep(400)
            用户作品主页 = ocr文本数组匹配(douyin.用户作品主页)
            if(!用户作品主页){
                return 评论区判断()
            }
        }

        let 主页_我_页面 = ocr文本数组匹配(douyin.主页_我_页面);
        while (主页_我_页面){
            if(isScriptExit()){ break }
            点击(douyin.用户主页_返回按钮)
            iSleep(400)
            主页_我_页面 = ocr文本数组匹配(douyin.主页_我_页面);
            if(!主页_我_页面){
                return 评论区判断()
            }
        }

        let 评论区_图片查看 = ocr文本数组匹配(douyin.评论区_图片查看);
        while (评论区_图片查看){
            if(isScriptExit()){ break }
            点击(douyin.用户主页_返回按钮)
            iSleep(400)
            评论区_图片查看 = ocr文本数组匹配(douyin.评论区_图片查看);
            if(!评论区_图片查看){
                return 评论区判断()
            }
        }
        let 视频评论区_误触内容 = ocr文本数组匹配(douyin.视频评论区_误触内容);
        while (视频评论区_误触内容){
            if(isScriptExit()){ break }
            const 关闭误触的点位 = {name: '【dy_评论区抓取】关闭 视频评论区_误触内容', x: random(250, 520), y: random(100, 200)};
            点击(关闭误触的点位)
            iSleep(400)
            视频评论区_误触内容 = ocr文本数组匹配(douyin.视频评论区_误触内容);
            if(!视频评论区_误触内容){
                return 评论区判断()
            }
        }

        let 评论区_发送图片误触 = ocr文本数组匹配(douyin.评论区_发送图片误触返回)
        while (评论区_发送图片误触){
            if (isScriptExit()){return }
            let 评论区_发送图片误触返回 = {name:'【dy_评论区抓取】关闭 评论区_发送图片误触',x:random(42,70),y:random(80,105)}
            点击(评论区_发送图片误触返回)
            iSleep(400)
            评论区_发送图片误触 = ocr文本数组匹配(douyin.视频评论区_误触内容);
            if(!评论区_发送图片误触){
                return 评论区判断()
            }
        }

        return false
    }

    const 评论区放大按钮 = findColor(douyin.视频播放页面的评论区放大按钮)
    if (评论区放大按钮){
        点击(评论区放大按钮)
    }

    let 评论区顶部 = 100;
    let 评论区底部 = 1222;
    let 是否结束评论区获取 = false;
    let 最后一条评论底部 = null

    日志打印_error("视频判断完成，开始执行【评论区获取】")
    if (!评论区判断()){return }
    setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
    let 评论数量节点 =  type("StaticText").labelMatch(".*评论.*").getOneNodeInfo(10000)
    let tryCount = 3;
    while (!评论数量节点 && tryCount>0){
        if(isScriptExit()){break}
        iSleep(100);
        const 还在预期页面 = findColor(douyin.评论页面艾特标识);
        if(还在预期页面){
            评论数量节点 = type("StaticText").labelMatch(".*评论.*").getOneNodeInfo(10000)
        }
        tryCount--
    }
    if(评论数量节点 && 评论数量节点.bounds.bottom > 100 && 评论数量节点.bounds.bottom < 500){
        评论区顶部 = 评论数量节点.bounds.bottom;
    }

    日志打印_debug(`【dy_评论区抓取】评论区范围为 top：${评论区顶部}  bottom：${评论区底部}`)

    function 获取评论的点踩爱心图标(y, ey) {
        const 更新点踩爱心按钮范围 = JSON.parse(JSON.stringify(douyin.视频播放页面的评论区点踩爱心图标));
        更新点踩爱心按钮范围.y = y;
        更新点踩爱心按钮范围.ey = ey;
        return findColor(更新点踩爱心按钮范围)
    }

    function 获取ip地址(str) {
        const match = str.trim().match(/[\u4e00-\u9fa5]+$/); // 匹配末尾的连续中文字符
        return match ? match[0] : ''; // 如果有匹配的中文字符，返回，否则返回空字符串
    }

    function 范围评论处理(范围评论内容) {
        if(!范围评论内容 || 范围评论内容.length === 0 || 范围评论内容.length === 1){
            return null
        }
        范围评论内容.sort((a, b) => {
            return a.y - b.y;
        });
        if(范围评论内容.length > 3 && (范围评论内容[0].x - 范围评论内容[1].x) > 20){
            范围评论内容.splice(0, 1)
        }
        //排除里面的无效文本
        const 第一次筛选后评论内容 = 范围评论内容.filter((单行文本) => {
            return!(单行文本.label.includes('收起') || 单行文本.label.includes('作者回复过')
                || 单行文本.label.includes('作者赞过') || 单行文本.label === '' || 单行文本.x > 400
                || 单行文本.label.includes('评论氛围是否满意') || 单行文本.label.includes('条回复')
                || 单行文本.label.startsWith('展开')|| (单行文本.label.includes('不满意')  && 单行文本.label.includes('一般'))
                || (单行文本.label.startsWith('展开') || 单行文本.label.startsWith('展廾')
                    || 单行文本.label.startsWith('一 展开') || 单行文本.label.startsWith('一 展廾')
                    || 单行文本.label.startsWith('— 展开') || 单行文本.label.startsWith('—展开')
                    || 单行文本.label.startsWith('一展廾')) && (单行文本.label.endsWith('凹复V') || 单行文本.label.endsWith('回复丷')
                    || 单行文本.label.endsWith('回复') || 单行文本.label.endsWith('回复V')
                    || 单行文本.label.endsWith('回复 V')));

        });

        let ip = ''
        function 找到评论时间并格式化(arr) {
            arr.sort((a, b) => {
                if (Math.abs(a.y - b.y) <= 5) {
                    return a.x - b.x;
                } else {
                    return a.y - b.y;
                }
            });
            let indexOfReply = -1;
            for (let i = arr.length - 1; i >= 0; i--) {
                if (arr[i].label.includes('回复')) {
                    indexOfReply = i;
                    break;
                }
            }
            if (indexOfReply !== -1) {
                const new_arr = arr.slice(0, indexOfReply + 1);
                new_arr[new_arr.length-1].label = new_arr[new_arr.length-1].label.replace('回复', '')
                var 评论时间 = 时间格式化(new_arr[new_arr.length-1].label);
                // 日志打印_warning(new_arr[new_arr.length-1].label+ '  评论时间1: ' + 评论时间)
                if(评论时间 && 评论时间 !== '2024-08-01'){
                    ip = 获取ip地址(new_arr[new_arr.length-1].label)
                    new_arr[new_arr.length-1].label = 评论时间;
                    return new_arr;
                }
                else if(new_arr.length > 1){
                    var 评论时间 = 时间格式化(new_arr[new_arr.length-2].label);
                    日志打印_warning(new_arr[new_arr.length-2].label + '  评论时间2: ' + 评论时间)
                    if(评论时间){
                        ip = 获取ip地址(new_arr[new_arr.length-2].label)
                        new_arr[new_arr.length-2].label = 评论时间;
                        const new_arr_2 = new_arr.slice(0, new_arr.length-1);
                        return new_arr_2;
                    }
                }
            }
            return null;
        }

        const 筛选后评论内容 = 找到评论时间并格式化(第一次筛选后评论内容);
        日志打印_debug('筛选后评论内容: '+JSON.stringify(筛选后评论内容))
        logd('ip3: '+ ip)

        if(!筛选后评论内容 || 筛选后评论内容.length < 2 || 筛选后评论内容[0].label.endsWith('作者')
            || 筛选后评论内容[0].label.endsWith('互相关注') || 筛选后评论内容[0].label.endsWith('你的关注')){
            return null
        }
        if(筛选后评论内容[筛选后评论内容.length-1].y - 筛选后评论内容[0].y - 筛选后评论内容[0].height < 30){
            return null
        }
        if(筛选后评论内容[0].width > 551){
            return null
        }
        let 头像_x = 66;
        if(筛选后评论内容[筛选后评论内容.length-1].x > 50){
            头像_x = 138;
        }

        const 用户评论信息 = {name: 筛选后评论内容[0].label, 评论内容: null, 评论时间: 筛选后评论内容[筛选后评论内容.length-1].label,
            x: 头像_x, y: 筛选后评论内容[0].y+筛选后评论内容[0].height/2+评论区顶部}
        if(筛选后评论内容.length === 2){
            用户评论信息.评论内容 = '[该用户回复的为表情或者图片消息]'
            logi(筛选后评论内容[筛选后评论内容.length-1].y-筛选后评论内容[0].y)
        }
        else {
            用户评论信息.评论内容 = 筛选后评论内容.slice(1, -1).map(单行文本 => 单行文本.label).join('');
        }
        用户评论信息.ip = ip
        // 日志打印_debug('用户评论信息: ' + JSON.stringify(用户评论信息))
        return 用户评论信息
    }

    // function 评论区判断() {
    //
    //     const 判断 = findMultiColor([douyin.商家店铺左尖括号返回按钮, douyin.左上角返回按钮,douyin.用户账号已注销,
    //         douyin.视频播放页面的评论区放大按钮,douyin.视频播放页面的评论区缩小按钮_被遮罩,douyin.视频播放页面的评论区缩小按钮,
    //         douyin.视频播放页面的评论区点踩爱心图标, douyin.视频播放页面的评论区关闭按钮])
    //     if(判断){
    //         logw(JSON.stringify(判断))
    //         const index = 判断.index
    //         switch (index) {
    //             case 0:
    //                 let 商家店铺左尖括号返回按钮 = 判断.point
    //                 while (true){
    //                     if(isScriptExit()){ break }
    //                     点击(商家店铺左尖括号返回按钮)
    //                     iSleep(400)
    //                     商家店铺左尖括号返回按钮 = findColor(douyin.商家店铺左尖括号返回按钮)
    //                     if(!商家店铺左尖括号返回按钮){
    //                         return 评论区判断()
    //                     }
    //                 }
    //             case 1:
    //                 let 左上角返回按钮 = 判断.point
    //                 while (true){
    //                     if(isScriptExit()){ break }
    //                     点击(左上角返回按钮)
    //                     iSleep(400)
    //                     const 用户账号已注销 = findColor(douyin.用户账号已注销)
    //                     if(!用户账号已注销){
    //                         return 评论区判断()
    //                     }
    //                 }
    //             case 2:
    //                 while (true){
    //                     if(isScriptExit()){ break }
    //                     点击(douyin.用户主页_返回按钮)
    //                     iSleep(400)
    //                     左上角返回按钮 = findColor(douyin.左上角返回按钮)
    //                     if(!左上角返回按钮){
    //                         return 评论区判断()
    //                     }
    //                 }
    //
    //             case 3:
    //                 let 视频播放页面的评论区放大按钮 = 判断.point
    //                 while (true){
    //                     if(isScriptExit()){ break }
    //                     点击(视频播放页面的评论区放大按钮)
    //                     iSleep(400)
    //                     视频播放页面的评论区放大按钮 = findColor(douyin.视频播放页面的评论区放大按钮)
    //                     if(!视频播放页面的评论区放大按钮){
    //                         return 评论区判断()
    //                     }
    //                 }
    //             case 4:
    //                 let 视频播放页面的评论区缩小按钮_被遮罩 = 判断.point
    //                 while (true){
    //                     if(isScriptExit()){ break }
    //                     点击(视频播放页面的评论区缩小按钮_被遮罩)
    //                     iSleep(400)
    //                     视频播放页面的评论区缩小按钮_被遮罩 = findColor(douyin.视频播放页面的评论区缩小按钮_被遮罩)
    //                     if(!视频播放页面的评论区缩小按钮_被遮罩){
    //                         return 评论区判断()
    //                     }
    //                 }
    //         }
    //         return true
    //     }
    //
    //
    //     let 打开键盘 = ocr文本数组匹配(ios.键盘弹出)
    //     while (打开键盘){
    //         if(isScriptExit()){ break }
    //         const 关闭_弹出键盘 = {name: '【dy_评论区抓取】关闭_弹出键盘', x: random(140, 568), y: random(292, 418)};
    //         点击(关闭_弹出键盘)
    //         iSleep(400)
    //         打开键盘 = ocr文本数组匹配(ios.键盘弹出)
    //
    //         if(!打开键盘){
    //             return 评论区判断()
    //         }
    //     }
    //     const 评论区_title = ocr文本数组匹配(douyin.评论区_title);
    //     if(评论区_title) { return true }
    //
    //     let 用户作品主页 = ocr文本数组匹配(douyin.用户作品主页);
    //     while (用户作品主页){
    //         if(isScriptExit()){ break }
    //         点击(douyin.用户主页_返回按钮)
    //         iSleep(400)
    //         用户作品主页 = ocr文本数组匹配(douyin.用户作品主页)
    //         if(!用户作品主页){
    //             return 评论区判断()
    //         }
    //     }
    //
    //     let 主页_我_页面 = ocr文本数组匹配(douyin.主页_我_页面);
    //     while (主页_我_页面){
    //         if(isScriptExit()){ break }
    //         点击(douyin.用户主页_返回按钮)
    //         iSleep(400)
    //         主页_我_页面 = ocr文本数组匹配(douyin.主页_我_页面);
    //         if(!主页_我_页面){
    //             return 评论区判断()
    //         }
    //     }
    //
    //     let 评论区_图片查看 = ocr文本数组匹配(douyin.评论区_图片查看);
    //     while (评论区_图片查看){
    //         if(isScriptExit()){ break }
    //         点击(douyin.用户主页_返回按钮)
    //         iSleep(400)
    //         评论区_图片查看 = ocr文本数组匹配(douyin.评论区_图片查看);
    //         if(!评论区_图片查看){
    //             return 评论区判断()
    //         }
    //     }
    //     let 视频评论区_误触内容 = ocr文本数组匹配(douyin.视频评论区_误触内容);
    //     while (视频评论区_误触内容){
    //         if(isScriptExit()){ break }
    //         const 关闭误触的点位 = {name: '【dy_评论区抓取】关闭 视频评论区_误触内容', x: random(250, 520), y: random(100, 200)};
    //         点击(关闭误触的点位)
    //         iSleep(400)
    //         视频评论区_误触内容 = ocr文本数组匹配(douyin.视频评论区_误触内容);
    //         if(!视频评论区_误触内容){
    //             return 评论区判断()
    //         }
    //     }
    //
    //     return false
    // }


    const 已经获取抖音ID的用户 = []
    let 左侧头像切割 = 100
    while (!是否结束评论区获取){
        if(isScriptExit()){ break }
        const 页面所有文字内容 = ocr范围识别(左侧头像切割, 评论区顶部, ScreenWidth, 评论区底部)
        if(!页面所有文字内容){
            日志打印_error('【dy_评论区抓取】 页面评论内容 获取失败， 正在重新获取！ ');
            iSleep(200)
            continue
        }

        页面所有文字内容.sort((a, b) => {
            // 首先按照y值进行排序
            if (Math.abs(a.y - b.y) <= 5) {
                // 如果y值差不超过5，则按照x值排序
                return a.x - b.x;
            } else {
                // 否则按照y值排序
                return a.y - b.y;
            }
        });

        const 点踩爱心图标top = 评论区顶部;
        let 上一个爱心图标 = null;
        const 用户列表 = [];
        const 评论区切片索引 = [];
        let 上传评论数据 = null
        let 当前发送抖音ID = null
        for (let i = 0; i < 页面所有文字内容.length; i++) {
            if (isScriptExit()) { return }
            const 单列文字内容 = 页面所有文字内容[i];
            日志打印_debug(JSON.stringify(单列文字内容))
            if (单列文字内容.label.includes('暂时没有更多了')  || 单列文字内容.label.startsWith('已折叠') || 单列文字内容.label.startsWith('哲时没有更多了') || 单列文字内容.label.endsWith('没有更多了')) {
                // 评论页面内容已经获取完了
                日志打印_debug(`【dy_评论区抓取】已到达评论区底部 ：${单列文字内容.label} `)
                是否结束评论区获取 = true;
            }
            if (单列文字内容.label.includes('回复')) {
                /*  用 【回复】 分割用户的评论内容 */
                const 点踩爱心图标bottom = 单列文字内容.y + 单列文字内容.height + 40 + 评论区顶部;
                const 点赞爱心图标 = 获取评论的点踩爱心图标(点踩爱心图标top, 点踩爱心图标bottom);
                if (点赞爱心图标) {
                    最后一条评论底部 = 单列文字内容
                    if(!上一个爱心图标){
                        评论区切片索引.push({index: i, top: 评论区顶部})
                    }
                    else {
                        评论区切片索引.push({index: i, top: 上一个爱心图标.max_y})
                    }
                    上一个爱心图标 = JSON.parse(JSON.stringify(点赞爱心图标));
                }else {
                    日志打印_debug(`点赞爱心图标 未找到：${单列文字内容.label}`)
                }
            }
        }

        let startIndex = {index: 0, top: 评论区顶部};
        for (let index_ of 评论区切片索引) {
            let 范围评论 = null;
            if(startIndex.index === 0){
                范围评论 = 页面所有文字内容.slice(0, index_.index+1);
            }else {
                范围评论 = 页面所有文字内容.slice(startIndex.index+1, index_.index+1);
            }
            startIndex = JSON.parse(JSON.stringify(index_));
            日志打印_debug('提交筛选：' + JSON.stringify(范围评论))
            const 用户信息 = 范围评论处理(范围评论);
            if(用户信息){
                用户列表.push(用户信息)
            }
        }
        日志打印_debug('提交筛选：' + JSON.stringify(页面所有文字内容.slice(startIndex.index+1)))
        const 用户信息 = 范围评论处理(页面所有文字内容.slice(startIndex.index+1))
        if(用户信息){
            用户列表.push(用户信息)
        }
        const 评论区截图 = 区域截图base64(150, 150, 600, 1000);
        let 评论区变动_重新抓取 = false;


        日志打印_error("评论区处理完成，开始执行【评论区抓取】")

        for(const i in 用户列表){
            if(isScriptExit()) { break }
            if(!评论区判断()){ return }
            const 评论区用户 = 用户列表[i];
            日志打印_information('评论区用户： '+ JSON.stringify(评论区用户))
            const 进入评论用户主页 = 点击后检测(评论区用户, douyin.视频播放页面的评论区缩小按钮, [douyin.用户作品主页, ios.键盘弹出, douyin.用户账号已注销, douyin.主页_我_页面], 500);

            if (进入评论用户主页 === 0){
                let 简介 = douyin.dy_节点获取用户简介()
                const 用户_昵称_id = douyin.dy_节点获取抖音ID();
                if (用户_昵称_id){
                    当前发送抖音ID = 用户_昵称_id.抖音ID
                    if(!已经获取抖音ID的用户.includes(当前发送抖音ID) ){
                        上传评论数据 = {
                            "video_sid": videoSid,
                            "belong_account_id": uid,
                            "account_type": '抖音',
                            "customer_name": 用户_昵称_id.用户昵称,
                            "customer_id":用户_昵称_id.抖音ID,
                            "customer_comment_time": 评论区用户.评论时间,
                            "customer_ip_location": 评论区用户.ip,
                            "customer_comment": 评论区用户.评论内容,
                            "customer_homepage_img": '',
                            "customer_other_information": 简介,
                        }
                        已经获取抖音ID的用户.push(用户_昵称_id.抖音ID)
                        logd("上传评论数据:{}",JSON.stringify(上传评论数据))
                    }
                }
                日志打印_error("评论区抓取完成，开始执行【用户精准度判断】,评论时间:{}",评论区用户.评论时间)
                if (isToday(评论区用户.评论时间)){
                    logd("满足时间：{}", 用户_昵称_id.用户昵称)
                    let 私信结果 = douyin.dy_刺客_是否私信(videoSid,videoContent,评论区用户,用户_昵称_id,简介)
                    if (私信结果 === -1 || 私信结果 === -2){
                        return
                    }
                }else {
                    logd("上传评论数据:{}",JSON.stringify(上传评论数据))
                    if (上传评论数据){
                        api_插入视频评论用户(上传评论数据)
                    }
                }
                日志打印_error("单用户获取完成，开始执行【用户主页返回评论区】")
                const 返回评论页面 = 点击后检测(douyin.用户主页_返回按钮, douyin.用户作品主页, [douyin.评论页面艾特标识, douyin.视频播放页面的评论区关闭按钮, douyin.视频播放页面的评论区点踩爱心图标,douyin.用户作品主页]);
                logd("用户主页返回评论区结果:{}",返回评论页面)
                switch (返回评论页面) {
                    case -100:
                        return
                    case -1:
                        return
                    case 0:
                        break
                    case 1:
                        break
                    case 2:
                        break
                    case 3:
                        break
                }
                const 点击后_评论区截图 = 区域截图base64(150, 150, 600, 1000);
                if(点击后_评论区截图 !== 评论区截图){
                    日志打印_debug('评论区变动_重新抓取')
                    评论区变动_重新抓取 = true;
                    break
                }
            }
            if(!评论区判断()){ return }
            if(是否结束评论区获取) { break }
        }
        if(评论区变动_重新抓取){ continue }
        if (抖音_刺客时间()) { return -1}
        if (抖音_查询今日私信是否饱和()) { return -2}

        const bg_hd = time()
        const startX = random(10,20);
        const endX = random(10,20);
        let startY = 最后一条评论底部.y+ 最后一条评论底部.height+10+评论区顶部;
        let endY = 评论区顶部;

        日志打印_debug('【dy_评论区抓取】开始执行 评论区滑动')
        const 滑动检测 = 滑动误触检测([douyin.视频评论区_误触内容], startX, startY, endX, endY, 500, 2000);
        switch (滑动检测) {
            case 100:
                日志打印_debug('【dy_评论区抓取】评论区滑动 成功');
                break;
            case 0:
                const 关闭误触的点位 = {name: '【dy_评论区抓取】关闭 视频评论区_误触内容', x: random(250, 520), y: random(100, 200)};
                const 关闭误触的点位_结果 = 点击后检测(关闭误触的点位, douyin.视频评论区_误触内容, [douyin.视频播放页面的评论区缩小按钮]);
                if(关闭误触的点位_结果 === -1){
                    日志打印_error('关闭误触的点位_结果  失败！');
                    return
                }
                break;
        }
        日志打印_error("单用户抓取后评论区处理完成，开始执行【继续执行评论区抓取】")
        日志打印_warning('滑动耗时： '+ (time()-bg_hd))
        const 滑动后_评论区截图 = 区域截图base64(150, 150, 600, 1000);
        if(滑动后_评论区截图 === 评论区截图){
            break
        }
    }
    日志打印_debug(`【dy_评论区抓取】已结束抓取  `)
    return true
}

//返回-1 未知错误重启  -2私信频繁 1正常 -123不是当天用户
DouYin.prototype.dy_刺客_是否私信 = function (videoSid,videoContent,评论区用户,用户_昵称_id,简介) {
    // if (!isToday(评论时间)){
    //     logd("用户评论时间不满足：{}",评论区用户.评论时间)
    //     return -123
    // }
    const 当前发送抖音ID = 用户_昵称_id.抖音ID
    const user_data = {
        "video_sid": videoSid,
        "uid": uid,
        "account_type": "抖音",
        "video_title": videoContent,
        "home_info":简介,
        "belong_account_id": uid,
        "customer_name": 用户_昵称_id.用户昵称,
        "customer_id":用户_昵称_id.抖音ID,
        "customer_comment_time": 评论区用户.time,
        "customer_ip_location": 评论区用户.ip,
        "customer_comment": 评论区用户.content,
        "customer_homepage_img": '',
    }
    const 刺客流程筛选结果 = dy_刺客流程_用户筛选(user_data)
    if (刺客流程筛选结果 && 刺客流程筛选结果.精准度){
        if (上次私信时间){
            while ((上次私信时间 - time())/(60*1000)<脚本运行配置.dy.search_time_interval){
                if (isScriptExit()){return }
                iSleep(5000)
            }
        }

        const first_msg = api_获取私信话术('抖音', uid)
        脚本运行配置.dy.follow_up.send_msg.first_msg = first_msg
        脚本运行配置.dy.assassin_process.send_msg.first_msg = first_msg



        if (!douyin.dy_用户作品_进入用户私信页面()) { return -1}


        if (douyin.dy_检测私信频繁() || douyin.dy_检测私信发送未成功()){
            douyin.私信已发送列表.push(当前发送抖音ID)
            api_记录账号今日已私信数据(刺客流程筛选结果.aaci_atid, 当前发送抖音ID,2)
            douyin.搜索时间 = time() - 脚本运行配置.dy.search_time_interval*60*1000
            if (!douyin.dy_退出私信页面_返回用户主页()) { return -1}
            const 返回评论页面 = 点击后检测(douyin.用户主页_返回按钮, douyin.用户作品主页, [douyin.视频播放页面的评论区缩小按钮, douyin.视频播放页面的评论区关闭按钮, douyin.视频播放页面的评论区点踩爱心图标,douyin.用户作品主页]);
            switch (返回评论页面) {
                case -100:
                    return -1
                case -1:
                    return -1
                case 0:
                    break
                case 1:
                    break
                case 2:
                    break
                case 3:
                    break
            }
            return 1
        };

        const 聊天记录 = douyin.dy_节点_获取聊天记录();
        let 执行发送私信 = true
        if (聊天记录 && 聊天记录 !== ''){
            const 聊天记录Array = 聊天记录.split('\n')
            for(let ii in 聊天记录Array){
                if(isScriptExit()){break}
                if(聊天记录Array[ii].startsWith('我:')){
                    执行发送私信 = false
                    break
                }
            }
        }
        if(!执行发送私信){
            api_记录账号今日已私信数据(刺客流程筛选结果.aaci_atid, 当前发送抖音ID,2)
            douyin.私信已发送列表.push(当前发送抖音ID)
        }else {
            日志打印_error("用户判断完成，精准用户，开始执行【用户私信】")
            douyin.dy_发送私信(脚本运行配置.dy.assassin_process.send_msg.first_msg, 脚本运行配置.dy.assassin_process.send_msg.follow_probability)
            上次私信时间 = time()
            // douyin.dy_发送私信("你好，最近有关注小黄鱼吗？", )
            api_记录账号今日已私信数据(刺客流程筛选结果.aaci_atid, 当前发送抖音ID,1)
            douyin.私信已发送列表.push(当前发送抖音ID)
            const 私信未成功 = douyin.dy_检测私信发送未成功();
            const 私信频繁 = douyin.dy_检测私信频繁()
            抖音_私信统计更新(私信未成功, 私信频繁)
            if (私信频繁) {
                if(抖音_可切换私信账号){
                    douyin.dy_账号统计_切换_初始化()
                    return -2
                }else {
                    脚本运行配置.dy.search_time_interval = 8
                }
            }
        }
        if (!douyin.dy_退出私信页面_返回用户主页()) { return -1}
        日志打印_error("精准用户私信完成，开始执行【评论区抓取】")
    }
    return 1
}

DouYin.prototype.dy_刺客回到首页_检测消息 = function () {
    当前执行模块 = "刺客流程-回到首页_检测消息"
    let 页面检测 = douyin.dy_当前页面检测()
    let 是否回到首页 = false
    if (页面检测 === 1){
        let 返回主页 = {name:'综合页面_返回搜索按钮',x:random(42,58),y:random(67,98)}
        let 点击结果 = 点击后检测(返回主页,douyin.搜索页面的搜索按钮,[ios.键盘弹出])
        if (点击结果 === 0){
            返回主页 = {name:'搜索按钮_返回主页',x:random(42,58),y:random(67,98)}
            点击结果 = 点击后检测(返回主页,douyin.搜索页面的搜索按钮,[douyin.视频播放页_关注按钮])
            if (点击结果 === 0){
                是否回到首页 = true
            }
        }
    }else if (页面检测 === 2){
        let 返回主页 = {name:'搜索按钮_返回主页',x:random(42,58),y:random(67,98)}
        let 点击结果 = 点击后检测(返回主页,douyin.搜索页面的搜索按钮,[douyin.视频播放页_关注按钮])
        if (点击结果 === 0){
            是否回到首页 = true
        }
    }else if (页面检测 === 3){
        let 用户主页_返回综合页面按钮 = {name:'用户主页_返回综合页面按钮',x:random(36,50),y:random(65,100)}
        let 点击结果 = 点击后检测(用户主页_返回综合页面按钮,douyin.视频播放页_关注按钮,[douyin.搜索页面的搜索按钮])
        if (点击结果 === 0){
            let 返回主页 = {name:'综合页面_返回搜索按钮',x:random(42,58),y:random(67,98)}
            点击结果 = 点击后检测(返回主页,douyin.搜索页面的搜索按钮,[ios.键盘弹出])
            if (点击结果 === 0){
                返回主页 = {name:'搜索按钮_返回主页',x:random(42,58),y:random(67,98)}
                点击结果 = 点击后检测(返回主页,douyin.搜索页面的搜索按钮,[douyin.视频播放页_关注按钮])
                if (点击结果 === 0){
                    是否回到首页 = true
                }
            }
        }
    }

    if (是否回到首页){
        // douyin.dy_跟进客户(3)
        douyin.dy_首页视频养号(2)
    }

}

DouYin.prototype.dy_当前页面检测 = function () {
    let 页面判断 = douyin.dy_搜索结果分类选项选择('综合')
    if (页面判断){
        return 1
    }
    页面判断 = ocr文本不完全匹配('搜索',648,60,720,107)
    if (页面判断){
        return 2
    }

    if (findColor(douyin.视频播放页_关注按钮) && !(ocr文本不完全匹配('首页',25,1250,720,1320) || ocr文本不完全匹配('消息',25,1250,720,1320))){
        return 3
    }
    return -1
}

DouYin.prototype.dy_节点获取用户简介 = function (){
    try {
        setFetchNodeParam({"labelFilter":"1","maxDepth":"20","visibleFilter":"1","boundsFilter":"1","excludedAttributes":""})
        let nd = type("Button").labelMatch("粉丝").getOneNodeInfo(10000)
        let 重试次数 = 3
        while (!nd && 重试次数>=0){
            重试次数--
            nd = type("Button").labelMatch("粉丝").getOneNodeInfo(10000)
            iSleep(1000)
        }
        // logd("获取简介:{}",JSON.stringify(nd))
        if (!nd){
            return ''
        }
        let parent = nd.parent()
        重试次数 = 3
        while (!parent && 重试次数>=0){
            重试次数--
            parent = nd.parent()
            iSleep(1000)
        }
        if (!parent){
            return ''
        }
        // logd("获取简介:{}",JSON.stringify(parent))
        parent = parent.parent()
        重试次数 = 3
        while (!parent && 重试次数>=0){
            重试次数--
            parent = parent.parent()
            iSleep(1000)
        }
        if (!parent){
            return ''
        }
        // logd("获取简介:{}",JSON.stringify(parent))
        parent = parent.parent()
        重试次数 = 3
        while (!parent && 重试次数>=0){
            重试次数--
            parent = parent.parent()
            iSleep(1000)
        }
        if (!parent){
            return ''
        }
        // logd("获取简介:{}",JSON.stringify(parent))
        parent = parent.nextSiblings()[1]
        重试次数 = 3
        while (!parent && 重试次数>=0){
            重试次数--
            parent = parent.nextSiblings()[1]
            iSleep(1000)
        }
        if (!parent){
            return ''
        }
        // logd("获取简介:{}",JSON.stringify(parent))
        parent = parent.allChildren()[0].allChildren()[0]
        重试次数 = 3
        while (!parent && 重试次数>=0){
            重试次数--
            parent = parent.allChildren()[0].allChildren()[0]
            iSleep(1000)
        }
        if (!parent){
            return ''
        }
        // logd("获取简介:{}",JSON.stringify(parent))
        let parent_type = parent.siblings()
        重试次数 = 3
        while (!parent_type && 重试次数>=0){
            重试次数--
            parent_type = parent.siblings()
            iSleep(1000)
        }
        // logd("兄弟节点:{}",JSON.stringify(parent_type))
        if (!parent_type.length || parent_type[0].type === 'StaticText'){
            return ''
        }
        return parent.name
    }catch (e) {
        return ''
    }

}

//私信时间
function 抖音_刺客时间() {
    logd("脚本运行配置：{}",JSON.stringify(脚本运行配置))
    const [s_hours, s_minutes] = 脚本运行配置.dy.assassin_process.start_time.split(':');
    const [e_hours, e_minutes] = 脚本运行配置.dy.assassin_process.end_time.split(':');
    const start_time = new Date();
    start_time.setHours(s_hours, s_minutes, 0, 0);

    const end_time = new Date();
    end_time.setHours(e_hours, e_minutes, 0, 0);
    const now = new Date();
    let result = false
    if(start_time < end_time){
        if (start_time <= now && now < end_time){ result = true }
    }else {
        if (start_time <= now || now < end_time){ result = true }
    }
    if(result){
        日志打印_warning(` 当前是-[抖音_刺客时间] ${start_time}-${end_time}`)
    }
    return result
}

function 获取检索关键词(uid,ios_id){
    日志打印_information('开始执行 -- 【获取检索关键词】,:{},:{}',uid,ios_id)
    const start_time = time();
    const data = {
        uid: uid,
        ios_id: ios_id
    }
    const insertUrl = `http://192.168.0.127:50001/get_keywords`;
    let result = null;
    for(let i = 0; i < 3; i++) {
        if (isScriptExit()) { break }
        const r = http.postJSON(insertUrl, data, 180 * 1000, {"key-word": "test"});
        日志打印_debug(`【关键词一级筛选】: ${r}`);
        if (r) {
            try{
                const response = JSON.parse(r);
                if (response.state === 200) {
                    result = response.keywords;
                    break;
                } else {
                    日志打印_debug(`【获取检索关键词】 请求失败: ${r}`);
                }
            }catch (e) {
                日志打印_debug(`【获取检索关键词】 请求失败 catch: ${e}`);
            }
        }
        iSleep(2000,false)
    }

    if (!result){
        if (uid.includes('外汇')){
            const options = ["外汇复盘技巧", "外汇形态分析", "外汇数据解读", "外汇投资技巧", "外汇货币对选择"];
            result = options[Math.floor(Math.random() * options.length)];
        }
    }
    日志打印_warning(`【获取检索关键词】耗时: ${time() - start_time}`);
    return result;
}

// 判断字符串日期是否为当天
// logd(isToday("2025-1-08"))
function isToday(dateString) {
    if (!dateString){return false}

    function normalizeDate(dateStr) {
        // 使用正则表达式匹配年份、月份和日期
        const match = dateStr.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
        if (!match) {
            throw new Error("Invalid date format. Expected format: YYYY-MM-D");
        }

        // 提取年份、月份和日期
        let [_, year, month, day] = match;

        // 补齐月份和日期为两位数
        month = month.padStart(2, '0');
        day = day.padStart(2, '0');

        // 返回规范化的日期
        return `${year}-${month}-${day}`;
    }

    dateString = normalizeDate(dateString)
    // 将输入的字符串日期转为 Date 对象
    const inputDate = new Date(dateString);

    // 获取当前日期
    const today = new Date();

    // 比较年、月、日是否相等
    return (
        inputDate.getFullYear() === today.getFullYear() &&
        inputDate.getMonth() === today.getMonth() &&
        inputDate.getDate() === today.getDate()
    );
}

// logd(parseTimeString( "2024.5.6"))
//判断是否是时间，是则格式化，不是返回-1
function parseTimeString(timeString) {
    const now = new Date();
    // 去除空格，替换中文冒号为英文冒号
    try {
        timeString = timeString.replace(/\s+/g, '').replace(/：/g, ':');
        const timeRegex = /(昨天\s*\d{1,2}:\d{2}|[0-9]*小时前|[0-9]*天前|[0-9]*分钟前|[0-9]{4}\.[0-9]{1,2}\.[0-9]{1,2})/;
        logd("去除空格：{}", timeString);

        const match = timeString.match(timeRegex);
        if (!match) {
            logd("未能匹配任何时间格式");
            return -1;
        }

        timeString = match[0];
        // logd("提取日期：{}", timeString);

        function formatDate(date) {
            const year = date.getFullYear();
            const month = String(date.getMonth() + 1).padStart(2, '0');
            const day = String(date.getDate()).padStart(2, '0');
            return `${year}-${month}-${day}`;
        }

        function formatDateToISO(dateString) {
            const date = new Date(dateString);
            const year = date.getFullYear();
            const month = String(date.getMonth() + 1).padStart(2, '0'); // 补全双位月份
            const day = String(date.getDate()).padStart(2, '0');       // 补全双位日期
            const hours = String(date.getHours()).padStart(2, '0');   // 补全双位小时
            const minutes = String(date.getMinutes()).padStart(2, '0'); // 补全双位分钟

            return `${year}-${month}-${day} ${hours}:${minutes}`;
        }

        // Match "昨天 HH:mm"
        if (/^昨天\s*\d{1,2}:\d{2}$/.test(timeString)) {
            const [, hour, minute] = timeString.match(/昨天(\d{1,2}):(\d{2})/);
            const yesterday = new Date(now);
            yesterday.setDate(now.getDate() - 1);
            yesterday.setHours(Number(hour), Number(minute), 0, 0);
            return formatDateToISO(yesterday);
        }

        // Match "YYYY.MM.DD"
        if (/^\d{4}\.\d{1,2}\.\d{1,2}$/.test(timeString)) {
            if (/^\d{4}\.\d{1,2}\.\d{1,2}$/.test(timeString)) {
                const standardizedDate = timeString.replace(/\./g, '-'); // 替换为标准分隔符
                const [year, month, day] = standardizedDate.split('-'); // 拆分年月日
                return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')} 08:00`; // 规范化为双位格式
            }
        }

        // Match "X小时前"
        if (/^\d*小时前$/.test(timeString)) {
            let hours = parseInt(timeString.match(/^(\d*)小时前$/)[1], 10);
            if (!hours){
                hours = 0
            }
            const pastDate = new Date(now);
            pastDate.setHours(now.getHours() - hours);
            return formatDateToISO(pastDate);
        }

        // Match "X天前"
        if (/^\d*天前$/.test(timeString)) {
            let days = parseInt(timeString.match(/^(\d*)天前$/)[1], 10);
            logd("天：{}",days)
            if (!days){
                days = 3
            }
            const pastDate = new Date(now);
            pastDate.setDate(now.getDate() - days);
            return formatDateToISO(pastDate);
        }

        // Match "X分钟前"
        if (/^\d*分钟前$/.test(timeString)) {
            let minutes = parseInt(timeString.match(/^(\d*)分钟前$/)[1], 10);
            if (!minutes){
                minutes = 0
            }
            const pastDate = new Date(now);
            pastDate.setMinutes(now.getMinutes() - minutes);
            return formatDateToISO(pastDate);
        }
        // Return -1 if no match
        return -1;
    }catch (e) {
        return -1
    }

}

/**
 * 计算两个字符串的相似度
 * @param {string} str1 - 第一个字符串
 * @param {string} str2 - 第二个字符串
 * @returns {number} 相似度（0 到 1 之间）
 */
function calculateSimilarity(str1, str2) {
    // 计算编辑距离的函数
    function getEditDistance(s1, s2) {
        const len1 = s1.length;
        const len2 = s2.length;
        const dp = Array.from({ length: len1 + 1 }, () => Array(len2 + 1).fill(0));

        // 初始化dp数组
        for (let i = 0; i <= len1; i++) dp[i][0] = i;
        for (let j = 0; j <= len2; j++) dp[0][j] = j;

        // 动态规划填充dp数组
        for (let i = 1; i <= len1; i++) {
            for (let j = 1; j <= len2; j++) {
                if (s1[i - 1] === s2[j - 1]) {
                    dp[i][j] = dp[i - 1][j - 1]; // 不操作
                } else {
                    dp[i][j] = Math.min(
                        dp[i - 1][j] + 1,    // 删除
                        dp[i][j - 1] + 1,    // 插入
                        dp[i - 1][j - 1] + 1 // 替换
                    );
                }
            }
        }
        return dp[len1][len2];
    }

    // 获取编辑距离
    const editDistance = getEditDistance(str1, str2);

    // 计算相似度
    const maxLength = Math.max(str1.length, str2.length);
    if (maxLength === 0) return 1; // 两个空字符串相似度为 1
    return (1 - editDistance / maxLength).toFixed(4);
}






