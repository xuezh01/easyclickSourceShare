
function 抖音粉丝群获客() {
    脚本当前运行阶段 = `抖音粉丝群获客：【${脚本运行配置.dy.user_group}】`
    let 运行配置 = 脚本运行配置.dy.user_group
    const 请求关键词 = api_获取检索关键词('抖音',抖音_获取当前账号的抖音ID())
    if(!请求关键词){
        脚本当前运行阶段 =`【抖音】【${脚本运行配置.dy.user_group}】该关键词无更多视频,请重新分配关键词！`
        iSleep(20000)
    }else {
        douyin.关键词已无视频 = 请求关键词
        脚本运行配置.dy.user_group.keyword = 请求关键词.key_word
    }
    douyin.初始化()
    // if (!douyin.dy_首页导航_切换(1)) {douyin.dy_启动抖音(); return -1}
    if (!douyin.dy_首页搜索按钮点击(脚本运行配置.dy.search_time_interval)) { return -2}
    if (!douyin.dy_搜索页面输入查询(脚本运行配置.dy.user_group.keyword)) { return -3}
    if (!douyin.dy_搜索结果分类选项选择('用户')) { return -4}

    while (!ocr文本不完全匹配('找不到',0,600,750,1330)){
        const 博主页面ocr = ocr范围识别(170,206,558,1332)
        logd("ocr:{}",JSON.stringify(博主页面ocr))
        let 博主主页进入按钮 = []
        let 博主信息_list = []
        let 群聊信息_list = {}
        if (博主页面ocr){
            for (var i in 博主页面ocr){
                var 单行内容 = 博主页面ocr[i]
                if (单行内容.label.includes('抖音号')){
                    博主主页进入按钮.push(单行内容)
                }
            }
        }else {
            return -5
        }
        logd("博主主页进入按钮:{}",JSON.stringify(博主主页进入按钮))
        for (var i = 0;i<博主主页进入按钮.length;i++){
            let 抖音号 = {name:"博主搜索结果进入博主主页按钮",x:(博主主页进入按钮[i].x+博主主页进入按钮[i].width/2+170),y:(博主主页进入按钮[i].y+博主主页进入按钮[i].height/2+206)}
            let 点击结果 = 点击后检测(抖音号, douyin.搜索页_搜索结果标签, [douyin.用户作品主页, douyin.搜索反馈与建议]);
            if (点击结果>=0){
                const 博主信息 = {blogger_name: '',blogger_id:'',blogger_main_page:{},filte:null,have_group:''}
                const 用户_昵称_id = douyin.dy_节点获取抖音ID();
                if (用户_昵称_id){
                    博主信息.blogger_main_page.简介 = douyin.dy_节点获取用户简介()
                    博主信息.blogger_name = 用户_昵称_id.用户昵称;
                    博主信息.blogger_id = 用户_昵称_id.抖音ID;
                }
                let 插入结果 = 博主信息插入(博主信息.blogger_id,博主信息.blogger_name,博主信息.blogger_main_page.简介,0,0)
                if (!插入结果){

                }
                let 群聊信息 = douyin.dy_博主群聊获取(博主信息.blogger_id)
                if (群聊信息){
                    群聊信息_list[博主信息.blogger_name] = 群聊信息
                    博主信息.have_group = true
                }else {
                    博主信息.have_group = false
                }
                博主信息_list.push(博主信息)
            }
            const 返回搜索页面 = 点击后检测(douyin.用户主页_返回按钮, douyin.用户作品主页, [douyin.搜索页_搜索]);
            logd("点击结果:{}",返回搜索页面)
        }
        logd("博主信息_list:{}",JSON.stringify(博主信息_list))
        logd("群聊信息_list:{}",JSON.stringify(群聊信息_list))
        滑动(300,1300,210,300,1000)
    }
    return 1
}

function 正则群聊人数(input) {
    const regex = /[（(](\d{1,3})[）)]$/;
    const match = input.match(regex); // 匹配正则
    return match ? match[1] : null; // 如果匹配成功，返回数字部分；否则返回 null
}

function 正则群聊名称(input) {
    const regex = /[（(](\d{1,3})[）)]$/;
    return input.replace(regex, ""); // 替换匹配的部分为空字符串
}

function 群聊运行时间 (){
    logd("脚本运行配置_群聊获客：{}",JSON.stringify(脚本运行配置))
    const [s_hours, s_minutes] = 脚本运行配置.dy.user_group.start_time.split(':');
    const [e_hours, e_minutes] = 脚本运行配置.dy.user_group.end_time.split(':');
    const start_time = new Date();
    start_time.setHours(s_hours, s_minutes, 0, 0);

    const end_time = new Date();
    end_time.setHours(e_hours, e_minutes, 0, 0);
    const now = new Date();
    let result = false
    if(start_time < end_time){
        if (start_time <= now && now < end_time){ result = true }
    }else {
        if (start_time <= now || now < end_time){ result = true }
    }
    if(result){
        日志打印_warning(` 当前是-[抖音_同行关注] ${start_time}-${end_time}`)
    }
    return result
}

/*
* 返回 1完成关注 2加入群聊
* */
DouYin.prototype.dy_加入粉丝群 = function (节点,条件) {
    let 是否仅关注 = false
    if (条件.includes('仅关注')){
        是否仅关注 = true
    }
    logd('所有节点:{}',JSON.stringify(节点))
    setFetchNodeParam({"labelFilter":"1","maxDepth":"17","visibleFilter":"1","boundsFilter":"2","excludedAttributes":""})
    const 加入节点 = bounds(节点.bounds.left, 节点.bounds.top, 节点.bounds.right, 节点.bounds.bottom).type('Button').label('加入').getOneNodeInfo(10000)
    if (加入节点){
        加入节点.clickCenter()
    }else {
        return -1
    }
    iSleep(2000)
    const 关注节点 = type('Button').label('立即关注').getOneNodeInfo(10000)
    logd('关注节点:{}',JSON.stringify(关注节点))
    if (关注节点){
        关注节点.clickCenter()
    }else {
        return -2
    }
    iSleep(2000)
    if (关注节点 && 是否仅关注){
        const 立即加入按钮 = ocr文本不完全匹配('立即加入',0,678,750,1330)
        if (立即加入按钮){
            const 加入点击结果 = 点击后检测(立即加入按钮,douyin.粉丝群加入标识,[douyin.粉丝群页面标识])
            if (加入点击结果>=0){
                return 2
            }
        }
    }else {
        加入节点.clickCenter()
    }
    return 1
}

DouYin.prototype.dy_博主群聊获取 = function (博主信息){
    const 是否有群聊 = findColor(douyin.博主主页群聊标识)
    let 群聊信息_json = {}
    if (!是否有群聊){
        return false
    }

    const 进入群聊 = 点击后检测(是否有群聊,douyin.博主主页群聊标识,[douyin.粉丝群标识])
    if (进入群聊 != 0){
        return false
    }

    const 已折叠 = ocr文本不完全匹配('已折叠',20,140,750,1330)
    if (已折叠){
        点击屏幕检测(已折叠,1000,20,140,750,1330)
    }
    setFetchNodeParam({"labelFilter":"1","maxDepth":"17","visibleFilter":"1","boundsFilter":"2","excludedAttributes":""})
    const 群聊节点 = type('CollectionView').getOneNodeInfo(10000)
    if (!群聊节点){
        return false
    }

    let 群聊节点_子节点 = 群聊节点.allChildren()
    logd('群聊节点:{}',JSON.stringify(群聊节点_子节点))
    for (var i of 群聊节点_子节点){
        let 群成员名单 = null
        if (i.type === 'Cell'){
            douyin.群聊页面加入按钮_y值设置(i.bounds.top,i.bounds.bottom)
            let 加入按钮 = findColor(douyin.群聊页面加入按钮)
            if (!加入按钮){
                continue
            }

            //
            // let 查看群聊详情按钮 = {name:"查看群聊详情按钮",x:random(46,126),y:random(i.bounds.top+50,i.bounds.top+120)}
            // let 点击结果 = 点击后检测(查看群聊详情按钮,douyin.群聊页面加入按钮,[douyin.群聊详情标识])
            // if (点击结果 != 0){
            //     continue
            // }
            // setFetchNodeParam({"labelFilter":"2","maxDepth":"15","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
            // let 群聊管理信息节点 = type('StaticText').getNodeInfo(10000)
            // while (!群聊管理信息节点){
            //     setFetchNodeParam({"labelFilter":"2","maxDepth":"15","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
            //     群聊管理信息节点 = type('StaticText').getNodeInfo(10000)
            //     iSleep(10000)
            // }
            // 群聊管理信息节点.sort((a, b) => a.bounds.top - b.bounds.top);
            // let 节点文字信息 = 群聊管理信息节点.map(node => node.value);
            // logd("群聊管理信息节点:{}",JSON.stringify(节点文字信息))

            const 群聊ocr信息 = ocr范围识别(150,i.bounds.top,548,i.bounds.bottom)
            logd("群聊ocr信息:{}",JSON.stringify(群聊ocr信息))
            const 群聊信息 = {name: '',人数:'',群聊描述:'',是否关注:'',是否需要等待同意:'',是否加入:false,是否群聊已满:false}
            for (var ii of 群聊ocr信息) {
                var 数量 = 正则群聊人数(ii.label)
                if (数量) {
                    群聊信息.name = 正则群聊名称(ii.label)
                    群聊信息.人数 = 数量
                } else {
                    群聊信息.群聊描述 += ii.label
                }
            }

            const data = {
                "group_name":博主信息.name,
                "belong_blogger_id":博主信息.id,
                "join_condition":群聊信息.群聊描述,
                "is_join":群聊信息.是否加入,
                "is_follow":群聊信息.是否关注,
                "is_wait_for_consent":群聊信息.是否需要等待同意,
                "group_member":群聊信息.人数,
                "belong_uid": uid,
                "account_type": '抖音',
                "fans_group_id": ""
            }

            let 群聊插入结果 = dy_博主群聊信息插入(data)
            if (!群聊插入结果 && !群聊插入结果.hasOwnProperty("fans_group")){
                continue
            }
            const 群聊_id = 群聊插入结果.fans_group.at_fs_id
            logd("群聊信息.群聊描述:{}",JSON.stringify(群聊信息.群聊描述))
            if (群聊信息.群聊描述.includes('关注')){
                let 粉丝群加入结果 = douyin.dy_加入粉丝群(i,群聊信息.群聊描述)
                logd("粉丝群加入:{}",粉丝群加入结果)
                // 群聊息插入(群聊信息.name,博主_id,群聊信息.群聊描述,群聊信息.是否加入,群聊信息.人数)
                if (粉丝群加入结果 === 1){
                    群聊信息.是否关注 = true
                }else if (粉丝群加入结果 === 2){
                    群聊信息.是否关注 = true
                    群聊信息.是否加入 = true
                    群成员名单 = douyin.dy_粉丝群用户获取(群聊_id)
                }
            }
            群聊信息_json[群聊信息.name] = {}
            const 是否满群 = ocr文本不完全匹配('群已满',520,i.bounds.top,740,i.bounds.bottom)
            if (是否满群){
                群聊信息_json[群聊信息.name].是否群聊已满 = true
            }
            群聊信息_json[群聊信息.name].信息 = 群聊信息
            群聊信息_json[群聊信息.name].群成员 = 群成员名单
        }
    }
    const 粉丝群列表页面_返回用户主页按钮 = {name:'粉丝群列表页面_返回用户主页按钮',x:random(40,50),y:random(65,100)}
    let 点击结果 = 点击后检测(粉丝群列表页面_返回用户主页按钮,douyin.粉丝群标识,[douyin.用户作品主页])
    if (点击结果 !=0){
        return -4
    }

    return 群聊信息_json


    return false
}

DouYin.prototype.dy_粉丝群用户获取 = function (群聊_id) {
    const 群聊详情按钮 = {name:"群聊详情按钮",x:random(675,720),y:random(60,100)}
    const 详情点击结果 = 点击后检测(群聊详情按钮,douyin.粉丝群页面标识,[douyin.粉丝群详情页面标识])
    let 群成员名单列表 = []
    if (详情点击结果!=0){
        return -1
    }
    const 群聊详细页面_进入群成员列表按钮 = ocr文本不完全匹配('群聊成员',20,115,500,600)
    if (!群聊详细页面_进入群成员列表按钮){
        return -2
    }
    const 粉丝群聊详细页面进入粉丝列表按钮点击结果 = 点击后检测(群聊详细页面_进入群成员列表按钮,douyin.粉丝群详情页面标识,[douyin.粉丝群粉丝列表页面])
    if (粉丝群聊详细页面进入粉丝列表按钮点击结果!=0){
        return -3
    }
    setFetchNodeParam({"labelFilter":"1","maxDepth":"17","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
    const 群成员列表搜索框 = type('TextField').value('搜索').getOneNodeInfo(10*1000)
    setFetchNodeParam({"labelFilter":"2","maxDepth":"15","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
    let 群主_管理员标题 = type('StaticText').labelMatch('群主/管理员').getOneNodeInfo(10*1000)
    const 群成员按钮标题 = type('StaticText').labelMatch('群成员').bounds(0,群成员列表搜索框.bounds.bottom,750,1330).getOneNodeInfo(10*1000)
    if (!群成员按钮标题){
        return -4
    }
    let 滑动次数 = 3
    do {
        滑动次数--
        if (isScriptExit()){return }
        滑动(random(96,100),群成员按钮标题.bounds.bottom,random(96,100),群成员列表搜索框.bounds.bottom-20,900)
        群主_管理员标题 = type('StaticText').labelMatch('群主/管理员').getOneNodeInfo(10*1000)
    }while (群主_管理员标题 && 滑动次数>0)
    iSleep(5000)
    let 是否获取完成 = false
    let 列表最后一个成员名称 = null
    while (!是否获取完成){
        iSleep(2000)
        const 群成员节点列表 = type('Button').bounds(0,群成员列表搜索框.bounds.bottom,750,1330).getNodeInfo(10*1000)
        if (列表最后一个成员名称 && 列表最后一个成员名称.name === 群成员节点列表[群成员节点列表.length-1].name){
            是否获取完成 = true
        }
        if (!群成员节点列表 || 群成员节点列表.length == 0){
            return -5
        }
        for (var i of 群成员节点列表){
            i.clickCenter()
            iSleep(1000)
            let 简介 = douyin.dy_节点获取用户简介()
            const 用户_昵称_id = douyin.dy_节点获取抖音ID();
            const 用户信息 = {name:'',douyin_id:'',主页简介:''}
            if (用户_昵称_id){
                用户信息.name = 用户_昵称_id.用户昵称;
                用户信息.douyin_id = 用户_昵称_id.抖音ID;
                用户信息.主页简介 = 简介;
                群成员名单列表.push(用户信息)
                let filet = 0
                if (checkNickname(用户信息.name)){
                    filet = 1
                }
                群成员信息插入(用户信息.douyin_id,群聊_id,用户信息.name,filet,0,用户信息.主页简介,'')
            }
            const 返回搜索页面 = 点击后检测(douyin.用户主页_返回按钮, douyin.用户作品主页, [douyin.粉丝群粉丝列表页面]);
            if (返回搜索页面 !=0){
                return -6
            }
        }
        列表最后一个成员名称 = 群成员节点列表[群成员节点列表.length-1]
        滑动(random(96,100),列表最后一个成员名称.bounds.bottom,random(96,100),群成员列表搜索框.bounds.bottom-20,1500)
    }
    if (douyin.dy_粉丝列表页面返回_搜索页面()!=1){
        logd('报错')
    }
    return 群成员名单列表
}

DouYin.prototype.dy_粉丝列表页面返回_搜索页面 = function (){
    const 粉丝列表页面_返回粉丝群详情页面按钮 = {name:"粉丝列表页面_返回粉丝群详情页面按钮",x:random(40,50),y:random(70,90)}
    let 点击结果 = 点击后检测(粉丝列表页面_返回粉丝群详情页面按钮,douyin.粉丝群粉丝列表页面,[douyin.粉丝群详情页面标识])
    if (点击结果 !=0){
        return -1
    }
    const 粉丝群详情页面_返回聊天页面按钮 = {name:'粉丝群详情页面_返回聊天页面按钮',x:random(40,50),y:random(65,100)}
    点击结果 = 点击后检测(粉丝群详情页面_返回聊天页面按钮,douyin.粉丝群详情页面标识,[douyin.粉丝群页面标识])
    if (点击结果 !=0){
        return -2
    }
    const 聊天页面返回_粉丝群列表按钮 = {name:'聊天页面返回_粉丝群列表按钮',x:random(40,50),y:random(65,100)}
    点击结果 = 点击后检测(聊天页面返回_粉丝群列表按钮,douyin.粉丝群页面标识,[douyin.粉丝群标识])
    if (点击结果 !=0){
        return -3
    }
    // const 粉丝群列表页面_返回用户主页按钮 = {name:'粉丝群列表页面_返回用户主页按钮',x:random(40,50),y:random(65,100)}
    // 点击结果 = 点击后检测(粉丝群列表页面_返回用户主页按钮,douyin.粉丝群标识,[douyin.用户作品主页])
    // if (点击结果 !=0){
    //     return -4
    // }
    return 1
}



DouYin.prototype.dy_满足条件群聊申请加入 = function (满足条件群聊) {
    脚本当前运行阶段 = `【同行持续跟进】满足条件群聊申请加入`
    if (!douyin.dy_首页导航_切换(1)) {
        douyin.dy_启动抖音()
        return -1
    }
    if (!douyin.dy_首页搜索按钮点击(脚本运行配置.dy.search_time_interval)) { return }

    function 页面判断() {
        if (findColor(douyin.搜索页面的搜索按钮)){
            return true
        }
        return false
    }

    for (var i of 满足条件群聊){
        if (!douyin.dy_搜索页面输入查询(i.blogger_id)) { return }
        if (!douyin.dy_搜索结果分类选项选择('用户')) { return }
        if (douyin.dy_搜索结果频繁_检测(脚本运行配置.dy.search_pinfan_hours)){ return }

        const 进入结果 = douyin.dy_用户列表_用户主页进入(i.blogger_id);
        switch (进入结果) {
            case -1:
                return
            case 0:
                douyin.dy_搜索页_返回首页()
                continue
            case 1:
                break
        }
        if (!页面判断()){return -1}
        let 群聊信息 =douyin.dy_博主群聊获取(i.blogger_id)

    }
}

DouYin.prototype.dy_已记录群聊跟进 = function () {
    const data = {
        "belong_uid":uid,
        "account_type":'抖音',
        "follow_account_ai_id":抖音_获取当前账号的抖音ID()
    }
    const 已记录群聊信息 = dy_获取本账号群聊信息(data)
    if (!已记录群聊信息){
        return -1
    }
    const 群聊信息分类 = {'满足条件群聊':[],'已加入可跟进群聊':[],'已申请群聊':[]}
    for (var i of 已记录群聊信息){
        if (i.is_join){
            群聊信息分类.已加入可跟进群聊.push(i)
            continue
        }
        if (i.is_wait_for_consent){
            群聊信息分类.已申请群聊.push(i)
            continue
        }
       var 是否满足条件 = 群聊条件判断(i,获取当前时间())
        if (是否满足条件){
            群聊信息分类.满足条件群聊.push(i)
        }
    }
    if (群聊信息分类.满足条件群聊.length>0){
        
    }
    return 1
}

// 计算两个日期之间的天数
function calculateDaysBetween(date1, date2) {
    const diffTime = Math.abs(new Date(date2) - new Date(date1));
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}

// 判断是否满足进群条件
function 群聊条件判断(entry, currentDate) {
    if (!entry.join_condition.includes('关注群主超过')  || entry.join_condition.includes('粉丝团')) {
        return false; // 如果条件不包含关注天数要求，返回false
    }

    // 从条件中提取所需的关注天数
    const match = entry.join_condition.match(/关注群主超过(\d+)天/);
    if (!match) {
        return false; // 如果无法解析关注天数，返回false
    }

    const requiredDays = parseInt(match[1], 10);
    const followTime = new Date(entry.gp_ins_tm);

    // 计算关注时间到当前时间的天数
    const followedDays = calculateDaysBetween(followTime, currentDate);

    return followedDays > requiredDays;
}


const aaa = [
    {
        "bauto_id": 226,
        "blogger_id": "1210103573",
        "blogger_name": "短视频AI矩阵引流营销",
        "blogger_main_page": "全网短视频平台AI矩阵精准营销！一站式线上精准引流营销！短视频平台全域一站式精准引流，平台系统小程序开发，实体店精准引流拓客，线上精准引流营销，项目线上运营精准托管！",
        "is_follow": 0,
        "is_follow_tm": "2025-01-10T16:05:37",
        "follow_account_ai_id": "rgrg",
        "fans_group_id": "7273267944338231296",
        "group_name": "NG吴先森的发发群 ",
        "join_condition": "活跃群进群门槛：关注群主超过60天、20级粉丝团成员",
        "is_join": 0,
        "is_wait_for_consent": 0,
        "group_member": 0,
        "gp_ins_tm": "2025-01-10T11:26:25"
    },
    {
        "bauto_id": 226,
        "blogger_id": "rgrg",
        "blogger_name": "rgrg",
        "blogger_main_page": "rgrg",
        "is_follow": 0,
        "is_follow_tm": "2025-01-10T16:05:37",
        "follow_account_ai_id": "rgrg",
        "fans_group_id": "7273267944338231296",
        "group_name": "rgrg",
        "join_condition": "进群门槛：开通群主的专属会员",
        "is_join": 0,
        "is_wait_for_consent": 0,
        "group_member": 0,
        "gp_ins_tm": "2025-01-10T11:31:35"
    },
    {
        "bauto_id": 226,
        "blogger_id": "rgrg",
        "blogger_name": "rgrg",
        "blogger_main_page": "rgrg",
        "is_follow": 0,
        "is_follow_tm": "2025-01-10T16:05:37",
        "follow_account_ai_id": "rgrg",
        "fans_group_id": "7273267944338231296",
        "group_name": "rgrg3",
        "join_condition": "进群门槛：关注群主超过7天",
        "is_join": 0,
        "is_wait_for_consent": 0,
        "group_member": 0,
        "gp_ins_tm": "2025-01-10T14:05:43"
    }
    ]



function checkNickname(nicheng) {
    // 将昵称转换为小写
    nicheng = nicheng.toLowerCase();

    // 定义关键字数组
    const firstLevel = [
        "ac", "ex", "space", "doo", "plotlo", "百利好", "交易",
        "裸k", "ona", "汉声集团", "ericchiu", "汇市", "xau", "atfx", "kvb", "fxcm", "tick"
    ];

    const secondLevel = [
        "xm", "tm", "gm", "am", "ec", "ea", "金银", "黄金", "回收", "汇", "网银", "量化", "资本",
        "经纪人", "享达", "国际", "king", "客户", "经理", "wrj", "工作室", "macro", "巨汇", "福汇",
        "gtc", "泽汇", "换汇", "澳洲", "sq", "老牌", "平方", "服务", "摸金", "代理", "总部", "经纪人"
    ];

    // 判断是否匹配一级关键字
    for (let keyword of firstLevel) {
        if (nicheng.includes(keyword)) {
            return true;
        }
    }

    // 判断是否匹配至少两个二级关键字
    let secondLevelNum = 0;
    for (let keyword of secondLevel) {
        if (nicheng.includes(keyword)) {
            secondLevelNum++;
            if (secondLevelNum >= 2) {
                return true;
            }
        }
    }

    // 如果没有匹配，则返回 false
    return false;
}

DouYin.prototype.粉丝群标识 = {
    name: '粉丝群标识',
    textArray: ['公开群','按可加入排序','进群','加入'],
    x: 0,
    y: 0,
    ex: ScreenWidth,
    ey: 1330,
    binaryzation: false,
    matchCount: 2
}

DouYin.prototype.群聊详情标识 = {
    name: '粉丝群标识',
    textArray: ['群主','进群门槛','条件不符'],
    x: 0,
    y: 330,
    ex: ScreenWidth,
    ey: 1330,
    binaryzation: false,
    matchCount: 2
}