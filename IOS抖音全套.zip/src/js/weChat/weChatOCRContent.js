
WeChat.prototype.ocr内容初始化 = function () {

    if(device_name === 'iPad'){
        WeChat.prototype.底部导航 = {
            name: '底部导航',
            textArray: ['微信', '通讯录', '发现', '我'],
            x: 0,
            y: 1900,
            ex: ScreenWidth,
            ey: ScreenHeight,
            binaryzation: false,
            matchCount: 2
        }

        WeChat.prototype.好友_聊天详情页 = {
            name: '聊天详情页',
            textArray: ['聊天详情','查找聊天内容', '消息免打扰', '置顶聊天', '提醒', '设置当前聊天背景', '清空聊天记录', '投诉'],
            x: 0,
            y: 50,
            ex: 900,
            ey: 1260,
            binaryzation: false,
            matchCount: 3
        }
        WeChat.prototype.好友_资料设置页面 = {
            name: '聊天详情页',
            textArray: ['资料设置','设置备注和标签','朋友权限', '把他推荐给朋友', '设为星标朋友', '加入黑名单', '删除联系人'],
            x: 0,
            y: 40,
            ex: 900,
            ey: 1260,
            binaryzation: false,
            matchCount: 3
        }

        WeChat.prototype.好友_基础资料页面 = {
            name: '用户详情页',
            textArray: ['备注和标签','朋友权限', '朋友圈', '视频号', '更多信息', '发消息', '音视频通话'],
            x: 10,
            y: 120,
            ex: 1150,
            ey: 1620,
            binaryzation: false,
            matchCount: 3
        }

        WeChat.prototype.消息页顶部 = {
            name: '消息页顶部',
            textArray: ['微信','搜索'],
            x: 460,
            y: 40,
            ex: 1100,
            ey: 230,
            binaryzation: false,
            matchCount: 2
        }
        WeChat.prototype.消息页_小程序页打开 = {
            name: '消息页_小程序页打开',
            textArray: ['微信'],
            x: 460,
            y: 1900,
            ex: 1100,
            ey: ScreenHeight,
            binaryzation: false,
            matchCount: 1
        }
    }
    else {
        WeChat.prototype.底部导航 = {
            name: '底部导航',
            textArray: ['微信', '通讯录', '发现', '我'],
            x: 0,
            y: 1200,
            ex: ScreenWidth,
            ey: ScreenHeight,
            binaryzation: false,
            matchCount: 2
        }


        WeChat.prototype.通讯录页面title = {
            name: '通讯录页面title',
            textArray: ['通讯录'],
            x: 240,
            y: 40,
            ex: 500,
            ey: 120,
            binaryzation: false,
            matchCount: 1
        }
    }

}