
function WeChat() {
}

let wechat = new WeChat()


WeChat.prototype.初始化 = function (){

    wechat.wx_图色初始化();
    wechat.ocr内容初始化();
    laoleng.EC.init(1);
    laoleng.EC.initOcr();
    laoleng.EC.initNode();

    if(device_name === 'iPad'){
        wechat.消息导航按钮 = {name: '消息导航', x: random(270, 320), y:random(1950,1980)}
        wechat.通讯录导航按钮 = {name: '通讯录导航', x: random(610, 650), y:random(1950,1980)}
        wechat.发现导航按钮 = {name: '发现导航', x: random(950, 990), y:random(1950,1980)}
        wechat.我导航按钮 = {name: '我导航', x: random(1250, 1280), y:random(1950,1980)}
        wechat.左上角_返回按钮 = {name: '左上角_返回按钮', x: random(40, 50), y:random(77,97)}
        wechat.通讯录页_搜索框 = {name: '通讯录页_搜索框', x: random(690, 850), y:random(160,220)}
        wechat.聊天页_右上角_更多按钮 = {name: '聊天页_右上角_更多按钮', x: random(1455, 1490), y:random(85,90)}
        wechat.聊天详情页_用户头像_按钮 = {name: '聊天详情页_用户头像_按钮', x: random(55, 145), y:random(190,270)}
        wechat.小程序页_关闭按钮 = {name: '小程序页_关闭按钮', x: random(687, 838), y:random(1972,2014)}
        wechat.聊天页_消息输入框 = {name: '聊天页_消息输入框', x: random(420, 1220), y:random(1945,1995)}
        wechat.通讯录_顶部_搜索框 = {name: '通讯录_顶部_搜索框', x: random(500, 1050), y:random(170,215)}
    }
    else {
        wechat.消息导航按钮 = {name: '消息导航', x: random(70, 112), y:random(1255,1279)}
        wechat.通讯录导航按钮 = {name: '通讯录导航', x: random(262, 293), y:random(1255,1279)}
        wechat.发现导航按钮 = {name: '发现导航', x: random(448, 489), y:random(1255,1279)}
        wechat.我导航按钮 = {name: '我导航', x: random(638, 670), y:random(1255,1279)}
        wechat.左上角_返回按钮 = {name: '左上角_返回按钮', x: random(35, 44), y:random(76,90)}
        wechat.通讯录页_搜索框 = {name: '通讯录页_搜索框', x: random(298, 437), y:random(148,195)}
    }
    wechat.wx_系统回复 = ['微信团队','服务通知','微信支付','文件传输助手']

    wechat.wx_无需回复名单 = {
        微信团队: 3096660526,
        服务通知: 13170513,
        微信支付: 2699456688,
        文件传输助手: 2328077139,

    }
    wechat.本设备微信号 = 'yan240135341'
    wechat.wx_page = {
        now_page: '',
        unknown_page: '未知',

        page_1: '消息导航页面',
        page_1_1: '消息_聊天_页面',
        page_1_2: '消息_聊天_好友基础资料_页面',
        page_1_3: '消息_聊天_资料设置_页面',
        page_1_4: '消息_聊天_聊天详情_页面',
        page_1_5: '消息_顶部小程序_页面',

        page_2: '通讯录导航页面',
        page_2_1: '通讯录_用户详情_页面',
        page_2_2: '通讯录_用户详情_资料设置_页面',

        page_3: '发现导航页面',
        page_3_1: '朋友圈页面',

        page_4: '我导航页面'
    }
}

WeChat.prototype.wx_启动微信 = function (){
    当前执行模块 = 'wx_启动微信';
    日志打印_debug('开始执行   --- 【wx_启动微信】')

    appBundleId = null;
    wechat.wx_page.now_page = wechat.wx_page.unknown_page
    home();  //返回主页面
    iSleep(100);
    let 微信App = findColor(wechat.微信App);
    重试次数 = 3;
    while(!微信App && 重试次数 > 0){
        if(isScriptExit()) {break}
        home();  //返回主页面
        iSleep(100);
        微信App = findColor(wechat.微信App);
        重试次数--;
    }
    if(!微信App){
        日志打印_error('微信App 寻找失败！')
        return false
    }
    const 抖音启动结果 = 点击后检测(微信App, wechat.微信App, [wechat.微信启动页面, wechat.底部导航])
    switch (抖音启动结果) {
        case -100:
            日志打印_error('微信App 位置点击失败！')
            return wechat.wx_重启微信()
        case -1:
            return wechat.wx_重启微信()
        case 0:
            iSleep(3000);
            break
        case 1:
            break
    }
    wechat.wx_page.now_page = wechat.wx_page.page_1
    appBundleId = 'com.tencent.xin';
    日志打印_debug('   --- 【wx_启动微信】---  执行结束')
    return true
}

WeChat.prototype.wx_重启微信 = function (){
    当前执行模块 = 'wx_重启微信';
    日志打印_debug('开始执行   --- 【wx_重启微信】')

    appBundleId = null;
    wechat.wx_page.now_page = wechat.wx_page.unknown_page
    let 关闭结果 = appKillByBundleId('com.tencent.xin', '1');
    let 重试次数 = 3;
    while(关闭结果 && 重试次数>0){
        if(isScriptExit()){break}
        sleep(100);
        关闭结果 = appKillByBundleId('com.tencent.xin', '1');
        重试次数--;
    }
    iSleep(100);
    home();  //返回主页面
    iSleep(100);
    let 微信App = findColor(wechat.微信App);
    重试次数 = 3;
    while(!微信App && 重试次数 > 0){
        if(isScriptExit()) {break}
        home();  //返回主页面
        iSleep(100);
        微信App = findColor(wechat.微信App);
        重试次数--;
    }
    if(!微信App){
        日志打印_error('微信App 寻找失败！')
        return false
    }
    const 抖音启动结果 = 点击后检测(微信App, wechat.微信App, [wechat.微信启动页面, wechat.底部导航])
    switch (抖音启动结果) {
        case -100:
            日志打印_error('微信App 位置点击失败！')
            return false
        case -1:
            return false
        case 0:
            iSleep(3000);
            break
        case 1:
            break
    }
    wechat.wx_page.now_page = wechat.wx_page.page_1
    appBundleId = 'com.tencent.xin';
    日志打印_debug('   --- 【wx_启动微信】---  执行结束')
    return true
}


WeChat.prototype.wx_切换导航 = function (页面) {
    当前执行模块 = 'wx_切换导航';

    let not_choose = null;
    let choose = null;
    let btn = null;
    if(页面 === 1){
        not_choose = wechat.消息导航未选择;
        choose = wechat.消息导航已选择;
        btn = wechat.消息导航按钮;
    }
    else if(页面 === 2){
        not_choose = wechat.通讯录导航未选择;
        choose = wechat.通讯录导航已选择;
        btn = wechat.通讯录导航按钮;
    }
    else if(页面 === 3){
        not_choose = wechat.发现导航未选择;
        choose = wechat.发现导航已选择;
        btn = wechat.发现导航按钮;
    }
    else if(页面 === 4){
        not_choose = wechat.我导航未选择;
        choose = wechat.我导航已选择;
        btn = wechat.我导航按钮;
    }

    if(!!findColor(choose)){
        日志打印_debug(`已在页面-【${btn.name}】`)
        return true
    }
    if(!findColor(not_choose)){
        日志打印_error(`未知页面-无法切换到【${btn.name}】`)
        return false
    }
    const 切换结果 = 点击后检测(btn, not_choose, [choose])
    switch (切换结果) {
        case -100:
            return false
        case -1:
            return false
        case 0:
            日志打印_debug(`成功切换到【${btn.name}】`)
            return true
    }

}

WeChat.prototype.wx_聊天消息发送 = function (text) {
    当前执行模块 = 'wx_聊天消息发送';
    日志打印_debug('开始执行   --- 【wx_聊天消息发送】')
    const 键盘弹出_结果 = 点击后检测(wechat.聊天页_消息输入框, wechat.聊天页标志, [ios.键盘弹出])
    switch (键盘弹出_结果) {
        case -100:
            wechat.wx_page.now_page = wechat.wx_page.unknown_page
            日志打印_error('[键盘弹出_结果] 失败！')
            return
        case -1:
            日志打印_error(' [键盘弹出_结果] 失败！')
            wechat.wx_page.now_page = wechat.wx_page.unknown_page
            return
        case 0:
            wechat.wx_page.now_page = wechat.wx_page.page_1_1
            break
    }

    文本内容输入(text, {name: '微信聊天页面_聊天输入框'})
    键盘发送();
    return
}

WeChat.prototype.wx_获取本设备微信号 = function () {
    当前执行模块 = 'wx_获取本设备微信号';
    日志打印_debug('开始执行   --- 【wx_获取本设备微信号】')
    if (wechat.本设备微信号){
        return true
    }
    if(!wechat.wx_切换导航(4)){
        return false
    }
    setFetchNodeParam({"labelFilter":"1","maxDepth":"20","visibleFilter":"1","boundsFilter":"1","excludedAttributes":""})
    let node = type('StaticText').labelMatch("微信号：.*").getOneNodeInfo(10000)
    let 重试次数 = 3
    while (!node && 重试次数>0){
        if(isScriptExit()) {break}
        const 还在预期页面 = findColor(wechat.我导航已选择)
        if(还在预期页面){
            node = type('StaticText').labelMatch("微信号：.*").getOneNodeInfo(10000)
        }
        重试次数--
    }
    if(!node){
        日志打印_error('[本设备微信号]获取失败')
        return false
    }
    const 微信号 = node.label.replace('微信号：', '')
    wechat.本设备微信号 = 微信号
    日志打印_debug(`[本设备微信号]：${微信号}`)
    return true
}

WeChat.prototype.wx_获取通讯录名单 = function () {
    当前执行模块 = 'wx_获取通讯录名单';
    日志打印_debug('开始执行   --- 【wx_获取通讯录名单】')

    const 切换到_通讯录 = wechat.wx_切换导航(2);
    if(!切换到_通讯录){
        日志打印_error('【切换到_通讯录】失败！')
        return false
    }

    setFetchNodeParam({"labelFilter":"1","maxDepth":"20","visibleFilter":"1","boundsFilter":"1","excludedAttributes":""})
    const 通讯录页面_Table容器 = type("Table").getOneNodeInfo(30000);
    if(!通讯录页面_Table容器){
        日志打印_error('通讯录页面_Table容器 获取失败')
        return null
    }
    const Cells = 通讯录页面_Table容器.allChildren();
    if(!Cells || Cells.length <= 0){
        日志打印_error('通讯录页面_Table容器.allChildren 获取失败')
        return null
    }

    const 通讯录名单1 = [];
    const 通讯录名单2 = [];
    for(let i in Cells){
        if(isScriptExit()) {break}
        const cell = Cells[i];
        if(cell.type === 'Cell' && cell.name !== '' && cell.name){
            const name = cell.name.endsWith(',')? cell.name.slice(0, -1): cell.name;
            const data = {name: name.trim(), repeat: false}
            if(通讯录名单1.includes(name)){
                data.repeat = true
            }
            通讯录名单1.push(name)
            通讯录名单2.push({name: name, repeat: false});
        }
    }
    return 通讯录名单2
}

WeChat.prototype.wx_双击获取未读消息 = function (){
    当前执行模块 = 'wx_双击获取未读消息';
    日志打印_debug('开始执行   --- 【wx_双击获取未读消息】')

    wechat.wx_page.now_page = wechat.wx_page.page_1
    const 双击前 = 区域截图base64(15, 1600, 800, 1900)
    双击(wechat.消息导航按钮)
    iSleep(300)
    const 双击后 = 区域截图base64(15, 1600, 800, 1900)
    if(双击前 !== 双击后){
        return wechat.wx_动态页首条未读消息处理()
    }else {
        return wechat.wx_静置页未读消息处理()
    }
}

WeChat.prototype.wx_返回_消息导航页面 = function () {
    当前执行模块 = 'wx_返回_消息导航页面';
    日志打印_debug('开始执行   --- 【wx_返回_消息导航页面】')

    日志打印_warning(`当前页面：【${wechat.wx_page.now_page}】`)
    switch (wechat.wx_page.now_page) {
        case wechat.wx_page.page_1:
            const 在消息导航页面 = findColor(wechat.消息导航已选择)
            if(在消息导航页面){
                return
            }
            break
        case wechat.wx_page.page_1_1:
            // 消息_聊天_页面
            const page_1_1_返回结果 = 点击后检测(wechat.左上角_返回按钮, wechat.聊天页标志, [wechat.消息导航已选择])
            if (page_1_1_返回结果 === 0){
                return
            }
            break
        case wechat.wx_page.page_1_2:
            // 消息_聊天_好友基础资料_页面
            const 好友_基础资料页面_返回结果 = 点击后检测(wechat.左上角_返回按钮, wechat.好友_基础资料页面, [wechat.聊天页标志, wechat.好友_聊天详情页])
            if (好友_基础资料页面_返回结果 === 0){
                const 聊天页_返回结果 = 点击后检测(wechat.左上角_返回按钮, wechat.聊天页标志, [wechat.消息导航已选择])
                if (聊天页_返回结果 === 0){
                    return
                }
            }
            else if(好友_基础资料页面_返回结果 === 1){
                const 好友_聊天详情页_返回结果 = 点击后检测(wechat.左上角_返回按钮, wechat.好友_聊天详情页, [wechat.聊天页标志])
                if (好友_聊天详情页_返回结果 === 0){
                    const 聊天页_返回结果 = 点击后检测(wechat.左上角_返回按钮, wechat.聊天页标志, [wechat.消息导航已选择])
                    if (聊天页_返回结果 === 0){
                        return
                    }
                }
            }
            break
        case wechat.wx_page.page_1_3:
            // 消息_聊天_资料设置_页面
            const 好友_资料设置页面_返回结果 = 点击后检测(wechat.左上角_返回按钮, wechat.好友_资料设置页面, [wechat.好友_基础资料页面])
            if (好友_资料设置页面_返回结果 === 0){
                const 好友_基础资料页面_返回结果 = 点击后检测(wechat.左上角_返回按钮, wechat.好友_基础资料页面, [wechat.聊天页标志, wechat.好友_聊天详情页])
                if (好友_基础资料页面_返回结果 === 0){
                    const 聊天页_返回结果 = 点击后检测(wechat.左上角_返回按钮, wechat.聊天页标志, [wechat.消息导航已选择])
                    if (聊天页_返回结果 === 0){
                        return
                    }
                }
                else if(好友_基础资料页面_返回结果 === 1){
                    const 好友_聊天详情页_返回结果 = 点击后检测(wechat.左上角_返回按钮, wechat.好友_聊天详情页, [wechat.聊天页标志])
                    if (好友_聊天详情页_返回结果 === 0){
                        const 聊天页_返回结果 = 点击后检测(wechat.左上角_返回按钮, wechat.聊天页标志, [wechat.消息导航已选择])
                        if (聊天页_返回结果 === 0){
                            return
                        }
                    }
                }
            }
            break
    }
    wechat.wx_page.now_page = wechat.wx_page.unknown_page
    return
}

WeChat.prototype.wx_进入好友聊天 = function (用户, 截图) {
    当前执行模块 = 'wx_进入好友聊天';
    日志打印_debug('开始执行   --- 【wx_进入好友聊天】')

    const 进入好友聊天 = 点击后检测(用户, wechat.消息导航已选择, [wechat.页面左上角_返回按钮, wechat.聊天页标志])
    switch (进入好友聊天) {
        case -1:
            wechat.wx_page.now_page =  wechat.wx_page.unknown_page
            日志打印_error('[进入好友聊天] 失败！')
            return
        case -100:
            wechat.wx_page.now_page =  wechat.wx_page.unknown_page
            日志打印_error('[进入好友聊天] 失败！')
            return
        case 0:
            break
        case 1:
            break
    }
    wechat.wx_page.now_page =  wechat.wx_page.page_1_1

    function 群聊判定(name) {
        const 群聊名称正则 =  /,\(\d+\)$/;
        const match = name.match(群聊名称正则);
        return match ? match[0] : null;

    }
    // 获取当前聊天页用户昵称
    const 好友昵称 = wechat.wx_获取聊天页好友昵称()
    日志打印_information(`当前页：${好友昵称}`)
    if(好友昵称 === null){
        return
    }
    if( wechat.wx_系统回复.includes(好友昵称)){
        wechat.wx_无需回复名单_新增(好友昵称, 截图)
        return
    }
    const 群聊判定结果 = 群聊判定(好友昵称)
    if(群聊判定结果){
        wechat.wx_无需回复名单_新增(好友昵称.replace(群聊判定结果, ''), 截图)
        return
    }

    if (好友昵称 !== 'q邱俊华' && 好友昵称 !== '虚拟员工02'){
        wechat.wx_无需回复名单_新增(好友昵称.replace(群聊判定结果, ''), 截图)
        return
    }

    const 聊天记录 = wechat.wx_获取聊天记录(好友昵称)

    if(聊天记录.length === 0){
        //  未获取到聊天记录 无需回复 误进入
        return
    }
    if(聊天记录[聊天记录.length-1].startsWith('我：')){
        // 无最新消息 无需回复
        return
    }
    return {name: 好友昵称, msg:聊天记录.join('@!x%x~')}

}

WeChat.prototype.wx_是否回复确认 = function (base64_img) {

    for(var name in wechat.wx_无需回复名单){
        if(isScriptExit()){break}
        if(wechat.wx_无需回复名单.hasOwnProperty(name) && wechat.wx_无需回复名单[name] === base64_img){
            日志打印_warning(`--【${name}】-该用户无需回复！`)
            return false
        }
    }
    return true
}

WeChat.prototype.wx_动态页首条未读消息处理 = function () {
    当前执行模块 = 'wx_动态页首条未读消息处理';
    日志打印_debug('开始执行   --- 【wx_动态页首条未读消息处理】')

    wechat.未读消息标识.ey = 460
    const 未读消息标识 = findColor(wechat.未读消息标识)
    if(!未读消息标识){
        // 未读消息标识 识别失败 ！？
        日志打印_error('未读消息标识 识别失败 ！？')
        return
    }

    const 用户 = stringToHash(区域截图base64(未读消息标识.max_x, 未读消息标识.min_y, 1330, 未读消息标识.min_y+70))
    // logw(用户)
    const 需要回复 = wechat.wx_是否回复确认(用户)
    if(!需要回复){
        return
    }
    return wechat.wx_进入好友聊天(未读消息标识, 用户)
}

WeChat.prototype.wx_静置页未读消息处理 = function () {
    当前执行模块 = 'wx_静置页未读消息处理';
    日志打印_debug('开始执行   --- 【wx_静置页未读消息处理】')


    wechat.未读消息标识.ey = 1915
    let 未读消息标识 = findColor(wechat.未读消息标识)
    if(!未读消息标识){
        // 回到聊天消息顶部
        return wechat.wx_回到聊天消息顶部()
    }
    const 用户 = stringToHash(区域截图base64(未读消息标识.max_x, 未读消息标识.min_y, 1330, 未读消息标识.min_y+70))
    const 需要回复 = wechat.wx_是否回复确认(用户)
    if(!需要回复){
        while (true){
            if(isScriptExit()) {break}
            wechat.未读消息标识.ey = 未读消息标识.max_y
            未读消息标识 = findColor(wechat.未读消息标识)
            if(!未读消息标识){
                // 回到聊天消息顶部
                return wechat.wx_回到聊天消息顶部()
            }
            const 用户 = stringToHash(区域截图base64(a.max_x, a.min_y, 1330, a.min_y+70))
            const 需要回复 = wechat.wx_是否回复确认(用户)
            if(!需要回复){
                continue
            }
            return wechat.wx_进入好友聊天(未读消息标识, 用户)
        }
    }
    return wechat.wx_进入好友聊天(未读消息标识, 用户)
}

WeChat.prototype.wx_回到聊天消息顶部 = function () {
    当前执行模块 = 'wx_回到聊天消息顶部';
    日志打印_debug('开始执行   --- 【wx_回到聊天消息顶部】')
    wechat.wx_page.now_page = wechat.wx_page.page_1
    while (true){
        if(isScriptExit()) {break}
        const 在_消息页顶部 = ocr文本数组匹配(wechat.消息页顶部)
        if(在_消息页顶部){
            break
        }
        const 滑动结果 = 滑动误触检测([wechat.消息页顶部, wechat.消息页_小程序页打开, wechat.页面左上角_返回按钮], random(1015, 1100), random(260, 300), random(1015, 1100), random(1800, 1850),500, 100, 3)
        switch (滑动结果) {
            case 100:
                continue;
            case 0:
                return true
            case 1:
                // 关闭小程序
                wechat.wx_page.now_page = wechat.wx_page.page_1_4
                const 小程序页_关闭结果 = 点击后检测(wechat.小程序页_关闭按钮, wechat.消息页_小程序页打开, [wechat.消息页顶部, wechat.消息导航已选择])
                switch (小程序页_关闭结果) {
                    case -100:
                        wechat.wx_page.now_page = wechat.wx_page.unknown_page
                        return false;
                    case -1:
                        wechat.wx_page.now_page = wechat.wx_page.unknown_page
                        return false;
                    case 0:
                        wechat.wx_page.now_page = wechat.wx_page.page_1
                        return true;
                    case 1:
                        wechat.wx_page.now_page = wechat.wx_page.page_1
                        continue;
                }
            case 2:
                // 进入其他页面，点击返回
                wechat.wx_page.now_page = wechat.wx_page.page_1_1
                const 消息页_返回结果 = 点击后检测(wechat.左上角_返回按钮, wechat.页面左上角_返回按钮, [wechat.消息页顶部, wechat.消息导航已选择])
                switch (消息页_返回结果) {
                    case -100:
                        wechat.wx_page.now_page = wechat.wx_page.unknown_page
                        return false;
                    case -1:
                        wechat.wx_page.now_page = wechat.wx_page.unknown_page
                        return false;
                    case 0:
                        wechat.wx_page.now_page = wechat.wx_page.page_1
                        return true;
                    case 1:
                        wechat.wx_page.now_page = wechat.wx_page.page_1
                        continue;
                }
        }
    }
}

WeChat.prototype.wx_无需回复名单_新增 = function (name, base64_img) {
    wechat.wx_无需回复名单[name] = base64_img
    日志打印_debug(`[wx_无需回复名单] ${name}：新增成功！`)
}

WeChat.prototype.wx_获取聊天记录 = function (custmoerName){
    当前执行模块 = 'wx_获取聊天记录'
    日志打印_debug('开始执行   --- 【wx_获取聊天记录】')

    function 未转文本语音(str) {
        const 未转文字语音正则 = /语音,\d+''$/;
        const 未转文字 = 未转文字语音正则.test(str);
        if(!未转文字){
            const 未播放语音正则 = /语音,\d+'',未播放$/;
            return 未播放语音正则.test(str);
        }
        return true
    }
    
    function 聊天内容处理(name, text) {
        const 未转文字语音正则 = /语音,\d+''/;
        const 匹配结果 = text.match(未转文字语音正则);
        if(匹配结果){
            return text.replace(`${name},${匹配结果[0]}`, '').replace(',', '')
        }else {
            return text.replace(`${name},`, '')
        }
    }

    function 语音转文本(point) {
        日志打印_debug('执行- 【语音转文本】')

        长按(point);
        iSleep(1000);
        let 语音转文字按钮 = findColor(wechat.语音转文字按钮)
        let 重试次数 = 3
        while(!语音转文字按钮 && 重试次数>0){
            if(isScriptExit()) {break}
            长按(point);
            iSleep(1000);
            语音转文字按钮 = findColor(wechat.语音转文字按钮)
            重试次数--;
        }
        if(!语音转文字按钮){
            日志打印_error('[语音转文字按钮]获取失败！')
            return false
        }
        点击(语音转文字按钮);
        iSleep(500)
        let 语音转文字结果 = !!findColor(wechat.语音转文字按钮)
       重试次数 = 3
        while(语音转文字结果 && 重试次数>0){
            if(isScriptExit()) {break}
            点击(语音转文字按钮);
            iSleep(500);
            语音转文字结果 = !!findColor(wechat.语音转文字按钮)
            重试次数--;
        }
        return true
    }

    function 获取所有Cell() {
        日志打印_debug('获取所有Cell')
        setFetchNodeParam({"labelFilter":"1","maxDepth":"20","visibleFilter":"1","boundsFilter":"1","excludedAttributes":""})
        let 聊天页面_Table容器 = type("Table").getOneNodeInfo(10000);
        let 重试次数 = 3
        while (!聊天页面_Table容器 && 重试次数>0){
            iSleep(100)
            const 还在聊天页面 = !!findColor(wechat.聊天页标志)
            if(还在聊天页面){
                聊天页面_Table容器 = type("Table").getOneNodeInfo(10000);
            }
            重试次数--
        }
        if(!聊天页面_Table容器){
            日志打印_error('[聊天页面_Table容器]获取失败！')
            return []
        }
        const Cells = 聊天页面_Table容器.allChildren();
        return Cells
    }

    const 聊天记录 = []
    while (true){
        if(isScriptExit()){break}

        const Cells = 获取所有Cell()
        if(Cells.length <= 0){ break }
        聊天记录.length = 0
        for(let i in Cells){
            if(isScriptExit()) {break}
            const cell = Cells[i];
            const 文本 = cell.allChildren()[0].name;
            if((cell.bounds.bottom - cell.bounds.top) <= 140){
                continue
            }
            if(未转文本语音(文本)){
                if(cell.bounds.top < 140){
                    const step = 500
                    const 滑动距离 = Math.max(140 - cell.bounds.top, 160)
                    日志打印_information(`[上滑动距离]: ${滑动距离}`)
                    if(滑动距离 <= step){
                        滑动(random(730, 800), 1850-滑动距离, random(730, 800), 1850, 600);
                        while(!屏幕区域变化检测(500, 0, 150,160,1890)){
                            if(isScriptExit()){ break }
                            iSleep(100);
                        }
                        聊天记录.length = 0
                        break
                    }else {
                        for(let s=0; s<Math.ceil(滑动距离/step); s++){
                            if(isScriptExit()){ break }
                            滑动(random(730, 800), 1350, random(730, 800), 1850, 600);
                            while(!屏幕区域变化检测(500, 0, 150,160,1890)){
                                if(isScriptExit()){ break }
                                iSleep(100);
                            }
                        }
                        聊天记录.length = 0
                        break
                    }

                }
                if(cell.bounds.bottom > 1906){
                    const step = 500
                    const 滑动距离 = Math.max(cell.bounds.bottom - 1906, 160)
                    日志打印_information(`[下滑动距离]: ${滑动距离}`)
                    if(滑动距离 <= step){
                        滑动(random(730, 800), 1850, random(730, 800), 1850-滑动距离, 600);
                        while(!屏幕区域变化检测(500, 0, 150,160,1890)){
                            if(isScriptExit()){ break }
                            iSleep(100);
                        }
                        聊天记录.length = 0
                        break
                    }else {
                        for(let s=0; s<Math.ceil(滑动距离/step); s++){
                            if(isScriptExit()){ break }
                            滑动(random(730, 800), 1850, random(730, 800), 1350, 600);
                            while(!屏幕区域变化检测(500, 0, 150,160,1890)){
                                if(isScriptExit()){ break }
                                iSleep(100);
                            }
                        }
                        聊天记录.length = 0
                        break
                    }
                }
                let 语音框位置 = null
                if(device_name === 'iPad'){
                    if(文本.startsWith('我,')){
                        语音框位置 = {name: '语音框位置', x: random(1255, 1340), y: cell.bounds.bottom/2 + cell.bounds.top/2};
                    }else {
                        语音框位置 = {name: '语音框位置', x: random(200, 320), y: cell.bounds.bottom/2 + cell.bounds.top/2};
                    }

                }else {
                    if(文本.startsWith('我,')){
                        语音框位置 = {name: '语音框位置', x: random(150, 200), y: cell.bounds.bottom/2 + cell.bounds.top/2};
                    }else {
                        语音框位置 = {name: '语音框位置', x: random(150, 200), y: cell.bounds.bottom/2 + cell.bounds.top/2};
                    }

                }
                语音转文本(语音框位置);
                聊天记录.length = 0
                break
            }
            if(文本.startsWith('我,')){
                const 我的发言= 聊天内容处理('我', 文本)
                聊天记录.push(`我：${我的发言}`)
                logi(`我: ${我的发言}     ${cell.bounds.bottom - cell.bounds.top}`)
            }else {
                const 客户的发言= 聊天内容处理(custmoerName, 文本)
                聊天记录.push(`客户：${客户的发言}`)
                logw(`${custmoerName}: ${客户的发言}    ${cell.bounds.bottom - cell.bounds.top}`)
            }
        }
        if(聊天记录.length > 0){
            break
        }

    }

    return 聊天记录
}

WeChat.prototype.wx_获取聊天页好友昵称 = function (){
    当前执行模块 = 'wx_获取聊天页好友昵称';
    日志打印_debug('开始执行   --- 【wx_获取聊天页好友昵称】')
    setFetchNodeParam({"labelFilter":"2","maxDepth":"6","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
    iSleep(100)
    let 顶部导航 = type("NavigationBar").bounds(0, 40, ScreenWidth, 140).getOneNodeInfo(10000)
    let 重试次数 = 3;
    while (!顶部导航 && 重试次数>0){
        if(isScriptExit()){break}
        iSleep(100)
        const 还在聊天页面 = !!findColor(wechat.页面左上角_返回按钮)
        if(还在聊天页面){
            顶部导航 = type("NavigationBar").bounds(0, 40, ScreenWidth, 140).getOneNodeInfo(10000)
        }else {
            日志打印_error('[页面左上角_返回按钮]未找到！')
        }
        重试次数--;
    }
    if(!顶部导航){
        日志打印_error('NavigationBar 获取失败')
        return null
    }
    let 用户昵称 = null
    const children = 顶部导航.allChildren()

    children.forEach( child =>{
        if(isScriptExit()){return}
        if(child.type === 'Other'){
            用户昵称 = child.name;
        }
    })

    if(用户昵称 === null){
        日志打印_error(`[用户昵称] 获取失败: ${JSON.stringify(children)}`)
        return null
    }
    日志打印_debug(`当前聊天页面名称：${用户昵称}`)
    return 用户昵称
}

WeChat.prototype.wx_获取聊天页好友微信号 = function () {
    当前执行模块 = 'wx_获取聊天页好友微信号';
    日志打印_debug('开始执行   --- 【wx_获取聊天页好友微信号】')
    const 进入_聊天详情页 = 点击后检测(wechat.聊天页_右上角_更多按钮, wechat.聊天页标志, [wechat.好友_聊天详情页])
    switch (进入_聊天详情页) {
        case -100:
            return null
        case -1:
            return null
        case 0:
            break
    }

    const 进入_用户详情页 = 点击后检测(wechat.聊天详情页_用户头像_按钮, wechat.好友_聊天详情页, [wechat.好友_基础资料页面])
    switch (进入_用户详情页) {
        case -100:
            return null
        case -1:
            return null
        case 0:
            break
    }

}

WeChat.prototype.wx_用户详情页获取微信号 = function () {
    当前执行模块 = 'wx_用户详情页获取微信号';
    日志打印_debug('开始执行   --- 【wx_用户详情页获取微信号】')

    setFetchNodeParam({"labelFilter":"1","maxDepth":"20","visibleFilter":"1","boundsFilter":"1","excludedAttributes":""})
    let node = type("Button").label('视频').getOneNodeInfo(10000)
    let 重试次数 = 3;
    while (!node && 重试次数>0){
        if(isScriptExit()){break}
        iSleep(100)
        const 还在用户详情页面 = ocr文本数组匹配(wechat.好友_基础资料页面)
        if(还在用户详情页面){
            node = type("Button").label('视频').getOneNodeInfo(10000)
        }else {
            日志打印_error('[用户详情页]未找到！')
        }
        重试次数--;
    }
    if(!node){
        日志打印_error('[node]节点获取失败！')
        return null
    }
    const children = node.allChildren()
    let 微信号 = null
    let text_微信号_top = -1
    let text_微信号_bottom = -1
    for(let i in children){
        if(isScriptExit()){break}

        const child = children[i]
        if(child.label.startsWith('微信号：')){
            text_微信号_top = child.bounds.top
            text_微信号_bottom = child.bounds.bottom
            continue;
        }
        if(text_微信号_top === child.bounds.top && text_微信号_bottom === child.bounds.bottom){
            微信号 = child.label
            break
        }
    }
    日志打印_debug(`[当前微信号]：${微信号}`)
    return 微信号
}

WeChat.prototype.wx_用户详情页_跳转聊天 = function () {
    当前执行模块 = 'wx_用户详情页_跳转聊天';
    日志打印_debug('开始执行   --- 【wx_用户详情页_跳转聊天】')

    const 用户详情页_发消息按钮 = findColor(wechat.用户详情页_发消息按钮)
    if(!用户详情页_发消息按钮){
        日志打印_error('[用户详情页_发消息按钮]寻找失败！')
        return 0
    }
    const 跳转聊天 = 点击后检测(用户详情页_发消息按钮, wechat.好友_基础资料页面, [wechat.聊天页标志])
    switch (跳转聊天) {
        case -100:
            return -1
        case -1:
            return -1
        case 0:
            return 1
    }
}

WeChat.prototype.wx_进入好友搜索页 = function () {
    当前执行模块 = 'wx_进入好友搜索页';
    日志打印_debug('开始执行   --- 【wx_进入好友搜索页】')

    if(!wechat.wx_切换导航(2)){
        return false
    }
    const 通讯录页_顶部_搜索框 = JSON.parse(JSON.stringify(wechat.顶部_搜索框))
    通讯录页_顶部_搜索框.x = 560
    let 找到_顶部_搜索框 = findColor(通讯录页_顶部_搜索框)
    while(!找到_顶部_搜索框){
        if(isScriptExit()){break}
        const 滑动结果 = 滑动误触检测([通讯录页_顶部_搜索框, wechat.页面左上角_返回按钮, wechat.好友_基础资料页面], random(1015, 1100), random(260, 300), random(1015, 1100), random(1800, 1850),500, 100, 3)
        switch (滑动结果) {
            case 100:
                continue;
            case 0:
                return true
            case 1:
                // 关闭小程序
                const 未知页_关闭结果 = 点击后检测(wechat.左上角_返回按钮, wechat.页面左上角_返回按钮, [通讯录页_顶部_搜索框, wechat.通讯录导航已选择])
                switch (未知页_关闭结果) {
                    case -100:
                        return false;
                    case -1:
                        return false;
                    case 0:
                        return true;
                    case 1:
                        continue;
                }
            case 2:
                // 进入其他页面，点击返回
                const 用户详情页_关闭结果 = 点击后检测(wechat.左上角_返回按钮, wechat.好友_基础资料页面, [通讯录页_顶部_搜索框, wechat.通讯录导航已选择])
                switch (用户详情页_关闭结果) {
                    case -100:
                        return false;
                    case -1:
                        return false;
                    case 0:
                        return true;
                    case 1:
                        continue;
                }
        }
    }

    const 搜索框_进入搜索页 = JSON.parse(JSON.stringify(wechat.顶部_搜索框))
    搜索框_进入搜索页.ex = 560
    const 跳转聊天 = 点击后检测(wechat.通讯录_顶部_搜索框, wechat.通讯录导航已选择, [搜索框_进入搜索页])
    switch (跳转聊天) {
        case -100:
            return false
        case -1:
            return false
        case 0:
            return true
    }
}

WeChat.prototype.wx_搜索好友 = function (好友) {
    /*
     {
        nicheng: '',
        beizhu: '',
        wechatId: '',
    */
    当前执行模块 = 'wx_搜索好友_进入聊天';
    日志打印_debug('开始执行   --- 【wx_搜索好友_进入聊天】')

    const 搜索框_进入搜索页 = JSON.parse(JSON.stringify(wechat.顶部_搜索框))
    搜索框_进入搜索页.ex = 560
    const 已打开键盘 = ocr文本数组匹配(ios.键盘弹出)
    if(!已打开键盘){
        const 搜索框_进入搜索页_位置 = {name: '搜索框_进入搜索页_位置', x: random(330, 1000), y:random(68,100)}
        const 键盘_打开结果 = 点击后检测(搜索框_进入搜索页_位置, 搜索框_进入搜索页, [ios.键盘弹出])
        switch (键盘_打开结果) {
            case -100:
                return false
            case -1:
                return false
            case 0:
                break
        }
    }

    setFetchNodeParam({"labelFilter":"1","maxDepth":"20","visibleFilter":"1","boundsFilter":"1","excludedAttributes":""})
    let 重试次数 = 3
    let node = null
    if(!好友.wechatId.startsWith('wxid_')){
        文本内容输入(好友.wechatId, 搜索框_进入搜索页)
        iSleep(1000)
        node = type('StaticText').label(`微信号:${搜索条件}`).getOneNodeInfo(10000)
        while (!node && 重试次数>0){
            if(isScriptExit()){break}
            const 还在搜索页面 = !!findColor(搜索框_进入搜索页)
            if(还在搜索页面){
                node = type('StaticText').label(`微信号:${搜索条件}`).getOneNodeInfo(10000)
            }
            重试次数--
        }
        if(!node){
            日志打印_error(`[微信号]好友查找失败：${JSON.stringify(好友)}`)
            return false
        }
    }else {
        // 备注搜索
        文本内容输入(好友.beizhu, 搜索框_进入搜索页)
        iSleep(1000)
        node = type('StaticText').labelMatch(`${好友.beizhu}`).getOneNodeInfo(10000)
        while (!node && 重试次数>0){
            if(isScriptExit()){break}
            const 还在搜索页面 = !!findColor(搜索框_进入搜索页)
            if(还在搜索页面){
                node = type('StaticText').labelMatch(`${好友.beizhu}`).getOneNodeInfo(10000)
            }
            重试次数--
        }
        if(!node){
            日志打印_error(`[昵称]好友查找失败：${JSON.stringify(好友)}`)
            return false
        }
        if(好友.beizhu !== node.label && 好友.beizhu !== node.label.replace('昵称:', '')){
            日志打印_error(`[昵称]好友查找[匹配]失败：${JSON.stringify(好友)}  --- ${node.label}`)
            return false
        }
    }
    logi(JSON.stringify(node))
    const 好友搜索结果 = {name: '好友搜索结果', x: node.bounds.left/2+node.bounds.right/2, y:node.bounds.top/2+node.bounds.bottom/2}
    return 好友搜索结果
}