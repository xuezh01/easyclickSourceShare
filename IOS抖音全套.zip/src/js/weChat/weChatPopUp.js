WeChat.prototype.微信弹窗检测 = function (ocr内容, start_time) {
    if (无法收到新消息通知弹窗(ocr内容)) {
        日志打印_debug(`====【ocr处理弹窗】耗时：${time() - start_time} =========`)
        return true
    }
}

无法收到新消息通知 = {
    name: '无法收到新消息通知',
    textArray: ['不再提示', '确定', '无法收到新消息通知'],
    matchCount: 2
}
function 无法收到新消息通知弹窗(ocr内容) {
    let 无法收到新消息 = 弹窗匹配结果(ocr内容, 无法收到新消息通知);
    if(无法收到新消息){
        日志打印_debug('【处理弹窗】 ====无法收到新消息=========')
        const 无法收到新消息_不再提示 = {name: '无法收到新消息_不再提示', x: random(150, 290), y:random(770, 816)};
        点击(无法收到新消息_不再提示);
        return true
    }
    return false
}
