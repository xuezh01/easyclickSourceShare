
function 请求AI回复(account_id, customer_id, customer_name, 聊天记录) {
    日志打印_information('执行【请求AI回复】')
    const url = "http://agi2.ivreal.com:8011/go_private/get_reply"
    const pa =  {
        "reply_data": {
            "userDouyinID": account_id,
            "douyinID": customer_id,
            "conversion_name": customer_name,
            "message": 聊天记录
        },
        "customer_data": {
            "api_key": 脚本运行配置.ai_config.api_key,
            "api_model": "gpt-3.5-turbo-1106",
            "api_base": "https://api.chatanywhere.com.cn/v1",
            "robot_name": 脚本运行配置.ai_config.robot_name,
            "robot_role": 脚本运行配置.ai_config.robot_role,
            "product_name": 脚本运行配置.ai_config.product_name,
            "phone_number": 脚本运行配置.ai_config.phone_number,
            "company_addr": 脚本运行配置.ai_config.company_addr,
            "company_name": 脚本运行配置.ai_config.company_name,
            "robot_gender": 脚本运行配置.ai_config.robot_gender,
            "speaking_style": 脚本运行配置.ai_config.speaking_style,
            "company_values": 脚本运行配置.ai_config.company_values,
            "goal_description": 脚本运行配置.ai_config.goal_description,
            "product_detail": 脚本运行配置.ai_config.product_detail,
            "zhanghao": uid,
            "wechat_number": 脚本运行配置.ai_config.wechat_number,
        }
    }
    /*   回复内容
    {
        "answer": "好的，感谢反馈！",
        "stage": "结束对话",
        "SaleType": {
        "name": "OTHER_MODE",
            "value": 5
    },
        "currentmessage": "",
        "tag": "",
        "human_assistance": "0",
        "must_replay": false
    }*/

    for(let i = 0; i < 2; i++) {
        if (isScriptExit()) { break }
        try{
            const response = http.postJSON(url, JSON.stringify(pa), 60 * 1000, {"Content-Type": "application/json"});
            日志打印_debug(`【请求AI回复】：${response}`);
            if(response){
                const re = JSON.parse(response);
                if(re && re.hasOwnProperty('answer')){
                    return re.answer;
                }
            }
        }catch (e) {
            日志打印_error(`【请求AI回复】 解析失败 catch: ${e}`);
        }
    }
    return
}


function 视频判断(params){
    日志打印_information('开始执行 -- 【视频判断】')
    const start_time = time();

    const headers = {
        "Content-Type": "application/json"
    };
    //不带文件的请求
    var url = ''
    if(uid.includes('外汇测试')){
        日志打印_information('精准视频判断： 外汇行业');
        url = "http://agi2.ivreal.com:8011/screen/video_judgment";
    }
    else if(uid.includes('债务')){
        日志打印_information('精准视频判断： 债务行业');
        url =  "http://agi2.ivreal.com:8011/debt/video_judgment"
    }
    else if(uid.includes('金融')){
        日志打印_information('精准视频判断： 供应链金融|北京');
        url =  "http://agi2.ivreal.com:8011/finance/video_judgment"
    }
    else if(uid.includes('AI')){
        日志打印_information('精准视频判断： AI拓客');
        url = "http://agi2.ivreal.com:8011/ai_product/video_judgment"
    }
    let result = true;
    for(let i = 0; i < 2; i++) {
        if (isScriptExit()) { break }
        var response = http.postJSON(url, params,30 * 1000,headers);
        日志打印_debug("精准视频判断结果： -    " + response);
        if(response){
            try {
                const re = JSON.parse(response);
                result =  re['result']["videoFilte"];
                break;
            }catch (e) {
                日志打印_error(`【视频判断】 解析失败 catch: ${e}`);
                result = true;
            }
        }
    }
    日志打印_warning(`【视频判断 耗时】：${time()-start_time}`);
    return result;
}

function 视频是否已经获取(内容) {
    logd('判断视频内容为:{}',内容)
    var url = "http://47.108.92.250:2024/look_kw_in_DataBase"
    var params = {'videoContent':内容}
    var r = http.postJSON(url,params,180 * 1000)
    if (r){
        var r_json = JSON.parse(r)
        if (r_json['state'] === 200 || r_json['state'] === '200'){
            if (r_json['result']['mohu'] || r_json['result']['mohu'] === 'true'){
                return true
            }
        }
    }
    return false
}




// 视频判断()

//私信第一句话