
const 快手流程信息配置 = {
    // 24小时制
    '私信时间段_起': 14,
    '私信时间段_止': 15,
    '评论抓取_起': 18,
    '评论抓取_止': 19,
    '抓取关键词': '债务重组',
    '抓取视频截止日期': '2023-07-20'
}


function 快手流程调度() {
    while (true){
        if(isScriptExit()){ break }

        while(评论抓取时间段()){
            if(isScriptExit()){ break }
            ks_startKeywordSearch('qiuqiu', 快手流程信息配置.抓取关键词, 快手流程信息配置.抓取视频截止日期)
        }

        while(私信发送时间段()){
            if(isScriptExit()){ break }
            ks_startSendCustomerMsg('qiuqiu')
        }

        while (!评论抓取时间段() && !私信发送时间段()){
            if(isScriptExit()){ break }
            ks_startYanghao()
        }
    }

}

function 评论抓取时间段(){
    if (快手流程信息配置.评论抓取_止 <= 快手流程信息配置.评论抓取_起){
        return getNowHour() >= 快手流程信息配置.评论抓取_起 || getNowHour() < 快手流程信息配置.评论抓取_止
    }
    else {
        return 快手流程信息配置.评论抓取_起 <= getNowHour() && getNowHour() < 快手流程信息配置.评论抓取_止
    }
}

function 私信发送时间段(){
    if (获取今日已发送私信数量() >= 30){
        return false
    }
    if (快手流程信息配置.私信时间段_止 <= 快手流程信息配置.私信时间段_起){
        return getNowHour() >= 快手流程信息配置.私信时间段_起 || getNowHour() < 快手流程信息配置.私信时间段_止
    }
    else {
        return 快手流程信息配置.私信时间段_起 <= getNowHour() && getNowHour() < 快手流程信息配置.私信时间段_止
    }
}

