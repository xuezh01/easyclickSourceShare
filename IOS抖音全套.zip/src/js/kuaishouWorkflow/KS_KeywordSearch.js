

function ks_startKeywordSearch(uid, 关键词,截止日期){
    打印日志 = true;
    ks.初始化();
    ks.ks_启动快手();
    ks.ks_右上角搜索按钮点击();
    ks.ks_搜索页面输入查询(关键词);
    ks.ks_搜索结果分类话题选择();

    const 已浏览话题 = [];
    let tryCount = 5;
    while (tryCount > 0){
        if(isScriptExit()){ break }
        if(!评论抓取时间段()){ break }
        logw('【快手脚本】评论抓取时间段')

        let 无新话题 = 0;
        const 话题排序 = ks.ks_话题播放量排序();
        for(const i in 话题排序){
            if(isScriptExit()){ break }
            if(!评论抓取时间段()){ break }
            const 选择话题 = 话题排序[i];
            if (已浏览话题.includes(选择话题.name)){
                continue;
            }
            已浏览话题.push(选择话题.name);
            无新话题++;
            const 进入结果 = ks.ks_进入话题详情页(选择话题);
            if(!进入结果){ continue; }
            const 话题_有最新视频内容 = ks.ks_话题视频_选择最新();
            if(!话题_有最新视频内容){continue};
            let 上个视频信息 = null;
            let 无更多视频 = 0;
            while(true){
                if(isScriptExit()){ break }
                const 视频信息 = ks.ks_视频信息采集();
                if(视频信息 === 上个视频信息){
                    无更多视频++;
                }else {
                    无更多视频 = 0;
                }
                if(无更多视频 > 5){
                    break;
                }
                上个视频信息 = 视频信息;
                if (视频信息.评论数量 === 0){
                    ks.ks_上滑切换视频();
                    continue;
                }
                // if(!日期比较(视频信息.发布日期, 截止日期)) {break}

                const data = 对比快手视频信息(uid, 视频信息.作者, 视频信息.name, 视频信息.评论数量, 视频信息.发布日期, 视频信息.类型, 选择话题.name);
                logd('快手信息对比:{}',JSON.stringify(data))
                if(!data){
                    ks.ks_上滑切换视频();
                    continue;
                }
                const videoSid = data.videoSid;
                const 精准度 = data.Filte; // -1未判断 0不精准 1精准
                let history_commentCount =  data.kuaishou_commentCount;
                if(视频信息.评论数量 - history_commentCount <= 0){
                    ks.ks_上滑切换视频();
                    continue;
                }
                if(精准度 === -1){
                    //精准度判断
                    // 判断结果 === 精准
                    var params = {
                        "api_key":"",
                        "api_base":"",
                        "videoContent": 视频信息['name'],
                        "keyword": 关键词,
                        "hangye": "债务重组"
                    }
                    var return_shipin = 视频判断(params)
                    let 视频结果 = ''
                    if (return_shipin !== null){
                        视频结果 = return_shipin['job']['videoFilte']
                        if (视频结果 !== undefined && 视频结果 !== 'true' && !视频结果){
                            更新视频精准度(uid,视频信息.作者,视频信息.发布日期,视频信息.类型,0)
                            ks.ks_上滑切换视频();
                            continue;
                        }else {
                            更新视频精准度(uid,视频信息.作者,视频信息.发布日期,视频信息.类型,1)
                        }
                    }else {
                        logi("=======视频精准度判断接口出错=======")
                    }
                }

                ks.ks_进入评论区(视频信息);
                ks.ks_多worker获取用户评论信息(videoSid,视频信息['name']);
                ks.ks_关闭评论区();
                ks.ks_上滑切换视频();
            };
            ks.ks_返回话题搜索页();
        }
        ks.ks_话题栏上滑刷新话题();
        if(无新话题 === 0){
            tryCount--;
        }
    }
}