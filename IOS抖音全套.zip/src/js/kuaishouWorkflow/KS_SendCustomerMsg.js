
function ks_startSendCustomerMsg(uid,sendText) {
    打印日志 = true;

    ks.初始化();
    ks.ks_启动快手();
    ks.ks_右上角搜索按钮点击();
    const result = 获取快手可私信用户(uid)
    if(!result){
        loge('【获取快手可私信用户】服务器数据请求失败！')
        return
    }
    const followCustomer = result;
    const 已使用的快手IDs = [];
    for (const i in followCustomer){
        if(isScriptExit()) {break}
        if(!私信发送时间段()) {break}
        logw('【快手脚本】私信发送时间段')

        if (获取今日已发送私信数量() >= 30) {break}
        const 快手ID = followCustomer[i].kuaishou_id;
        if(已使用的快手IDs.includes(快手ID)){
            continue;
        }
        已使用的快手IDs.push(快手ID);
        ks.ks_搜索页面输入查询(快手ID);
        const 找到用户 = ks.ks_用户快手号匹配();
        if(!找到用户){
            更新快手私信用户状态(uid, 快手ID, 2)
            continue;
        }
        ks.ks_进入搜索用户私信页面();
        const 私信发送结果 = ks.ks_私信发送(sendText, 快手ID);
        if(私信发送结果){
            logd('发送成功 ++')
            更新今日已发送私信数量();
        }else {
            logd('之前已发送')
        }
        更新快手私信用户状态(uid, 快手ID, 1);
        ks.ks_退出私信页面()
    }

}

function 获取今日已发送私信数量() {
    const dd = new Date();
    const year = dd.getFullYear();
    const month = String(dd.getMonth() + 1).padStart(2, '0');
    const day = String(dd.getDate()).padStart(2, '0');
    const formattedDate = `${year}-${month}-${day}`;
    logd(formattedDate);
    const 今日已发送私信数量string = readConfigString(formattedDate);
    const parsedNumber = parseInt(今日已发送私信数量string, 0);
    const 今日已发送私信数量 = isNaN(parsedNumber)? 0 : parsedNumber;
    logd(`今日已发送私信数量: ${今日已发送私信数量}`)
    return 今日已发送私信数量
}

function 更新今日已发送私信数量() {
    const count = 获取今日已发送私信数量() + 1;
    const dd = new Date();
    const year = dd.getFullYear();
    const month = String(dd.getMonth() + 1).padStart(2, '0');
    const day = String(dd.getDate()).padStart(2, '0');
    const formattedDate = `${year}-${month}-${day}`;
    updateConfig(formattedDate, count)
}