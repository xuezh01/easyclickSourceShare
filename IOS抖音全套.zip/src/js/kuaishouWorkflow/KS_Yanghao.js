
function ks_startYanghao() {
    while (!评论抓取时间段() && !私信发送时间段()){
        if(isScriptExit()){return}
        logw('【快手脚本】养号时间段')
        ks.初始化();
        ks.ks_启动快手();
        let 定次数重启 = 0;
        while(!评论抓取时间段() && !私信发送时间段()){
            if(isScriptExit()){return}

            logw('【快手脚本】养号时间段')
            if(isScriptExit()){ break }
            ks.ks_上滑切换视频();
            iSleep(random(20000, 100000));
            定次数重启++;
            if(定次数重启 > 100){
                break
            }
        }
    }

}