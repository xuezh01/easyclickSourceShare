
const APIServer = 'http://47.108.92.250:8888';
// const APIServer = 'http://192.168.0.119:9999';



function api_设备uid查询() {
    const queryUrl = `${APIServer}/get_device_bind_uid?device_id=${encodeURI(device_id)}`
    while (true){
        if(isScriptExit()) {break}
        try {
            const response = http.httpGet(queryUrl, {}, 30 * 1000, {'Content-Type': 'application/json'});
            日志打印_debug(`【设备uid查询】：${response}`)
            const result = JSON.parse(response)
            if (result.code === 200) {
                return result;
            }
        }catch (e) {
            日志打印_error(`【设备uid查询】 请求失败catch: ${e}`);
        }
        日志打印_error(`【设备uid查询】 正在重试！`);
        iSleep(500)
    }
}

function api_设备信息更新(uid) {
    日志打印_information('开始执行 -- 【api_设备信息更新】')
    const bindUrl = `${APIServer}/device_bind_uid`;
    const data = {
        "device_id": device_id,
        "device_name": device_name,
        "device_os_version": device_version,
        "device_expiration_time": device_expiration_time,
        "uid":uid
    }
    for(let i=0; i<3; i++){
        const bind_result = http.postJSON(bindUrl, data, 100000, {'Content-Type': 'application/json'})
        日志打印_debug(`【api_设备信息更新】：${bind_result}`);

        try{
            logi(`【api_设备信息更新】：${bind_result}`)
            const bind_state = JSON.parse(bind_result);
            if(bind_state.code === 200){
                //绑定成功
                return true
            }
        }catch (e) {
            日志打印_error(`【api_设备信息更新】 请求失败catch: ${e}`);
            return false
        }
    }
    return false
}

function api_更新账号今日私信信息(设备抖音账号信息) {
    日志打印_information('开始执行 -- 【更新账号今日私信信息】')
    const queryUrl = `${APIServer}/update_device_app_account`;
    const data = [
        {
            "account_id": "12345",
            "account_name": "测试111",
            "belong_uid": "外汇",
            "account_type": "Facebook",
            "belong_device_id": "352dc4327a0839c2e5f48aa6db14f4f4dfbd3597",
            "account_state": "",
            "account_information": "其他信息",
            "send_count": 2,
            "send_failed_count": 3,
            "send_pinfan_count": 0,
        },
        {
            "account_id": "56789",
            "account_name": "测试222",
            "belong_uid": "外汇",
            "account_type": "Facebook",
            "belong_device_id": "352dc4327a0839c2e5f48aa6db14f4f4dfbd3597",
            "account_state": "私信被禁言",
            "account_information": "",
            "send_count": 0,
            "send_failed_count": 0,
            "send_pinfan_count": 0,
        }
    ];
    while (true){
        if(isScriptExit()){break}
        try{
            const response = http.postJSON(queryUrl, JSON.stringify(设备抖音账号信息), 10000,{'Content-Type': 'application/json'})
            日志打印_debug(`【更新账号今日私信信息】：${response}`);
            const result = JSON.parse(response)
            if(result.code === 200){
                return result.data
            }
        }catch (e) {
            日志打印_error(`【更新账号今日私信信息】 请求失败catch: ${e}`);
        }
        iSleep(500)
    }
}

function api_获取视频是否已观看(视频信息) {
    日志打印_information('开始执行 -- 【获取视频是否已观看】')
    const queryUrl = `${APIServer}/viewed_video`;
    const data = {
        "account_id": "ssss",
        "account_type": "抖音",
        "belong_uid": "外汇",
        "belong_device_id": "352dc4327a0839c2e5f48aa6db14f4f4dfbd3597",
        "video_keyword": "外汇行情不好",
        "video_up_id": "98765",
        "video_up_name": "测试博主",
        "video_type": "视频",
        "video_comment_count": 1200,
        "video_title": "外汇行情不好，来一起交流",
        "video_up_homepage": "http://example.com",
        "video_up_information": ""
}
    while (true){
        if(isScriptExit()){break}
        try{
            const response = http.postJSON(queryUrl, 视频信息, 10000,{'Content-Type': 'application/json'})
            日志打印_debug(`【获取视频是否已观看】：${response}`);
            const result = JSON.parse(response)
            if(result.code === 200){
                日志打印_warning(`【获取视频是否已观看】：${result.message}`);
                return result.result
            }
        }catch (e) {
            日志打印_error(`【获取视频是否已观看】 请求失败catch: ${e}`);
        }
        iSleep(500)
    }
}

function api_记录视频留痕(留痕记录) {
    日志打印_information('开始执行 -- 【记录视频留痕】')
    const queryUrl = `${APIServer}/update_viewed_video_leave_traces_account`;
    const data = {
        "video_sid": 6,
        "account_id": "抖音22",
    }
    while (true){
        if(isScriptExit()){break}
        try{
            const response = http.postJSON(queryUrl, 留痕记录, 10000,{'Content-Type': 'application/json'})
            日志打印_debug(`【记录视频留痕】：${response}`);
            const result = JSON.parse(response)
            if(result.code === 200){
                日志打印_warning(`【记录视频留痕】：${result.message}`);
                return true
            }
        }catch (e) {
            日志打印_error(`【获取视频是否已观看】 请求失败catch: ${e}`);
        }
        iSleep(500)
    }
}

function api_记录视频精准度(视频判断结果记录) {
    日志打印_information('开始执行 -- 【api_记录视频精准度】')
    const queryUrl = `${APIServer}/update_viewed_video_accuracy`;
    // const data = {
    //     "video_sid": 6,
    //     "accuracy": "p1",
    // }

    while (true){
        if(isScriptExit()){break}
        try{
            const response = http.postJSON(queryUrl, 视频判断结果记录, 10000,{'Content-Type': 'application/json'})
            日志打印_debug(`【记录视频精准度】：${response}`);
            const result = JSON.parse(response)
            if(result.code === 200){
                日志打印_warning(`【记录视频精准度】：${result.message}`);
                return true
            }
        }catch (e) {
            日志打印_error(`【记录视频精准度】 请求失败catch: ${e}`);
        }
        iSleep(500)
    }
}

function api_插入视频评论用户(用户信息) {
    日志打印_information('开始执行 -- 【插入视频评论用户】')
    const queryUrl = `${APIServer}/insert_video_comment`;
    const data = {
        "video_sid": 6,
        "belong_account_id": '测试',
        "customer_name": 用户信息.name,
        "customer_id": 用户信息.douyinID,
        "customer_comment_time": 用户信息.commentTime,
        "customer_ip_location": 用户信息.ip,
        "customer_comment": 用户信息.comment,
        "customer_homepage_img": 用户信息.customer_homepage_img,
    }
    while (true){
        if(isScriptExit()){break}
        try{
            const response = http.postJSON(queryUrl, 用户信息, 10000,{'Content-Type': 'application/json'})
            日志打印_debug(`【插入视频评论用户】：${response}`);
            const result = JSON.parse(response)
            if(result.code === 200){
                日志打印_warning(`【插入视频评论用户】：${result.message}`);
                return true
            }
        }catch (e) {
            日志打印_error(`【插入视频评论用户】 请求失败catch: ${e}`);
        }
        iSleep(500)
    }
}

function api_记录当前账号已发送私信id() {
    日志打印_information('开始执行 -- 【记录当前账号已发送私信id】')
    const queryUrl = `${APIServer}/record_customer_id`;
    const data = {
        "account_id": '123123',
        "account_type": "抖音",
        "send_customer_id": "",
        "last_send_customer_id": "",
    }
    while (true){
        if(isScriptExit()){break}
        try{
            const response = http.postJSON(queryUrl, data, 10000,{'Content-Type': 'application/json'})
            日志打印_debug(`【记录当前账号已发送私信id】：${response}`);
            const result = JSON.parse(response)
            if(result.code === 200){
                日志打印_warning(`【记录当前账号已发送私信id】：${result.message}`);
                return true
            }
        }catch (e) {
            日志打印_error(`【记录当前账号已发送私信id】 请求失败catch: ${e}`);
        }
        iSleep(1000)
    }
}

function api_记录跟进用户(data) {
    日志打印_information('开始执行 -- 【记录跟进用户】')
    const queryUrl = `${APIServer}/record_follow_customer`;
    // const data = {
    //     "belong_uid": '123123',
    //     "belong_device_id": "sdascasdasdasd",
    //     "belong_app_account_id": "dyid",
    //     "belong_app_account_type": "抖音",
    //     "follow_type": "点赞评论",
    //     "follow_customer_name": "测试",
    //     "follow_customer_id": "888888",
    //     "follow_customer_comment": "",
    //     "follow_customer_replay_msg": "三十多岁",
    //     "follow_img": 区域截图base64(0,0,ScreenWidth, ScreenHeight),
    // }
    while (true){
        if(isScriptExit()){break}
        try{
            const response = http.postJSON(queryUrl, data, 10000,{'Content-Type': 'application/json'})
            日志打印_debug(`【记录跟进用户】：${response}`);
            const result = JSON.parse(response)
            if(result.code === 200){
                日志打印_warning(`【记录跟进用户】：${result.message}`);
                return true
            }
        }catch (e) {
            日志打印_error(`【记录跟进用户】 请求失败catch: ${e}`);
        }
        iSleep(1000)
    }
}

function api_获取本设备账号跟进任务(设备抖音账号信息) {
    日志打印_information('开始执行 -- 【获取本设备账号跟进任务】')
    const queryUrl = `${APIServer}/get_task_by_account`;
    const data = []
    设备抖音账号信息.forEach( account =>{
        data.push(
            {
                "account_id": account.account_id,
                "belong_uid": account.belong_uid,
                "account_type": account.account_type,
            }
        )
    })
    while (true){
        if(isScriptExit()){break}
        try{
            日志打印_error(`【获取本设备账号跟进任务】 设备抖音账号信息: ${JSON.stringify(data)}`);

            const response = http.postJSON(queryUrl, JSON.stringify(data), 10000,{'Content-Type': 'application/json'})
            日志打印_debug(`【获取本设备账号跟进任务】：${response}`);
            const result = JSON.parse(response)
            if(result.code === 200){
                return result.data
            }
        }catch (e) {
            日志打印_error(`【获取本设备账号跟进任务】 请求失败catch: ${e}`);
        }
        iSleep(1000)
    }
}

function api_跟进任务执行成功(data) {
    日志打印_information('开始执行 -- 【跟进任务执行成功】')
    const queryUrl = `${APIServer}/finished_task_by_account`;
    // const data = {
    //     "task_id": "ssss",
    //     "focus_customer_record_id": "抖音",
    //     "task_state": "外汇"
    //
    // }
    while (true){
        if(isScriptExit()){break}
        try{
            const response = http.postJSON(queryUrl, data, 10000,{'Content-Type': 'application/json'})
            日志打印_debug(`【跟进任务执行成功】：${response}`);
            const result = JSON.parse(response)
            if(result.code === 200){
                日志打印_warning(`【跟进任务执行成功】：${result.message}`);
                return result.result
            }
        }catch (e) {
            日志打印_error(`【跟进任务执行成功】 请求失败catch: ${e}`);
        }
        iSleep(500)
    }
}

var 测试环境 = false
function api_获取一条账号今日可私信数据(account_type, account_id) {
    日志打印_information('开始执行 -- 【api_获取一条账号今日可私信数据】')
    let queryUrl = `${APIServer}/ec_get_one_chat_task?account_type=${encodeURI(account_type)}&who_get=${account_id}&belong_uid=${encodeURI(uid)}`;
    // if(测试环境){
    //     queryUrl = `http://192.168.0.119:9999/ec_get_one_chat_task_ts?account_type=${encodeURI(account_type)}&who_get=${account_id}&belong_uid=${encodeURI('外环外')}`;
    // }
    // logd(queryUrl)
    // const data = {
    //     "task_id": "ssss",
    //     "focus_customer_record_id": "抖音",
    //     "task_state": "外汇"
    //
    // }
    while (true){
        if(isScriptExit()){break}
        try{
            const response = http.httpGet(queryUrl, '', 10000,{'Content-Type': 'application/json'})
            日志打印_debug(`【获取账号今日可私信数据】：${response}`);
            const result = JSON.parse(response)
            if(result.state === 200){
                return result.data
            }
        }catch (e) {
            日志打印_error(`【api_获取一条账号今日可私信数据】 请求失败catch: ${e}`);
        }
        iSleep(500)
    }
}


function api_查看是否还有私信数据(account_type) {
    日志打印_information('开始执行 -- 【api_查看是否还有私信数据】')
    let queryUrl = `${APIServer}/ec_get_have_data?account_type=${encodeURI(account_type)}&belong_uid=${encodeURI(uid)}`;
    // if(测试环境){
    //     queryUrl = `http://192.168.0.119:9999/ec_get_have_data_ts?account_type=${encodeURI(account_type)}&belong_uid=${encodeURI('外环外')}`;
    // }
    日志打印_information(`开始执行 -- 【api_查看是否还有私信数据】${queryUrl}`)

    while (true){
        if(isScriptExit()){break}
        try{
            const response = http.httpGet(queryUrl, '', 10000,{'Content-Type': 'application/json'})
            日志打印_debug(`【api_查看是否还有私信数据】：${response}`);
            const result = JSON.parse(response)
            if(result.state === 200){
                if(result.data !== 0){
                    return true
                }
                return false
            }
        }catch (e) {
            日志打印_error(`【api_查看是否还有私信数据】 请求失败catch: ${e}`);
        }
        iSleep(500)
    }
}

function api_记录账号今日已私信数据(aaci_atid, account_id, is_chat) {
    日志打印_information('开始执行 -- 【api_记录账号今日已私信数据】')
    const queryUrl = `${APIServer}/set_app_chat_task_is_chat`;
    logd(queryUrl)
    const data = {
        "aaci_atid": aaci_atid,
        "account_id": account_id,
        "is_chat": is_chat,
    }
    while (true){
        if(isScriptExit()){break}
        try{
            const response = http.postJSON(queryUrl, data, 10000,{'Content-Type': 'application/json'})
            日志打印_debug(`【api_记录账号今日已私信数据】：${response}`);
            const result = JSON.parse(response)
            if(result.state === 200){
                return true
            }
        }catch (e) {
            日志打印_error(`【api_记录账号今日已私信数据】 请求失败catch: ${e}`);
        }
        iSleep(500)
    }
}

function api_记录风控日志(account_type, account_id, msg_type, msg) {
    日志打印_information('开始执行 -- 【api_记录风控日志】')
    const queryUrl = `${APIServer}/insert_risk_control`;
    const data = {
        "device_id": device_id,
        "uid": uid,
        "account_type": account_type,
        "account_id": account_id,
        "msg_type": msg_type,
        "msg": msg,
    }
    http.postJSON(queryUrl, data, 10000,{'Content-Type': 'application/json'})
}

function api_上传设备状态(msg) {
    日志打印_information('开始执行 -- 【api_上传设备状态】')
    const queryUrl = `${APIServer}/put_m_msg_to_frontend`;
    const data = {
        "device_id": device_id,
        "msg_to_frontend": JSON.stringify(msg),
    }
    const res = http.postJSON(queryUrl, data, 10000,{'Content-Type': 'application/json'})
    日志打印_information(`【api_上传设备状态】：${res}`)
    try{
        const result = JSON.parse(res)
        if(result.state === 200){
            if(result.msg && JSON.stringify(result.msg) !== '{}'){
                return result.msg.msg_to_device
            }
        }
    }catch (e) {
        日志打印_error(`【api_上传设备状态】 请求失败catch: ${e}`);
    }
    return null
}

function api_获取prompt(uid, account_type) {
    日志打印_information('开始执行 -- 【api_获取prompt】')
    const queryUrl = `${APIServer}/get_prompt`;
    const data = {
        "uid": uid,
        "account_type": account_type,
    }
    while (true){
        if(isScriptExit()){break}
        try{
            const response = http.postJSON(queryUrl, data, 10000,{'Content-Type': 'application/json'})
            日志打印_debug(`【api_获取prompt】：${response}`);
            const result = JSON.parse(response)
            if(result.code === 200){
                return result.result[0]
            }
        }catch (e) {
            日志打印_error(`【api_获取prompt】 请求失败catch: ${e}`);
        }
        iSleep(500)
    }
}

function api_判断视频精准度(uid, account_type, up_name, keyword, videoContent) {
    日志打印_information('开始执行 -- 【api_判断视频精准度】')
    const prompt_text = api_获取prompt(uid, account_type)
    日志打印_debug(`【api_判断视频精准度】prompt_text：${prompt_text.prompt}`);
    try{
        const prompt = JSON.parse(prompt_text.prompt)
        if(!prompt.hasOwnProperty('video_api')){
            日志打印_error(`【api_判断视频精准度】 video_api 缺失！`);
            return true
        }
        const video_api = prompt.video_api
        const products_services = prompt.products_services || ''
        const detailed_requirements = prompt.detailed_description || ''
        const requirement_keywords = prompt.requirement_keywords || ''
        const data = {
            "uid": uid,
            "videoContent": videoContent,
            "keyword": keyword,
            "products_services": products_services,
            "detailed_requirements": detailed_requirements,
            "requirement_keywords": requirement_keywords,
            "up_name": up_name,
        }
        let 重试次数 = 3
        while (重试次数 > 0){
            if(isScriptExit()){break}
            try{
                const response = http.postJSON(video_api, data, 10000,{'Content-Type': 'application/json'})
                日志打印_debug(`【api_判断视频精准度】：${response}`);
                if(response){
                    try {
                        const re = JSON.parse(response);
                        return re['result']["videoFilte"];
                    }catch (e) {
                        日志打印_error(`【api_判断视频精准度】 response 解析失败 catch: ${e}`);
                    }
                }
            }catch (e) {
                日志打印_error(`【api_判断视频精准度】 请求失败catch: ${e}`);
            }
            重试次数--
            iSleep(500)
        }
        return true

    }catch (e) {
        日志打印_error(`【api_判断视频精准度】 prompt 解析失败: ${e}`);
        return true
    }
}

function api_获取检索关键词(account_type, account_id) {
    日志打印_information('开始执行 -- 【api_获取检索关键词】')
    const queryUrl = `${APIServer}/ec_get_one_key_word_task`;
    const data = {
        "belong_uid": uid,
        "account_type": account_type,
        "who_get_account_id": account_id,
        "who_get_device_id": device_id }
    while (true){
        if(isScriptExit()){break}
        try{
            const response = http.postJSON(queryUrl, data, 10000,{'Content-Type': 'application/json'})
            日志打印_debug(`【api_获取检索关键词】：${response}`);
            const result = JSON.parse(response)
            if(result.state === 200){
                return result.data
            }
        }catch (e) {
            日志打印_error(`【api_获取检索关键词】 请求失败catch: ${e}`);
        }
        iSleep(2000)
    }
}

function api_更新关键词状态(katid) {
    日志打印_information('开始执行 -- 【api_更新关键词状态】')
    const queryUrl = `${APIServer}/update_key_word_task_state`;
    const data = {
        "katid": katid,
        "state": 1
       }
    while (true){
        if(isScriptExit()){break}
        try{
            const response = http.postJSON(queryUrl, data, 10000,{'Content-Type': 'application/json'})
            日志打印_debug(`【api_更新关键词状态】：${response}`);
            const result = JSON.parse(response)
            if(result.state === 200){
                return
            }
        }catch (e) {
            日志打印_error(`【result.data】 请求失败catch: ${e}`);
        }
        iSleep(2000)
    }
}

function api_昵称检索用户列表识别(name_list) {
    日志打印_information('开始执行 -- 【api_昵称检索用户列表识别】')
    const queryUrl = `${APIServer}/exists_GrabCustomer_key_word_by_similary`;

    const data = {
        "belong_uid": 'ivreal',
        "name_list": JSON.stringify(name_list)
    }
    日志打印_debug(`【api_昵称检索用户列表识别】：${JSON.stringify(data)}`);

    while (true){
        if(isScriptExit()){break}
        try{
            const response = http.postJSON(queryUrl, data, 10000,{'Content-Type': 'application/json'})
            日志打印_debug(`【api_昵称检索用户列表识别】：${response}`);
            const result = JSON.parse(response)
            if(result.state === 200){
                const found = result.found
                if(!found || found === null || found === 'null' || found === '' || found === undefined){
                    return []
                }
                return found
            }
        }catch (e) {
            日志打印_error(`【api_昵称检索用户列表识别】 请求失败catch: ${e}`);
        }
        iSleep(2000)
    }
}

function api_昵称检索插入用户(data) {
    日志打印_information('开始执行 -- 【api_昵称检索用户列表识别】')
    const queryUrl = `${APIServer}/inser_customer_in_GrabCustomer_key_word`;


    while (true){
        if(isScriptExit()){break}
        try{
            const response = http.postJSON(queryUrl, data, 10000,{'Content-Type': 'application/json'})
            日志打印_debug(`【api_昵称检索用户列表识别】：${response}`);
            const result = JSON.parse(response)
            if(result.state === 200){
                return
            }
        }catch (e) {
            日志打印_error(`【api_昵称检索用户列表识别】 请求失败catch: ${e}`);
        }
        iSleep(2000)
    }
}

function api_获取昵称关键词(account_type, account_id) {
    日志打印_information('开始执行 -- 【api_获取昵称关键词】')
    const queryUrl = `${APIServer}/ec_get_one_key_word_task_name`;
    const data = {
        "belong_uid": uid,
        "account_type": account_type,
        "who_get_account_id": account_id,
        "who_get_device_id": device_id }
    while (true){
        if(isScriptExit()){break}
        try{
            const response = http.postJSON(queryUrl, data, 10000,{'Content-Type': 'application/json'})
            日志打印_debug(`【api_获取昵称关键词】：${response}`);
            const result = JSON.parse(response)
            if(result.state === 200){
                return result.data
            }
        }catch (e) {
            日志打印_error(`【api_获取昵称关键词】 请求失败catch: ${e}`);
        }
        iSleep(2000)
    }
}

function api_更新昵称关键词状态(katid) {
    日志打印_information('开始执行 -- 【api_更新昵称关键词状态】')
    const queryUrl = `${APIServer}/update_key_word_task_state_name`;
    const data = {
        "katid": katid,
        "state": 1
    }
    while (true){
        if(isScriptExit()){break}
        try{
            const response = http.postJSON(queryUrl, data, 10000,{'Content-Type': 'application/json'})
            日志打印_debug(`【api_更新昵称关键词状态】：${response}`);
            const result = JSON.parse(response)
            if(result.state === 200){
                return
            }
        }catch (e) {
            日志打印_error(`【api_更新昵称关键词状态】 请求失败catch: ${e}`);
        }
        iSleep(2000)
    }
}

function api_获取私信话术(account_type, account_id) {
    日志打印_information('开始执行 -- 【api_获取私信话术】')
    const queryUrl = `${APIServer}/ai_get_script`;
    const data = {
        "belong_uid": uid,
        "account_type": account_type,
        "account_id": account_id,
        "device_id": device_id
    }
    while (true){
        if(isScriptExit()){break}
        try{
            const response = http.postJSON(queryUrl, data, 10000,{'Content-Type': 'application/json'})
            日志打印_debug(`【api_获取私信话术】：${response}`);
            const result = JSON.parse(response)
            if(result.state === 200){
                const msg = result.chat_script
                if(msg === ''){
                    脚本当前运行阶段 = '无话术可用'
                    日志打印_error(`【api_获取私信话术】 无话术可用`);
                    iSleep(2000)
                    continue
                }
                return msg
            }
        }catch (e) {
            日志打印_error(`【api_获取私信话术】 请求失败catch: ${e}`);
        }
        iSleep(2000)
    }
}