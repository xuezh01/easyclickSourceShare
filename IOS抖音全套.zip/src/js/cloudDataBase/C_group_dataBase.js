const url = 'http://47.108.92.250:8888'

function 博主信息插入(blogger_id,blogger_name,blogger_main_page,filte,have_group) {
    const bolgger_url = `${url}/insert_blogger_information`
    const data = {
        "blogger_id":blogger_id,
        "blogger_name":blogger_name,
        "blogger_main_page":blogger_main_page,
        "filte":filte,
        "have_group":have_group
    }
    let r = http.postJSON(bolgger_url,JSON.stringify(data), 30 * 1000, {"key-word": "test"})
    let result = null;
    if(r){
        try {
            const response = JSON.parse(r);
            if(response.state === 200){
                result = response.result;
            }else {
                日志打印_error(`【博主信息插入】 请求失败: ${r}`);
            }
        }catch (e) {
            日志打印_error(`【博主信息插入】 解析 catch: ${e}`);
        }
    }
    return result;
}

function 群聊息插入(group_name,belong_blogger_id,join_condition,is_join,is_follow,is_wait_for_consent,group_member) {
    const bolgger_url = `${url}/insert_Fans_group`
    const data = {
        "group_name":group_name,
        "belong_blogger_id":belong_blogger_id,
        "join_condition":join_condition,
        "is_join":is_join,
        "is_follow":is_follow,
        "is_wait_for_consent":is_wait_for_consent,
        "group_member": parseInt(group_member)
    }
    let r = http.postJSON(bolgger_url,JSON.stringify(data), 30 * 1000, {"key-word": "test"})
    let result = null;
    if(r){
        try {
            const response = JSON.parse(r);
            if(response.state === 200){
                result = response.result;
            }else {
                日志打印_error(`【群聊息插入】 请求失败: ${r}`);
            }
        }catch (e) {
            日志打印_error(`【群聊息插入】 解析 catch: ${e}`);
        }
    }
    return result;
}

function 群成员信息插入(fans_id,group_id,fans_name,filte,is_chat,is_chat_time,main_page,work_information) {
    const bolgger_url = `${url}/insert_Fans_list`
    const data = {
        "fans_id":fans_id,
        "group_id":group_id,
        "fans_name":fans_name,
        "filte":filte,
        "is_chat":is_chat,
        "is_chat_time":is_chat_time,
        "main_page":main_page,
        "work_information":work_information
    }
    let r = http.postJSON(bolgger_url,JSON.stringify(data), 30 * 1000, {"key-word": "test"})
    let result = null;
    if(r){
        try {
            const response = JSON.parse(r);
            if(response.state === 200){
                result = response.result;
            }else {
                 日志打印_error(`【群成员信息插入】 请求失败: ${r}`);
            }
        }catch (e) {
            日志打印_error(`【群成员信息插入】 解析 catch: ${e}`);
        }
    }
    return result;
}

function 博主信息更新(blogger_id,filte,have_group) {
    const bolgger_url = `${url}/update_blogger_information`
    const data = {
        "blogger_id":blogger_id,
        "filte":filte,
        "have_group":have_group
    }
    let r = http.postJSON(bolgger_url,JSON.stringify(data), 30 * 1000, {"key-word": "test"})
    let result = null;
    if(r){
        try {
            const response = JSON.parse(r);
            if(response.state === 200){
                result = response.result;
            }else {
                日志打印_error(`【博主精准信息更新】 请求失败: ${r}`);
            }
        }catch (e) {
            日志打印_error(`【博主精准信息更新】 解析 catch: ${e}`);
        }
    }
    日志打印_warning(`【博主精准信息更新】 请求结果: ${JSON.stringify(result)}`)
    return result;
}

function 更新粉丝群信息(fans_group_id,join_condition,is_join,is_follow,is_wait_for_consent,group_member){
    const bolgger_url = `${url}/update_Fans_group`
    const data = {
        "fans_group_id":fans_group_id,
        "join_condition":join_condition,
        "is_join":is_join,
        "is_follow":is_follow,
        "is_wait_for_consent":is_wait_for_consent,
        "group_member":group_member
    }
    let r = http.postJSON(bolgger_url,JSON.stringify(data), 30 * 1000, {"key-word": "test"})
    let result = null;
    if(r){
        try {
            const response = JSON.parse(r);
            if(response.state === 200){
                result = response.result;
            }else {
                日志打印_error(`【更新粉丝群信息】 请求失败: ${r}`);
            }
        }catch (e) {
            日志打印_error(`【更新粉丝群信息】 解析 catch: ${e}`);
        }
    }
    日志打印_warning(`【更新粉丝群信息】 请求结果: ${JSON.stringify(result)}`)
    return result;
}

function 更新群成员信息(fans_id,group_id,fans_name,filte,is_chat,is_chat_time,main_page,work_information) {
    const bolgger_url = `${url}/update_Fans_list`
    const data = {
        "fans_id":fans_id,
        "group_id":group_id,
        "fans_name":fans_name,
        "filte":filte,
        "is_chat":is_chat,
        "is_chat_time":is_chat_time,
        "main_page":main_page,
        "work_information":work_information
    }
    let r = http.postJSON(bolgger_url,JSON.stringify(data), 30 * 1000, {"key-word": "test"})
    let result = null;
    if(r){
        try {
            const response = JSON.parse(r);
            if(response.state === 200){
                result = response.result;
            }else {
                日志打印_error(`【更新粉丝群信息】 请求失败: ${r}`);
            }
        }catch (e) {
            日志打印_error(`【更新粉丝群信息】 解析 catch: ${e}`);
        }
    }
    日志打印_warning(`【更新粉丝群信息】 请求结果: ${JSON.stringify(result)}`)
    return result;
}

function 私信任务提交(run_date,comment_sid_list,account_id,account_type,belong_uid) {
    const url = `${url}/push_chat_task_by_comment_sid_one`
    const data = {
        "run_date": run_date,
        "comment_sid_list": comment_sid_list,
        "account_id":account_id,
        "account_type":account_type,
        "belong_uid":belong_uid
    }
    let r = http.postJSON(url,JSON.stringify(data), 30 * 1000, {"key-word": "test"})
    let result = null;
    if(r){
        try {
            const response = JSON.parse(r);
            if(response.state === 200){
                result = response.result;
            }else {
                日志打印_error(`【更新粉丝群信息】 请求失败: ${r}`);
            }
        }catch (e) {
            日志打印_error(`【更新粉丝群信息】 解析 catch: ${e}`);
        }
    }
    日志打印_warning(`【更新粉丝群信息】 请求结果: ${JSON.stringify(result)}`)
    return result;
}