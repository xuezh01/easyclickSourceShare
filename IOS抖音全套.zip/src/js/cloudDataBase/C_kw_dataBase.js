/* 【关键词搜索】*/

const DBurl = 'http://47.108.92.250:2034';

function 插入关键词搜索记录(uid, keyword, location, releaseTime) {
    日志打印_information('开始执行 -- 【插入关键词搜索记录】')
    const start_time = time();
    const data = {
        uid: uid,
        keyword: keyword,
        location: location,
        releaseTime: releaseTime
    }
    const insertUrl = `${DBurl}/insert_kw_search`;
    let result = null;
    for(let i = 0; i < 5; i++){
        if(isScriptExit()){break}
        const r = http.postJSON(insertUrl, data, 30 * 1000, {"key-word": "test"});
        日志打印_debug(`【插入关键词搜索记录】 请求结果: ${r}`);
        if(r){
            try {
                const response = JSON.parse(r);
                if (response.state === 200) {
                    result = response.result.keywordSid;
                    break;
                } else {
                    日志打印_error(`【插入关键词搜索记录】 请求失败: ${r}`);
                }
            }catch (e) {
                日志打印_error(`【插入关键词搜索记录】 请求失败 catch: ${e}`);
            }
        }
    }
    日志打印_warning(`【插入关键词搜索记录 耗时】：${time() - start_time}`);
    return result;
}

function 插入关键词用户记录(nicheng, douyinID, commentTime, comment, videoSid) {
    日志打印_information('开始执行 -- 【插入关键词用户记录】')
    const start_time = time();
    const data = {
        videoSid: videoSid,
        nicheng: nicheng,
        douyinID: douyinID,
        commentTime: commentTime,
        comment: comment,
    }
    日志打印_information(`【插入关键词用户记录】:${JSON.stringify(data)}`)

    // const insertUrl = `http://192.168.0.119:2024/insert_kw_comment`;
    const insertUrl = `${DBurl}/insert_kw_comment`;
    while (true){
        if(isScriptExit()){break}
        let result = null;
        for(let i = 0; i < 5; i++){
            if(isScriptExit()){break}
            const r = http.postJSON(insertUrl, data, 30 * 1000, {"key-word": "test"});
            日志打印_debug(`【插入关键词用户记录】 请求结果: ${r}`);
            if(r){
                try{
                    const response = JSON.parse(r);
                    if (response.state === 200) {
                        result = response.result.commentSid;
                        日志打印_warning(`【插入关键词用户记录 耗时】: ${time() - start_time}`);
                        return result;
                    } else {
                        日志打印_error(`【插入关键词用户记录】 请求失败: ${r}`);
                    }
                }catch (e) {
                    日志打印_error(`【插入关键词用户记录】 请求失败 catch: ${e}`);
                }
            }
        }
    }
}

function 获取已浏览视频内容数据(uid) {
    日志打印_information('开始执行 -- 【获取已浏览视频内容数据】')
    const start_time = time();
    // const queryUrl = `${DBurl}/get_kw_all_video_content?uid=${encodeURI(uid)}`;
    // const queryUrl = `${DBurl}/get_all_video_content`;
    const queryUrl = `${DBurl}/get_all_video_content`;
    let result = null;
    for(let i = 0; i < 5; i++){
        if(isScriptExit()){break}
        const r = http.httpGet(queryUrl, {}, 30 * 1000, {"key-word": "test"});
        日志打印_debug(`【获取已浏览视频内容数据】 请求结果: ${r}`);
        if(r){
            try{
                const response = JSON.parse(r);
                if (response !== null) {
                    const videoContent = []
                    for(let i in response){
                        let value = response[i].videoContent;
                        videoContent.push(value);
                    }
                    result = videoContent;
                    break;
                } else {
                    日志打印_error(`【获取已浏览视频内容数据】 请求失败: ${r}`);
                }
            }catch (e) {
                日志打印_error(`【获取已浏览视频内容数据】 请求失败catch: ${e}`);
            }
        }
    }
    日志打印_warning(`【获取已浏览视频内容数据 耗时】：${time() - start_time}`);
    return result;
}

function 插入已浏览视频内容(keywordSid, videoContent, author, author_douyin_id, video_type, releaseTime, comment_number, step=0, look_over=0) {
    日志打印_information('开始执行 -- 【插入已浏览视频内容】')
    const start_time = time();
    const data = {
        "uid": uid,
        "keywordSid": keywordSid,
        "videoContent": videoContent,
        "author": author,   // 作者
        "author_douyin_id": author_douyin_id, // 作者 抖音ID
        "video_type": video_type, // 视频类型
        "releaseTime": releaseTime, // 视频发布时间
        "comment_number": comment_number, // 评论数量
        "step": step,  // 操作步数
        "look_over": look_over, // 操作完毕
    }
    const insertUrl = `${DBurl}/insert_kw_video`;
    let result = null;
    while (true){
        if (isScriptExit()) { break }
        for(let i = 0; i < 5; i++) {
            if (isScriptExit()) { break }
            const r = http.postJSON(insertUrl, data, 30 * 1000, {"key-word": "test"});
            日志打印_information(`【插入已浏览视频内容】 请求结果: ${r}`);
            if(r){
                try{
                    const response = JSON.parse(r);
                    if (response.state === 200) {
                        日志打印_warning(`【插入已浏览视频内容】 请求结果: ${r}`);
                        result = response.result;
                        日志打印_warning(`【插入已浏览视频内容】耗时: ${time() - start_time}`);
                        return result;
                    } else {
                        日志打印_error(`【插入已浏览视频内容】 请求失败: ${r}`);
                    }
                }catch (e) {
                    日志打印_error(`【插入已浏览视频内容】 请求失败catch: ${e}`);
                }
            }
        }
    }

}

function 更新视频留痕(videoSid, leave_traces) {
    日志打印_information('开始执行 -- 【更新视频留痕】')
    const start_time = time();
    const data = {
        "uid": uid,
        "videoSid": videoSid,
        "leave_traces": leave_traces,
    }
    const insertUrl = `${DBurl}/update_leave_traces_by_videoSid`;
    // const insertUrl = `http://192.168.0.119:2024/insert_kw_video`;
    let result = null;
    for(let i = 0; i < 5; i++) {
        if (isScriptExit()) { break }
        const r = http.postJSON(insertUrl, data, 30 * 1000, {"key-word": "test"});
        日志打印_information(`【更新视频留痕】 请求结果: ${r}`);
        if(r){
            try{
                const response = JSON.parse(r);
                if (response.state === 200) {
                    日志打印_warning(`【更新视频留痕】 请求结果: ${r}`);
                    result = response.result;
                    break;
                } else {
                    日志打印_error(`【更新视频留痕】 请求失败: ${r}`);
                }
            }catch (e) {
                日志打印_error(`【更新视频留痕】 请求失败catch: ${e}`);
            }
        }
    }
    日志打印_warning(`【更新视频留痕】耗时: ${time() - start_time}`);
    return result;
}

function 更新已浏览视频内容(videoSid, step, look_over) {
    日志打印_information('开始执行 -- 【更新已浏览视频内容】')
    const start_time = time();
    const data = {
        "videoSid":videoSid,
        "step":step,
        "look_over":look_over
    }
    const insertUrl = `${DBurl}/insert_kw_video`;
    // const insertUrl = `http://192.168.0.119:2024/update_video_step_look_over`;
    let result = null;
    for(let i = 0; i < 5; i++) {
        if (isScriptExit()) { break }
        const r = http.postJSON(insertUrl, data, 30 * 1000, {"key-word": "test"});
        日志打印_debug(`【更新已浏览视频内容】: ${r}`);
        if(r){
            try {
                const response = JSON.parse(r);
                if (response.state === 200) {
                    result = response.result;
                    break;
                } else {
                    日志打印_error(`【更新已浏览视频内容】 请求失败: ${r}`);
                }
            }catch (e) {
                日志打印_error(`【更新已浏览视频内容】 请求失败 catch: ${e}`);
            }
        }
    }
    日志打印_warning(`【更新已浏览视频内容】耗时: ${time() - start_time}`);
    return result;
}

function 更新私信记录(ischat, commentSid) {
    日志打印_information('开始执行 -- 【更新私信记录】')
    const start_time = time();
    const data = {
        ischat: ischat,
        commentSid: commentSid
    }
    const insertUrl = `${DBurl}/update_sixin_follow`;
    // const insertUrl = `http://192.168.0.119:2024/update_sixin_follow`
    let result = null;
    for(let i = 0; i < 5; i++) {
        if (isScriptExit()) { break }
        const r = http.postJSON(insertUrl, data, 180 * 1000, {"key-word": "test"});
        日志打印_debug(`【更新私信记录】: ${r}`);
        if (r){
            try{
                const response = JSON.parse(r);
                if (response.state === 200) {
                    result = true;
                    break;
                } else {
                    日志打印_error(`【插入已浏览视频内容】 请求失败: ${r}`);
                }
            }catch (e) {
                日志打印_error(`【插入已浏览视频内容】 请求失败 catch: ${e}`);
            }
        }
    }
    日志打印_warning(`【更新私信记录】耗时: ${time() - start_time}`);
    return result;
}


function 插入无人值守关键词搜索记录(keyword, location, releaseTime) {
    日志打印_information('开始执行 -- 【插入无人值守关键词搜索记录】')
    const start_time = time();
    const data = {
        uid: uid,
        keyword: keyword,
        location: location,
        releaseTime: releaseTime,
        device_id:device_id
    }
    const insertUrl = `${DBurl}/insert_kw_search`;
    let result = null;
    while (true){
        if (isScriptExit()) { break }
        const r = http.postJSON(insertUrl, data, 30 * 1000, {"key-word": "test"});
        日志打印_debug(`【插入无人值守关键词搜索记录】：${r}`);
        if (r) {
            try {
                const response = JSON.parse(r);
                if (response.state === 200) {
                    result =  response.result.keywordSid;
                    break;
                } else {
                    日志打印_error(`【插入关键词搜索记录】 请求失败: ${r}`);
                }
            }catch (e) {
                日志打印_error(`【插入关键词搜索记录】 请求失败 catch: ${e}`);
            }
        }
    }
    日志打印_warning(`【插入无人值守关键词搜索记录 耗时】：${time() - start_time}`);
    return result;
}

function 获取当前设备私信发送信息() {
    日志打印_information('开始执行 -- 【获取当前设备私信发送信息】')
    const start_time = time();
    const queryUrl = `${DBurl}/get_all_douyin_by_device_id?device_id=${encodeURI(device_id)}&is_chat=0`;
    let result = [];
    for(let i = 0; i < 5; i++) {
        if (isScriptExit()) { break }
        const r = http.httpGet(queryUrl, {}, 5 * 1000, {"key-word": "test"});
        日志打印_debug(`【获取当前设备私信发送信息】：${r}`);
        if (r) {
            try {
                const response = JSON.parse(r);
                if (response!== null) {
                    for(let i in response){
                        if(isScriptExit()){break}
                        let value = response[i];
                        result.push(value);
                    }
                    break;
                } else {
                    日志打印_error(`【获取当前设备私信发送信息】 请求失败: ${r}`);
                }
            }catch (e) {
                日志打印_error(`【获取当前设备私信发送信息】 请求失败catch: ${e}`);
            }
        }
    }
    日志打印_warning(`【获取当前设备私信发送信息 耗时】：${time() - start_time}`);
    return result;
}

function 插入设备信息状态(ios_id, serial_number, device_name,notes,is_charging, current_battery, authorization_date,script_running,current_task) {
    日志打印_information('开始执行 -- 【插入设备信息状态】')
    const start_time = time();
    const data =  {
        ios_id: ios_id,
        serial_number: serial_number,
        device_name: device_name,
        notes: notes,
        is_charging: is_charging,
        current_battery: current_battery,
        authorization_date: authorization_date,
        script_running: script_running,
        current_task: current_task
    }
    const insertUrl = `http://47.108.92.250:2002/data23`;
    // const insertUrl = `http://192.168.0.110:5002/api`
    let result = null;
    for(let i = 0; i < 1; i++) {
        if (isScriptExit()) { break }
        const r = http.postJSON(insertUrl, data, 30 * 1000, {"key-word": "test"});
        日志打印_debug(`【插入设备信息状态】: ${r}`);
        if (r)  {
            try {
                const response = JSON.parse(r);
                if (response.state === 200) {
                    result = response.result;
                    break;
                } else {
                    日志打印_error(`【插入设备信息状态】 请求失败: ${r}`);
                }
            }catch (e) {
                日志打印_error(`【插入设备信息状态】 请求失败 catch: ${e}`);
            }
        }
    }
    日志打印_warning(`【插入设备信息状态】耗时: ${time() - start_time}`);
    return result
}

function 上传私信回复图片(抖音号, image_base64) {
    const bindUrl = `${DBurl}/insert_device_replay_img`;
    const data = {
        "device_id": device_id,
        "douyinID":抖音号,
        "image_base64":image_base64,
    }
    while (true){
        if(isScriptExit()){break}
        for(let i=0; i<3; i++){
            const bind_result = http.postJSON(bindUrl, data, 100000, '')
            try{
                日志打印_information(`【上传私信回复图片】：${bind_result}`)
                const bind_state = JSON.parse(bind_result);
                if(bind_state.state === 200){
                    //绑定成功
                    return
                }
            }catch (e) {
                日志打印_error(`【上传私信回复图片】: ${e}`)
            }
        }
        iSleep(2000)
    }
}

function 查询用户是否已私信(douyinID, key_words) {
    const queryUrl = `${DBurl}/exists_kw_ischat_q?uid=${encodeURI(uid)}&douyinID=${encodeURI(douyinID)}&key_words=${encodeURI(key_words)}`;
    for(let i=0; i<3; i++){
        if(isScriptExit()){break}
        const r = http.httpGet(queryUrl, {}, 30 * 1000, '');
        if(r){
            try {
                日志打印_information(`【查询用户是否已私信】：${r}`)
                const response = JSON.parse(r);
                if (response.state === 200) {
                    return response.result;
                }
                else if (response.state === -1){
                    return false
                }
            }catch (e) {
                日志打印_error(`【error】查询用户是否已私信: ${e}`)
            }
        }
    }
    return false
}

function 记录用户已私信(douyinID, key_words) {
    const bindUrl = `${DBurl}/insert_kw_ischat_q`;
    const data = {
        "uid": uid,
        "douyinID":douyinID,
        "key_words":key_words,
    }
    while (true){
        if(isScriptExit()){break}
        for(let i=0; i<3; i++){
            const bind_result = http.postJSON(bindUrl, data, 100000, '')
            try{
                日志打印_information(`【记录用户已私信】：${bind_result}`)
                const bind_state = JSON.parse(bind_result);
                if(bind_state.state === 200){
                    //绑定成功
                    return
                }
            }catch (e) {
                日志打印_error(`【记录用户已私信】: ${e}`)
            }
        }
        iSleep(2000)
    }
}
