const ks_DBurl = 'http://47.108.92.250:2030';


/**
 * @description  对比快手视频信息
 * @param {用户登录账号} uid
 * @param {视频作者} videoAuthor
 * @param {视频标题} videoName
 * @param {评论数量} commentCount
 * @param {视频发布时间} releaseTime
 * @param {视频类型} videoType
 * @param {关键词} keyword
 */
function 对比快手视频信息(uid, videoAuthor, videoName, commentCount,releaseTime, videoType, keyword) {
    日志打印_information('开始执行 -- 【对比快手视频信息】')
    const start_time = time();
    const data = {
        uid: uid,
        videoAuthor: videoAuthor,
        videoName: videoName,
        commentCount: commentCount,
        releaseTime: releaseTime,
        videoType: videoType,
        keyword: keyword,
    }
    const insertUrl = `${ks_DBurl}/compare_insert_kuaishou_video`;
    let result = null;
    for(let i = 0; i < 5; i++) {
        if (isScriptExit()) { break }
        const r = http.postJSON(insertUrl, JSON.stringify(data), 30 * 1000, {"key-word": "test"});
        日志打印_debug(`【对比快手视频信息】：${r}`);
        if(r){
            try {
                const response = JSON.parse(r);
                if(response.state === 200){
                    result = response.result;
                    break;
                }else {
                    日志打印_error(`【对比快手视频信息】 请求失败: ${r}`);
                }
            }catch (e) {
                日志打印_error(`【对比快手视频信息】 解析 catch: ${e}`);
            }
        }
    }
    日志打印_warning(`【对比快手视频信息 耗时】：${time()-start_time}`);
    return result;
}

/**
 * @description  插入快手视频下的评论内容
 * @param {视频标识} videoSid
 * @param {昵称} nicheng
 * @param {评论内容} comment
 * @param {评论时间} commentTime
 * @param {快手ID} kuaishou_id
 * @param {是否私信} isChat
 */
function 插入快手视频下的评论内容(videoSid, nicheng, comment, commentTime,kuaishou_id, isChat, Filte) {
    日志打印_information('开始执行 -- 【插入快手视频下的评论内容】')
    const start_time = time();
    const data = {
        videoSid: videoSid,
        nicheng: nicheng,
        comment: comment,
        commentTime: commentTime,
        kuaishou_id: kuaishou_id,
        isChat: 0,
        comment_filte:Filte
    }
    const insertUrl = `${ks_DBurl}/insert_kuaishou_comment`;
    let result = null;
    for(let i = 0; i < 5; i++) {
        if (isScriptExit()) { break }
        const r = http.postJSON(insertUrl, JSON.stringify(data), 30 * 1000, {"key-word": "test"});
        日志打印_debug(`【插入快手视频下的评论内容】：${r}`);
        if(r) {
            try{
                const response = JSON.parse(r);
                if(response.state === 200){
                    result = response.result;
                    break;
                }else {
                    日志打印_error(`【插入快手视频下的评论内容】 请求失败: ${r}`);
                }
            }catch (e) {
                日志打印_error(`【插入快手视频下的评论内容】 解析失败 catch: ${e}`);
            }
        }
    }
    日志打印_warning(`【插入快手视频下的评论内容 耗时】：${time()-start_time}`);
    return result;
}


/**
 * @description  获取快手可私信用户
 * @param {用户登录账号} uid
 */
function 获取快手可私信用户(uid) {
    日志打印_information('开始执行 -- 【获取快手可私信用户】')
    const start_time = time();
    const queryUrl = `${ks_DBurl}/get_all_kuaishou_no_chat?uid=${encodeURI(uid)}`;
    let result = null;
    for(let i = 0; i < 5; i++) {
        if (isScriptExit()) { break }
        const r = http.httpGet(queryUrl, {}, 30 * 1000, {"key-word": "test"});
        日志打印_debug(`【获取快手可私信用户】：${r}`);
        if(r){
            try{
                const response = JSON.parse(r);
                if(response.state === 200){
                    result = response.result;
                    break;
                }else {
                    日志打印_error(`【获取快手可私信用户】 请求失败: ${r}`);
                }
            }catch (e) {
                日志打印_error(`【获取快手可私信用户】 解析失败catch: ${e}`);
            }
        }
    }
    日志打印_warning(`【获取快手可私信用户 耗时】：${time()-start_time}`);
    return result;
}


/**
 * @description  更新快手私信用户状态
 * @param {用户登录账号} uid
 * @param {快手ID} kuaishou_id
 * @param {是否私信} isChat
 */
function 更新快手私信用户状态(uid, kuaishou_id, isChat) {
    日志打印_information('开始执行 -- 【更新快手私信用户状态】')
    const start_time = time();
    const data = {
        uid: uid,
        kuaishou_id: kuaishou_id,
        isChat: isChat,
    }
    const insertUrl = `${ks_DBurl}/update_kuaishou_comment_ischat`;
    let result = null;
    for(let i = 0; i < 5; i++) {
        if (isScriptExit()) { break }
        const r = http.postJSON(insertUrl, JSON.stringify(data), 30 * 1000, {"key-word": "test"});
        日志打印_debug(`【更新快手私信用户状态】：${r}`);
        if(r){
            try{
                const response = JSON.parse(r);
                if(response.state === 200){
                    result = response.result;
                    break;
                }else {
                    日志打印_error(`【更新快手私信用户状态】 请求失败: ${r}`);
                }
            }catch (e) {
                日志打印_error(`【更新快手私信用户状态】 解析失败 catch: ${e}`);
            }
        }
    }
    日志打印_warning(`【更新快手私信用户状态 耗时】：${time()-start_time}`);
    return result;
}

function 更新视频精准度(uid,videoAuthor,releaseTime,videoType,Filte) {
    日志打印_information('开始执行 -- 【精准度判断状态】')
    const start_time = time();
    const data = {
        uid: uid,
        videoAuthor: videoAuthor,
        releaseTime: releaseTime,
        videoType :videoType,
        Filte:Filte
    }
    const insertUrl = `${ks_DBurl}/update_kuaishou_video_filte`;
    let result = null;
    for(let i = 0; i < 5; i++) {
        if (isScriptExit()) { break }
        const r = http.postJSON(insertUrl, JSON.stringify(data), 30 * 1000, {"key-word": "test"});
        日志打印_debug(`【精准度判断】：${r}`);
        if(r) {
            try{
                const response = JSON.parse(r);
                if(response.state === 200){
                    result = response.result;
                    break;
                }else {
                    日志打印_error(`【更新快手私信用户状态】 请求失败: ${r}`);
                }
            }catch (e) {
                日志打印_error(`【更新快手私信用户状态】 解析失败 catch: ${r}`);
            }
        }
    }
    日志打印_warning(`【精准度判断 耗时】：${time()-start_time}`);
    return result;
}

function 更新评论赛选(){

}