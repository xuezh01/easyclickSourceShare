
const APIServer_two = 'http://47.108.92.250:8888';

function dy_刺客_提交当前任务(data) {
    let url = `${APIServer_two}/push_chat_task_by_comment_sid_one`;
    // let data = {commentSid:commentSid}
    const r = http.postJSON(url,JSON.stringify(data),20*1000,{"key-word": "test"})
    if (!r){
        return false
    }
    const response = JSON.parse(r);
    logd("提交当前任务:{}",JSON.stringify(response))
    if (response && response.state === 200 && response.data){
        logd("刺客流程_用户筛选流程提交结果:可私信")
        return {"task":response.data.task,"aaci_atid":response.data.aaci_atid}
    }
    logd("刺客流程_用户筛选流程提交结果:不可私信")
    return false
}

function dy_刺客流程_用户筛选(data) {
    let url = `${APIServer_two}/insert_video_comment_cike`;
    // let url = '192.168.0.119:9999/insert_video_comment_cike'
    // let data = {commentSid:commentSid}
    const r = http.postJSON(url,JSON.stringify(data),20*1000,{"key-word": "test"})
    if (!r){
        return false
    }
    const response = JSON.parse(r);
    logd("刺客流程_用户筛选流程结果:{},:{},:{}",JSON.stringify(response),response.state,response.filte)
    if (response && response.state === 200 && (response.filte.includes('P1')||response.filte.includes('P2')) && response.comment_sid){
        const 日期 = 获取当前时间().split('T')[0]
        const 提交任务数据 = {
            "run_date": 日期,
            "comment_sid_list":[response.comment_sid],
            "account_id":抖音_获取当前账号的抖音ID(),
            "account_type":"抖音",
            "belong_uid":uid
        }
        const 提交结果 = dy_刺客_提交当前任务(提交任务数据)
        logd("发送任务提交结果:{}",JSON.stringify(提交结果))
        if (提交结果 && parseInt(提交结果.task) === 1 && 提交结果.aaci_atid){
            logd("刺客流程_用户筛选流程结果:可私信")
            return {"精准度":true,"aaci_atid":提交结果.aaci_atid}
        }else {
            logd("提交结果问题:{}",JSON.stringify(提交结果))
        }
    }
    logd("刺客流程_用户筛选流程结果:不可私信")
    return false
}

function dy_持续跟进流程_已获取用户筛选(data) {
    // let url = `${APIServer_two}/insert_video_comment_cike`;
    let url = 'http://192.168.0.119:9999/exist_video_comment'
    // let data = {commentSid:commentSid}
    const r = http.postJSON(url,JSON.stringify(data),20*1000,{"key-word": "test"})
    logd(JSON.stringify(r))
    if (!r){
        return []
    }
    const response = JSON.parse(r);
    logd("持续跟进流程_以获取用户筛选:{},:{},:{}",JSON.stringify(response),response.name_list,Array.isArray(response.name_list))
    if (response && response.state === 200){
        if (response.name_list && Array.isArray(response.name_list)){
            return response.name_list
        }
    }
    logd("持续跟进流程_以获取用户筛选:没有用户")
    return []
}

function dy_关注博主_查询博主是否已被其他账号关注(data){
    let url = 'http://192.168.0.119:9999/exist_video_comment'
    // let data = {commentSid:commentSid}
    const r = http.postJSON(url,JSON.stringify(data),20*1000,{"key-word": "test"})
    logd(JSON.stringify(r))
    while (true){
        if(isScriptExit()){break}
        try{
            const response = http.postJSON(queryUrl, data, 10000,{'Content-Type': 'application/json'})
            日志打印_debug(`【跟进任务执行成功】：${response}`);
            const result = JSON.parse(response)
            if(result.code === 200){
                日志打印_warning(`【跟进任务执行成功】：${result.message}`);
                return result.result
            }
        }catch (e) {
            日志打印_error(`【跟进任务执行成功】 请求失败catch: ${e}`);
        }
        iSleep(500)
    }
}

function dy_博主精准度判断 (){

}

function dy_博主是否被已被关注 (data){
    日志打印_information('开始执行 -- 【博主是否被关注判断】')
    const queryUrl = `${APIServer}/get_blogger_is_follow`;
    while (true){
        if(isScriptExit()){break}
        try{
            const response = http.postJSON(queryUrl, data, 10000,{'Content-Type': 'application/json'})
            日志打印_debug(`【跟进任务执行成功】：${response}`);
            const result = JSON.parse(response)
            if(result.state === 200){
                日志打印_warning(`【跟进任务执行成功】：${result.msg}`);
                return false
            }else if(result.state === -1){
                return true
            }
        }catch (e) {
            日志打印_error(`【跟进任务执行成功】 请求失败catch: ${e}`);
        }
        iSleep(500)
    }
}

function dy_插入博主信息 (data) {
    日志打印_information('开始执行 -- 【插入抖音博主信息】')
    const queryUrl = `${APIServer}/insert_blogger_information`;
    while (true){
        if(isScriptExit()){break}
        try{
            const response = http.postJSON(queryUrl, data, 10000,{'Content-Type': 'application/json'})
            日志打印_debug(`【跟进任务执行成功】：${response}`);
            const result = JSON.parse(response)
            if(result.state === 200){
                if (result.msg.includes('成功')){
                    return true
                }else {
                    return false
                }
            }
        }catch (e) {
            日志打印_error(`【跟进任务执行成功】 请求失败catch: ${e}`);
        }
        iSleep(500)
    }
}

function dy_获取已有精准博主 (){
    日志打印_information('开始执行 -- 【获取已有精准博主】')
    const queryUrl = `${APIServer}/get_my_follow_blogger_and_fan_group_by_blogger_id`;
    const data = {
        "belong_uid":uid,
        "account_type":"抖音"
    }
    while (true){
        if(isScriptExit()){break}
        try{
            const response = http.postJSON(queryUrl, data, 10000,{'Content-Type': 'application/json'})
            日志打印_debug(`【跟进任务执行成功】：${response}`);
            const result = JSON.parse(response)
            if(result.state === 200 && result.result){
                // 提取 video_up_id 值到新的数组
                const videoUpIds = result.result.map(item => item.video_up_id);
                return videoUpIds
            }else {
                return null
            }
        }catch (e) {
            日志打印_error(`【跟进任务执行成功】 请求失败catch: ${e}`);
        }
        iSleep(500)
    }
}



// var a = {"api": "http://agi2.ivreal.com:8011/screen/key_word",
//     "video_api": "http://agi2.ivreal.com:8011/all_purpose/video_judgment", "products_services": "AI软件产品",
//     "requirement_keywords": "AI获客",
//     "detailed_description": "寻找AI分销商提供市场推广策略指导，市场动态分析、趋势预测等专业服务，与分销商洽谈合作，帮助分销商抓住市场机遇,希望分销商售卖公司提供的产品",
//     "p1_standard": "分销商公司，寻找优质的AI产品\n- **特点**: 用户正在寻找优秀的产品与产品公司洽谈合作达成分销协议\n- **关键词**: 合作、怎么合作、有电话吗、可以了解一下吗？、你好怎么加盟?",
//     "p2_standard": "正在寻找优质的AI产品，需要详细的了解软件,在洽谈分销合作\n- **特点**: 对AI产品感兴趣,想加盟和分销,对AI产品有疑虑\n- **关键词**: 怎么体验、可以体验一下吗？、怎么配合、如何学习交易",
//     "p3_standard": "才接触AI对AI产品有合作意愿，目前正在观望和理解\n- **特点**: 才了解AI产品，对人工智能软件感兴趣，正在观望\n- **关键词**: 资料可以发一下吗？、这个是什么领域的AI产品、你好，可以发资料吗？、你们招募合伙人怎么操作、费用应该需要多少呀？",
//     "p4_standard": "对AI产品保持疑虑,对AI产品存在许多问题\n- **特点**: 对AI系统的控制能力表示担忧，对AI产品的经济成本和效益，担心投资回报率不高。\n- **关键词**: 是比较成熟的软件吗？、你们的ai系统和黑谷的ai系统有啥功能区别、有产品了吗？、询问其他同类型其他产品的区别与比较"}
//


