
function 获取聊天回复(wechat_id, customer, message) {
    日志打印_information('开始执行 -- 【获取聊天回复】')
    const start_time = time();

    const replayUrl = `http://47.108.92.250:8011/chatgpt/get_replay`
    const headers = {'Content-Type': 'application/json','Accept': 'application/json' }

    const msg = ["我:提供最舒适、最有支撑的睡眠体验，需要了解一下吗","客户:你叫什么"]
    const data = {
        "wechat_id": 'qwert',
        "belong_uid": 'admin',
        "customer_wx": customer,
        "message": message
    }
    logd(JSON.stringify(data))
    while (true){
        if(isScriptExit()){break}
        for(let i=0; i<3; i++){
            const bind_result = http.postJSON(replayUrl, data, 100000, headers)
            try{
                日志打印_information(`【获取聊天回复】：${bind_result}`)
                const bind_state = JSON.parse(bind_result);
                if(bind_state.state === 200){
                    //绑定成功
                    日志打印_warning(`【获取聊天回复】耗时: ${time() - start_time}`);
                    return bind_state.result.answer
                }
            }catch (e) {
                日志打印_error(`【error】获取聊天回复: ${e}`)
            }
        }
        iSleep(2000)
    }
}
