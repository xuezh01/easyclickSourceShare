
DouYin.prototype.用户有无作品判断 = function () {
    return !ocr文本数组匹配(douyin.用户主页无作品)
}


function 私信置信度增加(data){
// 原始字符串和表情列表
//     var hs = "你好,我是外汇官方小助理,看到你需求,加主页v详聊";
    var  hs = data;

    let 表情list = ["[握手]", "[奋斗]", "[得意]", "[抱拳]", "[发]", "[撒花]"," [互粉]"];

// 1. 随机选择 0 到 2 个表情
    let numOfEmojis = Math.floor(Math.random() * 3); // 随机选择 0, 1 或 2
    let selectedEmojis = [];
    for (let i = 0; i < numOfEmojis; i++) {
        if(isScriptExit()){break}
        // 从表情list中随机选择一个表情
        let randomIndex = Math.floor(Math.random() * 表情list.length);
        selectedEmojis.push(表情list[randomIndex]);
    }

// 2. 将表情插入到标点符号后面
    const 标点符号 = [",", ".", "，", "。", "！", "？"]; // 常见的标点符号
    let modifiedHs = hs;

// 遍历标点符号并随机决定是否插入表情
    for (let emoji of selectedEmojis) {
        if(isScriptExit()){break}
        // 找到 hs 中随机的一个标点符号
        let punctuationIndices = [];
        for (let i = 0; i < modifiedHs.length; i++) {
            if(isScriptExit()){break}
            if (标点符号.includes(modifiedHs[i])) {
                punctuationIndices.push(i);
            }
        }

        if (punctuationIndices.length > 0) {
            // 随机选择一个标点符号的位置
            let randomPunctuationIndex = punctuationIndices[Math.floor(Math.random() * punctuationIndices.length)];
            // 在标点符号后面插入表情
            modifiedHs = modifiedHs.slice(0, randomPunctuationIndex + 1) + emoji + modifiedHs.slice(randomPunctuationIndex + 1);
        }
    }

    logi("随机符号========:{}",modifiedHs)

    let i = 0;
    return modifiedHs
}









DouYin.prototype.dy_退出用户选择_返回用户搜索页面 = function () {
    当前执行模块 = 'dy_退出用户选择_返回用户搜索页面'
    日志打印_debug(`开始执行 - 【dy_退出用户选择_返回用户搜索页面】`);

    const 返回用户主页 = 点击后检测(douyin.用户主页_返回按钮, douyin.用户主页私信按钮, [douyin.用户作品主页]);
    switch (返回用户主页) {
        case -100:
            日志打印_error('返回用户主页  失败！')
            return false
        case -1:
            日志打印_error('返回用户主页  失败！')
            return false
        case 0:
            日志打印_debug('返回用户主页  成功！')
            break
    }
    进入实时回复 = false;
    const 返回搜索页面 = 点击后检测(douyin.用户主页_返回按钮, douyin.用户作品主页, [douyin.搜索页_搜索]);
    switch (返回搜索页面) {
        case -100:
            日志打印_error('返回搜索页面  失败！')
            return false
        case -1:
            日志打印_error('返回搜索页面  失败！')
            return false
        case 0:
            日志打印_debug('返回搜索页面  成功！')
            return true;
    }
}


DouYin.prototype.dy_退出用户搜索页面_返回首页 = function () {
    当前执行模块 = 'dy_退出用户搜索页面_返回首页'
    日志打印_debug(`开始执行 - 【dy_退出用户搜索页面_返回首页】`);

    const 返回用户主页_按钮 = {name: '【dy_退出用户搜索页面_返回首页】用户_返回按钮', x: random(50, 68), y:random(74,93)};
    const 返回抖音主页 = 点击后检测(返回用户主页_按钮, douyin.搜索页_搜索, [douyin.底部导航_首页, douyin.视频播放页_关注按钮]);
    switch (返回抖音主页) {
        case -100:
            日志打印_error('返回抖音主页  失败！')
            return false
        case -1:
            日志打印_error('返回抖音主页  失败！')
            return false
        case 0:
            日志打印_debug('返回抖音主页  成功！')
            return true
        case 1:
            日志打印_debug('返回抖音主页  成功！')
            return true
    }
}



DouYin.prototype.私信发送频率 = function (设定基准时间, 设定波动时间, 设置基准时间波动) {
    // 将基准时间和波动时间从分钟转换为毫秒
    const 基准时间 = 设定基准时间 * 60 * 1000;
    const 基准时间波动 = 设置基准时间波动 * 60 * 1000;
    const 随机基准时间 = 基准时间 + Math.random() * 基准时间波动 - 基准时间波动 / 2;
    const 最小时间 = (基准时间 - 设定波动时间 * 60 * 1000) - 随机基准时间 / 2;
    const 最大时间 = (基准时间 + 设定波动时间 * 60 * 1000) + 随机基准时间 / 2;

    // 在基准时间范围内生成随机基准时间


    // 生成一个随机时间间隔
    const 随机时间间隔 = Math.random() * (最大时间 - 最小时间) + 最小时间;

    return 随机时间间隔;
}

DouYin.prototype.时间 = function (interval) {
    const currentTime = new Date();
    const nextSendTime = new Date(currentTime.getTime() + interval);

    return {
        currentTime: currentTime.toISOString(),
        nextSendTime: nextSendTime.toISOString(),
        waitTimeMilliseconds: interval
    };
}


DouYin.prototype.时间转化 = function (time) {
    const date = new Date(time);

    // 获取小时、分钟和秒
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');

    // 组合成时分秒格式的字符串
    return `${hours}:${minutes}:${seconds}`;
}





