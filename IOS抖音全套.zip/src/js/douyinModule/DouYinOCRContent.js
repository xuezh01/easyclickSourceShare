DouYin.prototype.ocr内容初始化 = function () {
    DouYin.prototype.首页_底部导航_二值化 = {
        name: '首页_底部导航_二值化',
        textArray: ['首页','消息', '朋友','商城', '茸页', '苴页'],
        x: 0,
        y: 1200,
        ex: ScreenWidth,
        ey: ScreenHeight,
        binaryzation: true,
        matchCount: 1
    }
    DouYin.prototype.首页_底部导航_首页选中_二值化 = {
        name: '首页_底部导航_首页选中_二值化',
        textArray: ['首页', '茸页', '苴页'],
        x: 0,
        y: 1200,
        ex: 150,
        ey: ScreenHeight,
        binaryzation: true,
        matchCount: 1
    }
    DouYin.prototype.首页_底部导航 = {
        name: '首页_底部导航',
        textArray: ['首页','消息', '朋友','商城', '茸页', '苴页'],
        x: 0,
        y: 1200,
        ex: ScreenWidth,
        ey: ScreenHeight,
        binaryzation: false,
        matchCount: 2
    }


    DouYin.prototype.首页_顶部导航 = {
        name: '首页_顶部导航',
        textArray: ['团购','同城','关注', '商城','推荐', '直播', '精选'],
        x: 0,
        y: 40,
        ex: ScreenWidth,
        ey: 150,
        binaryzation: false,
        matchCount: 2
    }
    DouYin.prototype.首页_单列_双列 = {
        name: '首页_单列_双列',
        textArray: ['单列','双列'],
        x: 50,
        y: 60,
        ex: 630,
        ey: 160,
        binaryzation: false,
        matchCount: 1
    }


    DouYin.prototype.主页_我_页面 = {
        name: '主页_我_页面',
        textArray: ['抖音商城','我的钱包','观看历史', '常访问的人','我的小程序', '全部功能', '编辑主页', '获赞', '全部功飵'],
        x: 0,
        y: 300,
        ex: ScreenWidth,
        ey: 1200,
        binaryzation: false,
        matchCount: 3
    }

    DouYin.prototype.搜索结果频繁 = {
        name: '搜索结果频繁',
        textArray: ['搜索结果为空','结果为空','相关的内容', '没有搜到相关的内容'],
        x: 90,
        y: 300,
        ex: 720,
        ey: 1100,
        binaryzation: false,
        matchCount: 2
    }
    DouYin.prototype.搜索结果频繁_服务器 = {
        name: '搜索结果频繁_服务器',
        textArray: ['你搜的太多','让服务器宝宝休息一下吧'],
        x: 90,
        y: 300,
        ex: 720,
        ey: 1100,
        binaryzation: false,
        matchCount: 1
    }
    DouYin.prototype.账号右侧弹窗 = {
        name: '账号右侧弹窗',
        textArray: ['我的订单','我的钱包','我的二维码', '观看历史','离线缓存', '稍后再看', '抖音创作者中心', '小程序', '抖音公益', '未成年模式', '我的客服', '设置', '更多功能'],
        x: 140,
        y: 40,
        ex: ScreenWidth,
        ey: ScreenHeight,
        binaryzation: false,
        matchCount: 4
    }
    DouYin.prototype.账号左侧弹窗 = {
        name: '账号左侧弹窗',
        textArray: ['扫一扫','设置','通知消息', '常访问的人','常用功能', '观看历史', '离线模式', '稍后再看', '直播广场', '更多功能', '附近团购', '发起群聊'],
        x: 0,
        y: 40,
        ex: 600,
        ey: ScreenHeight,
        binaryzation: false,
        matchCount: 4
    }
    DouYin.prototype.账号设置页面 = {
        name: '账号设置页面',
        textArray: ['账号与安全','隐私设置','支付设置', '通用设置','通知设置', '聊天设置', '播放设置', '背景设置', '长辈模式'],
        x: 0,
        y: 40,
        ex: ScreenWidth,
        ey: ScreenHeight,
        binaryzation: false,
        matchCount: 4
    }
    DouYin.prototype.账号与安全页面 = {
        name: '账号与安全页面',
        textArray: ['账号与安全','切换账号','抖音号','我的抖音码', '手机号绑定','抖音密码', '登录设备管理', '保存登录信息', '第三方账号绑定', '授权管理', '我的合作码'],
        x: 0,
        y: 40,
        ex: ScreenWidth,
        ey: ScreenHeight,
        binaryzation: false,
        matchCount: 4
    }
    DouYin.prototype.弹窗_账号切换中 = {
        name: '弹窗_账号切换中',
        textArray: ['账号切换中'],
        x: 270,
        y: 600,
        ex: 468,
        ey: 740,
        binaryzation: false,
        matchCount: 1
    }
    DouYin.prototype.搜索页_搜索 = {
        name: '搜索页_搜索',
        textArray: ['搜索'],
        x: 625,
        y: 0,
        ex: ScreenWidth,
        ey: 120,
        binaryzation: false,
        matchCount: 1
    }

    DouYin.prototype.搜索页_搜索结果标签 = {
        name: '搜索页_搜索结果标签',
        textArray: ['综合', '视频', '用户', '直播','商品','全网','话题','小程序','音乐'],
        x: 0,
        y: 40,
        ex: ScreenWidth,
        ey: 250,
        binaryzation: false,
        matchCount: 2
    }
    DouYin.prototype.搜索页_视频筛选依据 = {
        name: '搜索页_视频筛选依据',
        textArray: ['排序依据', '综合排序', '最新发布', '最多点赞', '发布时间', '不限', '一天内', '一周内', '半年内', '视频时长', '分钟以', '搜索范围', '关注的人', '最近看过', '还未看过'],
        x: 0,
        y: 200,
        ex: ScreenWidth,
        ey: 950,
        binaryzation: false,
        matchCount: 3
    }
    DouYin.prototype.搜索页_用户筛选依据 = {
        name: '搜索页_视频筛选依据',
        textArray: ['粉丝数量', '用户类型', '普通用户', '企业认证', '个人认证'],
        x: 0,
        y: 200,
        ex: ScreenWidth,
        ey: 750,
        binaryzation: false,
        matchCount: 1
    }
    DouYin.prototype.搜索页_用户筛选结果 = {
        name: '搜索页_用户筛选结果',
        textArray: ['搜索结果为空', '找不到想要的账号', '告诉我们'],
        x: 50,
        y: 700,
        ex: 700,
        ey: 950,
        binaryzation: false,
        matchCount: 2
    }

    DouYin.prototype.搜索页_视频筛选结果 = {
        name: '搜索页_视频筛选结果',
        textArray: ['暂无内容', '查看所有内容', '没有更多了', '查看所有最近看过的内容'],
        x: 0,
        y: 40,
        ex: ScreenWidth,
        ey: ScreenHeight,
        binaryzation: false,
        matchCount: 1
    }

    DouYin.prototype.视频评论区_无内容 = {
        name: '视频评论区_无内容',
        textArray: ['期待你的评论', '去评论', '发条评论表达你的想法'],
        x: 0,
        y: 330,
        ex: ScreenWidth,
        ey: ScreenHeight,
        binaryzation: false,
        matchCount: 1
    }

    DouYin.prototype.视频评论区_误触内容 = {
        name: '视频评论区_误触内容',
        textArray: ['空格', 'space', 'search', '添加表情', '分享表情', '举报', '复制该评论'],
        x: 0,
        y: 580,
        ex: ScreenWidth,
        ey: ScreenHeight,
        binaryzation: false,
        matchCount: 2
    }

    DouYin.prototype.用户作品主页 = {
        name: '用户作品主页',
        textArray: ['获赞', '粉丝', '关注'],
        x: 0,
        y: 250,
        ex: 600,
        ey: 600,
        binaryzation: false,
        matchCount: 2,
        filterText: ['编辑主页','互关']
    }
    DouYin.prototype.评论区_title = {
        name: '评论区_title',
        textArray: ['大家都在搜', '条评论'],
        x: 0,
        y: 40,
        ex: ScreenWidth,
        ey: 520,
        binaryzation: false,
        matchCount: 1
    }
    DouYin.prototype.评论区_图片查看 = {
        name: '评论区_图片查看',
        textArray: ['我也发一张'],
        x: 0,
        y: 820,
        ex: 300,
        ey: 1200,
        binaryzation: false,
        matchCount: 1
    }


    DouYin.prototype.搜索反馈与建议 = {
        name: '搜索反馈与建议',
        textArray: ['搜索反馈与建议', '找不到自己的账号', '找不到我粉丝的账号', '其他', '找不到我关注的账号', '找不到我关注的账号', '找不到该作者', '下一步'],
        x: 0,
        y: 430,
        ex: ScreenWidth,
        ey: ScreenHeight,
        binaryzation: false,
        matchCount: 2
    }

    DouYin.prototype.用户账号已注销 = {
        name: '用户账号已注销',
        textArray: ['账号已注销', '用户已将自己账号注销', '所属内容无法查看', '注销'],
        x: 0,
        y: 300,
        ex: ScreenWidth,
        ey: 800,
        binaryzation: false,
        matchCount: 2
    }

    DouYin.prototype.用户作品主页_更多弹出窗 = {
        name: '用户作品主页_更多弹出窗',
        textArray: ['分享名片', '发私信', '拉黑', '设置备注','举报','设置分组','是朋友','添加密友','移除粉丝'],
        x: 0,
        y: 40,
        ex: ScreenWidth,
        ey: ScreenHeight,
        binaryzation: false,
        matchCount: 2
    }

    DouYin.prototype.互相关注_用户作品主页_更多弹出窗 = {
        name: '互相关注_用户作品主页_更多弹出窗',
        textArray: ['分享名片', '发私信', '拉黑', '设置备注','举报','设置分组','是朋友','添加密友','移除粉丝'],
        x: 0,
        y: 40,
        ex: ScreenWidth,
        ey: ScreenHeight,
        binaryzation: false,
        matchCount: 2
    }


    DouYin.prototype.消息列表_互动消息_页面标识 = {
        name: '消息列表_互动消息_页面标识',
        textArray: ['全部消息', '全部'],
        x: 250,
        y: 40,
        ex: 490,
        ey: 140,
        binaryzation: false,
        matchCount: 1
    }
    DouYin.prototype.消息列表_陌生人消息_页面标识 = {
        name: '消息列表_陌生人消息_页面标识',
        textArray: ['陌生人消息', '陌生人'],
        x: 140,
        y: 40,
        ex: 580,
        ey: ScreenHeight,
        binaryzation: false,
        matchCount: 1
    }
    DouYin.prototype.私信页面_确认聊天_页面标识 = {
        name: '私信页面_确认聊天_页面标识',
        textArray: ['拉黑', '删除', '确认聊天'],
        x: 0,
        y: 1000,
        ex: ScreenWidth,
        ey: ScreenHeight,
        binaryzation: false,
        matchCount: 1
    }

    DouYin.prototype.用户主页无作品 = {
        name: '用户主页无作品',
        textArray: ['还没有作品', '没有作品', '发布的作品会显示在这里', '私密账号', '查看内容和喜欢'],
        x: 0,
        y: 720,
        ex: ScreenWidth,
        ey: 888,
        binaryzation: false,
        matchCount: 1
    }

    DouYin.prototype.搜索页_话题_立即参与 = {
        name: '搜索页_话题_立即参与',
        textArray: ['立即参与'],
        x: 530,
        y: 220,
        ex: ScreenWidth,
        ey:ScreenHeight,
        binaryzation: false,
        matchCount: 1
    }

    DouYin.prototype.话题页_话题导航 = {
        name: '搜索页_话题收藏',
        textArray: ['综合', '最热','最新','相似话题','收藏'],
        x: 0,
        y: 100,
        ex: ScreenWidth,
        ey:700,
        binaryzation: false,
        matchCount: 3
    }

    DouYin.prototype.抖音主页我的 = {
        name:'抖音主页我的',
        textArray: ['添加朋友', '编辑主页','作品','喜欢','新访客'],
        x: 0,
        y: 0,
        ex: ScreenWidth,
        ey:ScreenHeight,
        binaryzation: false,
        matchCount: 4
    }

    DouYin.prototype.编辑资料页面 = {
        name:'编辑资料页面',
        textArray: ['更换头像','名字','简介','生日','抖音号','学校'],
        x: 0,
        y: 0,
        ex: ScreenWidth,
        ey:ScreenHeight,
        binaryzation: false,
        matchCount: 4
    }

    DouYin.prototype.我的_设置页面 = {
        name:'我的_设置页面',
        textArray: ['设置','更多功能'],
        x: 250,
        y: 0,
        ex: ScreenWidth,
        ey:ScreenHeight,
        binaryzation: false,
        matchCount: 2
    }

    DouYin.prototype.账号与安全页面 = {
        name:'账号与安全页面',
        textArray: ['切换账号'],
        x: 0,
        y: 50,
        ex: ScreenWidth,
        ey:450,
        binaryzation: false,
        matchCount: 1
    }

    DouYin.prototype.搜索视频_播放页面_title = {
        name:'搜索视频_播放页面_title',
        textArray: ['搜你想看的', '搜索'],
        x: 0,
        y: 40,
        ex: ScreenWidth,
        ey:130,
        binaryzation: true,
        matchCount: 2
    }

    DouYin.prototype.视频播放_广告_播放完毕 = {
        name:'视频播放_广告_播放完毕',
        textArray: ['立即了解', '点击重播', '详情'],
        x: 0,
        y: 1250,
        ex: ScreenWidth,
        ey: ScreenHeight,
        binaryzation: false,
        matchCount: 2
    }

    DouYin.prototype.粉丝群标识 = {
        name: '粉丝群标识',
        textArray: ['公开群','按可加入排序','进群','加入'],
        x: 0,
        y: 0,
        ex: ScreenWidth,
        ey: 1330,
        binaryzation: false,
        matchCount: 2
    }

    DouYin.prototype.粉丝群加入标识 = {
        name: '粉丝群加入标识',
        textArray: ['立即加入','可进群','已关注','已满足'],
        x: 0,
        y: 0,
        ex: ScreenWidth,
        ey: 1330,
        binaryzation: false,
        matchCount: 2
    }

    DouYin.prototype.粉丝群页面标识 = {
        name: '粉丝群页面标识',
        textArray: ['名群成员','刚刚','你通过','加入了'],
        x: 0,
        y: 0,
        ex: ScreenWidth,
        ey: 1330,
        binaryzation: false,
        matchCount: 2
    }

    DouYin.prototype.粉丝群详情页面标识 = {
        name: '粉丝群详情页面标识',
        textArray: ['群聊成员','群资料','聊天信息','群公告'],
        x: 0,
        y: 0,
        ex: ScreenWidth,
        ey: 1330,
        binaryzation: false,
        matchCount: 2
    }

    DouYin.prototype.粉丝群粉丝列表页面 = {
        name: '粉丝群粉丝列表页面',
        textArray: ['群成员','搜索','群主','管理员','最早','最近'],
        x: 0,
        y: 0,
        ex: ScreenWidth,
        ey: 1330,
        binaryzation: false,
        matchCount: 1
    }

    DouYin.prototype.图文搜索_综合页面非视频排除 = {
        name: '图文搜索_综合页面非视频排除',
        textArray: ['抖音百科','相关搜索','温馨提示'],
        x: 0,
        y: 0,
        ex: ScreenWidth,
        ey: 1330,
        binaryzation: false,
        matchCount: 1
    }

    DouYin.prototype.图文搜索_滑动作品误触抖音百科 = {
        name: '图文搜索_滑动作品误触抖音百科',
        textArray: ['抖音百科','目录','本条目'],
        x: 0,
        y: 0,
        ex: ScreenWidth,
        ey: 1330,
        binaryzation: false,
        matchCount: 1
    }

    DouYin.prototype.图文搜索_滑动作品误触今日头条 = {
        name: '图文搜索_滑动作品误触今日头条',
        textArray: ['头条','APP内打开'],
        x: 0,
        y: 1170,
        ex: ScreenWidth,
        ey: 1330,
        binaryzation: false,
        matchCount: 1
    }

    DouYin.prototype.评论区_发送图片误触返回 = {
        name: '评论区_发送图片误触返回',
        textArray: ['最近项目','图片','动图','拍照'],
        x: 0,
        y: 45,
        ex: ScreenWidth,
        ey: 400,
        binaryzation: false,
        matchCount: 1
    }
}

