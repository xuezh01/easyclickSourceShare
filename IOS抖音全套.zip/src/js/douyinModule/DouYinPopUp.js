/**
 * @description  抖音弹窗处理
 */

DouYin.prototype.抖音弹窗检测 = function (ocr内容, start_time){
    if(通讯录授权弹窗(ocr内容)){
        日志打印_debug(`====【ocr处理弹窗】耗时：${time()-start_time} =========`)
        return true
    }
    if(剪切板粘贴请求弹窗(ocr内容)){
        日志打印_debug(`====【ocr处理弹窗】耗时：${time()-start_time} =========`)
        return true
    }
    if(位置访问授权请求弹窗(ocr内容)){
        日志打印_debug(`====【ocr处理弹窗】耗时：${time()-start_time} =========`)
        return true
    }
    if(开启评论回复提醒请求弹窗(ocr内容)){
        日志打印_debug(`====【ocr处理弹窗】耗时：${time()-start_time} =========`)
        return true
    }
    if(休息弹窗(ocr内容)){
        日志打印_debug(`====【ocr处理弹窗】耗时：${time()-start_time} =========`)
        return true
    }
    if(悬浮窗播放提醒弹窗(ocr内容)){
        日志打印_debug(`====【ocr处理弹窗】耗时：${time()-start_time} =========`)
        return true
    }
    if (点击合集误触返回(ocr内容)){
        日志打印_debug("进入集合误触:{}",JSON.stringify(ocr内容))
        日志打印_debug(`====【ocr处理弹窗】耗时：${time()-start_time} =========`)
        return true
    }
    if(网络连接弹窗(ocr内容)){
        日志打印_debug(`====【ocr处理弹窗】耗时：${time()-start_time} =========`)
        return true
    }
    if(滑动验证弹窗(ocr内容)){
        日志打印_debug(`====【ocr处理弹窗】耗时：${time()-start_time} =========`)
        return true
    }
    if(青少年模式弹窗(ocr内容)){
        日志打印_debug(`====【ocr处理弹窗】耗时：${time()-start_time} =========`)
        return true
    }
    if (文图作品展开误触弹窗(ocr内容)){
        日志打印_debug(`====【ocr处理弹窗】耗时：${time()-start_time} =========`)
        return true
    }
    if(软件不再可用弹窗(ocr内容)){
        日志打印_debug(`====【ocr处理弹窗】耗时：${time()-start_time} =========`)
        return true
    }

    // if (评论粉丝群误触弹窗(ocr内容)){
    //     日志打印_debug(`====【ocr处理弹窗】评论粉丝群误触弹窗-耗时：${time()-start_time} =========`)
    //     return true
    // }
    if (评论链接误触弹窗(ocr内容)){
        日志打印_debug(`====【ocr处理弹窗】评论链接误触弹窗-耗时：${time()-start_time} =========`)
        return true
    }
    if (主页访客权限打开(ocr内容)){
        logw(`====【ocr处理弹窗】评论链接误触弹窗-耗时：${time()-start_time} =========`)
        return true
    }
    if (新人福利弹窗检测(ocr内容)){
        logw(`====【ocr处理弹窗】新人福利弹窗检测-耗时：${time()-start_time} =========`)
        return true
    }
    if (身份安全验证弹窗检测(ocr内容)){
        logw(`====【ocr处理弹窗】身份安全验证弹窗检测-耗时：${time()-start_time} =========`)
        api_记录风控日志('抖音', 抖音_获取当前账号的抖音ID(), '身份安全验证', `${JSON.stringify(ocr内容)}`)
        return true
    }
    if (评论区图片回复误触弹窗检测(ocr内容)){
        logw(`====【ocr处理弹窗】评论区图片回复误触弹窗检测-耗时：${time()-start_time} =========`)
        return true
    }
    if (关注私密账号弹窗弹窗检测(ocr内容)){
        logw(`====【ocr处理弹窗】关注私密账号弹窗-耗时：${time()-start_time} =========`)
        return true
    }
    return false
}

关注私密账号弹窗 = {
    name: '关注私密账号弹窗',
    textArray: ['对方已设置', '私密账号', '对方通过请求', '我知道了'],
    matchCount: 3
}
function 关注私密账号弹窗弹窗检测(ocr内容) {
    let 触发关注私密账号弹窗 = 弹窗匹配结果(ocr内容, 关注私密账号弹窗);
    if(触发关注私密账号弹窗){
        日志打印_debug('【处理弹窗】 ====触发关注私密账号弹窗=========')
        const 触发关注私密账号弹窗关闭 = {name: '触发关注私密账号弹窗关闭', x: random(290, 450), y:random(778, 818)};
        点击(触发关注私密账号弹窗关闭);
        return true
    }
    return false
}

评论区图片回复误触 = {
    name: '评论区图片回复误触',
    textArray: ['最近项目', '图片', '动图', '拍照'],
    matchCount: 3
}
function 评论区图片回复误触弹窗检测(ocr内容) {
    let 评论区图片回复误触弹窗 = 弹窗匹配结果(ocr内容, 评论区图片回复误触);
    if(评论区图片回复误触弹窗){
        日志打印_debug('【处理弹窗】 ====评论区图片回复误触弹窗=========')
        const 评论区图片回复误触弹窗关闭 = {name: '评论区图片回复误触弹窗关闭', x: random(45, 63), y:random(85, 95)};
        点击(评论区图片回复误触弹窗关闭);
        return true
    }
    return false
}

身份安全验证弹窗内容 = {
    name: '身份安全验证',
    textArray: ['系统识别你的', '操作环境', '存在风险', '保证账号安全', '完成', '身份验证'],
    matchCount: 3
}
function 身份安全验证弹窗检测(ocr内容) {
    let 身份安全验证 = 弹窗匹配结果(ocr内容, 身份安全验证弹窗内容);
    if(身份安全验证){
        日志打印_debug('【处理弹窗】 ====身份安全验证=========')
        const 身份安全验证弹窗关闭 = {name: '身份安全验证——取消按钮', x: random(192, 282), y:random(754, 808)};
        点击(身份安全验证弹窗关闭);
        return true
    }
    return false
}


通讯录授权内容 = {
    name: '通讯录授权内容',
    textArray: ['访问你的通讯录', '访问通讯录', '更改授权', '设置中'],
    matchCount: 3
}
function 通讯录授权弹窗(ocr内容) {
    let 通讯录授权 = 弹窗匹配结果(ocr内容, 通讯录授权内容);
    if(通讯录授权){
        日志打印_debug('【处理弹窗】 ====通讯录授权弹窗=========')
        const 通讯录授权弹窗关闭 = {name: '通讯录授权弹窗', x: random(190, 280), y:random(920, 960)};
        点击(通讯录授权弹窗关闭);
        return true
    }
    return false
}

剪切板粘贴请求 = {
    name: '剪切板粘贴请求',
    textArray: ['允许粘贴', '不允许粘贴', '你允许这样做吗'],
    matchCount: 2
}
function 剪切板粘贴请求弹窗(ocr内容) {
    let 剪切板粘贴 = 弹窗匹配结果(ocr内容, 剪切板粘贴请求);
    if(剪切板粘贴){
        日志打印_debug('【处理弹窗】 ====剪切板粘贴请求弹窗=========')
        const 剪切板粘贴弹窗关闭 = {name: '剪切板粘贴请求弹窗', x: random(420, 590), y:random(740, 780)};
        点击(剪切板粘贴弹窗关闭);
        return true
    }
    return false
}

位置访问授权请求 = {
    name: '位置访问授权请求',
    textArray: ['使用App时允许', '允许一次', '不允许', '使用你的位置', '分享你的位置'],
    matchCount: 2
}
function 位置访问授权请求弹窗(ocr内容) {
    let 位置访问授权 = 弹窗匹配结果(ocr内容, 位置访问授权请求);
    if(位置访问授权){
        日志打印_debug('【处理弹窗】 ====位置访问授权请求弹窗=========')
        const 位置访问授权弹窗关闭 = {name: '位置访问授权请求弹窗', x: random(270, 470), y:random(915, 960)};
        点击(位置访问授权弹窗关闭);
        return true
    }
    return false
}

开启评论回复提醒请求 = {
    name: '开启评论回复提醒请求弹窗',
    textArray: ['及时获得评论回复提醒', '你的评论收到了回复', '去开启', '不错过评论点赞'],
    matchCount: 2
}
function 开启评论回复提醒请求弹窗(ocr内容) {
    let 开启评论回复提醒 = 弹窗匹配结果(ocr内容, 开启评论回复提醒请求);
    if(开启评论回复提醒){
        日志打印_debug('【处理弹窗】 ====开启评论回复提醒请求弹窗=========')
        const 开启评论回复提醒请求弹窗关闭 = {name: '开启评论回复提醒请求弹窗', x: random(680, 690), y:random(860, 880)};
        点击(开启评论回复提醒请求弹窗关闭);
        return true
    }
    return false
}

休息弹窗提醒 = {
    name: '休息弹窗提醒',
    textArray: ['休息一下吧', '设置提醒', '合理分配时间', '提醒我休息', '使用管理助手'],
    matchCount: 2
}
function 休息弹窗(ocr内容) {
    let 出现休息弹窗提醒 = 弹窗匹配结果(ocr内容, 休息弹窗提醒);
    if(出现休息弹窗提醒){
        日志打印_debug('【处理弹窗】 ====休息弹窗=========')
        const 关闭休息弹窗 = {name: '关闭休息弹窗', x: random(150, 290), y:random(1125, 1175)};
        点击(关闭休息弹窗);
        return true
    }
    return false
}

悬浮窗播放提醒 = {
    name: '悬浮窗播放提醒',
    textArray: ['悬浮窗播放', '开启直播悬浮窗', '暂不使用', '立即开启', '继续观看精彩直播'],
    matchCount: 2
}
function 悬浮窗播放提醒弹窗(ocr内容) {
    let 出现悬浮窗播放提醒 = 弹窗匹配结果(ocr内容, 悬浮窗播放提醒);
    if(出现悬浮窗播放提醒){
        日志打印_debug('【处理弹窗】 ====悬浮窗播放提醒弹窗=========')
        const 关闭悬浮窗播放提醒弹窗 = {name: '关闭悬浮窗播放提醒弹窗', x: random(170, 300), y:random(775, 810)};
        点击(关闭悬浮窗播放提醒弹窗);
        return true
    }
    return false
}

点击合集误触 = {
    name: '点击合集误触',
    textArray: ['分享合集', '收藏合集'],
    matchCount: 2
}
function 点击合集误触返回(ocr内容) {
    let 误触合集弹窗 = 弹窗匹配结果(ocr内容, 点击合集误触);
    if(误触合集弹窗){
        日志打印_debug('【处理弹窗】 ====合集误触弹窗=========')
        const 关闭合集误触弹窗 = {name: '关闭合集误触弹窗', x: random(680, 715), y:random(388, 432)};
        点击(关闭合集误触弹窗);
        iSleep(1500)
        const 返回正常页面 = {name: '关闭合集误触弹窗返回键', x: random(26, 66), y:random(66, 96)};
        点击(返回正常页面);
        return true
    }
    return false
}

网络连接提醒 = {
    name: '网络连接提醒',
    textArray: ['网络上的设备', '不允许', '查找并连接'],
    matchCount: 2
}
function 网络连接弹窗(ocr内容) {
    let 出现网络连接提醒 = 弹窗匹配结果(ocr内容,网络连接提醒)
    if(出现网络连接提醒){
        日志打印_debug('【处理弹窗】 ====网络连接提醒弹窗=========')
        const 关闭网络连接提醒弹窗 = {name: '关闭网络连接提醒弹窗', x: random(450, 580), y:random(758, 810)};
        点击(关闭网络连接提醒弹窗);
        return true
    }
    return false
}

滑动验证提醒 = {
    name: '滑动验证提醒',
    textArray: ['请完成下列验证后继续', '上方拼图'],
    matchCount: 2
}
function 滑动验证弹窗(ocr内容) {
    let 出现滑动验证提醒 = 弹窗匹配结果(ocr内容,滑动验证提醒)
    if(出现滑动验证提醒){
        日志打印_debug('【处理弹窗】 ====滑动验证弹窗=========')
        const 关闭滑动验证弹窗 = {name: '关闭滑动验证弹窗', x: random(620, 644), y:random(390, 414)};
        点击(关闭滑动验证弹窗);
        return true
    }
    return false
}

青少年模式提醒 = {
    name: '青少年模式提醒',
    textArray: ['开启青少年模式','我知道了'],
    matchCount: 2
}
function 青少年模式弹窗(ocr内容) {
    let 出现青少年模式提醒 = 弹窗匹配结果(ocr内容,青少年模式提醒)
    if(出现青少年模式提醒){
        日志打印_debug('【处理弹窗】 ====青少年模式弹窗=========')
        // const 关闭青少年模式弹窗 = {name: '关闭青少年模式弹窗', x: random(620, 644), y:random(390, 414)};
        // 点击(关闭青少年模式弹窗);
        dy_模糊查询带点击(0,ScreenHeight/2,ScreenWidth,ScreenHeight,'我知道了')
        return true
    }
    return false
}

软件不再可用提醒 = {
    name: '软件不再可用提醒',
    textArray: ['不再可用'],
    matchCount: 2
}
function 软件不再可用弹窗(ocr内容) {
    let 出现软件不再可用提醒 = 弹窗匹配结果(ocr内容,软件不再可用提醒)
    if(出现软件不再可用提醒){
        日志打印_debug('【处理弹窗】 ====软件不再可用弹窗=========')
        const 关闭软件不再可用弹窗 = {name: '关闭软件不再可用弹窗', x: random(310, 436), y:random(712, 780)};
        点击(关闭软件不再可用弹窗);
        return true
    }
    return false
}


文图作品展开误触 = {
    name: '文图作品展开误触',
    textArray: ['说点什么','关注'],
    matchCount: 2
}
function 文图作品展开误触弹窗(ocr内容) {
    let 文图作品展开误触弹窗 = 弹窗匹配结果(ocr内容,文图作品展开误触)
    if(文图作品展开误触弹窗){
        日志打印_debug('【处理弹窗】 ====文图作品展开误触弹窗返回=========')
        const 文图作品展开误触弹窗返回 = {name: '文图作品展开误触弹窗返回', x: random(26, 66), y:random(66, 96)};
        点击(文图作品展开误触弹窗返回);
        return true
    }
    return false
}

评论链接误触 = {
    name: '评论链接误触',
    textArray: ['说点什么' ,'关注'],
    matchCount: 2
}
function 评论链接误触弹窗(ocr内容) {
    let 评论链接误触弹窗 = 弹窗匹配结果(ocr内容,评论链接误触)
    if(评论链接误触弹窗){
        日志打印_debug('【处理弹窗】 ====评论链接误触弹窗返回=========')
        const 评论链接误触弹窗返回 = {name: '评论链接误触弹窗返回', x: random(26, 66), y:random(66, 96)};
        点击(评论链接误触弹窗返回);
        return true
    }
    return false
}

评论粉丝群误触 = {
    name: '评论粉丝群误触',
    textArray: ['群主', '申请加入', '粉丝群', '进群门槛'],
    matchCount: 2
}
function 评论粉丝群误触弹窗(ocr内容) {
    let 评论粉丝群误触弹窗 = 弹窗匹配结果(ocr内容,评论粉丝群误触)
    if(评论粉丝群误触弹窗){
        日志打印_debug('【处理弹窗】 ====评论粉丝群误触弹窗=========')
        const 评论粉丝群误触弹窗返回 = {name: '评论粉丝群误触弹窗返回', x: random(96, 192), y:random(142, 196)};
        点击(评论粉丝群误触弹窗返回);
        return true
    }
    return false
}

悬浮窗播放提醒 = {
    name: '悬浮窗播放提醒',
    textArray: ['悬浮窗播放', '开启直播悬浮窗', '暂不使用', '立即开启', '继续观看精彩直播'],
    matchCount: 2
}
function 悬浮窗播放提醒弹窗(ocr内容) {
    let 出现悬浮窗播放提醒 = 弹窗匹配结果(ocr内容, 悬浮窗播放提醒);
    if(出现悬浮窗播放提醒){
        日志打印_debug('【处理弹窗】 ====悬浮窗播放提醒弹窗=========')
        const 关闭悬浮窗播放提醒弹窗 = {name: '关闭悬浮窗播放提醒弹窗', x: random(170, 300), y:random(775, 810)};
        点击(关闭悬浮窗播放提醒弹窗);
        return true
    }
    return false
}

dy主页访客开启 = {
    name: '主页访客开启',
    textArray: ['开启访客', '主页访客', '保持关闭', '授权查看'],
    matchCount: 3
}
function 主页访客权限打开(ocr内容) {
    let 主页访问权限开启 = 弹窗匹配结果(ocr内容, dy主页访客开启);
    if(主页访问权限开启){
        logd('【处理弹窗】 ====主页访客权限打开=========')
        const 主页访客权限打开 = {name: '主页访客权限打开', x: random(160, 580), y:random(870, 920)};
        点击(主页访客权限打开);
        return true
    }
    return false
}

新人福利弹窗 = {
    name: '新人福利弹窗',
    textArray: ['你有新人限时福利', '不感兴趣', '新人福利'],
    matchCount: 2
}
function 新人福利弹窗检测(ocr内容) {
    let 新人福利弹窗检测结果 = 弹窗匹配结果(ocr内容, 新人福利弹窗);
    if(新人福利弹窗检测结果){
        logd('【处理弹窗】 ====新人福利弹窗=========')
        const 新人福利弹窗关闭 = {name: '新人福利弹窗关闭', x: random(136, 260), y:random(1076, 1114)};
        点击(新人福利弹窗关闭);
        return true
    }
    return false
}
