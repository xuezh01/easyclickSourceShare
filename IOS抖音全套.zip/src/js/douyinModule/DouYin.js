
function DouYin() {
}

douyin = new DouYin()
douyin.当前账号_私信跟进列表 = []
douyin.私信跟进失败列表 = []
douyin.当前账号_评论跟进列表 = []
douyin.需要切换账号跟进 = false
douyin.关键词已无视频 = null
douyin.关键词已无用户 = null
douyin.私信已发送列表 = []
douyin.刺客流启动时间 = null
douyin.底部导航_首页_按钮 = {name: '底部导航_首页_按钮', x: random(36, 112), y:random(1262,1306)}
douyin.底部导航_消息_按钮 = {name: '底部导航_消息_按钮', x: random(495, 555), y:random(1262,1306)}
douyin.底部导航_我_按钮 = {name: '底部导航_我_按钮', x: random(646, 700), y:random(1262,1300)}
douyin.底部导航_我_右上角菜单_按钮 = {name: '底部导航_我_按钮', x: random(670,700), y:random(72,96)}
douyin.底部导航_首页_右上角搜索_按钮 = {name: '底部导航_首页_右上角搜索_按钮', x: random(678, 700), y:random(69, 92)}
douyin.搜索页面_搜索输入框_按钮 = {name: '搜索页面_搜索输入框_按钮', x: random(190, 430), y:random(65,95)}
douyin.用户主页_右上角_更多_按钮 = {name: '用户主页_右上角_更多_按钮', x: random(660, 700), y:random(60, 100)}
douyin.用户主页_返回按钮 = {name: '用户主页_返回按钮', x: random(50, 60), y:random(80,90)}
douyin.评论区_底部_评论输入框 = {name: '评论区_底部_评论输入框', x: random(88, 450), y:random(1255,1300)};
douyin.搜索页_左上角_返回按钮 = {name: '搜索页_左上角_返回按钮', x: random(42, 47), y:random(80,87)};
douyin.私信页_聊天详情_用户头像按钮 = {name: '私信页_聊天详情_用户头像按钮', x: random(100, 510), y:random(180,240)};
douyin.私信页_右上角_聊天详情按钮 = {name: '私信页_右上角_聊天详情按钮', x: random(680, 710), y:random(79,85)};
douyin.消息列表_搜索页_顶部输入框 = {name: '消息列表_搜索页_顶部输入框', x: random(151, 360), y:random(69,96)};
douyin.消息列表_搜索页_取消按钮 = {name: '消息列表_搜索页_取消按钮', x: random(664, 710), y:random(70,90)};
douyin.搜索时间 = null
douyin.跟进时间 = null
douyin.切号时间 = null
douyin.今日搜索结果频繁次数 = 0


DouYin.prototype.dy_启动抖音 = function (){
    当前执行模块 = 'dy_启动抖音';
    日志打印_debug('开始执行 -- 【dy_启动抖音】')
    api_记录风控日志('抖音', 抖音_获取当前账号的抖音ID(), '操作', '启动抖音')
    appBundleId = null;
    let 关闭结果 = appKillByBundleId('com.ss.iphone.ugc.Aweme', '1');
    let 重试次数 = 3;
    while(关闭结果 && 重试次数>0){
        if(isScriptExit()){break}
        sleep(100);
        关闭结果 = appKillByBundleId('com.ss.iphone.ugc.Aweme', '1');
        重试次数--;
    }
    iSleep(100);
    home();  //返回主页面
    iSleep(100);
    let 抖音App = findColor(douyin.抖音App);
    重试次数 = 3;
    while(!抖音App && 重试次数 > 0){
        if(isScriptExit()) {break}
        home();  //返回主页面
        iSleep(100);
        抖音App = findColor(douyin.抖音App);
        重试次数--;
    }
    if(!抖音App){
        日志打印_error('抖音App 寻找失败！')
        return false
    }
    const 抖音启动结果 = 点击后检测(抖音App, douyin.抖音App, [douyin.视频播放页_关注按钮, douyin.首页_顶部导航, douyin.首页_底部导航, douyin.首页_底部导航_二值化], 5000)
    switch (抖音启动结果) {
        case -100:
            日志打印_error('抖音App 位置点击失败！')
            return false
        case -1:
            return false
        case 0:
            break
        case 1:
            break
        case 2:
            break
        case 3:
            break
        case 4:
            break
    }
    appBundleId = 'com.ss.iphone.ugc.Aweme';
    进入实时回复 = false;
    日志打印_debug('   --- 【启动抖音】---  执行结束')

    return true
}

DouYin.prototype.dy_首页导航_切换 = function (page){
    /*
    *  page 1: 首页
    *  page 2: --
    *  page 3: 消息
    *  page 4: 我
    * */
    当前执行模块 = 'dy_首页导航_切换';
    日志打印_debug('开始执行 -- 【dy_首页导航_切换】')
    if(page === 2){
        日志打印_error('暂不支持切换到 [2] ！')
        return false
    }
    let 在抖音主页可导航 = ocr文本数组匹配(douyin.首页_底部导航)
    if(!在抖音主页可导航){
        在抖音主页可导航 = ocr文本数组匹配(douyin.首页_底部导航_二值化)
    }
    if(!在抖音主页可导航){
        日志打印_error('未检测到 [首页_底部导航]， 无法进行切换！')
        return false
    }
    if (page === 1){
        const 切换到_首页 = 点击后检测(douyin.底部导航_首页_按钮, douyin.首页_底部导航_二值化, [douyin.视频播放页_关注按钮, douyin.首页_顶部导航,  douyin.首页_底部导航_首页选中_二值化, douyin.首页_单列_双列])
        if(切换到_首页 === 0 || 切换到_首页 === 1 || 切换到_首页 === 2 || 切换到_首页 === 3) { return true }
        日志打印_error('[切换到_首页] 失败！')
        return false
    }
    if (page === 3){
        const 切换到_消息 = 点击后检测(douyin.底部导航_消息_按钮, douyin.首页_底部导航_二值化, [douyin.消息页_右上角搜索_放大镜])
        if( 切换到_消息 === 0 ) { return true }
        日志打印_error('[切换到_消息] 失败！')
        return false
    }
    if (page === 4){
        const 切换到_我 = 点击后检测(douyin.底部导航_我_按钮, douyin.首页_底部导航_二值化, [douyin.主页_我_页面])
        if( 切换到_我 === 0 ) { return true }
        日志打印_error('[切换到_我] 失败！')
        return false
    }
}

DouYin.prototype.dy_我_页面_当前账号信息 = function () {
    当前执行模块 = 'dy_我_页面_当前账号信息';
    日志打印_debug('开始执行 -- 【dy_我_页面_当前账号信息】')
    setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
    let 抖音号_节点 = type("Button").labelMatch("抖音号.*").getOneNodeInfo(10000);
    let tryCount = 3;
    while(!抖音号_节点 && tryCount>0){
        if(isScriptExit()) {break}
        iSleep(100)
        const 还在预期页面 = ocr文本数组匹配(douyin.主页_我_页面)
        if(还在预期页面){
            抖音号_节点 = type('Button').labelMatch("抖音号.*").getOneNodeInfo(10000);
        }
        tryCount--;
    }
    if(!抖音号_节点){
        日志打印_error('获取 [抖音号_节点] 失败！')
        return
    }

    const 抖音号 = douyin.裁剪ocr的抖音号(抖音号_节点.label);
    日志打印_warning(`当前账号的抖音号：${抖音号}`)

    const 账号信息 = { 抖音号: 抖音号, 私信功能: ''}

    账号信息.私信功能 = douyin.dy_私信功能检查()
    return 账号信息
}

DouYin.prototype.dy_展开账号右侧弹窗 = function (){
    当前执行模块 = 'dy_展开账号右侧弹窗';
    日志打印_debug('开始执行 -- 【dy_首页检测】')
    const 弹出账号右侧弹窗 = 点击后检测(douyin.底部导航_我_右上角菜单_按钮, douyin.主页_我_页面, [douyin.账号右侧弹窗]);
    switch (弹出账号右侧弹窗) {
        case -100:
            return false
        case -1:
            return false
        case 0:
            日志打印_debug('执行 [弹出账号右侧弹窗] 成功！');
            return true
    }
}

DouYin.prototype.dy_私信功能检查 = function (){
    当前执行模块 = 'dy_私信功能检查';
    日志打印_debug('开始执行 -- 【dy_私信功能检查】')

    setFetchNodeParam({"labelFilter":"2","maxDepth":"18","visibleFilter":"1","boundsFilter":"2","excludedAttributes":""})

    let 私信功能_节点 = bounds(0,40,ScreenWidth, 550).labelMatch(".*使用私信.*").getOneNodeInfo(10000)
    let tryCount = 2;
    while(!私信功能_节点 && tryCount>0){
        if(isScriptExit()) {break}
        iSleep(100)
        const 还在预期页面 = ocr文本数组匹配(douyin.主页_我_页面)
        if(还在预期页面){
            私信功能_节点 = bounds(0,40,ScreenWidth, 550).labelMatch(".*使用私信.*").getOneNodeInfo(10000)
        }
        tryCount--;
    }
    日志打印_warning(JSON.stringify(私信功能_节点))
    return 私信功能_节点 ? 私信功能_节点.label : '正常';
}

DouYin.prototype.dy_进入账号设置页面 = function (){
    当前执行模块 = 'dy_进入账号设置页面';
    日志打印_debug('开始执行 -- 【dy_进入账号设置页面】')

    let 右侧弹窗_设置按钮 = findColor(douyin.右侧弹窗_设置按钮1);
    if(!右侧弹窗_设置按钮){
        右侧弹窗_设置按钮 = findColor(douyin.右侧弹窗_设置按钮2);
        if(!右侧弹窗_设置按钮){
            setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
            let 设置_节点 = type("Button").label('设置').getOneNodeInfo(10000)
            let tryCount = 3;
            while (!设置_节点 && tryCount>0){
                if(isScriptExit()){break}

                iSleep(100)
                const 还在预期页面 = ocr文本数组匹配(douyin.账号右侧弹窗);
                if(还在预期页面){
                    设置_节点 = type("Button").label('设置').getOneNodeInfo(10000)
                }
                tryCount--;
            }
            if(!设置_节点){
                日志打印_error('寻找 [右侧弹窗_设置按钮] 失败！');
                return false
            }
            右侧弹窗_设置按钮 = {name: '右侧弹窗_设置按钮', x: 设置_节点.bounds.left/2+设置_节点.bounds.right/2, y: 设置_节点.bounds.top/2+设置_节点.bounds.bottom/2}
        }

    }

    const 进入账号设置页面 = 点击后检测(右侧弹窗_设置按钮, douyin.账号右侧弹窗, [douyin.账号设置页面]);
    switch (进入账号设置页面) {
        case -100:
            return false
        case -1:
            return false
        case 0:
            日志打印_debug('进入 [账号设置页面] 成功！');
            return true
    }
}

DouYin.prototype.dy_进入切换账号页面 = function (){
    当前执行模块 = 'dy_进入切换账号页面';
    日志打印_debug('开始执行 -- 【dy_进入切换账号页面】')

    let 设置_账号与安全_按钮 = findColor(douyin.设置_账号与安全_按钮);

    if(!设置_账号与安全_按钮){
        setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
        let 账号与安全_节点 = type("StaticText").label('账号与安全').getOneNodeInfo(10000)
        let tryCount = 3;
        while (!账号与安全_节点 && tryCount>0){
            if(isScriptExit()){break}
            iSleep(100)
            const 还在预期页面 = findColor(douyin.账号设置页面);
            if(还在预期页面){
                账号与安全_节点 = type("StaticText").label('账号与安全').getOneNodeInfo(10000)
            }
            tryCount--;
        }
        if(!账号与安全_节点){
            日志打印_error('寻找 [设置_账号与安全_按钮] 失败！');
            return false
        }
        设置_账号与安全_按钮 = {name: '设置_账号与安全_按钮', x: 账号与安全_节点.bounds.left/2+账号与安全_节点.bounds.right/2, y: 账号与安全_节点.bounds.top/2+账号与安全_节点.bounds.bottom/2}
    }

    const 进入账号与安全页面 = 点击后检测(设置_账号与安全_按钮, douyin.账号设置页面, [douyin.账号与安全页面]);
    switch (进入账号与安全页面) {
        case -100:
            return false;
        case -1:
            return false
        case 0:
            日志打印_debug('进入 [账号与安全页面] 成功！');
            break
    }
    setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
    let 切换账号_节点 = type("StaticText").label('切换账号').getOneNodeInfo(10000)
    let 重试次数 = 3;
    while(!切换账号_节点){
        if(isScriptExit()){break}
        iSleep(100)
        const 还在预期页面 = ocr文本数组匹配(douyin.账号与安全页面)
        if(还在预期页面){
            切换账号_节点 = type("StaticText").label('切换账号').getOneNodeInfo(10000)
        }
        重试次数 = 重试次数--;
    }
    if(!切换账号_节点){
        日志打印_error('寻找 [切换账号_按钮] 失败！');
        return false
    }
    const 切换账号_按钮_位置 = {name: '切换账号_按钮', x:切换账号_节点.bounds.left/2+切换账号_节点.bounds.right/2, y:切换账号_节点.bounds.top/2+切换账号_节点.bounds.bottom/2}
    const 进入切换账号页面 = 点击后检测(切换账号_按钮_位置, douyin.账号与安全页面, [douyin.添加或注册新账号]);
    switch (进入切换账号页面) {
        case -100:
            return false;
        case -1:
            return false
        case 0:
            日志打印_debug('进入 [切换账号页面] 成功！');
            return true
    }
}

DouYin.prototype.dy_统计账号信息 = function (){
    当前执行模块 = 'dy_统计账号信息';
    日志打印_debug('开始执行 -- 【dy_统计账号信息】')

    setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
    let Table_节点 = type("Table").getOneNodeInfo(10000);
    let 重试次数 = 3;
    while (!Table_节点){
        if(isScriptExit()) {break}
        iSleep(100)
        const 还在预期页面 = findColor(douyin.添加或注册新账号)
        if(还在预期页面){
            Table_节点 = type("Table").getOneNodeInfo(10000);
        }
        重试次数--;
    }
    if(!Table_节点){
        日志打印_error('获取 [Table_节点] 失败！');
        return
    }
    const children = Table_节点.allChildren();
    const 账号信息 = [];
    let 即将切换的账号 = null;
    for(let i in children){
        if(isScriptExit()) {break}

        const child = children[i];
        if(child.type === 'Cell' && child.label && child.label.includes('粉丝')){
            const 单个账号信息 = child.label.split('，');
            if(单个账号信息.length >= 3){
                const choose = 单个账号信息.includes('已选中');
                const data = {}
                if(单个账号信息[单个账号信息.length-1].endsWith('条未读消息')){
                    data.fans = 单个账号信息[单个账号信息.length-2];
                    data.account = 单个账号信息.slice(1,单个账号信息.length-2).join('，');
                }else {
                    data.fans = 单个账号信息[单个账号信息.length-1];
                    data.account = 单个账号信息.slice(1,单个账号信息.length-1).join('，');
                }
                data.choose = choose
                账号信息.push(data)
            }else {
                日志打印_error(`【账号信息】长度有问题：${单个账号信息}`)
            }
        }
    }
    if(账号信息.length === 0){
        日志打印_error(`统计 [账号信息] 失败:${JSON.stringify(children)}`);
        return
    }
    return 账号信息
}

DouYin.prototype.dy_切换账号 = function (){
    当前执行模块 = 'dy_切换账号';
    日志打印_debug('开始执行 -- 【dy_切换账号】')

    const 账号信息 = [];
    while (true){
        if(isScriptExit()) { break }
        if (!douyin.dy_首页导航_切换(4)) {
            douyin.dy_启动抖音()
            continue
        }
        const 主页_账号切换_按钮 = findMultiColor([douyin.主页_账号切换_未读消息, douyin.主页_账号切换_倒三角])
        if(!主页_账号切换_按钮) {
            日志打印_error('[主页_账号切换_按钮] 寻找失败')
            break
        }
        const 弹出切换账号 = 点击后检测(主页_账号切换_按钮.point, douyin.主页_我_页面, [douyin.添加或注册新账号])
        if(弹出切换账号 !== 0){
            日志打印_error('[主页_账号切换_按钮] 寻找失败')
            break
        }
        账号信息.length = 0
        setFetchNodeParam({"labelFilter":"2","maxDepth":"10","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
        let children = type("Cell").getNodeInfo(10000)
        let 重试次数 = 3
        while (!children && 重试次数 > 0){
            if(isScriptExit()){break}
            iSleep(100)
            const 在预期页面 = findColor(douyin.添加或注册新账号)
            if(在预期页面){
                children = type("Cell").getNodeInfo(10000)
            }
            重试次数--
        }
        if(!children){ continue }
        let 即将切换的账号 = null
        for(let i in children){
            if(isScriptExit()) {break}

            const child = children[i];
            if(child.type === 'Cell' && child.label && child.label.includes('粉丝')){
                const 单个账号信息 = child.label.split('，');
                if(单个账号信息.length >= 3){
                    const choose = 单个账号信息.includes('已选中');
                    const data = {}
                    if(单个账号信息[单个账号信息.length-1].endsWith('条未读消息')){
                        data.fans = 单个账号信息[单个账号信息.length-2];
                        data.account_name = 单个账号信息.slice(1,单个账号信息.length-2).join('，');
                    }else {
                        data.fans = 单个账号信息[单个账号信息.length-1];
                        data.account_name = 单个账号信息.slice(1,单个账号信息.length-1).join('，');
                    }
                    data.choose = choose
                    if(!choose){
                        即将切换的账号 = {name: child.label, x: child.bounds.left/2 + child.bounds.right/2, y: child.bounds.top/2 + child.bounds.bottom/2}
                    }
                    账号信息.push(data)
                }else {
                    日志打印_error(`【账号信息】长度有问题：${单个账号信息}`)
                }
            }
        }
        if(!即将切换的账号){
            break
        }
        const 切换账号_结果 = 点击后检测(即将切换的账号, douyin.添加或注册新账号, [douyin.主页_我_页面], 5000);
        if(切换账号_结果 !== 0){ continue }
        if(!账号信息 || 账号信息.length <= 0){
            continue
        }
        break
    }
    if(设备账号信息.dy.length >=  2){
        const douyinID = 抖音_获取当前账号的抖音ID()
        设备账号信息.dy.forEach( account => {
            if(account.account_id === douyinID){
                account.choose = false
            }else {
                account.choose = true
            }
        })
    }
    let 未关闭_切换账号弹窗 = findColor(douyin.添加或注册新账号)
    while(未关闭_切换账号弹窗){
        if(isScriptExit()) {return }
        点击(douyin.消息页_右上角搜索_放大镜)
        iSleep(500)
        未关闭_切换账号弹窗 = findColor(douyin.添加或注册新账号)
        if(!未关闭_切换账号弹窗){ break }
    }


    douyin.dy_返回_设定页面(douyin.主页_我_页面)
    douyin.切号时间 = time()
    return 账号信息

}

DouYin.prototype.dy_首页搜索按钮点击 = function (search_time_interval){
    当前执行模块 = 'dy_首页搜索按钮点击';
    日志打印_debug('开始执行 -- 【dy_首页搜索按钮点击】')

    while (douyin.搜索时间 && (time() -douyin.搜索时间) < search_time_interval*60*1000) {
        if (isScriptExit()) { return }
        if (!douyin.dy_首页导航_切换(1)) {
            douyin.dy_启动抖音()
            continue
        }
        while (douyin.搜索时间 && (time() -douyin.搜索时间) < search_time_interval*60*1000) {
            if (isScriptExit()) { return }
            douyin.dy_当前账号_跟进客户()
            douyin.dy_首页视频养号(1)
        }
    }
    if (!douyin.dy_首页导航_切换(1)) {
        douyin.dy_启动抖音()
        return
    }
    const 进入搜索页面 = 点击后检测(douyin.底部导航_首页_右上角搜索_按钮, douyin.首页_底部导航, [douyin.搜索页_输入框放大镜, douyin.搜索页_搜索], 2000);
    switch (进入搜索页面) {
        case -100:
            return false
        case 0:
            return true
        case -1:
            return false
        case 1:
            return true
    }
}

DouYin.prototype.dy_搜索页面输入查询 = function (content){
    当前执行模块 = 'dy_搜索页面输入查询';
    日志打印_debug('开始执行 -- 【dy_搜索页面输入查询】')

    const 键盘已弹出 = ocr文本数组匹配(ios.键盘弹出);
    if(!键盘已弹出){
        const 点击_搜索页面的搜索输入框 = 点击后检测(douyin.搜索页面_搜索输入框_按钮, douyin.搜索页_输入框放大镜, [ios.键盘弹出]);
        switch (点击_搜索页面的搜索输入框) {
            case -100:
                return false
            case -1:
                return false
            case 0:
                break;
        }
    }
    文本内容输入(content, douyin.搜索页面_搜索输入框_按钮);
    键盘发送()
    iSleep(1000)
    let 搜索成功 = ocr文本数组匹配(douyin.搜索页_搜索结果标签)
    let 重试次数 = 3
    while (!搜索成功 && 重试次数>0){
        if(isScriptExit()) {break}
        键盘发送()
        iSleep(1000)
        搜索成功 = ocr文本数组匹配(douyin.搜索页_搜索结果标签)
        重试次数--
    }
    douyin.搜索时间 = time()
    api_记录风控日志('抖音', 抖音_获取当前账号的抖音ID(), '操作', '进行了一次搜索')
    return !!搜索成功
}

DouYin.prototype.dy_搜索结果分类选项选择 = function (item){
    当前执行模块 = 'dy_搜索结果分类选项选择';
    日志打印_debug(`开始执行 -- 【dy_搜索结果分类选项选择】-${item}`)

    setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"2","boundsFilter":"1","excludedAttributes":""})
    iSleep(100)
    const 在_搜索页_搜索结果标签 = ocr文本数组匹配(douyin.搜索页_搜索结果标签)
    if(!在_搜索页_搜索结果标签){
        return false
    }

    function getNode() {
        let node = type('StaticText').label(item).getOneNodeInfo(10000);
        let 重试次数 = 2;
        while(!node && 重试次数 > 0){
            if(isScriptExit()){break}
            iSleep(100);
            const 还在预期页面 = ocr文本数组匹配(douyin.搜索页_搜索结果标签)
            if(还在预期页面){
                node = type('StaticText').label(item).getOneNodeInfo(10000);
            }
            重试次数--;
        }
        return node
    }

    let node = getNode();
    if(node && node.parent().label.includes('已选中')){
        return true
    }
    else {
        while(true){
            if(isScriptExit()) {break}
            if(node && node.bounds.right <= 620){
                break
            }
            日志打印_information(`需要滑动选择- ${item}`)
            滑动(450, 160, 110 , 160, 300)
            iSleep(100);
            const 还在预期页面 = ocr文本数组匹配(douyin.搜索页_搜索结果标签)
            if(还在预期页面){
                node = getNode();
            }else {
                return false
            }
        }
    }
    const 标签点击位置 = {name: `点击标签： ${node.name}`, x: node.bounds.left/2 + node.bounds.right/2, y: node.bounds.top/2 + node.bounds.bottom/2}
    点击(标签点击位置);
    return this.dy_搜索结果分类选项选择(item)
}

DouYin.prototype.dy_搜索结果频繁_检测 = function (search_pinfan_hours){
    当前执行模块 = 'dy_搜索结果频繁检测';
    日志打印_debug(`开始执行 -- 【dy_搜索结果频繁检测】`)

    const 搜索结果频繁_服务器 = ocr文本数组匹配(douyin.搜索结果频繁_服务器)
    const 搜索结果频繁 = ocr文本数组匹配(douyin.搜索结果频繁)
    if(搜索结果频繁 || 搜索结果频繁_服务器){
        douyin.今日搜索结果频繁次数 += 1;
        api_记录风控日志('抖音', 抖音_获取当前账号的抖音ID(), '检测', '搜索结果频繁')
    }else {
        if (douyin.今日搜索结果频繁次数 > 0){
            douyin.今日搜索结果频繁次数 -= 1;
        }
    }
    if (douyin.今日搜索结果频繁次数 > 2){
        if (抖音_可切换私信账号()){
            douyin.dy_搜索页_返回首页()
            douyin.dy_切换账号()
            douyin.今日搜索结果频繁次数 -= 1
            return true
        }
        function getFormattedTime(timestamp) {
            const date = new Date(timestamp);

            // 获取年月日时分秒
            const year = date.getFullYear();
            const month = (date.getMonth() + 1).toString().padStart(2, '0'); // 月份从0开始，+1
            const day = date.getDate().toString().padStart(2, '0');
            const hours = date.getHours().toString().padStart(2, '0');
            const minutes = date.getMinutes().toString().padStart(2, '0');
            const seconds = date.getSeconds().toString().padStart(2, '0');

            // 返回格式化后的字符串
            return `${year}年${month}月${day}日 ${hours}时${minutes}分${seconds}秒`;
        }

        while (douyin.搜索时间 && (time() -douyin.搜索时间) < search_pinfan_hours*60*1000) {
            if (isScriptExit()) { return }
            const 养号结束时间 = time() + search_pinfan_hours * 60 * 60 * 1000;
            脚本当前运行阶段 = `【今日搜索频繁】养号，预计结束时间: ${getFormattedTime(养号结束时间)}`
            const 在搜索页 = ocr文本数组匹配(douyin.搜索页_搜索)
            if (在搜索页){
                点击后检测(douyin.搜索页_左上角_返回按钮, douyin.搜索页_搜索, [douyin.视频播放页_关注按钮, douyin.首页_顶部导航, douyin.首页_底部导航])
            }
            if(!douyin.dy_首页导航_切换(1)){
                douyin.dy_启动抖音()
                continue
            }
            while (douyin.搜索时间 && (time() -douyin.搜索时间) < search_pinfan_hours*60*1000) {
                douyin.dy_当前账号_跟进客户()
                douyin.dy_首页视频养号(4)
                douyin.dy_当前账号_跟进客户()
                douyin.dy_切换账号_跟进客户()
            }
        }
        douyin.今日搜索结果频繁次数--
        return true
    }
    return false
}

DouYin.prototype.dy_搜索页_返回首页 = function (){
    当前执行模块 = 'dy_搜索页_返回首页';
    日志打印_debug(`开始执行 -- 【dy_搜索页_返回首页】`)

    const 搜索页_返回首页 = 点击后检测(douyin.搜索页_左上角_返回按钮, douyin.搜索页_搜索, [douyin.视频播放页_关注按钮, douyin.首页_顶部导航, douyin.首页_底部导航, douyin.首页_底部导航_首页选中_二值化])
    switch (搜索页_返回首页) {
        case -1:
            return false
        case -100:
            return false

    }
    return true
}

DouYin.prototype.dy_视频筛选 = function (排序依据, 发布时间, 视频时长, 搜索范围){
    当前执行模块 = 'dy_视频筛选';
    日志打印_debug(`开始执行 -- 【dy_视频筛选】`)

    while(!屏幕区域变化检测(200, 0, 300, ScreenWidth, ScreenHeight)){
        if(isScriptExit()) { return  }
        iSleep(100);
    }
    if (排序依据 === '综合排序' && 发布时间 === '不限' && 视频时长 === '不限' && 搜索范围 === '不限'){
       日志打印_debug('无需筛选')
    }else {
        let 搜索页_右上角_筛选按钮 = findColor(douyin.搜索页_右上角_筛选按钮)
        if(!搜索页_右上角_筛选按钮){
            setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
            let 筛选按钮_节点 = type("Button").label("筛选").getOneNodeInfo(10000)
            let 重试次数 = 3;
            while(!筛选按钮_节点 && 重试次数>0){
                if(isScriptExit()){break}
                iSleep(100);
                const 还在预期页面 = ocr文本数组匹配(douyin.搜索页_搜索结果标签)
                if(还在预期页面){
                    筛选按钮_节点 = type('Button').name("筛选").getOneNodeInfo(10000);
                }
                重试次数--;
            }
            if(!筛选按钮_节点){
                日志打印_error('寻找 [筛选按钮_节点] 失败');
                return false
            }
            搜索页_右上角_筛选按钮 = { name: '搜索页_右上角_筛选按钮',  x: 筛选按钮_节点.bounds.left + (筛选按钮_节点.bounds.right-筛选按钮_节点.bounds.left)/3, y:  筛选按钮_节点.bounds.top/2 + 筛选按钮_节点.bounds.bottom/2}
        }

        const 排序展开点击结果 = 点击后检测(搜索页_右上角_筛选按钮, douyin.搜索页_搜索结果标签, [douyin.搜索页_视频筛选依据]);
        if(排序展开点击结果 !== 0){ return false}

        if (排序依据 !== '综合排序'){
            switch (排序依据) {
                case '最新发布':
                    const 最新发布 = {name: '最新发布', x: random(230, 320), y: random(340, 360)}
                    const 选择_最新发布 = 点击屏幕检测(最新发布, 1000, 60, 200, ScreenWidth, 900)
                    if(!选择_最新发布) { return false }
                    break
                case '最多点赞':
                    const 最多点赞 = {name: '最多点赞', x: random(400, 500), y: random(340, 360)}
                    const 选择_最多点赞 = 点击屏幕检测(最多点赞, 1000, 60, 200, ScreenWidth, 900)
                    if(!选择_最多点赞) { return false }
                    break
            }
            iSleep(1000)
        }
        if (发布时间 !== '不限'){
            switch (发布时间) {
                case '一天内':
                    const 一天内 = {name: '一天内', x: random(240, 320), y: random(515, 540)}
                    const 选择_一天内 = 点击屏幕检测(一天内, 1000, 60, 200, ScreenWidth, 900)
                    if(!选择_一天内) { return false }
                    break
                case '一周内':
                    const 一周内 = {name: '一周内', x: random(410, 480), y: random(515, 540)}
                    const 选择_一周内 = 点击屏幕检测(一周内, 1000, 60, 200, ScreenWidth, 900)
                    if(!选择_一周内) { return false }
                    break
                case '半年内':
                    const 半年内 = {name: '半年内', x: random(585, 660), y: random(515, 540)}
                    const 选择_半年内 = 点击屏幕检测(半年内, 1000, 60, 200, ScreenWidth, 900)
                    if(!选择_半年内) { return false }
                    break
            }
            iSleep(1000)
        }
        if (视频时长 !== '不限'){
            switch (视频时长) {
                case '1分钟以下':
                    const 一分钟以下 = {name: '一分钟以下', x: random(240, 340), y: random(690, 715)}
                    const 选择_一分钟以下 = 点击屏幕检测(一分钟以下, 1000, 60, 200, ScreenWidth, 900)
                    if(!选择_一分钟以下) { return false }
                    break
                case '1-5分钟':
                    const 一五分钟 = {name: '一五分钟', x: random(425, 510), y: random(690, 715)}
                    const 选择_一五分钟 = 点击屏幕检测(一五分钟, 1000, 60, 200, ScreenWidth, 900)
                    if(!选择_一五分钟) { return false }
                    break
                case '5分钟以上':
                    const 五分钟以上 = {name: '五分钟以上', x: random(590, 670), y: random(690, 715)}
                    const 选择_五分钟以上 = 点击屏幕检测(五分钟以上, 1000, 60, 200, ScreenWidth, 900)
                    if(!选择_五分钟以上) { return false }
                    break
            }
            iSleep(1000)
        }
        if (搜索范围 !== '不限'){
            switch (搜索范围) {
                case '关注的人':
                    const 关注的人 = {name: '关注的人', x: random(235, 320), y: random(865, 890)}
                    const 选择_关注的人 = 点击屏幕检测(关注的人, 1000, 60, 200, ScreenWidth, 900)
                    if(!选择_关注的人) { return false }
                    break
                case '最近看过':
                    const 最近看过 = {name: '最近看过', x: random(405, 495), y: random(865, 890)}
                    const 选择_最近看过 = 点击屏幕检测(最近看过, 1000, 60, 200, ScreenWidth, 900)
                    if(!选择_最近看过) { return false }
                    break
                case '还未看过':
                    const 还未看过 = {name: '选择_还未看过', x: random(580, 650), y: random(865, 890)}
                    const 选择_还未看过 = 点击屏幕检测(还未看过, 1000, 60, 200, ScreenWidth, 900)
                    if(!选择_还未看过) { return false }
                    break
            }
            iSleep(1000)
        }
        const 关闭排序页面 = 点击屏幕检测(搜索页_右上角_筛选按钮, 1000, 60, 200, ScreenWidth, 900)
        if(!关闭排序页面){
            日志打印_error('（关闭排序页面）失败！')
            return false
        }
    }

    iSleep(2000);
    const 无视频内容 = ocr文本数组匹配(douyin.搜索页_视频筛选结果);
    if(无视频内容){
        api_更新关键词状态(douyin.关键词已无视频.katid)
        douyin.关键词已无视频 = null
        日志打印_error('该搜索条件下无相关视频内容')
        return false
    }
    return true
}

DouYin.prototype.dy_搜索结果的视频点击 = function () {
    当前执行模块 = 'dy_搜索结果的视频点击';
    日志打印_debug(`开始执行 -- 【dy_搜索结果的视频点击】`)

    const 第一个视频位置 = {name: '搜索结果的视频点击', x: random(18, 160), y: random(400, 652)};
    const 进入视频播放 = 点击屏幕检测(第一个视频位置, 1000, 50, 300, 300, 600);
    if(!进入视频播放){
        日志打印_error('进入 [视频播放] 失败！')
        return false
    }
    return true
}

DouYin.prototype.dy_视频信息采集 = function () {
    当前执行模块 = 'dy_视频信息采集'
    日志打印_debug(`开始执行 - 【dy_视频信息采集】`);

    const 视频播放页面的关注按钮 = findColor(douyin.视频播放页_关注按钮)
    if(!视频播放页面的关注按钮){
        return
    }

    const 视频信息 = { '作者': '', '抖音ID': '', '类型': '视频', '发布日期': '暂无', '评论数量': 0, 'name': '无', '评论区留痕': false}

    const 视频作者信息 = this.dy_获取视频作者(视频播放页面的关注按钮);
    if(!视频作者信息){
        return
    }

    视频信息.作者 = 视频作者信息.用户昵称;
    视频信息.抖音ID = 视频作者信息.抖音ID;
    视频信息.name = this.dy_获取视频标题(视频信息.作者);
    const 评论数量 = this.dy_获取视频评论数量(视频播放页面的关注按钮);
    if (评论数量 === undefined){
        return
    }
    视频信息.评论数量 = 评论数量
    日志打印_debug(JSON.stringify(视频信息))
    return 视频信息
}


DouYin.prototype.dy_搜索视频_广告视频判断 = function () {
    当前执行模块 = 'dy_搜索视频_广告视频判断'
    日志打印_debug(`开始执行 - 【dy_搜索视频_广告视频判断】`);
    const 视频播放页_广告标识 = findColor(douyin.视频播放页_广告标识)
    if(视频播放页_广告标识) { return true }

    const 视频播放_广告_播放完毕 = ocr文本数组匹配(douyin.视频播放_广告_播放完毕)
    if(视频播放_广告_播放完毕) { return true }


    return false
}

DouYin.prototype.dy_搜索视频_播放页面判断 = function () {
    当前执行模块 = 'dy_搜索视频_播放页面判断'
    日志打印_debug(`开始执行 - 【dy_搜索视频_播放页面判断】`);

    const 判断 = findMultiColor([douyin.视频播放页_关注按钮,douyin.用户主页_下滑后_右上角标识,douyin.用户主页_下滑后_右上角标识2,
                                        douyin.视频播放页面的评论区关闭按钮,douyin.搜索视频_播放页面_底部评论框_右侧_艾特标识,
                                        douyin.搜索视频_播放页面_底部评论框_右侧_笑脸标识, douyin.搜索视频_播放页面_底部评论框_右侧_图片标识])
    if(判断) {
        const index = 判断.index
        switch (index) {
            case 1:
                while (true){
                    if(isScriptExit()) {break}
                    点击(douyin.用户主页_返回按钮)
                    iSleep(400)
                    const 用户主页_下滑后_右上角标识 = findColor(douyin.用户主页_下滑后_右上角标识)
                    if(!用户主页_下滑后_右上角标识){
                        return douyin.dy_搜索视频_播放页面判断()
                    }
                }
            case 2:
                while (true){
                    if(isScriptExit()) {break}
                    点击(douyin.用户主页_返回按钮)
                    iSleep(400)
                    const 用户主页_下滑后_右上角标识2 = findColor(douyin.用户主页_下滑后_右上角标识2)
                    if(!用户主页_下滑后_右上角标识2){
                        return douyin.dy_搜索视频_播放页面判断()
                    }
                }
            case 3:
                let 视频播放页面的评论区关闭按钮 = findColor(douyin.视频播放页面的评论区关闭按钮)
                while (视频播放页面的评论区关闭按钮){
                    if(isScriptExit()) {break}
                    点击(视频播放页面的评论区关闭按钮)
                    iSleep(400)
                    视频播放页面的评论区关闭按钮 = findColor(douyin.视频播放页面的评论区关闭按钮)
                    if(!视频播放页面的评论区关闭按钮){
                        return douyin.dy_搜索视频_播放页面判断()
                    }
                }
        }
        return true
    }
    let 用户作品主页 = ocr文本数组匹配(douyin.用户作品主页)
    while (用户作品主页){
        if(isScriptExit()) {break}
        点击(douyin.用户主页_返回按钮)
        iSleep(400)
        用户作品主页 = ocr文本数组匹配(douyin.用户作品主页)
        if(!用户作品主页){
            return douyin.dy_搜索视频_播放页面判断()
        }
    }

    let 键盘弹出 = ocr文本数组匹配(ios.键盘弹出)
    while (键盘弹出){
        if(isScriptExit()) {break}
        const 键盘弹出关闭点位 = {name: '键盘弹出关闭点位', x: random(100, 600), y: random(150,220)}
        点击(键盘弹出关闭点位)
        iSleep(400)
        键盘弹出 = ocr文本数组匹配(ios.键盘弹出)
        if(!键盘弹出){
            return douyin.dy_搜索视频_播放页面判断()
        }
    }


    const 搜索视频_播放页面_title = ocr文本数组匹配(douyin.搜索视频_播放页面_title)
    if(搜索视频_播放页面_title) { return true }
    const 视频播放页_收藏按钮 = findColor(douyin.视频播放页_收藏按钮)
    const 视频播放页_分享按钮 = findColor(douyin.视频播放页_分享按钮)
    if(视频播放页_收藏按钮 && 视频播放页_分享按钮){
        const distance = 视频播放页_分享按钮.max_y - 视频播放页_收藏按钮.max_y
        日志打印_warning(`distance: ${distance}`);
        if(distance <= 150 && distance >= 130){
            日志打印_warning(`在视频播放页面`);
            return true
        }
    }
    if(douyin.dy_搜索视频_广告视频判断()){
        douyin.dy_上滑切换视频()
        return douyin.dy_搜索视频_播放页面判断()
    }

    let 搜索页_搜索结果标签 = ocr文本数组匹配(douyin.搜索页_搜索结果标签)
    while (搜索页_搜索结果标签){
        if(isScriptExit()) {break}
        const 第一个视频位置 = {name: '搜索结果的视频点击', x: random(18, 160), y: random(400, 652)};
        点击(第一个视频位置)
        iSleep(400)
        搜索页_搜索结果标签 = ocr文本数组匹配(douyin.搜索页_搜索结果标签)
        if(!搜索页_搜索结果标签){
            return douyin.dy_搜索视频_播放页面判断()
        }
    }
    日志打印_error('不在视频播放页面')
    return false
}

DouYin.prototype.dy_视频信息采集_后回到视频播放页面 = function () {
    当前执行模块 = 'dy_视频信息采集_后回到视频播放页面'
    日志打印_debug(`开始执行 - 【dy_视频信息采集_后回到视频播放页面】`);
    let 视频播放页面的评论区关闭按钮 = findColor(douyin.视频播放页面的评论区关闭按钮)
    while (视频播放页面的评论区关闭按钮){
        if(isScriptExit()) { break }
        点击(视频播放页面的评论区关闭按钮)
        iSleep(1200)
        视频播放页面的评论区关闭按钮 = findColor(douyin.视频播放页面的评论区关闭按钮)
    }
}

DouYin.prototype.dy_获取视频作者 = function (视频播放页面的关注按钮){
    当前执行模块 = 'dy_获取视频作者'
    日志打印_debug(`开始执行 - 【dy_获取视频作者】`);

    let 进入作者主页 = -1000;
    const 直播中 = !屏幕区域变化检测(500, 视频播放页面的关注按钮.min_x, 视频播放页面的关注按钮.min_y-55, 视频播放页面的关注按钮.max_x, 视频播放页面的关注按钮.max_y)
    if(直播中){
        日志打印_warning('视频作者正在直播')
        进入作者主页 = 滑动检测(douyin.视频播放页_关注按钮, [douyin.用户作品主页, douyin.私信页面表情标识], 600, random(400,500), 10, random(400,500), 3000)
    }else {
        日志打印_warning('视频作者未直播')
        const 视频头像 = {name: '[dy_获取视频作者]视频头像', x:视频播放页面的关注按钮.x, y:视频播放页面的关注按钮.min_y-55}
        进入作者主页 = 点击后检测(视频头像, douyin.视频播放页_关注按钮, [douyin.用户作品主页, douyin.私信页面表情标识], 3000)
    }

    switch (进入作者主页) {
        case -1000:
            return
        case -100:
            return
        case -1:
            return
        case 0:
            break;
        case 1:
            // 判断是否企业号，弹出私信框
            const 关闭_弹出私信页面_位置 = {name: '关闭_弹出私信页面_位置', x: random(678,705), y:random(114,136)}
            const 关闭作者私信弹窗 = 点击后检测(关闭_弹出私信页面_位置, douyin.私信页面表情标识, [douyin.用户作品主页])
            if(关闭作者私信弹窗 !== 0){
                日志打印_error('关闭作者私信弹窗 失败')
                return
            }
            break;
    }

    const 作者信息 = douyin.dy_节点获取抖音ID();
    if(!作者信息){
        return
    }
    const 作者主页截图 = 区域截图base64()
    作者信息.homepage = 作者主页截图
    // 返回视频播放页面
    const 返回作者视频播放 = 点击后检测(douyin.用户主页_返回按钮, douyin.用户作品主页, [douyin.视频播放页_关注按钮]);
    switch (返回作者视频播放) {
        case -100:
            return
        case -1:
            return
        case 0:
            break;
    }
    return 作者信息
}

DouYin.prototype.dy_获取视频标题 = function (作者名称){
    当前执行模块 = 'dy_获取视频标题'
    日志打印_debug(`开始执行 - 【dy_获取视频标题】`);

    const 识别内容 =ocr范围识别(0, 120, 630, 1230, true);
    let find_Aite = false;
    let 内容Array = [];
    let 最终内容Array = [];
    for(let i in 识别内容){
        if(isScriptExit()){break}

        const 单行文本 = 识别内容[i];
        if(单行文本.label.includes('点击') && 单行文本.label.includes('推荐给朋友')){
            continue;
        }
        if(单行文本.height >= 50){
            continue;
        }
        if(单行文本.label.endsWith('展开')){
            单行文本.label = 单行文本.label.replace('展开', '');
        }
        内容Array.push(单行文本.label);
        if(单行文本.label.startsWith('@') && !find_Aite){
            find_Aite = true;
            内容Array = []
        }
    }

    最终内容Array = 内容Array;
    if(!find_Aite){
        // 没有识别出 @
        function 判断是否包含作者昵称(A, B) {
            if(B === ''){
                return false;
            }
            if(B.length > 7){
                B = B.slice(0, 7)
            }
            for (let i = 0; i < A.length - 1; i++) {
                if (A[i] === B[0] && A[i + 1] === B[1]) {
                    return true;
                }
            }
            return false;
        }
        for( const i in 最终内容Array){
            if(isScriptExit()){break}
            const 识别文本 = 最终内容Array[i];
            if(判断是否包含作者昵称(识别文本, 作者名称)){
                最终内容Array = 最终内容Array.slice(i+1, 最终内容Array.length);
                break
            }
        }
    }
    const 需要移除的内容 = ['去汽水', '相关搜索', '相关短剧', '立即预约']
    let 视频所有文本内容 = 最终内容Array.filter(item => !需要移除的内容.some(subtext => item.includes(subtext)));
    if(视频所有文本内容 === undefined || 视频所有文本内容 === null || !视频所有文本内容){
        视频所有文本内容 = ''
    }else {
        视频所有文本内容 = 视频所有文本内容.join('')
    }
    return 视频所有文本内容
}

DouYin.prototype.dy_获取视频评论数量 = function (视频播放页面的关注按钮){
    当前执行模块 = 'dy_获取视频评论数量';
    日志打印_debug(`开始执行 - 【dy_获取视频评论数量】`);

    // 通过关注按钮获取评论按钮的位置
    const 评论按钮 = {name: '【dy_获取视频评论数量】评论按钮', x:视频播放页面的关注按钮.x, y: (视频播放页面的关注按钮.y + 220) };
    const 评论区打开 = 点击后检测(评论按钮, douyin.视频播放页_关注按钮, [douyin.视频播放页面的评论区放大按钮, ios.键盘弹出], 2000);
    switch (评论区打开) {
        case -100:
            return
        case -1:
            return
        case 0: // 评论区打开成功
            break;
        case 1:
            // 该视频无评论内容
            const 关闭_弹出键盘 = {name: '关闭_弹出键盘', x: random(140, 568), y: random(292, 418)};
            const 关闭_弹出键盘_结果 = 点击后检测(关闭_弹出键盘, ios.键盘弹出, [douyin.视频播放页面的评论区放大按钮]);
            if(关闭_弹出键盘_结果 !== 0){
                日志打印_error('关闭 [弹出键盘]  失败')
                return
            }
            break;
    }
    const 视频播放页面的评论区放大按钮 = findColor(douyin.视频播放页面的评论区放大按钮)
    if (!视频播放页面的评论区放大按钮) {
        日志打印_error('（视频播放页面的评论区放大按钮）寻找失败！');
        return
    }
    视频播放页面的评论区放大按钮.name = '【dy_获取视频评论数量】视频播放页面的评论区放大按钮'
    const 评论区放大结果 = 点击后检测(视频播放页面的评论区放大按钮, douyin.视频播放页面的评论区放大按钮, [douyin.视频播放页面的评论区缩小按钮]);
    if(评论区放大结果 !== 0){
        return
    }

    return dy_节点获取评论数量()

    function dy_节点获取评论数量() {
        日志打印_debug(`开始执行 - 【dy_节点获取评论数量】`);
        setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
        let 评论数量节点 =  type("StaticText").labelMatch(".*评论.*").getOneNodeInfo(10000)
        let 重试次数 = 3;
        while(!评论数量节点 && 重试次数>0){
            if(isScriptExit()) {break}
            iSleep(100);
            const 还在预期页面 = findColor(douyin.视频播放页面的评论区缩小按钮);
            if(还在预期页面){
                评论数量节点 = type("StaticText").labelMatch(".*评论.*").getOneNodeInfo(10000)
            }
            重试次数--;
        }
        if(!评论数量节点){
            return 0
        }
        return 快手_评论数量格式化(评论数量节点.label)
    }
}

DouYin.prototype.dy_评论区留痕 = function (留痕内容) {
    当前执行模块 = 'dy_评论区留痕'
    日志打印_debug('开始执行 - 【dy_评论区留痕】')

    const 已打开键盘 = ocr文本数组匹配(ios.键盘弹出)
    if(!已打开键盘){
        const 键盘弹出_结果 = 点击后检测(douyin.评论区_底部_评论输入框, douyin.视频播放页面的评论区缩小按钮, [ios.键盘弹出]);
        switch (键盘弹出_结果) {
            case -100:
                return false
            case -1:
                return false
            case 0:
                break
        }
    }
    文本内容输入(留痕内容, douyin.评论区_底部_评论输入框);
    键盘发送()
    iSleep(100)
    let 重试次数 = 3
    let 留痕结果 = ocr文本数组匹配(ios.键盘弹出)
    while (留痕结果 && 重试次数>0){
        if(isScriptExit()) { return }
        键盘发送()
        iSleep(100)
        留痕结果 = ocr文本数组匹配(ios.键盘弹出)
        重试次数--
    }
    return !留痕结果
}

DouYin.prototype.dy_打开用户主页_更多弹窗 = function () {
    日志打印_debug('开始执行 - 【dy_打开用户主页_更多弹窗】')

    const 打开_用户作品主页_更多弹出窗 = 点击后检测(douyin.用户主页_右上角_更多_按钮, douyin.用户作品主页, [douyin.用户作品主页_更多弹出窗]);
    switch (打开_用户作品主页_更多弹出窗) {
        case -100:
            return false
        case -1:
            return false
        case 0:
            return true
    }
}

DouYin.prototype.dy_获取用户主页_简介信息 = function () {
    日志打印_debug('开始执行 - 【dy_获取用户主页_简介信息】')
    setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
    let Others_节点 = bounds(0,160,ScreenWidth,800).type("Other").getNodeInfo(10000)
    let tryCount = 3;
    while(!Others_节点 && tryCount>0){
        if(isScriptExit()) {break}
        iSleep(100)
        const 还在预期页面 = ocr文本数组匹配(douyin.用户作品主页)
        if(还在预期页面){
            Others_节点 = bounds(0,160,ScreenWidth,800).type("Other").getNodeInfo(10000)
        }
        tryCount--;
    }
    if(!Others_节点){
        return ''
    }
    const 所有文本节点集合 = []
    for( let i in Others_节点){
        if(isScriptExit()) {break}
        const other = Others_节点[i]
        if(other.label && other.label !== ''){
            所有文本节点集合.push(other)
        }
    }
    所有文本节点集合.sort((a, b) => a.bounds.bottom - b.bounds.bottom);

    const 所有文本集合 = []
    for( let i in 所有文本节点集合){
        if(isScriptExit()) {break}
        const 节点 = 所有文本节点集合[i]
        所有文本集合.push(节点.label)
    }
    const 用户简介 = 所有文本集合.join(';')
    logw(用户简介)
    return 用户简介

}

DouYin.prototype.dy_关闭用户主页_更多弹窗 = function () {
    日志打印_debug('开始执行 - 【dy_关闭用户主页_更多弹窗】')

    let 用户主页私信弹窗关闭按钮 = findColor(douyin.用户主页私信弹窗关闭按钮);
    if(!用户主页私信弹窗关闭按钮){
        用户主页私信弹窗关闭按钮 = {name: '默认【dy_节点获取抖音ID】用户主页私信弹窗关闭按钮', x: random(200,300), y: random(250,600)}
    }
    点击(用户主页私信弹窗关闭按钮)
    iSleep(500)
    let 用户作品主页_更多弹出窗 = ocr文本数组匹配(douyin.用户作品主页_更多弹出窗)
    while (用户作品主页_更多弹出窗){
        if(isScriptExit()) {break}
        点击(用户主页私信弹窗关闭按钮)
        iSleep(500)
        用户作品主页_更多弹出窗 = ocr文本数组匹配(douyin.用户作品主页_更多弹出窗)
    }
    const 回到_用户作品主页 = ocr文本数组匹配(douyin.用户作品主页)
    if(回到_用户作品主页){
        return true
    }
    return false

}

DouYin.prototype.dy_节点获取抖音ID = function (关闭更多弹窗=true){
    日志打印_debug('开始执行 - 【dy_节点获取抖音ID】')

    const 打开用户主页_更多弹窗 = douyin.dy_打开用户主页_更多弹窗()
    if(!打开用户主页_更多弹窗){
        return
    }
    setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
    let 用户_抖音号_节点 =  type('Button').labelMatch("抖音号.*").getOneNodeInfo(10000);
    let tryCount = 3;
    while(!用户_抖音号_节点 && tryCount>0){
        if(isScriptExit()) {break}
        iSleep(100)
        const 还在预期页面 = ocr文本数组匹配(douyin.用户作品主页_更多弹出窗)
        if(还在预期页面){
            用户_抖音号_节点 = type('Button').labelMatch("抖音号.*").getOneNodeInfo(10000);
        }
        tryCount--;
    }
    if(!用户_抖音号_节点){
        return
    }

    const 兄弟nodes = 用户_抖音号_节点.siblings();
    let 获取用户昵称 = '';
    for(const i in 兄弟nodes){
        if(isScriptExit()) {break}
        const 兄弟 = 兄弟nodes[i];
        if(兄弟.type === 'StaticText'){
            获取用户昵称 = 兄弟.label;
            break
        }
    }
    if(关闭更多弹窗){
        const dy_关闭用户主页_更多弹窗 = douyin.dy_关闭用户主页_更多弹窗()
        if(!dy_关闭用户主页_更多弹窗){
            return
        }
    }
    return {用户昵称: 获取用户昵称, 抖音ID: douyin.裁剪ocr的抖音号(用户_抖音号_节点.label)}
}

DouYin.prototype.dy_上滑切换视频 = function (check=true) {
    日志打印_debug('执行 【dy_上滑切换视频】')
    const startX = random(240, 300);
    const endX = random(300, 390);
    const startY = random(900, 960);
    const endY = random(180, 200);
    let 滑动最大次数 = 10;
    const 当前视频 = douyin.dy_获取视频标题('dy_获取视频标题')
    while (滑动最大次数 > 0){
        if(isScriptExit()) {break}
        douyin.dy_搜索视频_播放页面判断()
        滑动(startX, startY, endX, endY, 200);
        iSleep(100);
        const 滑动后视频 = douyin.dy_获取视频标题('dy_获取视频标题')
        const 相似度 = 字符串相似度计算(滑动后视频, 当前视频)
        if(相似度 > 0.6){
            滑动最大次数--;
            continue;
        }
        return

    }
    if(check){
        api_更新关键词状态(douyin.关键词已无视频.katid)
        douyin.关键词已无视频 = null
    }
}

DouYin.prototype.dy_评论区抓取 = function (video_sid){
    当前执行模块 = 'dy_评论区抓取';
    日志打印_debug('开始执行 - 【dy_评论区抓取】')

    let 评论区顶部 = 100;
    let 评论区底部 = 1200;
    let 是否结束评论区获取 = false;

    setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
    let 评论数量节点 =  bounds(0,40, ScreenWidth,250).type("StaticText").labelMatch(".*评论.*").getOneNodeInfo(10000)
    let tryCount = 3;
    while (!评论数量节点 && tryCount>0){
        if(isScriptExit()){break}
        iSleep(100);
        const 还在预期页面 = findColor(douyin.视频播放页面的评论区缩小按钮);
        if(还在预期页面){
            评论数量节点 = bounds(0,40, ScreenWidth,250).type("StaticText").labelMatch(".*评论.*").getOneNodeInfo(10000)
        }
        tryCount--
    }
    if(评论数量节点 && 评论数量节点.bounds.bottom > 100 && 评论数量节点.bounds.bottom < 300){
        评论区顶部 = 评论数量节点.bounds.bottom;
    }

    日志打印_debug(`【dy_评论区抓取】评论区范围为 top：${评论区顶部}  bottom：${评论区底部}`)

    function 获取评论的点踩爱心图标(y, ey) {
        const 更新点踩爱心按钮范围 = JSON.parse(JSON.stringify(douyin.视频播放页面的评论区点踩爱心图标));
        更新点踩爱心按钮范围.y = y;
        更新点踩爱心按钮范围.ey = ey;
        return findColor(更新点踩爱心按钮范围)
    }
    function 获取ip地址(str) {
        const match = str.trim().match(/[\u4e00-\u9fa5]+$/); // 匹配末尾的连续中文字符
        return match ? match[0] : ''; // 如果有匹配的中文字符，返回，否则返回空字符串
    }

    function 范围评论处理(范围评论内容) {
        if(!范围评论内容 || 范围评论内容.length === 0 || 范围评论内容.length === 1){
            return null
        }
        范围评论内容.sort((a, b) => {
            return a.y - b.y;
        });
        if(范围评论内容.length > 3 && (范围评论内容[0].x - 范围评论内容[1].x) > 20){
            范围评论内容.splice(0, 1)
        }
        //排除里面的无效文本
        const 第一次筛选后评论内容 = 范围评论内容.filter((单行文本) => {
            return!(单行文本.label.includes('收起') || 单行文本.label.includes('作者回复过')
                    || 单行文本.label.includes('作者赞过') || 单行文本.label === '' || 单行文本.x > 400
                    || 单行文本.label.includes('评论氛围是否满意') || 单行文本.label.includes('条回复')
                    || 单行文本.label.startsWith('展开')|| (单行文本.label.includes('不满意')  && 单行文本.label.includes('一般'))
                    || (单行文本.label.startsWith('展开') || 单行文本.label.startsWith('展廾')
                    || 单行文本.label.startsWith('一 展开') || 单行文本.label.startsWith('一 展廾')
                    || 单行文本.label.startsWith('— 展开') || 单行文本.label.startsWith('—展开')
                    || 单行文本.label.startsWith('一展廾')) && (单行文本.label.endsWith('凹复V') || 单行文本.label.endsWith('回复丷')
                    || 单行文本.label.endsWith('回复') || 单行文本.label.endsWith('回复V')
                    || 单行文本.label.endsWith('回复 V')));

        });

        let ip = ''
        function 找到评论时间并格式化(arr) {
            arr.sort((a, b) => {
                if (Math.abs(a.y - b.y) <= 5) {
                    return a.x - b.x;
                } else {
                    return a.y - b.y;
                }
            });
            let indexOfReply = -1;
            for (let i = arr.length - 1; i >= 0; i--) {
                if (arr[i].label.includes('回复')) {
                    indexOfReply = i;
                    break;
                }
            }
            if (indexOfReply !== -1) {
                const new_arr = arr.slice(0, indexOfReply + 1);
                new_arr[new_arr.length-1].label = new_arr[new_arr.length-1].label.replace('回复', '')
                var 评论时间 = 时间格式化(new_arr[new_arr.length-1].label);
                // 日志打印_warning(new_arr[new_arr.length-1].label+ '  评论时间1: ' + 评论时间)
                if(评论时间 && 评论时间 !== '2024-08-01'){
                    ip = 获取ip地址(new_arr[new_arr.length-1].label)
                    new_arr[new_arr.length-1].label = 评论时间;
                    return new_arr;
                }
                else if(new_arr.length > 1){
                    var 评论时间 = 时间格式化(new_arr[new_arr.length-2].label);
                    日志打印_warning(new_arr[new_arr.length-2].label + '  评论时间2: ' + 评论时间)
                    if(评论时间){
                        ip = 获取ip地址(new_arr[new_arr.length-2].label)
                        new_arr[new_arr.length-2].label = 评论时间;
                        const new_arr_2 = new_arr.slice(0, new_arr.length-1);
                        return new_arr_2;
                    }
                }
            }
            return null;
        }

        const 筛选后评论内容 = 找到评论时间并格式化(第一次筛选后评论内容);
        日志打印_debug('筛选后评论内容: '+JSON.stringify(筛选后评论内容))
        logd('ip3: '+ ip)

        if(!筛选后评论内容 || 筛选后评论内容.length < 2 || 筛选后评论内容[0].label.endsWith('作者')
            || 筛选后评论内容[0].label.endsWith('互相关注') || 筛选后评论内容[0].label.endsWith('你的关注')){
            return null
        }
        if(筛选后评论内容[筛选后评论内容.length-1].y - 筛选后评论内容[0].y - 筛选后评论内容[0].height < 30){
            return null
        }
        if(筛选后评论内容[0].width > 551){
            return null
        }
        let 头像_x = 66;
        if(筛选后评论内容[筛选后评论内容.length-1].x > 50){
            头像_x = 138;
        }

        const 用户评论信息 = {name: 筛选后评论内容[0].label, 评论内容: null, 评论时间: 筛选后评论内容[筛选后评论内容.length-1].label,
            x: 头像_x, y: 筛选后评论内容[0].y+筛选后评论内容[0].height/2+评论区顶部}
        if(筛选后评论内容.length === 2){
            用户评论信息.评论内容 = '[该用户回复的为表情或者图片消息]'
            logi(筛选后评论内容[筛选后评论内容.length-1].y-筛选后评论内容[0].y)
        }
        else {
            用户评论信息.评论内容 = 筛选后评论内容.slice(1, -1).map(单行文本 => 单行文本.label).join('');
        }
        用户评论信息.ip = ip
        // 日志打印_debug('用户评论信息: ' + JSON.stringify(用户评论信息))
        return 用户评论信息
    }

    function 评论区判断() {

        const 判断 = findMultiColor([douyin.商家店铺左尖括号返回按钮, douyin.左上角返回按钮,douyin.用户账号已注销,
            douyin.视频播放页面的评论区放大按钮,douyin.视频播放页面的评论区缩小按钮_被遮罩,douyin.视频播放页面的评论区缩小按钮,
            douyin.视频播放页面的评论区点踩爱心图标, douyin.视频播放页面的评论区关闭按钮])
        if(判断){
            logw(JSON.stringify(判断))
            const index = 判断.index
            switch (index) {
                case 0:
                    let 商家店铺左尖括号返回按钮 = 判断.point
                    while (true){
                        if(isScriptExit()){ break }
                        点击(商家店铺左尖括号返回按钮)
                        iSleep(400)
                        商家店铺左尖括号返回按钮 = findColor(douyin.商家店铺左尖括号返回按钮)
                        if(!商家店铺左尖括号返回按钮){
                            return 评论区判断()
                        }
                    }
                case 1:
                    let 左上角返回按钮 = 判断.point
                    while (true){
                        if(isScriptExit()){ break }
                        点击(左上角返回按钮)
                        iSleep(400)
                        const 用户账号已注销 = findColor(douyin.用户账号已注销)
                        if(!用户账号已注销){
                            return 评论区判断()
                        }
                    }
                case 2:
                    while (true){
                        if(isScriptExit()){ break }
                        点击(douyin.用户主页_返回按钮)
                        iSleep(400)
                        左上角返回按钮 = findColor(douyin.左上角返回按钮)
                        if(!左上角返回按钮){
                            return 评论区判断()
                        }
                    }

                case 3:
                    let 视频播放页面的评论区放大按钮 = 判断.point
                    while (true){
                        if(isScriptExit()){ break }
                        点击(视频播放页面的评论区放大按钮)
                        iSleep(400)
                        视频播放页面的评论区放大按钮 = findColor(douyin.视频播放页面的评论区放大按钮)
                        if(!视频播放页面的评论区放大按钮){
                            return 评论区判断()
                        }
                    }
                case 4:
                    let 视频播放页面的评论区缩小按钮_被遮罩 = 判断.point
                    while (true){
                        if(isScriptExit()){ break }
                        点击(视频播放页面的评论区缩小按钮_被遮罩)
                        iSleep(400)
                        视频播放页面的评论区缩小按钮_被遮罩 = findColor(douyin.视频播放页面的评论区缩小按钮_被遮罩)
                        if(!视频播放页面的评论区缩小按钮_被遮罩){
                            return 评论区判断()
                        }
                    }
            }
            return true
        }


        let 打开键盘 = ocr文本数组匹配(ios.键盘弹出)
        while (打开键盘){
            if(isScriptExit()){ break }
            const 键盘弹出关闭点位 = {name: '键盘弹出关闭点位', x: random(100, 600), y: random(150,220)}
            点击(键盘弹出关闭点位)
            iSleep(400)
            打开键盘 = ocr文本数组匹配(ios.键盘弹出)
            if(!打开键盘){
                return 评论区判断()
            }
        }
        const 评论区_title = ocr文本数组匹配(douyin.评论区_title);
        if(评论区_title) { return true }

        let 用户作品主页 = ocr文本数组匹配(douyin.用户作品主页);
        while (用户作品主页){
            if(isScriptExit()){ break }
            点击(douyin.用户主页_返回按钮)
            iSleep(400)
            用户作品主页 = ocr文本数组匹配(douyin.用户作品主页)
            if(!用户作品主页){
                return 评论区判断()
            }
        }

        let 主页_我_页面 = ocr文本数组匹配(douyin.主页_我_页面);
        while (主页_我_页面){
            if(isScriptExit()){ break }
            点击(douyin.用户主页_返回按钮)
            iSleep(400)
            主页_我_页面 = ocr文本数组匹配(douyin.主页_我_页面);
            if(!主页_我_页面){
                return 评论区判断()
            }
        }

        let 评论区_图片查看 = ocr文本数组匹配(douyin.评论区_图片查看);
        while (评论区_图片查看){
            if(isScriptExit()){ break }
            点击(douyin.用户主页_返回按钮)
            iSleep(400)
            评论区_图片查看 = ocr文本数组匹配(douyin.评论区_图片查看);
            if(!评论区_图片查看){
                return 评论区判断()
            }
        }
        let 视频评论区_误触内容 = ocr文本数组匹配(douyin.视频评论区_误触内容);
        while (视频评论区_误触内容){
            if(isScriptExit()){ break }
            const 关闭误触的点位 = {name: '【dy_评论区抓取】关闭 视频评论区_误触内容', x: random(250, 520), y: random(100, 200)};
            点击(关闭误触的点位)
            iSleep(400)
            视频评论区_误触内容 = ocr文本数组匹配(douyin.视频评论区_误触内容);
            if(!视频评论区_误触内容){
                return 评论区判断()
            }
        }

        return false
    }

    const 已经获取抖音ID的用户 = []
    let 左侧头像切割 = 100
    while (!是否结束评论区获取){
        if(isScriptExit()){ break }
        if(!评论区判断()){ return }
        const 页面所有文字内容 = ocrMut范围识别(左侧头像切割, 评论区顶部, ScreenWidth, 评论区底部)
        if(!页面所有文字内容){
            日志打印_error('【dy_评论区抓取】 页面评论内容 获取失败， 正在重新获取！ ');
            iSleep(200)
            continue
        }
        // 页面所有文字内容.sort((a, b) => a.y - b.y);
        页面所有文字内容.sort((a, b) => {
            // 首先按照y值进行排序
            if (Math.abs(a.y - b.y) <= 5) {
                // 如果y值差不超过5，则按照x值排序
                return a.x - b.x;
            } else {
                // 否则按照y值排序
                return a.y - b.y;
            }
        });
        const 点踩爱心图标top = 评论区顶部;
        let 上一个爱心图标 = null;
        const 用户列表 = [];
        const 评论区切片索引 = [];
        for (let i = 0; i < 页面所有文字内容.length; i++) {
            if (isScriptExit()) { return }
            const 单列文字内容 = 页面所有文字内容[i];
            日志打印_debug(JSON.stringify(单列文字内容))
            if (单列文字内容.label.includes('暂时没有更多了')  || 单列文字内容.label.startsWith('已折叠') || 单列文字内容.label.startsWith('哲时没有更多了') || 单列文字内容.label.endsWith('没有更多了')) {
                // 评论页面内容已经获取完了
                日志打印_debug(`【dy_评论区抓取】已到达评论区底部 ：${单列文字内容.label} `)
                是否结束评论区获取 = true;
            }
            if (单列文字内容.label.includes('回复')) {
                /*  用 【回复】 分割用户的评论内容 */
                const 点踩爱心图标bottom = 单列文字内容.y + 单列文字内容.height + 40 + 评论区顶部;
                const 点赞爱心图标 = 获取评论的点踩爱心图标(点踩爱心图标top, 点踩爱心图标bottom);
                if (点赞爱心图标) {
                    if(!上一个爱心图标){
                        评论区切片索引.push({index: i, top: 评论区顶部})
                    }
                    else {
                        评论区切片索引.push({index: i, top: 上一个爱心图标.max_y})
                    }
                    上一个爱心图标 = JSON.parse(JSON.stringify(点赞爱心图标));
                }else {
                    日志打印_debug(`点赞爱心图标 未找到：${单列文字内容.label}`)
                }
            }
        }

        let startIndex = {index: 0, top: 评论区顶部};
        for (let index_ of 评论区切片索引) {
            let 范围评论 = null;
            if(startIndex.index === 0){
                范围评论 = 页面所有文字内容.slice(0, index_.index+1);
                if(index_.index === 0){
                    index_.index += 1
                }

            }else {
                范围评论 = 页面所有文字内容.slice(startIndex.index+1, index_.index+1);

            }
            startIndex = JSON.parse(JSON.stringify(index_));
            日志打印_warning('提交筛选：' + JSON.stringify(范围评论))
            const 用户信息 = 范围评论处理(范围评论);
            if(用户信息){
                用户列表.push(用户信息)
            }
        }
        日志打印_warning('提交筛选：' + JSON.stringify(页面所有文字内容.slice(startIndex.index+1)))
        const 用户信息 = 范围评论处理(页面所有文字内容.slice(startIndex.index+1))
        if(用户信息){
            用户列表.push(用户信息)
        }
        const 评论区截图 = 区域截图base64(150, 150, 600, 1000);
        let 评论区变动_重新抓取 = false;

        for(const i in 用户列表){
            if(isScriptExit()) { break }
            if(!评论区判断()){ return }
            const 评论区用户 = 用户列表[i];
            日志打印_information('评论区用户： '+ JSON.stringify(评论区用户))
            if (已经获取抖音ID的用户.includes(评论区用户.name)){ continue }
            已经获取抖音ID的用户.push(评论区用户.name)
            const 进入评论用户主页 = 点击后检测(评论区用户, douyin.视频播放页面的评论区缩小按钮, [douyin.用户作品主页], 1000);
            if(进入评论用户主页 === 0){
                const 简介信息 = douyin.dy_获取用户主页_简介信息()
                const 用户主页截图 = 区域截图base64(0,0, ScreenWidth, ScreenHeight)
                const 用户_昵称_id = douyin.dy_节点获取抖音ID();
                if (用户_昵称_id){
                    // 日志打印_error(`[用户_昵称_id] ${用户_昵称_id.抖音ID}`)
                    // 日志打印_error(`[已经获取抖音ID的用户] 包含抖音id：${用户_昵称_id}`)
                    if(!已经获取抖音ID的用户.includes(用户_昵称_id.抖音ID)){
                        const 上传评论数据 = {
                            "video_sid": video_sid,
                            "belong_account_id": uid,
                            "account_type": '抖音',
                            "customer_name": 用户_昵称_id.用户昵称,
                            "customer_id":用户_昵称_id.抖音ID,
                            "customer_comment_time": 评论区用户.评论时间,
                            "customer_ip_location": 评论区用户.ip,
                            "customer_comment": 评论区用户.评论内容,
                            "customer_homepage_img": 用户主页截图,
                            "customer_other_information": 简介信息,
                        }
                        api_插入视频评论用户(上传评论数据)
                        已经获取抖音ID的用户.push(用户_昵称_id.抖音ID)
                    }
                    else {
                        日志打印_error(`[已经获取抖音ID的用户] 包含抖音id：${用户_昵称_id.抖音ID}`)
                    }
                }
                else {
                    日志打印_error('[用户_昵称_id] 获取失败')
                }
                while (true){
                    if(isScriptExit()){ break }
                    const 在_用户作品主页 = ocr文本数组匹配(douyin.用户作品主页)
                    if(在_用户作品主页){
                        点击(douyin.用户主页_返回按钮)
                        iSleep(400)
                    }else {
                        break
                    }
                }
            }

            const 点击后_评论区截图 = 区域截图base64(150, 150, 600, 1000);
            if(点击后_评论区截图 !== 评论区截图){
                日志打印_debug('评论区变动_重新抓取')
                评论区变动_重新抓取 = true;
                break
            }
        }

        if(!评论区判断()){ return }
        if(是否结束评论区获取) { break }
        if(评论区变动_重新抓取){ continue }

        const bg_hd = time()
        const startX = random(10,20);
        const endX = random(10,20);
        let startY = 1150;
        let endY = 250;
        日志打印_debug('【dy_评论区抓取】开始执行 评论区滑动')
        滑动(startX, startY, endX, endY, 2000)
        while(!屏幕区域变化检测(200, 0, 300, 90, 1000)){
            if(isScriptExit()){break }
            sleep(100);
        }

        日志打印_warning('滑动耗时： '+ (time()-bg_hd))
        const 滑动后_评论区截图 = 区域截图base64(150, 150, 600, 1000);
        if(滑动后_评论区截图 === 评论区截图){
            break
        }
    }
    日志打印_debug(`【dy_评论区抓取】已结束抓取  `)
    return true
}

DouYin.prototype.dy_用户列表_用户主页进入 = function (douyinID) {
    当前执行模块 = 'dy_用户列表_用户主页进入'
    日志打印_debug('开始执行 - 【dy_用户列表_用户主页进入】')

    function 在预期页面() {
        const 在用户搜索页面 = findMultiColor([douyin.搜索页面的用户列表关注按钮, douyin.搜索页面的用户列表关注按钮2])
        return !!在用户搜索页面
    }

    const 抖音号存在搜索列表 = {
        name: `抖音号：${douyinID}`,
        firstColor: ["#FE2B54", "#101010"],
        x: 160,
        y: 200,
        ex: 540,
        ey: ScreenHeight,
        orz: 1,
    }
    if (ocr文本不完全匹配('结果为空', 0, 0, ScreenWidth, ScreenHeight)) {
        return 0
    }

    for (let i=0; i<3; i++){
        if (isScriptExit()) { break }
        const 用户 = 单点找色(抖音号存在搜索列表);
        if (!用户 && 在预期页面()) {
            continue
        }
        if (用户){
            const 进入用户主页 = 点击后检测(用户, douyin.搜索页_搜索结果标签, [douyin.用户作品主页, douyin.搜索反馈与建议]);
            switch (进入用户主页) {
                case -100:
                    return -1
                case -1:
                    return -1
                case 0:
                    return 1
                case 1:
                    const 关闭搜索与建议 = {name: '关闭搜索与建议', x:random(694,718), y:random(568,582)}
                    const 搜索页_搜索结果标签 = JSON.parse(JSON.stringify(douyin.搜索页_搜索结果标签))
                    搜索页_搜索结果标签.binaryzation = true;
                    const 关闭搜索与建议_结果 = 点击后检测(关闭搜索与建议, douyin.搜索反馈与建议, [douyin.搜索页_搜索结果标签])
                    switch (关闭搜索与建议_结果) {
                        case -1:
                            return 0
                        case -100:
                            return 0
                        case 0:
                            break
                    }
            }
        }
    }
    日志打印_warning(`【用户列表用户选择】ocr未获取到此用户：${douyinID}`);
    return 0
}

DouYin.prototype.dy_用户作品_进入用户私信页面 = function () {
    当前执行模块 = 'dy_进入用户私信页面';
    日志打印_debug('开始执行 - 【dy_进入用户私信页面】')

    if(!ocr文本数组匹配(douyin.用户作品主页_更多弹出窗)){
        const 打开用户主页_更多弹窗 = douyin.dy_打开用户主页_更多弹窗()
        if(!打开用户主页_更多弹窗){
            return false
        }
    }

    const 私信按钮 = findColor(douyin.用户主页私信按钮);
    if (!私信按钮) {
        日志打印_error('获取 [私信按钮] 失败！')
        return false
    }
    let 进入私信页面结果 = 点击后检测(私信按钮, douyin.用户作品主页_更多弹出窗, [douyin.商家店铺左尖括号返回按钮, douyin.左上角返回按钮]);
    switch (进入私信页面结果) {
        case -100:
            日志打印_error('(进入私信页面结果) 失败')
            return false
        case -1:
            return false
        case 0:
            return true;
        case 1:
            return true;
    }
}

DouYin.prototype.dy_更多弹窗_进入用户私信页面 = function () {
    当前执行模块 = 'dy_更多弹窗_进入用户私信页面';
    日志打印_debug('开始执行 - 【dy_更多弹窗_进入用户私信页面】')

    const 私信按钮 = findColor(douyin.用户主页私信按钮);
    if (!私信按钮) {
        日志打印_error('获取 [私信按钮] 失败！')
        return false
    }
    let 进入私信页面结果 = 点击后检测(私信按钮, douyin.用户作品主页_更多弹出窗, [douyin.商家店铺左尖括号返回按钮, douyin.左上角返回按钮]);
    switch (进入私信页面结果) {
        case -100:
            日志打印_error('(进入私信页面结果) 失败')
            return false
        case -1:
            return false
        case 0:
            return true;
        case 1:
            return true;
    }
}

DouYin.prototype.dy_检测私信频繁 = function () {
    日志打印_debug('开始执行 - 【私信频繁检测】');
    return !!ocr文本不完全匹配('过于频繁', 0, 40, ScreenWidth, ScreenHeight)
}

DouYin.prototype.dy_检测私信发送未成功 = function () {
    日志打印_debug('开始执行 - 【dy_检测私信发送未成功】');
    const 私信未成功发送 = findColor(douyin.私信未成功发送)
    if(!私信未成功发送){
        const 私信未成功发送2 = findColor(douyin.私信未成功发送2)
        if(私信未成功发送2){
            return true
        }else {
            return false
        }
    }else {
        return true
    }
}

DouYin.prototype.dy_退出私信页面_返回用户主页 = function () {
    当前执行模块 = 'dy_退出私信页面_返回用户主页';
    日志打印_debug(`开始执行 - 【dy_退出私信页面_返回用户主页】`);

    const 返回用户主页 = 点击后检测(douyin.用户主页_返回按钮, douyin.私信页面表情标识, [douyin.用户作品主页]);
    switch (返回用户主页) {
        case -100:
            return false
        case -1:
            return false
        case 0:
            进入实时回复 = false;
            return true;
    }
}

DouYin.prototype.dy_用户主页_返回搜索页 = function () {
    当前执行模块 = 'dy_用户主页_返回搜索页';
    日志打印_debug(`开始执行 - 【dy_用户主页_返回搜索页】`);

    const 返回搜索页面 = 点击后检测(douyin.用户主页_返回按钮, douyin.用户作品主页, [douyin.搜索页_搜索结果标签]);
    switch (返回搜索页面) {
        case -100:
            return false
        case -1:
            return false
        case 0:
            return true
    }
}

DouYin.prototype.dy_ocr_获取聊天记录 = function (){
    当前执行模块 = 'dy_ocr_获取聊天记录';
    日志打印_debug(`开始执行 - 【dy_ocr_获取聊天记录】`);

    let 聊天记录范围top = 0;
    let 聊天记录范围bottom = 0;
    const 聊天记录范围left = 100;
    const 聊天记录范围right = 650;


    聊天记录范围top = 130;
    聊天记录范围bottom = 1225;


    const ocrResult = ocr范围识别(聊天记录范围left, 聊天记录范围top, 聊天记录范围right, 聊天记录范围bottom)

    let msgHistoryArray = [];
    let 上个文本的bottom位置 = 0;
    let newOcrResult = [];
    let begin = false;
    const 排除文本未知_y = [聊天记录范围top];
    for(let i in ocrResult){
        if(isScriptExit()){ break };
        const 单行文本 = ocrResult[i];
        logd(单行文本.label+ '   ' + 单行文本.x + '   ' + 单行文本.y + '   ' + 单行文本.height)
        // 第一次筛选，排除其他无效文字,确定聊天记录头部开始位置
        if(单行文本.label.includes('礼貌发言') || 单行文本.label.includes('自觉遵守') ||  单行文本.label.includes('自律公约')
            || 单行文本.label.includes('感谢你的理') || 单行文本.label.includes('服务信息') ||  单行文本.label.includes('合法权益')
            || 单行文本.label.includes('了解更多') || 单行文本.label.includes('会话可能会') || 单行文本.label.includes('容易得到回复')
            || 单行文本.label.includes('咨询能更') || 单行文本.label.includes('咨询服务模式') || 单行文本.label.includes('方便以后找到')){
            begin = true;
            排除文本未知_y.push(单行文本.y);
            continue
        }
        if (begin){
            newOcrResult.push(单行文本)
        }
    }
    if(newOcrResult.length === 0 && !begin){
        newOcrResult = ocrResult;
    }
    const 排除的文本位置 = [];
    for(let i in newOcrResult){
        if(isScriptExit()){ return };
        const 单行文本 = newOcrResult[i];
        // logi(单行文本.label+ '   ' + 单行文本.y + '   ' + 单行文本.height)
        if(i>0){
            上个文本的bottom位置 = newOcrResult[i-1].y + newOcrResult[i-1].height;
        }
        // 第二次筛选，排除聊天记录中间出现的一些系统提示
        if( 单行文本.label.includes('自觉遵守') || 单行文本.label.includes('自律公约') || 单行文本.label.includes('密友')
            || 单行文本.label.includes('合法权益') || 单行文本.label.includes('了解更多') || 单行文本.label.includes('容易得到回复')
            || 单行文本.label.includes('咨询能更') || 单行文本.label.includes('咨询服务模式') || 单行文本.label.includes('对方的隐私设置')
            || 单行文本.label.includes('无法发送消息') || 单行文本.label.includes('智能客服接待中')|| 单行文本.label.includes('可发送一条文子消息')
            || 单行文本.label.includes('可以继续聊') || 单行文本.label.includes('消息发送限制') || 单行文本.label.includes('回复你或互关')
            || 单行文本.label.includes('服务评价') || 单行文本.label.includes('询问价格') || 单行文本.label.includes('询问优惠')
            || 单行文本.label.includes('接待结束') || 单行文本.label === '平价' || 单行文本.label.includes('过于频繁') || 单行文本.label === '抖音店铺'
            || 单行文本.label === '客服' || 单行文本.label.includes('比个心') || 单行文本.label === '视频通话' || 单行文本.label.endsWith('招呼')){

            if(!排除的文本位置.includes(单行文本.y)){
                排除的文本位置.push(单行文本.y);
            }
            continue;
        }
        let 排除文本 = false;
        for(let item of 排除的文本位置){
            if(isScriptExit()) break
            if( Math.abs(item-单行文本.y) <= 5){
                排除文本 = true;
                break
            }
        }
        if(排除文本){
            continue;
        }
        if(单行文本.height < 26){
            continue;
        }

        if(单行文本.y <= Math.max(...排除文本未知_y)){
            continue;
        }
        var isWithinRange = false;
        for (let i = 0; i < 排除文本未知_y.length; i++) {
            if(isScriptExit()){break}
            if (单行文本.y - 排除文本未知_y[i] <= 5) {
                isWithinRange = true;  // 如果找到符合条件的值，标记为 true
                break;  // 找到之后可以退出循环
            }
        }

        if (isWithinRange) {
            continue;  // 如果在范围内，跳过当前循环
        }

        if(单行文本.x < 29){
            if(!msgHistoryArray || msgHistoryArray.length === 0){
                msgHistoryArray.push(`客户：${单行文本.label}`);
            }else {
                const 最后的消息 = msgHistoryArray[msgHistoryArray.length-1];
                if(最后的消息.startsWith('客户')){
                    if((单行文本.y - 上个文本的bottom位置) <12){
                        msgHistoryArray[msgHistoryArray.length-1] = msgHistoryArray[msgHistoryArray.length-1] + `${单行文本.label}`
                    }else {
                        msgHistoryArray[msgHistoryArray.length-1] = msgHistoryArray[msgHistoryArray.length-1] + `。${单行文本.label}`
                    }
                }else {
                    msgHistoryArray.push(`客户：${单行文本.label}`);
                }

            }
            // logw(`客户：${单行文本.label}   ${单行文本.height}`)
        }else {
            if(!msgHistoryArray || msgHistoryArray.length === 0){
                msgHistoryArray.push(`我：${单行文本.label}`);
            }else {
                const 最后的消息 = msgHistoryArray[msgHistoryArray.length-1];
                if(最后的消息.startsWith('我')){
                    if((单行文本.y - 上个文本的bottom位置) <12){
                        msgHistoryArray[msgHistoryArray.length-1] = msgHistoryArray[msgHistoryArray.length-1] + `${单行文本.label}`
                    }else {
                        msgHistoryArray[msgHistoryArray.length-1] = msgHistoryArray[msgHistoryArray.length-1] + `。${单行文本.label}`
                    }
                }else {
                    msgHistoryArray.push(`我：${单行文本.label}`);

                }
            }
        }
    }
    if(msgHistoryArray.length === 0){
        return
    }
    const 聊天记录 = msgHistoryArray.join('\n');
    日志打印_debug(`聊天记录: ${聊天记录}`)
    return 聊天记录
}

DouYin.prototype.dy_节点_获取聊天记录 = function (){
    当前执行模块 = 'dy_节点_获取聊天记录'
    日志打印_debug(`开始执行 - 【dy_节点_获取聊天记录】`);

    const 寻找私信弹出页面放大标识 = findColor(douyin.私信弹出页面放大标识);
    if(寻找私信弹出页面放大标识){
        const 放大私信页面 = 点击后检测(寻找私信弹出页面放大标识, 寻找私信弹出页面放大标识, [douyin.商家店铺左尖括号返回按钮]);
        switch (放大私信页面) {
            case -100:
                日志打印_error('(放大私信页面) 失败')
                return
            case -1:
                return
            case 0:
                日志打印_debug('(放大私信页面) 成功');
                break;
        }
    }

    let 私信退出按钮 = findColor(douyin.商家店铺左尖括号返回按钮);
    if(!私信退出按钮){
        私信退出按钮 = findColor(douyin.左上角返回按钮);
        if(!私信退出按钮){
            日志打印_error('(私信退出按钮) 获取失败')
            return
        }
    }
    const 私信页面输入框表情按钮 = findColor(douyin.私信页面表情标识);
    if(!私信页面输入框表情按钮){
        日志打印_error('(私信页面输入框表情按钮) 获取失败')
        return
    }
    setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"1","boundsFilter":"2","excludedAttributes":""})
    let Table = type("Table").getOneNodeInfo(10000)
    let 重试次数 = 3;
    while(!Table && 重试次数>0){
        if(isScriptExit()){break}
        iSleep(100);
        const 还在预期页面 = findColor(douyin.私信页面表情标识)
        if(还在预期页面){
            Table = type("Table").getOneNodeInfo(10000)
        }
        重试次数--;
    }
    if(!Table){
        return this.dy_ocr_获取聊天记录();
    }

    const nodes = Table.allChildren();

    if(!nodes || nodes.length === 0){
        return this.dy_ocr_获取聊天记录();
    }
    const chatArray = []
    let 客户有回复 = false;
    for(let i in nodes){
        if(isScriptExit()){break}

        const node = nodes[i];
        if(node.type === 'Cell'){
            const childs = node.allChildren();
            for (let j in childs){
                if(isScriptExit()){break}
                const child = childs[j];
                const child_height = Math.abs(child.bounds.bottom - child.bounds.top)
                if(child.type === 'Other' && child.bounds.top >0 && child_height > 36 && child.label !== ''){
                    const text = child.label;
                    if(text.includes('抖音自律公约') || text.includes('会话可能会被记录') || text.includes('由于对方的隐私设置')
                        || text.includes('消息发送限制') || text.includes('智能客服接待结束') || text.includes('谨防上当受骗')
                        || text.includes('温馨提示') || text.includes('保障服务质量') || text.includes('请放心沟通')){
                        continue;
                    }
                    const 文本内容 = text.replace(/\n/g, '');

                    let 我的发送 = false;
                    my_msg_end.forEach(item => {
                        if(isScriptExit()){return}
                        if(文本内容.endsWith(item)){
                            我的发送 = true
                        }
                    });
                    if (child.bounds.right >= 613 || 我的发送) {
                        chatArray.push(`我:${文本内容}`);  // 替换所有换行符
                    } else {
                        chatArray.push(`客户:${文本内容}`);  // 替换所有换行符
                        客户有回复 = true;
                    }

                }
            }
        }
    }
    const 聊天记录 = chatArray.join('\n');
    日志打印_information(聊天记录)
    return 聊天记录
}
DouYin.prototype.dy_用户主页_点关注 = function (){
    let 用户主页_关注按钮 = findColor(douyin.用户主页_关注按钮)
    if (!用户主页_关注按钮) {
        return
    }
    点击(用户主页_关注按钮);
}

DouYin.prototype.dy_私信用户时点关注 = function (follow_probability){
    // const 企业号 = !!findColor(douyin.抖音企业号标识)
    // if(企业号){
    //     日志打印_debug('【企业号】不点关注')
    //     return
    // }
    // const 企业号2 = type('Button').name("企业").getOneNodeInfo(10000)
    // if(企业号2){
    //     日志打印_debug('【企业号2】不点关注')
    //     return
    // }
    const 随机数 = Math.random();
    const 概率 = follow_probability
    if(随机数 < 概率) {
        //点关注
        let 关注按钮 = findColor(douyin.私信页面关注标识)
        if (!关注按钮) {
            return
        }
        点击(关注按钮);
        日志打印_debug('【私信用户时点关注】点关注成功！')
        return;
    }
}

DouYin.prototype.dy_发送私信 = function (私信内容, n=0.3) {
    当前执行模块 = 'dy_发送私信';
    日志打印_debug(`开始执行 - 【dy_发送私信】`);

    douyin.dy_私信用户时点关注(n);
    const sendText = `${私信置信度增加(私信内容)}${my_msg_end[Math.floor(Math.random() * my_msg_end.length)]}`

    const 私信页面输入框表情按钮 = findColor(douyin.私信页面表情标识);
    if (!私信页面输入框表情按钮) {
        日志打印_error('(私信页面输入框表情按钮) 获取失败！')
        return false
    }

    const 私信输入框 = {name: '私信输入框', x: 私信页面输入框表情按钮.x - 250, y: 私信页面输入框表情按钮.min_y / 2 + 私信页面输入框表情按钮.max_y / 2};

    const 输入框点击结果 = 点击后检测(私信输入框, douyin.私信页面表情标识, [ios.键盘弹出]);
    switch (输入框点击结果) {
        case -100:
            return false
        case -1:
            return false
        case 0:
            日志打印_debug('(输入框点击结果) 成功！')
            break
    }

    文本内容输入(sendText, 私信输入框);
    iSleep(100);
    let 私信发送按钮 = findColor(douyin.私信页面消息发送按钮);
    let 重试次数 = 3;
    while (!私信发送按钮 && 重试次数>0) {
        if (isScriptExit()) {break}
        文本内容输入(sendText, 私信输入框);
        iSleep(100);
        私信发送按钮 = findColor(douyin.私信页面消息发送按钮);
        重试次数--;
    }
    if(!私信发送按钮){
        日志打印_error('(私信发送按钮) 获取失败！')
        return false
    }
    键盘发送()
    iSleep(100);
    私信发送按钮 = findColor(douyin.私信页面消息发送按钮);
    重试次数 = 3;
    while (私信发送按钮 && 重试次数>0) {
        if (isScriptExit()) {break}
        键盘发送()
        iSleep(100);
        私信发送按钮 = findColor(douyin.私信页面消息发送按钮);
        重试次数--;
    }
    const 关闭私信键盘 = {name: '关闭私信键盘', x: random(10, 25), y: random(460, 520)}
    点击(关闭私信键盘)
    iSleep(300);
    return true
}

DouYin.prototype.dy_用户筛选 = function (fansLimit, customerType) {
    当前执行模块 = 'dy_用户筛选';
    日志打印_debug('执行- 【dy_用户筛选】')
    // 等待页面加载完毕
    while (!屏幕区域变化检测(500, 160, 200, ScreenWidth, ScreenHeight)) {
        if (isScriptExit()) {return}
        iSleep(100);
    }
    if(fansLimit === '不限' && customerType === '不限'){
        日志打印_debug('无需筛选')
    }else {
        setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
        let 筛选按钮_节点 = type("Button").label("筛选").getOneNodeInfo(10000)
        let 重试次数 = 3;
        while(!筛选按钮_节点 && 重试次数>0){
            if(isScriptExit()){break}
            iSleep(100);
            const 还在预期页面 = ocr文本数组匹配(douyin.搜索页_搜索结果标签)
            if(还在预期页面){
                筛选按钮_节点 = type('Button').name("筛选").getOneNodeInfo(10000);
            }
            重试次数--;
        }
        if(!筛选按钮_节点){
            日志打印_error('寻找 [筛选按钮_节点] 失败');
            return false
        }

        const 筛选按钮位置 = {name: '筛选按钮_节点', x: 筛选按钮_节点.bounds.left + (筛选按钮_节点.bounds.right-筛选按钮_节点.bounds.left)/3, y:  筛选按钮_节点.bounds.top/2 + 筛选按钮_节点.bounds.bottom/2}
        const 排序展开点击结果 = 点击后检测(筛选按钮位置, douyin.搜索页_搜索, [douyin.搜索页_用户筛选依据]);
        switch (排序展开点击结果) {
            case -100:
                日志打印_error('（筛选按钮）不正确！')
                return false
            case -1:
                return false
            case 0:
                日志打印_debug('（排序展开点击）成功！')
                break
        }

        switch (customerType) {
            case '普通用户':
                const 普通用户 =  {name: '【用户类型选择】普通用户', x: random(230, 320), y: random(510, 530)}
                const 普通用户_选择结果 = 点击屏幕检测(普通用户, 1000, 60, 100, 700, 750);
                if(!普通用户_选择结果){
                    日志打印_error('（普通用户_选择结果）失败！')
                    return false
                }
                break
            case '企业认证':
                const 企业认证 =  {name: '【用户类型选择】企业认证', x: random(400, 510), y: random(510, 530)}
                const 企业认证_选择结果 = 点击屏幕检测(企业认证, 1000, 60, 100, 700, 750);
                if(!企业认证_选择结果){
                    日志打印_error('（企业认证_选择结果）失败！')
                    return false
                }
                break
            case '个人认证':
                const 个人认证 =  {name: '【用户类型选择】个人认证', x: random(575, 675), y: random(510, 530)}
                const 个人认证_选择结果 = 点击屏幕检测(个人认证, 1000, 60, 100, 700, 750);
                if(!个人认证_选择结果){
                    日志打印_error('（个人认证_选择结果）失败！')
                    return false
                }
                break

        }
        switch (fansLimit) {
            case '1000以下':
                const 粉丝数量_1000以下 = {name: '【粉丝数量选择】1000以下', x: random(230, 320), y: random(340, 360)}
                const 粉丝数量_1000以下_选择结果 = 点击屏幕检测(粉丝数量_1000以下, 1000, 60, 100, 700, 750);
                if(!粉丝数量_1000以下_选择结果){
                    日志打印_error('（粉丝数量_1000以下_选择结果）1次失败！')
                    return false
                }
                break
            case '1000-1w':
                const 粉丝数量_1000_1w = {name: '【粉丝数量选择】1000-1w', x: random(415, 515), y: random(340, 360)}
                const 粉丝数量_1000_1w_选择结果 = 点击屏幕检测(粉丝数量_1000_1w, 1000, 60, 100, 700, 750);
                if(!粉丝数量_1000_1w_选择结果){
                    日志打印_error('（粉丝数量_1000_1w_选择结果）次失败！')
                    return false
                }
                break
            case '1w-10w':
                const 粉丝数量_1w_10w = {name: '【粉丝数量选择】1w-10w', x: random(600, 680), y: random(340, 360)}
                const 粉丝数量_1w_10w_选择结果 = 点击屏幕检测(粉丝数量_1w_10w, 1000, 60, 100, 700, 750);
                if(!粉丝数量_1w_10w_选择结果){
                    日志打印_error('（粉丝数量_1w_10w_选择结果）次失败！')
                    return false
                }
                break
        }
        if(fansLimit === '10w-100w' || fansLimit === '100w以上'){
            const 处理排列 = {name: '【粉丝数量选择】【处理排列】', x: random(600, 680), y: random(340, 360)}
            const 处理排列结果 = 点击屏幕检测(处理排列, 1000, 60, 100, 700, 750);
            if(!处理排列结果){
                日志打印_error('（处理排列结果）失败！')
                return false
            }
            switch (fansLimit) {
                case '10w-100w':
                    const 粉丝数量_10w_100w = {name: '【粉丝数量选择】10w-100w', x: random(500, 615), y: random(340, 360)}
                    const 粉丝数量_10w_100w_选择结果 = 点击屏幕检测(粉丝数量_10w_100w, 1000, 60, 100, 700, 750);
                    if (!粉丝数量_10w_100w_选择结果) {
                        日志打印_error('（粉丝数量_10w_100w_选择结果）1次失败！')
                        return false
                    }
                    break
                case '100w以上':
                    const 粉丝数量_100w以上 = {name: '【粉丝数量选择】100w以上', x: random(680, 700), y: random(340, 360)}
                    const 粉丝数量_100w以上_选择结果 = 点击屏幕检测(粉丝数量_100w以上, 1000, 60, 100, 700, 750);
                    if (!粉丝数量_100w以上_选择结果) {
                        日志打印_error('（粉丝数量_100w以上_选择结果）1次失败！')
                        return false
                    }
                    break
            }
        }
        const 关闭排序页面 = 点击屏幕检测(筛选按钮位置, 1000, 60, 100, 700, 750);
        if(!关闭排序页面){
            日志打印_error('（关闭排序页面）失败！')
            return false
        }
    }
    iSleep(2000)
    const 搜索页_用户筛选结果 = ocr文本数组匹配(douyin.搜索页_用户筛选结果)
    if(搜索页_用户筛选结果){
        douyin.关键词已无用户 = null
        return false
    }
    return true

}

DouYin.prototype.dy_获取所有搜索页当前用户 = function () {
    当前执行模块 = 'dy_获取所有搜索页当前用户'
    日志打印_information('开始执行- 【dy_获取所有搜索页当前用户】')

    function 在预期页面() {
        let 在预期页面 = findColor(douyin.搜索页面的用户列表关注按钮)
        if(!在预期页面){
            在预期页面 = findColor(douyin.搜索页面的用户列表关注按钮2)
            if(在预期页面){
                return true
            }else {
                return false
            }
        }else {
            return true
        }
    }

    setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
    iSleep(100);
    let collectionView = type("CollectionView").getOneNodeInfo(10000)
    let 重试次数 = 3;
    while(!collectionView && 重试次数>0){
        if(isScriptExit()){break}
        const 还在预期页面 = 在预期页面();
        if(还在预期页面){
            collectionView = type("CollectionView").getOneNodeInfo(10000)
            iSleep(100);
        }
        重试次数--;
    }
    if(!collectionView){
        日志打印_error('collectionView  获取失败')
        return null
    }
    const children = collectionView.allChildren()
    function 获取用户_ocr_抖音号(top, bottom) {
        const ocr识别内容 = ocr范围识别(150, top, ScreenWidth, bottom)
        const guanzhu_index = ocr识别内容.findIndex( item => item.label.includes('关注'))
        if(guanzhu_index === -1){
            return ''
        }

        const index = ocr识别内容.findIndex( item => item.label.includes('私密') || item.label.includes('已关注'))
        if(index !== -1){
            return ''
        }
        const 识别内容 = ocr识别内容.filter(item => item.label && item.label !== "" && !item.label.includes('相关视频'));
        识别内容.sort((a, b) => {
            // 首先按照y值进行排序
            if (Math.abs(a.y - b.y) <= 5) {
                // 如果y值差不超过5，则按照x值排序
                return a.x - b.x;
            } else {
                // 否则按照y值排序
                return a.y - b.y;
            }
        });
        const ocr识别抖音号 = 识别内容[识别内容.length-1]
        logw(JSON.stringify(ocr识别抖音号))
        let 用户抖音号信息 = ''
        if (Array.isArray(ocr识别抖音号)){
            用户抖音号信息 = douyin.裁剪ocr的抖音号(ocr识别抖音号.map(item => item.label).join(''))
        }else {
            用户抖音号信息 = douyin.裁剪ocr的抖音号(ocr识别抖音号.label)
        }
        if(用户抖音号信息.includes('店铺')){
            用户抖音号信息 = 识别内容.map(item => item.label).join('')
        }
        logw(用户抖音号信息)
        return 用户抖音号信息
    }
    const 当前列表用户信息 = []
    for(let i in children){
        if(isScriptExit()){ return }
        const child = children[i]
        if(child.type === 'Cell' && child.bounds.top >200 && child.bounds.bottom < (ScreenHeight-2) && (child.bounds.bottom-child.bounds.top) > 120){
            const 用户信息 = 获取用户_ocr_抖音号(child.bounds.top, child.bounds.bottom)
            if(!用户信息 || 用户信息 === ''){ continue }
            当前列表用户信息.push({
                name: 用户信息,
                x: random(150, 550),
                y: random(child.bounds.top+10, child.bounds.bottom-10)
            })
            // if(!ocr文本不完全匹配('私密', 150, child.bounds.top, 500, child.bounds.bottom)){
            //     当前列表用户信息.push({name: '搜索页当前用户' , x:random(340,500), y: child.bounds.top/2+child.bounds.bottom/2})
            // }
        }
    }
    return 当前列表用户信息
}

DouYin.prototype.dy_选择用户获取抖音ID = function (用户信息){
    当前执行模块 = 'dy_选择用户获取抖音号'
    日志打印_information('开始执行- 【dy_选择用户获取抖音号】')

    const 进入用户主页 = 点击后检测(用户信息, douyin.搜索页_搜索结果标签, [douyin.用户作品主页], 2000);
    switch (进入用户主页) {
        case -100:
            return
        case -1:
            return
        case 0:
            break
    }
    const 抖音ID = douyin.dy_节点获取抖音ID(false)
    if(!抖音ID){
        return
    }
    return 抖音ID.抖音ID
}

DouYin.prototype.dy_用户主页_更多弹窗_返回用户搜索页面 = function () {
    当前执行模块 = 'dy_用户主页_更多弹窗_返回用户搜索页面'
    日志打印_debug(`开始执行 - 【dy_用户主页_更多弹窗_返回用户搜索页面】`);

    const 关闭用户主页_更多弹窗 = douyin.dy_关闭用户主页_更多弹窗()
    if(!关闭用户主页_更多弹窗){
        return false
    }

    const 返回用户主页_按钮 = {name: '【dy_用户主页_更多弹窗_返回用户搜索页面】用户_返回按钮', x: random(50, 68), y:random(74,93)};
    const 返回搜索页面 = 点击后检测(返回用户主页_按钮, douyin.用户作品主页, [douyin.搜索页_搜索结果标签]);
    switch (返回搜索页面) {
        case -100:
            return false
        case -1:
            return false
        case 0:
            return true;
    }
}
DouYin.prototype.dy_搜索页用户列表上滑 = function (){
    当前执行模块 = 'dy_搜索页用户列表上滑';
    const startX = random(430, 500);
    const endX = random(430, 500);
    const startY = random(1260, 1270);
    const endY = random(230, 250);
    while (true){
        if(isScriptExit()){break}
        const 滑动检测 = 滑动误触检测([douyin.搜索页_搜索结果标签, douyin.用户作品主页], startX, startY, endX, endY, 1000, 1000);
        switch (滑动检测){
            case 100:
                日志打印_debug('dy_搜索页用户列表上滑成功');
                while(!屏幕区域变化检测(200, 250, 250, 500, 1000)){
                    if(isScriptExit()){break }
                    sleep(100);
                }
                return true
            case -1:
                return false
            case 0:
                return true
            case 1:
                if(ocr文本数组匹配(douyin.搜索页_搜索结果标签)){
                    return true
                }
                const 返回用户主页 = 点击后检测(douyin.用户主页_返回按钮, douyin.私信页面表情标识, [douyin.用户作品主页]);
                switch (返回用户主页) {
                    case -100:
                        日志打印_error('返回用户主页  失败！')
                        return false
                    case -1:
                        日志打印_error('返回用户主页  失败！')
                        return false
                    case 0:
                        日志打印_debug('返回用户主页  成功！')
                        return this.dy_搜索页用户列表上滑()
                }
        }

    }

}


//*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************

DouYin.prototype.dy_关闭评论区 = function (){
    当前执行模块 = 'dy_关闭评论区';

    const 视频播放页面的评论区关闭按钮 = findColor(douyin.视频播放页面的评论区关闭按钮)
    if (!视频播放页面的评论区关闭按钮) {
        日志打印_error('【关闭评论区】（视频播放页面的评论区关闭按钮）寻找失败！')
        return false
    }
    视频播放页面的评论区关闭按钮.name = '【dy_关闭评论区】视频播放页面的评论区关闭按钮'
    const 关闭评论区_结果 = 点击后检测(视频播放页面的评论区关闭按钮, douyin.视频播放页面的评论区关闭按钮, [douyin.视频播放页_关注按钮]);
    switch (关闭评论区_结果) {
        case -100:
            日志打印_error('（关闭评论区_结果）失败！')
            return false
        case -1:
            return false
        case 0:
            日志打印_debug('（关闭评论区_结果）成功！')
            return true
    }
}

DouYin.prototype.dy_话题播放量排序 = function (){
    logi(`开始执行 - 【dy_话题播放量排序】`);
    iSleep(1000);
    let node = null;
    let 重试次数 = 3;
    while(!node && 重试次数 > 0){
        iSleep(100);
        const 还在预期页面 = ocr文本数组匹配(douyin.搜索页_话题_立即参与)
        if(还在预期页面){
            node = type("CollectionView").getOneNodeInfo(10000)
            iSleep(100);
        }
        重试次数--;
    }
    if(!node){
        日志打印_error('CollectionView 节点获取失败！')
        return null
    }
    const 话题排序 = []
    const cells = node.allChildren()
    for (const i in cells){
        if(isScriptExit()){ break }

        const cell = cells[i];
        if (cell.type !== 'Cell'){
            continue;
        }
        if(cell.bounds.top < node.bounds.top || cell.bounds.bottom > node.bounds.bottom){
            continue;
        }
        const 所有文本 = ocr范围识别(168, cell.bounds.top, cell.bounds.right, cell.bounds.bottom);
        if(!所有文本 || 所有文本.length < 2){
            continue;
        }

        const js = {name: null, '播放量': null, x: cell.bounds.left/2 + cell.bounds.right/2, y: cell.bounds.top/2 + cell.bounds.bottom/2};
        for( const j in 所有文本){
            if(isScriptExit()){ break }
            const 单行文本 = 所有文本[j]
            单行文本.label = 单行文本.label.replace('＃', '#')
            if(单行文本.label.includes('#')){
                const index = 单行文本.label.indexOf('#');
                js.name = 单行文本.label.slice(index);
                continue;
            }
            if(单行文本.label.includes('次播放')){
                const index = 单行文本.label.indexOf('次播放');
                js.播放量 = 单行文本.label.slice(0, index + 3);
            }
        }
        if(js.name && js.播放量){
            话题排序.push(js);
        }
    }
    话题排序.sort((a, b) => {
        const parsePlayCount = (str) => {
            if (str.includes('亿次播放')) {
                return parseFloat(str.replace('亿次播放', '')) * 100000000;
            } else if (str.includes('万次播放')) {
                return parseFloat(str.replace('万次播放', '')) * 10000;
            } else {
                return parseFloat(str) || 0;
            }
        };
        const playCountA = parsePlayCount(a['播放量']);
        const playCountB = parsePlayCount(b['播放量']);
        return playCountB - playCountA;
    });
    for(const i in 话题排序){
        logi(JSON.stringify(话题排序[i]))
    }
    return 话题排序
}

DouYin.prototype.dy_话题视频_进入选择最新 = function (话题) {
    logi(`开始执行 - 【dy_话题视频_进入选择最新】`);

    点击后检测(话题, douyin.搜索页_话题_立即参与, [douyin.话题页_话题导航])
    iSleep(500)
    let node = type("StaticText").label('最新').getOneNodeInfo(10000)
    if(!node){
        return this.dy_话题视频_进入选择最新()
    }
    const 最新按钮 = {name: '【dy_话题视频_进入选择最新】话题最新按钮',  x: node.bounds.left/2 + node.bounds.right/2, y: node.bounds.top/2 + node.bounds.bottom/2};
    const 最新按钮点击结果 = 点击屏幕检测(最新按钮, 2000,20, 750, 650, 1000);
    if(!最新按钮点击结果){
        loge(`【dy_话题视频_进入选择最新】 最新按钮点击 失败- ${JSON.stringify(最新按钮)}`)
        scriptError(`【dy_话题视频_进入选择最新】 最新按钮点击 失败- ${JSON.stringify(最新按钮)}`)
    }
    const 第一个视频位置 = {name: '【dy_话题视频_进入选择最新】话题最新第一个视频位置', x: node.bounds.left-60, y: node.bounds.bottom+150};
    点击后检测(第一个视频位置, douyin.话题页_话题导航, [douyin.视频播放页_关注按钮])
    return true
}

DouYin.prototype.dy_获取视频发布日期 = function(){
    logi(`开始执行 - 【dy_获取视频发布日期】`);

    const 视频播放页面的关注按钮 = findColor(douyin.视频播放页_关注按钮)
    if (!视频播放页面的关注按钮) {
        loge('【dy_获取视频发布日期】（视频播放页面的关注按钮）寻找失败！');
        scriptError('【dy_获取视频发布日期】（视频播放页面的关注按钮）寻找失败！');
    }
    // 通过关注按钮获取评论按钮的位置
    const 分享按钮 = {name: '【dy_获取视频发布日期】分享按钮', x:视频播放页面的关注按钮.x, y: (视频播放页面的关注按钮.y + 510) };
    const 评论区打开 = 点击后检测(分享按钮, douyin.视频播放页_关注按钮, [douyin.视频播放页面的评论区放大按钮, ios.键盘弹出]);
}

DouYin.prototype.dy_返回话题搜索页 = function () {
    logi(`开始执行 - 【dy_返回话题搜索页】`);

    const 视频播放关闭按钮 = {name: '【dy_返回话题搜索页】视频播放关闭按钮', x:random(35,50), y:random(80, 90)}
    点击后检测(视频播放关闭按钮, douyin.视频播放页_关注按钮, [douyin.话题页_话题导航])

    点击后检测(视频播放关闭按钮, douyin.话题页_话题导航, [douyin.搜索页_话题_立即参与])

}

DouYin.prototype.dy_话题栏上滑刷新话题 = function () {
    logi(`开始执行 - 【dy_话题栏上滑刷新话题】`);

    滑动(random(212,458), 1200, random(212,458), 450, 500);
    while(!屏幕区域变化检测(200, 212, 450, 458, 1200)){
        if(isScriptExit()){break }
        sleep(100);
    }
}

DouYin.prototype.裁剪ocr的抖音号 = function (douyin_id){
    return  douyin_id.replace('抖音号：', '')
        .replace('抖音号:', '')
        .replace('抖音号', '')
        .replace('抖音号；', '')
        .replace('抖音号;', '')
        .replace('口', '')
        .replace('日', '')
        .replace('国', '')
        .replace('曰', '')
        .replace('白', '')
        .replace('可', '')
        .replace('已', '')
        .replace('己', '')
        .replace('巳', '')
        .replace('；', '')
        .replace(';', '')
        .replace(':', '')
        .replace('/', '')
        .replace('：', '')
        .replace(/\s+/g, '');
}

/**
 * @description  通过写入文件传递进程之间的数据
 * @param {传递的数据} data
 * @param {是否为传递的最后一个数据} isFinished
 */
DouYin.prototype.传递worker数据 = function (data, isFinished){
    logi('写入数据文件内容：' + data);

    if(isFinished === null || isFinished === undefined){
        isFinished = false;
    }
    const dirPath = file.getSandBoxFilePath('douyin');
    let 重试次数 = 3;
    let 文件夹创建 = file.mkdirs(dirPath);
    while(!文件夹创建 && 重试次数 > 0){
        if(isScriptExit()){ return false; }

        文件夹创建 = file.mkdirs(dirPath);
        重试次数 = 重试次数 - 1;
    }
    if(!文件夹创建){
        scriptError(`文件夹创建失败：${dirPath}`)
    }

    let dataPath = ''
    if(!isFinished){
        dataPath = file.getSandBoxFilePath(`douyin/${获取当前时间()}.txt`);
    }else {
        dataPath = file.getSandBoxFilePath('douyin/finished.txt');
    }


    重试次数 = 3;
    let 数据写入文件 = file.writeFile(data, dataPath);
    while(!数据写入文件 && 重试次数 > 0){
        if(isScriptExit()){ return false }

        数据写入文件 = file.writeFile(data, dataPath);
        重试次数 = 重试次数 - 1;
    }
    if(!数据写入文件){
        scriptError(`数据写入文件失败：${dirPath}`)
    }

    // var data = file.readFile(dataPath);
    // logw(data);
}

DouYin.prototype.传递关键词评级数据 = function (data, isFinished){
    logi('写入数据文件内容：' + data);

    if(isFinished === null || isFinished === undefined){
        isFinished = false;
    }
    const dirPath = file.getSandBoxFilePath('alldouyin');
    let 重试次数 = 3;
    let 文件夹创建 = file.mkdirs(dirPath);
    while(!文件夹创建 && 重试次数 > 0){
        if(isScriptExit()){ return false; }
        文件夹创建 = file.mkdirs(dirPath);
        重试次数 = 重试次数 - 1;
    }
    if(!文件夹创建){
        scriptError(`文件夹创建失败：${dirPath}`)
    }

    let dataPath = ''
    if(!isFinished){
        dataPath = file.getSandBoxFilePath(`alldouyin/${获取当前时间()}.txt`);
    }else {
        dataPath = file.getSandBoxFilePath('alldouyin/finished.txt');
    }

    重试次数 = 3;
    let 数据写入文件 = file.writeFile(data, dataPath);
    while(!数据写入文件 && 重试次数 > 0){
        if(isScriptExit()){ return false }

        数据写入文件 = file.writeFile(data, dataPath);
        重试次数 = 重试次数 - 1;
    }
    if(!数据写入文件){
        scriptError(`数据写入文件失败：${dirPath}`)
    }

    // var data = file.readFile(dataPath);
    // logw(data);
}


DouYin.prototype.初始化 = function (){
    douyin.图色初始化()   // 初始化预设的图色标识
    douyin.ocr内容初始化()   // 初始化预设的ocr内容
    douyin.内部图色初始化()
    laoleng.EC.init(1)
    laoleng.EC.initOcr()
    laoleng.EC.initNode()
}


