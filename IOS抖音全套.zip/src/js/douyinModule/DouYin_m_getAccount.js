DouYin.prototype.dy_跟进客户 = function (){
    if (!douyin.跟进时间 || (douyin.跟进时间 && (time() -douyin.跟进时间) > 脚本运行配置.dy.follow_min_time*60*1000)){
        api_记录风控日志('抖音', 抖音_获取当前账号的抖音ID(), '操作', '跟进客户')
        douyin.dy_当前账号_跟进客户()
        douyin.dy_切换账号_跟进客户()
    }

}

DouYin.prototype.dy_账号统计_切换_初始化 = function (){
    当前执行模块 = 'dy_账号统计_切换_初始化';
    日志打印_warning('开始执行-【dy_账号统计_切换_初始化】')
    douyin.初始化()
    脚本当前运行阶段 = '统计设备抖音账号'
    while (true){
        if(isScriptExit()) { break }
        if (!douyin.dy_首页导航_切换(4)) {
            douyin.dy_启动抖音()
            continue
        }
        const 当前_账号_抖音号_私信 = douyin.dy_我_页面_当前账号信息()
        if(!当前_账号_抖音号_私信) { continue }

        const 当前账号 = {
            choose: true,
            account_id:当前_账号_抖音号_私信.抖音号,
            account_name: '',
            belong_uid: uid,
            account_type: '抖音',
            account_state:当前_账号_抖音号_私信.私信功能,
            send_count: 0,
            send_failed_count: 0,
            send_pinfan_count: 0,
            belong_device_id: device_id,
            account_information: '',

        }
        设备账号信息.dy.length = 0
        设备账号信息.dy.push(当前账号)
        douyin.dy_消息列表统计(3)
        if (!douyin.dy_首页导航_切换(4)) { continue }
        const 所有账号信息 = douyin.dy_切换账号()
        if(所有账号信息.length === 1){
            设备账号信息.dy.forEach(account => {
                account.account_name = 所有账号信息[0].account_name
                account.fans = 所有账号信息[0].fans
            })
            break
        }else {
            所有账号信息.forEach( account => {
                if (account.choose){
                    account.choose = false
                }else {
                    account.choose = true
                }
            })
            const 切换后_账号_抖音号_私信 = douyin.dy_我_页面_当前账号信息()
            if(!切换后_账号_抖音号_私信) { continue }
            所有账号信息.forEach( account => {
                if (account.choose){
                    account.account_id = 切换后_账号_抖音号_私信.抖音号
                    account.account_state = 切换后_账号_抖音号_私信.私信功能
                    account.send_count = 0
                    account.send_failed_count = 0
                    account.send_pinfan_count = 0
                    account.belong_uid = uid
                    account.account_type = '抖音'
                    account.belong_device_id = device_id
                    account.account_information = ''
                }else {
                    account.account_id = 当前_账号_抖音号_私信.抖音号
                    account.account_state = 当前_账号_抖音号_私信.私信功能
                    account.send_count = 0
                    account.send_failed_count = 0
                    account.send_pinfan_count = 0
                    account.belong_uid = uid
                    account.account_type = '抖音'
                    account.belong_device_id = device_id
                    account.account_information = ''
                }
            })
            设备账号信息.dy = 所有账号信息
            douyin.dy_消息列表统计(3)
            if (!douyin.dy_首页导航_切换(4)) { continue }
            break
        }
    }
    日志打印_warning(JSON.stringify(设备账号信息))
    抖音_更新账号今日私信()
    return
}

DouYin.prototype.dy_当前账号_跟进客户 = function (){
    当前执行模块 = 'dy_当前账号_跟进客户';
    日志打印_warning('开始执行-【dy_当前账号_跟进客户】')
    while (true){
        if(isScriptExit()) { break }
        if (!douyin.dy_首页导航_切换(3)) {
            douyin.dy_启动抖音()
            continue
        }
        douyin.dy_消息列表统计(3)
        break
    }
}

DouYin.prototype.dy_切换账号_跟进客户 = function (){
    当前执行模块 = 'dy_切换账号_跟进客户';
    日志打印_warning('开始执行-【dy_切换账号_跟进客户】')
    if(设备账号信息.dy.length <= 1){
        日志打印_warning('【抖音账号数量不够，无需切换账号】')
        return;
    }
    if (!douyin.切号时间 || (douyin.切号时间 && (time() -douyin.切号时间) > 脚本运行配置.dy.cut_min_time*60*1000)){
        douyin.dy_切换账号()
        douyin.dy_消息列表统计(3)
    }

}

DouYin.prototype.dy_首页视频养号 = function (分钟 = 3) {
    const 起始时间 = time()
    while ((time() -起始时间) < 分钟*60*1000) {
        if (isScriptExit()) { return }
        if (!douyin.dy_首页导航_切换(1)) {
            douyin.dy_启动抖音()
            continue
        }
        const 消息按钮截图 = 区域截图base64(460,1250,600,1320)
        while ((time() -起始时间) < 分钟*60*1000) {
            if (isScriptExit()) { return }
            当前执行模块 = 'dy_首页视频养号'
            douyin.dy_上滑切换视频(false)
            日志打印_information('【dy_上滑切换视频】养号中')
            iSleep(random(10000, 50000));
            let 新_消息按钮截图 = 区域截图base64(460,1250,600,1320)
            if(新_消息按钮截图 === 消息按钮截图) { return }
        }
    }
}

DouYin.prototype.dy_消息页_回复私信消息 = function () {
    日志打印_warning('开始执行-【dy_消息页_回复私信消息】')

    if(douyin.当前账号_私信跟进列表.length > 0){
        let 消息页_右上角搜索_放大镜 = findColor(douyin.消息页_右上角搜索_放大镜)
        while(!消息页_右上角搜索_放大镜){
            if(isScriptExit()) {break}
            if (!douyin.dy_首页导航_切换(3)) {
                douyin.dy_启动抖音()
            }
            消息页_右上角搜索_放大镜 = findColor(douyin.消息页_右上角搜索_放大镜)
        }
        const 进入消息搜索 = 点击后检测(消息页_右上角搜索_放大镜, douyin.消息页_右上角搜索_放大镜, [douyin.消息页_搜索输入框标识])
        if(进入消息搜索 !== 0) { return douyin.dy_消息页_回复私信消息() }

        while (douyin.当前账号_私信跟进列表.length > 0){
            if(isScriptExit()) {break}
            douyin.dy_返回_设定页面(douyin.消息页_搜索输入框标识)
            const 打开键盘 = 点击后检测(douyin.消息列表_搜索页_顶部输入框, douyin.消息页_搜索输入框标识, [ios.键盘弹出])
            if(打开键盘 !== 0) { return douyin.dy_消息页_回复私信消息() }
            const 回复内容 = douyin.当前账号_私信跟进列表[0]
            douyin.当前账号_私信跟进列表.shift()
            文本内容输入(回复内容.customer_id, {name: '消息页_搜索输入框'})
            键盘发送()
            setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
            let 用户节点 = type("StaticText").labelMatch(`抖音.*`).getOneNodeInfo(10000)
            let 重试次数 = 3
            while (!用户节点 && 重试次数>0){
                if(isScriptExit()) {break}
                iSleep(100)
                const 还在搜索页面 = findColor(douyin.消息页_搜索输入框标识)
                if(还在搜索页面){
                    用户节点 = type("StaticText").labelMatch(`抖音.*`).getOneNodeInfo(10000)
                    if(!用户节点){
                        用户节点 = label('发私信').getOneNodeInfo(10000)
                    }
                }
                重试次数--
            }
            if(!用户节点){
                const 打开键盘 = 点击后检测(douyin.消息列表_搜索页_顶部输入框, douyin.消息页_搜索输入框标识, [ios.键盘弹出])
                if(打开键盘 !== 0) { return douyin.dy_消息页_回复私信消息() }
                文本内容输入(回复内容.customer_name, {name: '消息页_搜索输入框'})
                键盘发送()
                用户节点 = type("Button").label(回复内容.customer_name).getOneNodeInfo(10000)
                重试次数 = 3
                while (!用户节点 && 重试次数>0){
                    if(isScriptExit()) {break}
                    iSleep(100)
                    const 还在搜索页面 = findColor(douyin.消息页_搜索输入框标识)
                    if(还在搜索页面){
                        用户节点 = type("Button").label(回复内容.customer_name).getOneNodeInfo(10000)
                        if(!用户节点){
                            用户节点 = label('发私信').getOneNodeInfo(10000)
                        }
                    }
                    重试次数--
                }
                if(!用户节点){
                    douyin.私信跟进失败列表.push(回复内容)
                    continue
                }

            }
            const 用户位置 = {name: `抖音号: ${回复内容.fiend_douyinID}`, x: 用户节点.bounds.left/2+用户节点.bounds.right/2, y: 用户节点.bounds.top/2+用户节点.bounds.bottom/2}
            const 进入用户私信 = 点击后检测(用户位置, douyin.消息页_右上角搜索_放大镜, [douyin.私信页面表情标识])
            if(进入用户私信 !== 0) { return douyin.dy_消息页_回复私信消息()}
            douyin.dy_发送私信(回复内容.replay_msg, 1)
            douyin.dy_返回_设定页面(douyin.私信页面表情标识)
            const 回复截图 = 区域截图base64()
            const 任务执行成功 = {
                "task_id": 回复内容.id,
                "focus_customer_record_id":回复内容.focus_customer_record_id,
                "task_state": 2
            }
            api_跟进任务执行成功(任务执行成功)
            const 记录数据 = {
                "belong_uid": uid,
                "belong_device_id": device_id,
                "belong_app_account_id": 抖音_获取当前账号的抖音ID(),
                "belong_app_account_type": "抖音",
                "follow_type": '人工回复私信',
                "follow_customer_name": 回复内容.customer_name,
                "follow_customer_id": 回复内容.customer_id,
                "follow_customer_comment": 回复内容.customer_comment,
                "lats_id": 回复内容.focus_customer_record_id,
                "follow_img": 回复截图,
            }
            api_记录跟进用户(记录数据)
        }
        douyin.dy_返回_设定页面(douyin.消息页_右上角搜索_放大镜)
    }
}

DouYin.prototype.dy_消息页_评论跟进 = function () {
    日志打印_warning('开始执行-【dy_消息页_评论跟进】')

    function 消息页_评论跟进() {
        日志打印_warning('开始执行-【消息页_评论跟进】')

        function 回复内容格式化(str, char) {
            const lastIndex = str.lastIndexOf(char);
            if (lastIndex !== -1) {
                return str.substring(0, lastIndex);
            }
            return str; // 如果没有找到char，返回原字符串
        }


        function 获取评论内容(top, bottom) {
            setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
            const 消息记录 = {type: '点赞评论', fiend_douyinID: '', fiend_name: ''}
            const StaticTexts = type("StaticText").bounds(0,top,ScreenWidth,bottom).getNodeInfo(10000)
            if (StaticTexts && StaticTexts.length > 0){
                const 互动用户名称 = StaticTexts.reduce((min, current) => {
                    if (current.label && current.label !=='' && (!min || current.bounds.left < current.bounds.left)) {
                        return current;
                    }
                    return min;
                }, null); //
                消息记录.fiend_name = 互动用户名称.label
            }

            const Others = type("Other").bounds(0,top,ScreenWidth,bottom).getNodeInfo(10000)
            if(Others && Others.length > 0){
                const 筛选最深层级Other = Others.filter(item => {
                    return item.childCount === 0
                });
                const 回复内容Other = 筛选最深层级Other.reduce((max, current) => {
                    if (current.label && current.label !=='' && (!max || current.bounds.bottom > max.bounds.bottom)) {
                        return current;
                    }
                    return max;
                }, null); //
                if(!回复内容Other){
                    日志打印_error('没找到 回复内容Other')
                    return
                }
                if(回复内容Other.label.includes('推荐了你的视频') || 回复内容Other.label.includes('收藏了你的视频 ') || 回复内容Other.label.includes('赞了你的评论 ')
                    || 回复内容Other.label.includes('赞了你的视频 ') || 回复内容Other.label.includes('提到了你 ')){
                    消息记录.type = 回复内容Other.label
                }
                else if(回复内容Other.label.includes('访问过你的主页')){
                    消息记录.type = '主页访问'
                }
                else {
                    消息记录.type = '回复评论'
                    消息记录.comment = 回复内容格式化(回复内容Other.label, '  ')
                    const StaticTexts = type("StaticText").bounds(0, top, ScreenWidth, bottom).getNodeInfo(10000)
                    if (StaticTexts && StaticTexts.length > 0) {
                        const 互动用户名称 = StaticTexts.reduce((min, current) => {
                            if (current.label && current.label !== '' && (!min || current.bounds.left < current.bounds.left)) {
                                return current;
                            }
                            return min;
                        }, null); //
                        if(!互动用户名称){
                            日志打印_error('没找到 互动用户名称')
                            return
                        }
                        消息记录.fiend_name = 互动用户名称.label
                        const index = douyin.当前账号_评论跟进列表.findIndex(item => item.customer_comment === 消息记录.comment && item.customer_name === 消息记录.fiend_name);
                        if (index !== -1) {
                            const Buttons = type("Button").bounds(0,top,ScreenWidth,bottom).getNodeInfo(10000)
                            if (Buttons && Buttons.length > 0){
                                const 评论内容 = douyin.当前账号_评论跟进列表[index]
                                douyin.当前账号_评论跟进列表.splice(index, 1);
                                for(let i in Buttons){
                                    if(isScriptExit()) { break }
                                    const button = Buttons[i]
                                    const 文本 = button.label
                                    if (文本.startsWith('赞') && 评论内容.hasOwnProperty('like') && 评论内容.is_like === 1){
                                        const 点赞按钮 = {name: '点赞按钮', x: button.bounds.left/2+button.bounds.right/2, y: button.bounds.top/2+button.bounds.bottom/2}
                                        点击(点赞按钮)
                                    }
                                    if (文本.startsWith('回复评论')){
                                        const 回复按钮 = {name: '回复评论按钮', x: button.bounds.left/2+button.bounds.right/2, y: button.bounds.top/2+button.bounds.bottom/2}
                                        for(let u=0; u<3; u++){
                                            if(isScriptExit()) {break}
                                            点击(回复按钮)
                                            iSleep(500)
                                            if(ocr文本数组匹配(ios.键盘弹出)){
                                                文本内容输入(评论内容.replay_msg, {name: '回复评论输入框'})
                                                键盘发送()
                                                const 任务执行成功 = {
                                                    "task_id": 评论内容.id,
                                                    "focus_customer_record_id":评论内容.focus_customer_record_id,
                                                    "task_state": 2
                                                }
                                                api_跟进任务执行成功(任务执行成功)
                                                const 记录数据 = {
                                                    "belong_uid": uid,
                                                    "belong_device_id": device_id,
                                                    "belong_app_account_id": 抖音_获取当前账号的抖音ID(),
                                                    "belong_app_account_type": "抖音",
                                                    "follow_type": '人工回复评论',
                                                    "follow_customer_name": 评论内容.customer_name,
                                                    "follow_customer_id": 评论内容.customer_id,
                                                    "follow_customer_comment": 评论内容.customer_comment,
                                                    "lats_id": 评论内容.focus_customer_record_id,
                                                    "follow_img": 区域截图base64(),
                                                }
                                                api_记录跟进用户(记录数据)
                                                return
                                            }
                                        }

                                    }
                                }
                            }else {
                                const 回复评论_节点 = type('StaticText').label("回复评论").bounds(0,top,ScreenWidth,bottom).getOneNodeInfo(10000)
                                if (回复评论_节点){
                                    const 评论内容 = douyin.当前账号_评论跟进列表[index]
                                    douyin.当前账号_评论跟进列表.splice(index, 1);
                                    const 回复按钮 = {name: '回复评论按钮', x: 回复评论_节点.bounds.left/2+回复评论_节点.bounds.right/2, y: 回复评论_节点.bounds.top/2+回复评论_节点.bounds.bottom/2}
                                    if (评论内容.hasOwnProperty('like') && 评论内容.like === 'like'){
                                        douyin.消息页_互动消息_评论回复点赞标识.y = top
                                        douyin.消息页_互动消息_评论回复点赞标识.ey = bottom
                                        const 消息页_互动消息_评论回复点赞标识 = findColor(douyin.消息页_互动消息_评论回复点赞标识)
                                        if(消息页_互动消息_评论回复点赞标识){
                                            点击(消息页_互动消息_评论回复点赞标识)
                                        }
                                    }
                                    for(let u=0; u<3; u++){
                                        if(isScriptExit()) {break}
                                        点击(回复按钮)
                                        iSleep(500)
                                        if(ocr文本数组匹配(ios.键盘弹出)){
                                            const 自定义字段 = {
                                                type: '人工回复评论',
                                                fiend_douyinID: 评论内容.fiend_douyinID,
                                                my_douyinID: 抖音_获取当前账号的抖音ID(),
                                                fiend_name: 评论内容.fiend_name,
                                                comment: 评论内容.comment,
                                                replay_msg: 评论内容.replay_msg,
                                            }
                                            const 互动消息_截图 = 区域截图base64(0, 0, ScreenWidth, ScreenHeight)
                                            上传私信回复图片(JSON.stringify(自定义字段), 互动消息_截图)
                                            文本内容输入(评论内容.replay_msg, {name: '回复评论输入框'})
                                            键盘发送()
                                            return
                                        }
                                    }

                                }

                            }
                        }
                    }
                    else {
                        日志打印_error('没找到 StaticText')
                    }
                }
            }
            else {
                日志打印_error('没找到 Others')
            }
            return
        }

        setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"1","boundsFilter":"2","excludedAttributes":""})
        while (true){
            if(isScriptExit()) {break}
            const cells = type("Cell").getNodeInfo(10000)
            if(cells && cells.length > 0){
                for(let i in cells){
                    if(isScriptExit()){break}
                    const cell = cells[i]
                    if(cell.bounds.top < 120 || cell.bounds.bottom > ScreenHeight){ continue }
                    获取评论内容(cell.bounds.top, cell.bounds.bottom)
                    douyin.dy_返回_设定页面(douyin.消息列表_互动消息_页面标识)
                }
                if(douyin.当前账号_评论跟进列表.length <= 0) { break }
                const startY = cells[cells.length-1].bounds.top
                const endY = cells[0].bounds.bottom/2 + cells[0].bounds.top/2
                滑动(random(6,30), startY, random(6,30), Math.max(endY,400), 1200)
                douyin.dy_返回_设定页面(douyin.消息列表_互动消息_页面标识)
            }
        }
        return
    }

    if(douyin.当前账号_评论跟进列表.length > 0){
        let 消息页_互动消息标识 = findColor(douyin.消息页_互动消息标识)
        while(!消息页_互动消息标识){
            if(isScriptExit()) {break}
            日志打印_error('[消息页_互动消息标识] 寻找中')
            if (!douyin.dy_首页导航_切换(3)) {
                douyin.dy_启动抖音()
                continue
            }
            消息页_互动消息标识 = findColor(douyin.消息页_互动消息标识)
        }
        const 进入消息页_互动页面 = 点击后检测(消息页_互动消息标识, douyin.消息页_互动消息标识, [douyin.消息列表_互动消息_页面标识] )
        if(进入消息页_互动页面 !== 0){
            return douyin.dy_消息页_评论跟进()
        }
        while (douyin.当前账号_评论跟进列表.length > 0){
            if(isScriptExit()) {break}
            消息页_评论跟进()
        }
    }
    douyin.dy_返回_设定页面(douyin.消息页_右上角搜索_放大镜)
}

DouYin.prototype.dy_消息列表统计 = function (无消息次数=3){
    当前执行模块 = 'dy_消息列表统计';
    日志打印_warning('开始执行-【dy_消息列表统计】')

    function 消息列表统计() {
        while (true){
            if(isScriptExit()) {break}
            if (!douyin.dy_首页导航_切换(3)) {
                douyin.dy_启动抖音()
                continue
            }
            douyin.dy_消息页_回复私信消息()
            let 消息页截图 = 区域截图base64(0, 1100, ScreenWidth, 1240)
            let tryCount = 无消息次数
            while (tryCount > 0){
                if(isScriptExit()) {break}
                douyin.dy_消息列表轮询()
                douyin.dy_返回_设定页面(douyin.消息页_右上角搜索_放大镜)
                点击(douyin.底部导航_消息_按钮)
                iSleep(200)
                const 点击后_消息页截图 = 区域截图base64(0, 1100, ScreenWidth, 1240)
                if(点击后_消息页截图 !== 消息页截图){
                    消息页截图 = 点击后_消息页截图
                    tryCount = 无消息次数
                }else {
                    tryCount--
                }
                if(tryCount <= 0 ){
                    break
                }
            }
            douyin.dy_消息页_评论跟进()
            break
        }
    }

    抖音_更新当前账号跟进列表()
    消息列表统计()

}

DouYin.prototype.dy_消息列表轮询 = function () {
    当前执行模块 = 'dy_消息列表轮询';
    日志打印_warning('开始执行-【dy_消息列表轮询】')
    const 消息列表_未读标识 = findMultiColor([douyin.消息列表_未读标识_数字,douyin.消息列表_未读标识_圆点, douyin.消息列表_未读标识_数字_2])
    if(消息列表_未读标识){
        const 进入页面 = 点击后检测(消息列表_未读标识.point, douyin.首页_底部导航, [douyin.私信页面表情标识, douyin.消息列表_新关注我的_页面标识, douyin.消息列表_互动消息_页面标识, douyin.消息列表_陌生人消息_页面标识])
        switch (进入页面) {
            case -1:
                return
            case -100:
                return
            case 0:
                return douyin.dy_消息列表_私信消息_记录()
            case 1:
                return douyin.dy_新关注我的_消息推送并记录()
            case 2:
                return douyin.dy_互动消息_消息推送并记录()
            case 3:
                return douyin.dy_陌生人消息_私信_消息记录()
        }
    }
}

DouYin.prototype.dy_获取私信好友_抖音id = function () {
    日志打印_warning('开始执行-【dy_获取私信好友_抖音id】')

    setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
    let 私信页面顶部节点合集 =  bounds(0,40,ScreenWidth,140).type('Other').getNodeInfo(10000);
    let tryCount = 3;
    while(!私信页面顶部节点合集 && tryCount>0){
        if(isScriptExit()) {break}
        iSleep(100)
        const 还在预期页面 = findColor(douyin.私信页面表情标识)
        if(还在预期页面){
            私信页面顶部节点合集 =  bounds(0,40,ScreenWidth,140).type('Other').getNodeInfo(10000);
        }
        tryCount--;
    }
    let 头像按钮 = null
    for (let i in 私信页面顶部节点合集){
        if(isScriptExit()) {break}
        const other = 私信页面顶部节点合集[i]
        const height = other.bounds.bottom - other.bounds.top
        const width = other.bounds.right - other.bounds.left
        // logi(`width: ${width}  height: ${height}`)
        if( height === 72 && (width === 72 || width === 74)){
            logi(JSON.stringify(other))
            头像按钮 = {name: '私信用户头像', x: other.bounds.right/2+ other.bounds.left/2, y: other.bounds.bottom/2+ other.bounds.top/2}
            break
        }
    }
    if(!头像按钮){ return  }
    const 进入私信用户主页 = 点击后检测(头像按钮, douyin.私信页面表情标识, [douyin.用户作品主页])
    if(进入私信用户主页 !== 0){ return  }
    douyin.dy_用户主页_点关注()
    const 用户信息 = douyin.dy_节点获取抖音ID()
    return 用户信息
}

DouYin.prototype.dy_消息列表_私信消息_记录 = function () {
    日志打印_warning('开始执行-【dy_消息列表_私信_消息记录】')

    const 用户消息 = douyin.dy_私信页面_消息记录()
    if(!用户消息) { return }
    let 记录数据 = null
    if (脚本运行配置.ai_config.state){
        // 接入ai自动回复
        const 聊天记录 = douyin.dy_节点_获取聊天记录()
        const replay = 请求AI回复(抖音_获取当前账号的抖音ID(), 用户消息.fiend_douyinID, 用户消息.fiend_name, 聊天记录)
        if (replay){
            douyin.dy_发送私信(replay, 1)
            记录数据 = {
                "belong_uid": uid,
                "belong_device_id": device_id,
                "belong_app_account_id": 抖音_获取当前账号的抖音ID(),
                "belong_app_account_type": "抖音",
                "follow_type": 'AI 自动回复',
                "follow_customer_name": 用户消息.fiend_name,
                "follow_customer_id": 用户消息.fiend_douyinID,
                "follow_customer_comment": '',
                "follow_img": 区域截图base64()
            }
        }
    }
    logw(`${用户消息.type} -- ${用户消息.fiend_douyinID} -- ${用户消息.fiend_name} -- ${用户消息.my_douyinID} -- ${用户消息.comment}`)
    if(!记录数据){
        记录数据 = {
            "belong_uid": uid,
            "belong_device_id": device_id,
            "belong_app_account_id": 用户消息.my_douyinID,
            "belong_app_account_type": "抖音",
            "follow_type": 用户消息.type,
            "follow_customer_name": 用户消息.fiend_name,
            "follow_customer_id": 用户消息.fiend_douyinID,
            "follow_customer_comment": 用户消息.comment,
            "follow_img": 用户消息.img
        }
    }
    api_记录跟进用户(记录数据)
    return
}

DouYin.prototype.dy_私信页面_消息记录 = function () {
    日志打印_warning('开始执行-【dy_私信页面_消息记录】')
    const 聊天记录截图 = 区域截图base64(0, 0, ScreenWidth, ScreenHeight)
    let 用户信息 = {抖音ID: '无' ,fiend_name: '无'}
    while (true){
        if(isScriptExit()){break}
        const 还在预期页面 = findColor(douyin.私信页面表情标识)
        if(还在预期页面){
            用户信息 = douyin.dy_获取私信好友_抖音id()
            if(用户信息){break}
        }else {
            break
        }
    }
    if(!用户信息){
        loge('获取失败')
        用户信息 = {抖音ID: '无' ,fiend_name: '无'}
    }
    douyin.dy_返回_设定页面(douyin.私信页面表情标识)
    const 消息记录 = {type: '消息列表私信', comment: '', fiend_douyinID: 用户信息.抖音ID, fiend_name: 用户信息.用户昵称, my_douyinID: 抖音_获取当前账号的抖音ID(), img: 聊天记录截图}

    return 消息记录
}

DouYin.prototype.dy_陌生人消息_私信_消息记录 = function () {
    日志打印_warning('开始执行-【dy_陌生人消息_私信_消息记录】')

    let 重复查找次数 = 3
    while (true){
        if(isScriptExit()) {break}

        douyin.dy_返回_设定页面(douyin.消息列表_陌生人消息_页面标识)
        const 消息列表_未读标识_数字 = findColor(douyin.消息列表_未读标识_数字)
        if(消息列表_未读标识_数字){
            重复查找次数 = 3
            const 进入陌生人消息_私信页面 = 点击后检测(消息列表_未读标识_数字, douyin.消息列表_陌生人消息_页面标识, [douyin.私信页面_确认聊天_页面标识, douyin.私信页面表情标识])
            switch (进入陌生人消息_私信页面) {
                case -1:
                    continue
                case -100:
                    continue
                case 0:
                    if(!douyin.dy_私信页面确认聊天){ continue; }
                    break
                case 1:
                    break
            }
            douyin.dy_私信用户时点关注(1);
            const 消息记录 = douyin.dy_私信页面_消息记录()
            if(!消息记录){continue}
            let 记录数据 = null
            if (脚本运行配置.ai_config.state){
                // 接入ai自动回复
                const 聊天记录 = douyin.dy_节点_获取聊天记录()
                const replay = 请求AI回复(抖音_获取当前账号的抖音ID(), 消息记录.fiend_douyinID, 消息记录.fiend_name, 聊天记录)
                if (replay){
                    douyin.dy_发送私信(replay, 1)
                    记录数据 = {
                        "belong_uid": uid,
                        "belong_device_id": device_id,
                        "belong_app_account_id": 抖音_获取当前账号的抖音ID(),
                        "belong_app_account_type": "抖音",
                        "follow_type": 'AI 自动回复',
                        "follow_customer_name": 消息记录.fiend_name,
                        "follow_customer_id": 消息记录.fiend_douyinID,
                        "follow_customer_comment": '',
                        "follow_img": 区域截图base64()
                    }
                }
            }
            logw(`${消息记录.type} -- ${消息记录.fiend_douyinID} -- ${消息记录.fiend_name} -- ${消息记录.my_douyinID} -- ${消息记录.comment}`)
            if(!记录数据){
                记录数据 = {
                    "belong_uid": uid,
                    "belong_device_id": device_id,
                    "belong_app_account_id": 消息记录.my_douyinID,
                    "belong_app_account_type": "抖音",
                    "follow_type": '陌生人消息',
                    "follow_customer_name": 消息记录.fiend_name,
                    "follow_customer_id": 消息记录.fiend_douyinID,
                    "follow_customer_comment": 消息记录.comment,
                    "follow_img": 区域截图base64()
                }
            }
            api_记录跟进用户(记录数据)
        }else {
            重复查找次数--
        }
        if(重复查找次数 <= 0){
            break
        }
    }
    return
}

DouYin.prototype.dy_私信页面确认聊天 = function () {
    日志打印_warning('开始执行-【dy_私信页面确认聊天】')

    setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"1","boundsFilter":"2","excludedAttributes":""})
    let 确认聊天_节点 = bounds(30,750,ScreenWidth,ScreenHeight).labelMatch("确认.*").getOneNodeInfo(10000)
    let tryCount = 3;
    while(!确认聊天_节点 && tryCount>0){
        if(isScriptExit()) {break}
        iSleep(100)
        const 还在预期页面 = ocr文本数组匹配(douyin.私信页面_确认聊天_页面标识)
        if(还在预期页面){
            确认聊天_节点 = bounds(30,750,ScreenWidth,ScreenHeight).labelMatch("确认.*").getOneNodeInfo(10000)
        }
        tryCount--;
    }
    if(!确认聊天_节点){ return false }

    const 确认聊天_按钮 = {name: '确认聊天_节点按钮', x: 确认聊天_节点.bounds.left/2+确认聊天_节点.bounds.right/2, y: 确认聊天_节点.bounds.top/2+确认聊天_节点.bounds.bottom/2}
    const 确认聊天 = 点击后检测(确认聊天_按钮, douyin.私信页面_确认聊天_页面标识, [douyin.私信页面表情标识])
    switch (确认聊天) {
        case -1:
            return false
        case -100:
            return false
        case 0:
            return true
    }
}

DouYin.prototype.dy_新关注我的_消息推送并记录 = function () {
    日志打印_warning('开始执行-【dy_新关注我的_消息推送并记录】')

    let 重复查找次数 = 3
    while (true){
        if(isScriptExit()) {break}

        douyin.dy_返回_设定页面(douyin.消息列表_新关注我的_页面标识)
        const 消息列表_新关注我的_未读_左侧圆点 = findColor(douyin.消息列表_新关注我的_未读_左侧圆点)
        if(消息列表_新关注我的_未读_左侧圆点){
            重复查找次数 = 3
            消息列表_新关注我的_未读_左侧圆点.x = random(460, 600)
            const 进入新关注我的_聊天页面 = 点击后检测(消息列表_新关注我的_未读_左侧圆点, douyin.消息列表_新关注我的_页面标识, [douyin.用户作品主页])
            switch (进入新关注我的_聊天页面) {
                case -1:
                    continue;
                case -100:
                    continue;
                case 0:
                    break

            }
            douyin.dy_用户主页_点关注()
            const 用户信息 = douyin.dy_节点获取抖音ID()
            if(!用户信息){ continue }
            const 记录数据 = {
                "belong_uid": uid,
                "belong_device_id": device_id,
                "belong_app_account_id": 抖音_获取当前账号的抖音ID(),
                "belong_app_account_type": "抖音",
                "follow_type": '关注我的用户',
                "follow_customer_name": 用户信息.用户昵称,
                "follow_customer_id": 用户信息.抖音ID,
                "follow_img": 区域截图base64()
            }
            api_记录跟进用户(记录数据)
        }else {
            重复查找次数--
        }
        if(重复查找次数 <= 0){
            return
        }
    }
}

DouYin.prototype.dy_互动消息_消息推送并记录 = function () {
    日志打印_warning('开始执行-【dy_互动消息_消息推送并记录】')

    function 回复内容格式化(str, char) {
        const lastIndex = str.lastIndexOf(char);
        if (lastIndex !== -1) {
            return str.substring(0, lastIndex);
        }
        return str; // 如果没有找到char，返回原字符串
    }


    function 获取评论内容(top, bottom) {
        setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"2","boundsFilter":"2","excludedAttributes":""})
        const 消息记录 = {type: '点赞评论', fiend_douyinID: '', fiend_name: '', comment: ''}
        const StaticTexts = type("StaticText").bounds(0,top,ScreenWidth,bottom).getNodeInfo(10000)
        if (StaticTexts && StaticTexts.length > 0){
            const 互动用户名称 = StaticTexts.reduce((min, current) => {
                if (current.label && current.label !=='' && (!min || current.bounds.left < current.bounds.left)) {
                    return current;
                }
                return min;
            }, null); //
            消息记录.fiend_name = 互动用户名称.label
        }

        const Others = type("Other").bounds(0,top,ScreenWidth,bottom).getNodeInfo(10000)
        if(Others && Others.length > 0){
            const 筛选最深层级Other = Others.filter(item => {
                return item.childCount === 0
            });
            const 回复内容Other = 筛选最深层级Other.reduce((max, current) => {
                if (current.label && current.label !=='' && (!max || current.bounds.bottom > max.bounds.bottom)) {
                    return current;
                }
                return max;
            }, null); //
            if(!回复内容Other){ return }
            loge(回复内容Other.label)
            if(回复内容Other.label.includes('推荐了你的视频') || 回复内容Other.label.includes('收藏了你的视频 ') || 回复内容Other.label.includes('赞了你的评论 ')
                                          || 回复内容Other.label.includes('赞了你的视频') || 回复内容Other.label.includes('提到了你') || 回复内容Other.label.includes('赞了你的图文')){
                消息记录.type = 回复内容格式化(回复内容Other.label, '  ')
            }
            else if(回复内容Other.label.includes('访问过你的主页')){
                消息记录.type = '主页访问'
            }
            else if(回复内容Other.label.includes('期待你的更新')){
                消息记录.type = '期待你的更新'
            }
            else {
                消息记录.type = '回复评论'
                消息记录.comment =  回复内容格式化(回复内容Other.label, '  ')
            }
            const 头像Other = 筛选最深层级Other.reduce((min, current) => {
                const width = current.bounds.right - current.bounds.left
                const height = current.bounds.right - current.bounds.left
                if (width === height && (!min || min.bounds.left > current.bounds.left)) {
                    return current;
                }
                return min;
            }, null); //
            if(!头像Other){ return }
            const 头像按钮 = {name: '头像按钮', x: random(60, 120), y: 头像Other.bounds.top/2+头像Other.bounds.bottom/2}
            const 进入用户作品主页 = 点击后检测(头像按钮, douyin.消息列表_互动消息_页面标识, [douyin.用户作品主页])
            if (进入用户作品主页 !== 0){ return }
            const 用户信息 = douyin.dy_节点获取抖音ID()
            if(!用户信息) { return }
            消息记录.fiend_douyinID = 用户信息.抖音ID
            消息记录.fiend_name = 用户信息.用户昵称
        }
        return 消息记录
    }

    const 记录数据 = {
        "belong_uid": uid,
        "belong_device_id": device_id,
        "belong_app_account_id": 抖音_获取当前账号的抖音ID(),
        "belong_app_account_type": "抖音",
        "follow_type": '互动消息展示',
        "follow_img": 区域截图base64()
    }
    api_记录跟进用户(记录数据)

    setFetchNodeParam({"labelFilter":"2","maxDepth":"20","visibleFilter":"1","boundsFilter":"2","excludedAttributes":""})
    while (true){
        if(isScriptExit()) {break}
        const cells = type("Cell").getNodeInfo(10000)
        if(cells && cells.length > 0){
            for(let i in cells){
                if(isScriptExit()){break}
                const cell = cells[i]
                if(cell.bounds.top < 120 || cell.bounds.bottom > ScreenHeight){ continue }
                const 消息列表_新关注我的_未读_左侧圆点 = JSON.parse(JSON.stringify(douyin.消息列表_新关注我的_未读_左侧圆点))
                消息列表_新关注我的_未读_左侧圆点.y = cell.bounds.top
                消息列表_新关注我的_未读_左侧圆点.ey = cell.bounds.bottom
                const 新的互动消息 = findColor(消息列表_新关注我的_未读_左侧圆点)
                if(新的互动消息){
                    const 消息记录 = 获取评论内容(cell.bounds.top, cell.bounds.bottom)
                    douyin.dy_返回_设定页面(douyin.消息列表_互动消息_页面标识)
                    日志打印_warning(`互动消息： ${JSON.stringify(消息记录)}`)
                    if(消息记录){
                        logw(JSON.stringify(消息记录))
                        douyin.dy_返回_设定页面(douyin.消息列表_互动消息_页面标识)
                        const 记录数据 = {
                            "belong_uid": uid,
                            "belong_device_id": device_id,
                            "belong_app_account_id":  抖音_获取当前账号的抖音ID(),
                            "belong_app_account_type": "抖音",
                            "follow_type": 消息记录.type,
                            "follow_customer_name": 消息记录.fiend_name,
                            "follow_customer_id": 消息记录.fiend_douyinID,
                            "follow_customer_comment": 消息记录.comment,
                            "follow_img": 区域截图base64(0, cell.bounds.top, ScreenWidth, cell.bounds.bottom)
                        }
                        api_记录跟进用户(记录数据)
                    }
                }else {
                    douyin.dy_返回_设定页面(douyin.消息列表_互动消息_页面标识)
                }
            }

            const startY =  cells[cells.length-1].bounds.top
            const endY = cells[0].bounds.bottom/2 + cells[0].bounds.top/2
            滑动(random(6,30), startY, random(6,30), Math.max(endY,400), 1200)
            douyin.dy_返回_设定页面(douyin.消息列表_互动消息_页面标识)
            const 还有新的互动消息 = findColor(douyin.消息列表_新关注我的_未读_左侧圆点)
            if(!还有新的互动消息){ break }
            const 记录数据 = {
                "belong_uid": uid,
                "belong_device_id": device_id,
                "belong_app_account_id": 抖音_获取当前账号的抖音ID(),
                "belong_app_account_type": "抖音",
                "follow_type": '互动消息展示',
                "follow_img": 区域截图base64()
            }
            api_记录跟进用户(记录数据)
        }
    }
    return
}

DouYin.prototype.dy_页面右滑 = function () {
    日志打印_warning('开始执行-【dy_页面右滑】')
    滑动(random(4, 15), random(460,600), ScreenWidth, random(460,600), 200);
}

DouYin.prototype.dy_返回_设定页面 = function (设定页面=null) {
    function 返回结果判定() {
        if(设定页面){
            if (设定页面.hasOwnProperty('textArray')){
                if(ocr文本数组匹配(设定页面)) {
                    日志打印_information(`成功 返回_设定页面: ${设定页面.name}`)
                    return true
                }
            }else {
                if(findColor(设定页面)) {
                    日志打印_information(`成功 返回_设定页面: ${设定页面.name}`)
                    return true
                }
            }
        }

        if(ocr文本数组匹配(douyin.首页_底部导航) && !findColor(douyin.私信页面表情标识)){
            return true
        }
        if(ocr文本数组匹配(douyin.账号左侧弹窗)){
            return true
        }
        return false
    }
    while (true){
        if(isScriptExit()) {break}
        日志打印_information('正在执行- 【返回_互动消息页面】')

        if(返回结果判定()){ return  }
        else {
            const 滑动前 = 区域截图base64(0, 40, ScreenWidth, 130)
            douyin.dy_页面右滑()
            iSleep(300)
            if(返回结果判定()){ return  }
            const 滑动后 = 区域截图base64(0, 40, ScreenWidth, 130)
            if(滑动前 === 滑动后){
                if(返回结果判定()){ return  }
                点击(douyin.用户主页_返回按钮)
            }
            iSleep(300)
            if(返回结果判定()){ return  }
        }


    }
}