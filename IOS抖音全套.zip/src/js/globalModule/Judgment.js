
//*********************************************【抖音-抖音-抖音-抖音-抖音-抖音-抖音 判断】************************************************************************************************
function formatAndCheckIfToday(dateString) {
    // 将字符串转换为 Date 对象
    const date = new Date(dateString);
    // 获取当前日期
    const today = new Date();
    // 格式化为 yyyy-mm-dd
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0'); // 月份从0开始，需加1
    const day = String(date.getDate()).padStart(2, '0');
    const formattedDate = `${year}-${month}-${day}`;
    // 判断是否是今天
    const isToday = date.getFullYear() === today.getFullYear() &&
        date.getMonth() === today.getMonth() &&
        date.getDate() === today.getDate();

    // 返回格式化日期和是否是今天
    // return { formattedDate, isToday };
    return isToday
}

function 抖音_查询今日私信是否饱和() {
    抖音_更新账号今日私信()

    let 当前可用账号 = 0
    设备账号信息.dy.forEach(item =>{
        if(isScriptExit()) {return}
        if(item.account_state === '正常'){
            当前可用账号++
        }
    })
    for(let i in 设备账号信息.dy){
        if(isScriptExit()) {break}
        const 账号 = 设备账号信息.dy[i];
        if(账号.send_count >= 脚本运行配置.dy.keyword_search.send_msg.max_count || 账号.account_state !== '正常' ){
            当前可用账号--;
        }
    }
    logw(`抖音_查询今日私信是否饱和: ${当前可用账号 > 0}`)
    if(当前可用账号 > 0){
        return false
    }else {
        return true
    }
}

function 抖音_查询今日是否有私信数据() {
    return api_查看是否还有私信数据('抖音')
}

function 抖音_更新当前账号跟进列表() {
    const 跟进任务 = api_获取本设备账号跟进任务(设备账号信息.dy)
    if(跟进任务 && 跟进任务.length > 0){
        douyin.当前账号_评论跟进列表.length = 0
        const 当前账号 = 抖音_获取当前账号的抖音ID()
        douyin.需要切换账号跟进 = false
        for(let i in 跟进任务){
            if(isScriptExit()) {break}
            const 跟进内容 = 跟进任务[i]
            if(跟进内容.account_id === 当前账号){
                if(跟进内容.task_type === '回复评论'){
                    douyin.当前账号_评论跟进列表.push(跟进内容)
                }else {
                    douyin.当前账号_私信跟进列表.push(跟进内容)
                }
            }
            else {
                douyin.需要切换账号跟进 = true
            }
        }
        if(douyin.私信跟进失败列表.length > 0){
            douyin.需要切换账号跟进 = true
            for(let i in douyin.私信跟进失败列表){
                if(isScriptExit()) {break}
                const 跟进失败内容 = douyin.私信跟进失败列表[i]
                if (跟进失败内容.account_id !== 当前账号){
                    跟进失败内容.account_id = 当前账号
                    douyin.当前账号_私信跟进列表.push(跟进失败内容)
                    douyin.私信跟进失败列表.splice(i, 1);
                    i--;
                }
                // 由于删除了元素，数组长度会减少，所以需要调整索引
            }
        }
    }

    logw(`当前账号_私信跟进列表: ${JSON.stringify(douyin.当前账号_私信跟进列表)}`)
    logw(`当前账号_评论跟进列表: ${JSON.stringify(douyin.当前账号_评论跟进列表)}`)
}

function 抖音_更新账号今日私信() {
    const 当前账号 = 抖音_获取当前账号的抖音ID()
    const 今日私信统计数据 = api_更新账号今日私信信息(设备账号信息.dy)
    今日私信统计数据.forEach( account => {
        if (account.hasOwnProperty('run_date')){
            delete account.run_date;
        }
        if(account.account_id === 当前账号){
            account.choose = true
        }else {
            account.choose = false
        }
    })
    设备账号信息.dy.length = 0
    设备账号信息.dy = 今日私信统计数据
    日志打印_warning(`[抖音_更新账号今日私信]${JSON.stringify(设备账号信息.dy)}`)
}

function 抖音_当前账号私信已饱和() {
    let 饱和 = false
    loge(`[抖音_当前账号私信已饱和]:${JSON.stringify(设备账号信息.dy)}`)
    设备账号信息.dy.forEach(item=>{
        if(isScriptExit()){return}
        if(item.choose){
            if(item.send_count && item.send_count >= 脚本运行配置.dy.keyword_search.send_msg.max_count){
                饱和 = true
            }
            if(item.account_state !== '正常'){
                饱和 = true
            }
        }
    })
    logw(`抖音_当前账号私信已饱和:${饱和} ==  ${JSON.stringify(设备账号信息.dy)}`)
    return 饱和
}

function 抖音_可切换私信账号() {
    if (设备账号信息.dy.length < 2){
        日志打印_warning('【抖音切换账号】无账号可切换')
        return false
    }
    设备账号信息.dy.forEach(item =>{
        if (isScriptExit()) {return}
        if(!item.choose){
            if( item.account_state === '正常' && item.send_count < 脚本运行配置.dy.keyword_search.send_msg.max_count){
                return true
            }
            日志打印_warning('【抖音切换账号】无账号可切换')
            return false
        }
    })
    return true
}
function 抖音_获取当前账号私信用户_抖音ID() {
    const douyinID = 抖音_获取当前账号的抖音ID()
    return api_获取一条账号今日可私信数据('抖音',douyinID)
}

function 抖音_私信统计更新(私信未成功, 私信频繁){
    日志打印_warning(`[私信统计更新前]${JSON.stringify(设备账号信息.dy)}`)

    设备账号信息.dy.forEach(account =>{
        if(isScriptExit()){return}
        if(account.choose){
            account.send_count = account.send_count + 1;
            if(私信未成功){
                account.send_failed_count = account.send_failed_count + 1;
            }
            if(私信频繁){
                account.send_pinfan_count = account.send_pinfan_count + 1;
            }
        }
    })
    日志打印_warning(`[私信统计更新后]${JSON.stringify(设备账号信息.dy)}`)

    日志打印_warning(`[抖音_私信统计更新]${JSON.stringify(设备账号信息.dy)}`)
    抖音_更新账号今日私信()
}

function 抖音_获取当前账号的抖音ID() {
    let 抖音号 = ''
    设备账号信息.dy.forEach(account =>{
        if(isScriptExit()){return}
        if(account.choose){
            抖音号 = account.account_id
        }
    })
    return 抖音号
}


//私信时间
function 抖音_私信时间() {
    const [s_hours, s_minutes] = 脚本运行配置.dy.keyword_search.send_msg.start_time.split(':');
    const [e_hours, e_minutes] = 脚本运行配置.dy.keyword_search.send_msg.end_time.split(':');
    const start_time = new Date();
    start_time.setHours(s_hours, s_minutes, 0, 0);

    const end_time = new Date();
    end_time.setHours(e_hours, e_minutes, 0, 0);
    const now = new Date();
    let result = false
    if(start_time < end_time){
        if (start_time <= now && now < end_time){ result = true }
    }else {
        if (start_time <= now || now < end_time){ result = true }
    }
    if(result){
        日志打印_warning(` 当前是-[抖音_私信时间] ${start_time}-${end_time}`)
    }
    return result
}

//关键词检索时间
function 抖音_关键词检索时间() {
    const [s_hours, s_minutes] = 脚本运行配置.dy.keyword_search.start_time.split(':');
    const [e_hours, e_minutes] = 脚本运行配置.dy.keyword_search.end_time.split(':');
    const start_time = new Date();
    start_time.setHours(s_hours, s_minutes, 0, 0);

    const end_time = new Date();
    end_time.setHours(e_hours, e_minutes, 0, 0);
    const now = new Date();
    let result = false
    if(start_time < end_time){
        if (start_time <= now && now < end_time){ result = true }
    }else {
        if (start_time <= now || now < end_time){ result = true }
    }
    if(result){
        日志打印_warning(` 当前是-[抖音_关键词检索时间] ${start_time}-${end_time}`)
    }
    return result
}

function 抖音_昵称检索时间() {
    const [s_hours, s_minutes] = 脚本运行配置.dy.keyword_name.start_time.split(':');
    const [e_hours, e_minutes] = 脚本运行配置.dy.keyword_name.end_time.split(':');
    const start_time = new Date();
    start_time.setHours(s_hours, s_minutes, 0, 0);

    const end_time = new Date();
    end_time.setHours(e_hours, e_minutes, 0, 0);
    const now = new Date();
    let result = false
    if(start_time < end_time){
        if (start_time <= now && now < end_time){ result = true }
    }else {
        if (start_time <= now || now < end_time){ result = true }
    }
    if(result){
        日志打印_warning(` 当前是-[抖音_昵称检索时间] ${start_time}-${end_time}`)
    }
    return result
}

//*********************************************【快手-快手-快手-快手-快手 判断】************************************************************************************************
function 快手_查询今日是否有私信数据() {
    return api_查看是否还有私信数据('快手')
}
function 快手_查询今日私信是否饱和() {
    抖音_更新账号今日私信()
    let 当前可用账号 = 0
    设备账号信息.ks.forEach(item =>{
        if(isScriptExit()) {return}
        if(item.account_state === '正常'){
            当前可用账号++
        }
    })
    for(let i in 设备账号信息.ks){
        if(isScriptExit()) {break}
        const 账号 = 设备账号信息.ks[i];
        if(账号.send_count >= 脚本运行配置.ks.keyword_search.send_msg.max_count || 账号.account_state !== '正常' ){
            当前可用账号--;
        }
    }
    logw(`快手_查询今日私信是否饱和: ${JSON.stringify(设备账号信息.ks)}`)
    if(当前可用账号 > 0){
        return false
    }else {
        return true
    }
}

function 快手_获取当前账号的快手ID() {
    let 快手号 = ''
    设备账号信息.ks.forEach(account =>{
        if(isScriptExit()){return}
        if(account.choose){
            抖音号 = account.account_id
        }
    })
    return 快手号
}

function 快手_获取当前账号私信用户_抖音ID() {
    const kuaishouID = 快手_获取当前账号的快手ID()
    return  api_获取一条账号今日可私信数据('快手', kuaishouID)
}

function 快手_更新账号今日私信() {
    const 当前账号 = 快手_获取当前账号的快手ID()
    日志打印_warning(`[快手_更新账号今日私信]${JSON.stringify(设备账号信息.ks)}`)
    const 今日私信统计数据 = api_更新账号今日私信信息(设备账号信息.ks)
    今日私信统计数据.forEach( account => {
        if (account.hasOwnProperty('run_date')){
            delete account.run_date;
        }
        if(account.account_id === 当前账号){
            account.choose = true
        }else {
            account.choose = false
        }
    })
    设备账号信息.ks.length = 0
    设备账号信息.ks = 今日私信统计数据
}

function 快手_私信时间() {

    const [s_hours, s_minutes] = 脚本运行配置.ks.keyword_search.send_msg.start_time.split(':');
    const [e_hours, e_minutes] = 脚本运行配置.ks.keyword_search.send_msg.end_time.split(':');
    const start_time = new Date();
    start_time.setHours(s_hours, s_minutes, 0, 0);

    const end_time = new Date();
    end_time.setHours(e_hours, e_minutes, 0, 0);
    const now = new Date();
    let result = false
    if(start_time < end_time){
        if (start_time <= now && now < end_time){ result = true }
    }else {
        if (start_time <= now || now < end_time){ result = true }
    }
    if(result){
        日志打印_warning(` 当前是-[快手_私信时间]  ${start_time}-${end_time}`)
    }
    return result
}

function 快手_可切换私信账号() {
    if (设备账号信息.ks.length < 2){
        日志打印_warning('【快手切换账号】无账号可切换')
        return false
    }
    设备账号信息.ks.forEach(item =>{
        if (isScriptExit()) {return}
        if(!item.choose){
            if( item.account_state === '正常' && item.send_count < 脚本运行配置.ks.keyword_search.send_msg.max_count ){
                return true
            }
            日志打印_warning('【快手切换账号】无账号可切换')
            return false
        }
    })
    return true
}

function 快手_当前账号私信已饱和() {
    let 饱和 = false
    loge(`[快手_当前账号私信已饱和]:${JSON.stringify(设备账号信息.ks)}`)
    设备账号信息.ks.forEach(item=>{
        if(isScriptExit()){return}
        if(item.choose){
            if(item.send_count && item.send_count >=脚本运行配置.ks.keyword_search.send_msg.max_count){
                饱和 = true
            }
            if(item.account_state !== '正常'){
                饱和 = true
            }
        }
    })
    logw(`快手_当前账号私信已饱和:${饱和} ==  ${JSON.stringify(设备账号信息.ks)}`)
    return 饱和
}

function 快手_私信统计更新(私信未成功, 私信频繁){
    设备账号信息.ks.forEach(account =>{
        if(isScriptExit()){return}
        if(account.choose){
            account.send_count = account.send_count + 1;
            if(私信未成功){
                account.send_failed_count = account.send_failed_count + 1;
            }
            if(私信频繁){
                account.send_pinfan_count = account.send_pinfan_count + 1;
            }
        }
    })
    快手_更新账号今日私信()
}

function 快手_关键词检索时间() {
    const [s_hours, s_minutes] = 脚本运行配置.ks.keyword_search.start_time.split(':');
    const [e_hours, e_minutes] = 脚本运行配置.ks.keyword_search.end_time.split(':');
    const start_time = new Date();
    start_time.setHours(s_hours, s_minutes, 0, 0);

    const end_time = new Date();
    end_time.setHours(e_hours, e_minutes, 0, 0);
    const now = new Date();
    let result = false
    if(start_time < end_time){
        if (start_time <= now && now < end_time){ result = true }
    }else {
        if (start_time <= now || now < end_time){ result = true }
    }
    if(result){
        日志打印_warning(` 当前是-[快手_关键词检索时间]   ${start_time}-${end_time}`)
    }
    return result
}

function 快手_评论数量格式化(comment){
    comment = comment.replace('评论','')
    if (comment.includes('万')){
        comment = comment.replace('万', '0000').replace('.', '')
    }
    else if(comment.includes('抢首评') || comment.includes('暂无评论')){
        comment = '0'
    }
    const parsedValue = parseInt(comment);
    return parsedValue!== undefined && parsedValue!== null &&!isNaN(parsedValue)? parsedValue : 0;
}