
//   ======================================== 该模块为点击后检测的封装函数 ======================================== //


/**
 * @description  点击后ocr检测 【即点击后， 通过ocr检测跳转是否成功】
 * @param {点击位置} points
 * @param {点击前} currentOcr
 * @param {点击后} nextOcr
 * @param {重试} tryCount
 * @returns {number}  -1 - 未知页面， 0 - 点位无效，1 - 成功
 */
function 点击后ocr检测(points, currentOcr, nextOcr, tryCount=3){
    日志打印_debug(`【点击后ocr检测】currentOcr：${JSON.stringify(currentOcr)}`)
    日志打印_debug(`【点击后ocr检测】nextOcr：${JSON.stringify(nextOcr)}`)
    if(tryCount <= 0){
        日志打印_error(`【点击后ocr检测】点击的点位无效${JSON.stringify(points)}`)
        return 0
    }
    const sleepTime = 1000;  //默认点击后第一次等待 1s
    点击(points);
    iSleep(sleepTime);
    const 跳转成功 = ocr文本数组匹配(nextOcr);
    if(跳转成功){
        return 1
    }else {
        // 跳转不成功， 可能是页面加载中， 加长等待
        let 等待次数 = 3;
        while(等待次数>0){
            if(isScriptExit()) {break}
            iSleep(sleepTime);
            const 跳转成功 = ocr文本数组匹配(nextOcr);
            等待次数--;
            if(跳转成功) {
                return 1
            }
        }
        // 等待后跳转不成功， 先判断是否点击成功
        const 点击成功 = !ocr文本数组匹配(currentOcr);
        if(!点击成功){
            // 本次点击未生效  重新点击识别
            return 点击后ocr检测(points, currentOcr, nextOcr, tryCount-1)
        }else {
            return -1
        }
    }
}



/**
 * @description  点击后图色_ocr检测
 * @param {点击位置} points
 * @param {点击前} currentMark
 * @param {点击后} nextOcr
 * @param {重试} tryCount
 * @returns {number}  -1 - 未知页面， 0 - 点位无效，1 - 成功
 */
function 点击后图色_ocr检测(points, currentMark, nextOcr, tryCount=3, sleepTime=1000){
    日志打印_debug(`【点击后图色_ocr检测】currentMark：${currentMark.name}`)
    日志打印_debug(`【点击后图色_ocr检测】nextMark：${JSON.stringify(nextOcr)}`)
    点击(points);
    iSleep(sleepTime);

    const 跳转成功 = ocr文本数组匹配(nextOcr);
    if(跳转成功){
        return 1
    }else {
        // 跳转不成功， 可能是页面加载中，加长等待
        let 等待次数 = 3;
        while(等待次数>0){
            if(isScriptExit()) {break}
            iSleep(sleepTime);
            const 跳转成功 = ocr文本数组匹配(nextOcr);
            等待次数--;
            if(跳转成功) {
                return 1
            }
        }
        // 等待后跳转不成功， 先判断是否点击成功
        const 点击成功 = !findColor(currentMark);
        if(!点击成功){
            if(tryCount <= 0){
                日志打印_error(`【点击后图色_ocr检测】点击的点位无效${JSON.stringify(points)}`)
                return 0
            }
            // 本次点击未生效  重新点击识别
            return 点击后图色_ocr检测(points, currentMark, nextOcr, tryCount-1)
        }else {
            // 进入错误处理
            return -1
        }
    }
}


/**
 * @description  点击页面跳转检测 【即点击后， 通过图色标识 判断点击是否成功】
 * @param {点击位置} points
 * @param {点击前} currentOcr
 * @param {点击后} nextMark
 * @param {重试} tryCount
 * @returns {number}  -1 - 未知页面， 0 - 点位无效，1 - 成功
 */
function 点击后ocr_图色检测(points, currentOcr, nextMark, tryCount=3){
    日志打印_debug(`【点击后ocr_图色检测】currentOcr：${JSON.stringify(currentOcr)}`)
    日志打印_debug(`【点击后ocr_图色检测】nextMark：${nextMark.name}`)
    if(tryCount <= 0){
        日志打印_error(`【点击后ocr_图色检测】点击的点位无效${JSON.stringify(points)}`)
        return 0
    }
    const sleepTime = 1000;  //默认点击后第一次等待 1s
    点击(points);
    iSleep(sleepTime);

    const 跳转成功 = findColor(nextMark);
    if(跳转成功){
        return 1
    }else {
        // 跳转不成功， 可能是页面加载中，加长等待
        let 等待次数 = 3;
        while(等待次数>0){
            if(isScriptExit()) {break}
            iSleep(sleepTime);
            const 跳转成功 = findColor(nextMark);
            等待次数--;
            if(跳转成功) {
                return 1
            }
        }
        // 等待后跳转不成功， 先判断是否点击成功
        const 点击成功 = !ocr文本数组匹配(currentOcr);
        if(!点击成功){
            // 本次点击未生效  重新点击识别
            return 点击后ocr_图色检测(points, currentOcr, nextMark, tryCount-1)
        }else {
            return -1
        }
    }
}



/**
 * @description  点击屏幕检测 【即点击后， 屏幕某个区域在等待时间后发生变化， 慎用】
 * @param {被点击的元素} points
 * @param {点击后等待时间} sleepTime;
 * @param x {x起始坐标}
 * @param y {y起始坐标}
 * @param ex {终点X坐标}
 * @param ey {终点Y坐标}
 * @returns {boolean}
 */
function 点击屏幕检测(points, sleepTime, x, y, ex, ey){
    日志打印_debug('执行【点击屏幕检测】')
    sleepTime = sleepTime || 1000;
    let 重试次数 = 5;
    while (重试次数 > 0){
        if(isScriptExit()){break}
        const firstBase64String = 区域截图base64(x, y, ex, ey);
        点击(points);
        iSleep(sleepTime);
        const secondBase64String = 区域截图base64(x, y, ex, ey);
        if(secondBase64String === firstBase64String){
            日志打印_warning('点击屏幕检测 重新执行！')
            重试次数--;
            continue;
        }
        return true;
    }
    return false
}

/**
 * @description  点击后检测
 * @param {被点击的元素} points
 * @param {点击后等待时间} sleepTime;
 * @param currentMark {页面标志，用于判断点击未成功后，是否能再次点击}
 * @param nextMarks {可能出现的标志合集}
 * @param 容错 {boolean}  true: 点击后未找到预设的标志，则视为脚本错误，执行 scriptError   false: 点击后未找到预设的标志，返回 -1，供后续其他处理
 * @returns {number}
 */
function 点击后检测(points, currentMark, nextMarks, sleepTime=2000){
    const nextMarks_names = [];
    for(const i in nextMarks){
        if(isScriptExit()){break}
        nextMarks_names.push(nextMarks[i].name)
    }
    // 日志打印_debug(`【点击后检测】执行-页面标志：${currentMark.name}  检测标志：${JSON.stringify(nextMarks_names)}`)

    for(let i=0; i<3; i++){
        if(isScriptExit()){break}
        点击(points);
        iSleep(sleepTime); //默认点击后等待 2s
        for (let j=0; j<3; j++){
            if(isScriptExit()){ break }

            for (const ii in nextMarks){
                if(isScriptExit()) {break}
                const mark = nextMarks[ii];
                if (mark.hasOwnProperty('textArray')){
                    const 跳转成功 = ocr文本数组匹配(mark);
                    if(跳转成功){
                        return parseInt(ii)  //返回 找到的标志的索引
                    }
                }
                else if (mark.hasOwnProperty('firstColor')){
                    const 跳转成功 = findColor(mark);
                    if(跳转成功) {
                        return parseInt(ii)
                    }
                }else {
                    日志打印_error(`【点击后检测】当前页面标志格式不正确- ${currentMark.name}  检测标志：${JSON.stringify(nextMarks_names)}`)
                    return -1
                }
            }
        }
        日志打印_debug('【点击后检测】未找到跳转后的标志- 重试')
        let 可以再次点击 = false;
        if (currentMark.hasOwnProperty('textArray')){
            可以再次点击 = ocr文本数组匹配(currentMark);

        }
        else if (currentMark.hasOwnProperty('firstColor')){
            可以再次点击 = !!findColor(currentMark);
        }else {
            日志打印_error(`【点击后检测】当前页面标志格式不正确- ${currentMark.name}  检测标志：${JSON.stringify(nextMarks_names)}`)
            return -1
        }
        if(!可以再次点击){
            日志打印_error(`【点击后检测】 进入未知页面-${currentMark.name}   检测标志：${JSON.stringify(nextMarks_names)}`)
            return -1
        }
    }
    日志打印_error(`【点击后检测】 点击的点位可能无效-${currentMark.name}   检测标志：${JSON.stringify(nextMarks_names)}`)
    return -100
}

/**
 * @description  点击后消失检测
 * @param {被点击的元素} points
 * @param {点击后等待时间} sleepTime;
 * @param currentMark {页面标志，用于判断点击未成功后，是否能再次点击}
 * @param disappearMark {点击后要消失的标志}
 * @param 容错 {boolean}  true: 点击后未找到预设的标志，则视为脚本错误，执行 scriptError   false: 点击后未找到预设的标志，返回 -1，供后续其他处理
 * @returns {number}
 */
function 点击后消失检测(points, currentMark, disappearMark, sleepTime=1000) {
    日志打印_debug(`【点击后消失检测】执行-页面标志：${currentMark.name}  消失的标志：${JSON.stringify(disappearMark.name)}`)

    for(let i=0; i<3; i++){
        if(isScriptExit()){break}
        点击(points);
        iSleep(sleepTime); //默认点击后等待 1s

        if (disappearMark.hasOwnProperty('textArray')){
            const 标志消失 = !ocr文本数组匹配(disappearMark);
            if(标志消失){
                return 0
            }

        }
        else if (disappearMark.hasOwnProperty('firstColor')){
            const 标志消失 = !findColor(disappearMark);
            if(标志消失){
                return 0
            }
        }else {
            日志打印_error(`【点击后消失检测】当前页面标志格式不正确- ${currentMark.name} 消失的标志：${JSON.stringify(disappearMark.name)}`)
            return -1
        }

        if (currentMark.hasOwnProperty('textArray')){
            const 可以再次点击 = ocr文本数组匹配(currentMark);
            if(可以再次点击){
                continue;
            }
        }
        else if (currentMark.hasOwnProperty('firstColor')){
            const 可以再次点击 = findColor(currentMark);
            if(可以再次点击){
                continue;
            }
        }else {
            日志打印_error(`【点击后消失检测】当前页面标志格式不正确- ${currentMark.name} 消失的标志：${JSON.stringify(disappearMark.name)}`)
            return -1
        }
    }
    日志打印_error(`【点击后消失检测】 点击的点位可能无效-${currentMark.name}   消失的标志：${JSON.stringify(disappearMark.name)}`)
    return -100

}
/**
 * @description  滑动检测
 * @param {滑动后等待时间} sleepTime;
 * @param currentMark {页面标志，用于判断滑动未成功后，是否能再次滑动}
 * @param nextMarks {可能出现的标志合集}
 * @param x {x起始坐标}
 * @param y {y起始坐标}
 * @param ex {终点X坐标}
 * @param ey {终点Y坐标}
 * @returns {number}
 */
function 滑动检测(currentMark, nextMarks,
              x, y, ex, ey, sleepTime=1000) {

    const nextMarks_names = [];
    for(const i in nextMarks){
        if(isScriptExit()){break}
        nextMarks_names.push(nextMarks[i].name)
    }
    日志打印_debug(`【滑动检测】执行-页面标志：${currentMark.name}  检测标志：${JSON.stringify(nextMarks_names)}`)

    while (true){
        if(isScriptExit()) {break}

        滑动(x, y, ex, ey, random(200,300));
        iSleep(sleepTime); //默认点击后第一次等待 1s
        let 滑动后_还在当前页面 = false;
        if (currentMark.hasOwnProperty('textArray')){
            滑动后_还在当前页面 = ocr文本数组匹配(currentMark);

        }
        else if (currentMark.hasOwnProperty('firstColor')){
            滑动后_还在当前页面 = !!findColor(currentMark);
        }else {
            日志打印_error(`【滑动检测】当前页面标志格式不正确- ${currentMark.name}\n   检测标志：${JSON.stringify(nextMarks_names)}`)
            return -1
        }
        if(滑动后_还在当前页面){
            日志打印_debug('滑动检测  -滑动重试-')
            continue;
        }
        let 等待重找次数 = 3;
        while(等待重找次数>0){
            if(isScriptExit()) {break}
            for (const i in nextMarks){
                if(isScriptExit()) {break}
                const mark = nextMarks[i];
                if (mark.hasOwnProperty('textArray')){
                    const 滑动成功 = ocr文本数组匹配(mark);
                    if(滑动成功){
                        return parseInt(i)  //返回 找到的标志的索引
                    }
                }
                else if (mark.hasOwnProperty('firstColor')){
                    const 滑动成功 = findColor(mark);
                    if(滑动成功) {
                        return parseInt(i)
                    }
                }else {
                    日志打印_error(`【滑动检测】当前页面标志格式不正确- ${currentMark.name}\n   检测标志：${JSON.stringify(nextMarks_names)}`)
                    return -1
                }
            }
            等待重找次数--;
        }
        日志打印_error(`【滑动检测】 进入未知页面-\n${currentMark.name}\n   检测标志：${JSON.stringify(nextMarks_names)}`)
        return -1
    }
}

/**
 * @description  滑动误触检测
 * @param {滑动后等待时间} sleepTime;
 * @param {滑动持续时间} duration;
 * @param findMarks {可能出现的误触标志合集}
 * @param x {x起始坐标}
 * @param y {y起始坐标}
 * @param ex {终点X坐标}
 * @param ey {终点Y坐标}
 * @param slideCount {滑动次数}
 * @returns {number}
 */
function 滑动误触检测(findMarks,x, y, ex, ey, sleepTime=1000, duration=500, slideCount=1) {
    日志打印_debug(`执行【滑动误触检测】`)
    slideCount = Math.max(1, slideCount)
    for(let i=0; i<slideCount; i++){
        if(isScriptExit()){ break }
        滑动(x, y, ex, ey, duration);
    }
    iSleep(sleepTime); //默认点击后第一次等待 1s

    for (const i in findMarks){
        if(isScriptExit()) {break}
        const mark = findMarks[i];
        if (mark.hasOwnProperty('textArray')){
            const 滑动成功 = ocr文本数组匹配(mark);
            if(滑动成功){
                return parseInt(i)  //返回 找到的标志的索引
            }
        }
        else if (mark.hasOwnProperty('firstColor')){
            const 滑动成功 = findColor(mark);
            if(滑动成功) {
                return parseInt(i)
            }
        }else {
            日志打印_error(`【滑动误触检测】滑动后页面标志格式不正确-${JSON.stringify(points)}\n${JSON.stringify(findMarks)}`);
            return -1
        }
    }
    return 100
}



