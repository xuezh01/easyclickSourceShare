

function 开启飞行模式() {
    当前执行模块 = '开启飞行模式'
    日志打印_debug('准备重启软件')
    laoleng.EC.init(1);
    laoleng.EC.initOcr();
    laoleng.EC.initNode();

    setFetchNodeParam({"labelFilter":"1","maxDepth":"20","visibleFilter":"1","boundsFilter":"1","excludedAttributes":""})
    takeMeToFront();
    iSleep(100);
    滑动(ScreenWidth/2, ScreenHeight-5, ScreenWidth/2, 100, 300);
    iSleep(100);
    let node_no_selected = type("Switch").label('飞行模式').getOneNodeInfo(10000)
    while (!node_no_selected){
        if(isScriptExit()){break}
        iSleep(100)
        日志打印_information('滑动重试！')
        takeMeToFront();
        iSleep(100);
        滑动(ScreenWidth/2, ScreenHeight-5, ScreenWidth/2, 100, 300);
        iSleep(100);
        node_no_selected = type("Switch").label('飞行模式').getOneNodeInfo(10000)
    }

    const 飞行模式位置 = {name: '飞行模式位置', x: node_no_selected.bounds.left/2 + node_no_selected.bounds.right/2, y: node_no_selected.bounds.top/2 + node_no_selected.bounds.bottom/2}
    点击(飞行模式位置);
    iSleep(2000)
    let 飞行模式已启动 = findColor(ios.上拉窗_ios飞行模式已启动);
    logw(JSON.stringify(飞行模式已启动))
    while(!飞行模式已启动){
        if(isScriptExit()){break}
        点击(飞行模式位置);
        iSleep(500)
        飞行模式已启动 = findColor(ios.上拉窗_ios飞行模式已启动);
        logw(JSON.stringify(飞行模式已启动))
    }
    home();
    appKillByBundleId('com.ivreal.iphone.agi', '1');
}