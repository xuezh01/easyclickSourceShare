
 //   ======================================== 该模块为ocr的所有封装函数 ======================================== //


/**
 * @description  获取范围内的ocr的识别结果
 * @param x {left}
 * @param y {top}
 * @param ex {right}
 * @param ey {bottom}
 * @param binaryzation {是否二值化}
 * @returns {Object || null}
 */
function ocr范围识别(x, y, ex, ey, binaryzation=false, img=null) {
    const params = [x, y, ex, ey];
    if (params.some(param => param === null || param === undefined)) {
        throw new Error(`【ocr范围识别】参数错误：${JSON.stringify({x, y, ex, ey})}` );
    }
    if(ey <= y || ex <= x) {
        throw new Error(`【ocr范围识别】参数错误：${JSON.stringify({x, y, ex, ey})}` );
    }

    let 识别结果 = null;
    let 重试次数 = 3;
    while(!识别结果 && 重试次数 > 0){
        if(isScriptExit()){ break };
        if(!img){
            img = 屏幕截图();
        }
        重试次数--;
        newImg = image.clip(img, x, y, ex, ey)
        if(binaryzation){
            var binaryzationImage = image.binaryzation(newImg, 200);
            识别结果 = ocr.ocrImage(binaryzationImage, 2000, {});
            image.recycle(binaryzationImage);
        }else {
            识别结果 = ocr.ocrImage(newImg, 2000, {});
        }
    }
    if(打印日志){
        日志打印_debug(`【ocr范围识别】:  ${JSON.stringify(识别结果)}`)
    }
    image.recycle(img);
    image.recycle(newImg);
    return 识别结果
}



function ocrMut范围识别(x, y, ex, ey, binaryzation=false, img=null) {

    let 识别结果 = null;
    let 重试次数 = 3;
    while(!识别结果 && 重试次数 > 0){
         if(isScriptExit()){ break };
         if(!img){
             img = 屏幕截图();
         }
         重试次数--;
         newImg = image.clip(img, x, y, ex, ey)
         if(binaryzation){
             var binaryzationImage = image.binaryzation(newImg, 200);
             识别结果 = myOcrMut.ocrImage(binaryzationImage, 20000, {});
             image.recycle(binaryzationImage);
         }else {
             识别结果 = ocr.ocrImage(newImg, 2000, {});
         }
     }
     if(打印日志){
         日志打印_debug(`【ocrMut范围识别】:  ${JSON.stringify(识别结果)}`)
     }
     image.recycle(img);
     image.recycle(newImg);
     myOcrMut.releaseAll()
     return 识别结果
 }

 /**
  * @description  范围内的ocr的识别结果匹配文本数组
  * @param ocrContent {JSON}
  * @returns {boolean}
  */
 function ocr文本数组匹配(ocrContent) {
     const {  name, textArray, x, y, ex, ey,binaryzation, matchCount } = ocrContent;
     日志打印_debug(`【ocr文本数组匹配】： ${name}`)
     let filterText = null
     if(ocrContent.hasOwnProperty('filterText')){
         filterText = ocrContent.filterText
     }
     for( let ii=0; ii<2; ii++){
         if(isScriptExit()){break}
         const 识别结果 = ocr范围识别(x, y, ex, ey, binaryzation);
         let 匹配成功数量 = 0;
         const findTextArray = JSON.parse(JSON.stringify(textArray))
         logw(`寻找： ${findTextArray}`)
         if(识别结果){
             if(filterText){
                 for(let i in 识别结果){
                     if(isScriptExit()){break}
                     const 单行文本 = 识别结果[i];
                     for (let j = 0; j < filterText.length; j++) {
                         if(isScriptExit()){break}
                         const index = 单行文本.label.indexOf(filterText[j])
                         if (index !== -1) {
                             return false
                         }
                     }
                 }

             }

             for(let i in 识别结果){
                 if(isScriptExit()){break}
                 const 单行文本 = 识别结果[i];
                 for (let j = 0; j < findTextArray.length; j++) {
                     if(isScriptExit()){break}
                     const index = 单行文本.label.indexOf(findTextArray[j])
                     if (index !== -1) {
                         findTextArray.splice(j, 1)
                         j--;
                         匹配成功数量++;
                         if(匹配成功数量 >= matchCount){
                             logw(`寻找成功： ${findTextArray}`)
                             return true
                         }

                     }
                 }
             }
         }
     }
     loge(`寻找失败： ${textArray}`)
     return false
 }


 /**
  * @description  ocr文本不完全匹配
  * @param {文本内容} text
  * @param x {x起始坐标}
  * @param y {y起始坐标}
  * @param ex {终点X坐标}
  * @param ey {终点Y坐标}
  * @returns {Object || null}
  */
 function ocr文本不完全匹配(text, x, y, ex, ey) {
     const 范围识别内容 = ocr范围识别(x, y, ex, ey);
     let 不完全匹配项 = null;
     for(let i in 范围识别内容){
         if(isScriptExit()) {break}
         const itemNode = 范围识别内容[i];
         if (itemNode.label.includes(text)) {
             不完全匹配项 = {name: itemNode.label, x: itemNode.x + x + itemNode.width/2, y: itemNode.y + y + itemNode.height/2}
             return 不完全匹配项
         }
     }
     return null
 }

