/*
    设备基础信息
*/
setPipCtrlScript(false)
const device_local_version = 211;
const { ScreenWidth, ScreenHeight } = 获取设备屏幕宽高();
var device_id = device.getDeviceId();
var device_name = device.getDeviceName();
var device_version = device.getOSVersion();
var device_expiration_time = getDeviceExpTime();
var 脚本当前运行阶段 = '正在启动中';
var uid = null;
let ws = null;
var 设备账号信息 = {
    dy: [],
    ks: [],
};
var device_battery = device.getBattery();
var device_isCharging = device.isCharging();
var device_server_ok = isServiceOk();
var my_msg_end = ['  .', ' . ', '  ~', '~  ', ' ~ ', "`  ", "  `", " ` "]

var 设备状态同步时间 = null
function 设备信息同步后台() {
    const now = new Date()
    if(!设备状态同步时间 || (now - 设备状态同步时间) > 30 * 1000){
        const 设备基础信息 = {
            device_id: device_id,  // 主键
            device_scriptRunning: 脚本当前运行阶段, // 脚本当前运行阶段
            device_battery: device.getBattery(),
            device_isCharging: device.isCharging(),
            device_version: device_version,
            device_local_version: device_local_version,
            device_server_ok: isServiceOk(),
            // use_account: 抖音_获取当前账号的抖音ID(),
            account_information: 设备账号信息
        };
        const msg = api_上传设备状态(设备基础信息)
        处理后台传递消息(msg)
        设备状态同步时间 = new Date()
    }
}

function 处理后台传递消息(msg) {
    if (msg){
        try {
            const command = JSON.parse(msg)
            if(command.task === 'updateVersion'){
                更新软件()
            }
            else if(command.task === 'updateSetup'){
                if(command.app_type.includes('抖音') && command.dy.task === '关键词检索任务'){
                    const old_keyword = 脚本运行配置.dy.keyword_search.keyword
                    const new_keyword = command.dy.keyword_search.keyword
                    if(new_keyword !== old_keyword){
                        douyin.关键词已无视频 = false
                    }
                }
                脚本运行配置 = command
                日志打印_warning(`[脚本运行配置]:更新成功！`)
            }
        }catch (e) {
            日志打印_error(`[处理后台传递消息]: ${e}`)
        }
    }

}

function 定时关闭() {
    const close_time = new Date();
    close_time.setHours(4, 10, 0, 0);
    const close_time2 = new Date();
    close_time2.setHours(4, 20, 0, 0);
    const now = new Date();
    if ( close_time <= now && now <= close_time2){
       loge('准备关闭')
       appKillByBundleId(appBundleId, '1')
       appKillByBundleId('com.ivreal.iphone.keyida.ai', '1');
    }
}


var 脚本运行配置 = {
    task: 'startScript',
    app_type: ['抖音', '快手'],
    dy: {
        task: '昵称检索任务',
        search_time_interval: 3,  // 搜索间隔  1 分钟
        search_pinfan_hours: 0.5,  // 搜索频繁距离下一次搜索间时长  0.5小时
        follow_min_time: 3,     // 跟进最少间隔  3 分钟
        cut_min_time: 3,     // 切号最少间隔  3 分钟
        keyword_search: {
            keyword: '外汇测试',  // 搜索关键词
            industry: '外汇交易',  // 所属行业
            start_time: '7:30',      // 搜索关键词-起始时间
            end_time: '21:30',      // 搜索关键词-结束时间
            enhance_grip: false,
            type: '视频',   // 视频或者图文
            min_interval_days: 20,
            video_filter: {     // 视频筛选
                video_sort_by: '综合排序',   // 排序依据 - ['综合排序', '最新发布', '最多点赞']
                video_release_time: '不限',   // 视频发布时间 - ['不限', '一天内', '一周内', '半年内']
                video_duration: '不限',       // 视频时长 - ['不限', '1分钟以下', '1-5分钟', '5分钟以上']
                video_search_scope: '不限',   // 搜索范围 - ['不限', '关注的人', '最近看过', '还未看过']
            },
            leave_traces: {
                state: true,            // 是否留痕
                message: '666，强'    // 留痕内容
            },
            send_msg: {                     // 私信发送
                start_time: '20:30',        // 私信发送-起始时间
                end_time: '21:30',          // 私信发送-结束时间
                follow_probability: 0.3,    // 私信用户时点关注的概率
                first_msg: '你好',           // 私信用户时的第一句话
                max_count: 30,              // 私信用户最大数量
            }
        },
        keyword_name: {
            keyword: 'ai获客',  // 搜索关键词
            industry: '人工智能',  // 所属行业
            start_time: '7:30',      // 搜索关键词-起始时间
            end_time: '23:30',      // 搜索关键词-结束时间
            customer_filter: {     // 视频筛选
                fansLimit: '不限',   // 排序依据 - ['不限', '1000以下', '1000-1w', '1w-10w', '10w-100w', '100w以上']
                customerType: '不限',   // 用户类型 - ['不限', '普通用户', '企业认证', '个人认证']

            },
            send_msg: {                     // 私信发送
                start_time: '20:30',        // 私信发送-起始时间
                end_time: '21:30',          // 私信发送-结束时间
                follow_probability: 0.3,    // 私信用户时点关注的概率
                first_msg: '你好',           // 私信用户时的第一句话
                max_count: 30,              // 私信用户最大数量
            }
        },

    },
    ks: {
        task: '关键词检索任务',
        search_time_interval: 3,  // 搜索间隔  3 分钟
        keyword_search: {
            keyword: '外汇测试',  // 搜索关键词
            industry: '外汇交易',  // 所属行业
            start_time: '7:30',      // 搜索关键词-起始时间
            end_time: '21:30',      // 搜索关键词-结束时间
            leave_traces: {
                state: true,            // 是否留痕
                message: '666，强'    // 留痕内容
            },
            send_msg: {                     // 私信发送
                start_time: '20:30',        // 私信发送-起始时间
                end_time: '21:30',          // 私信发送-结束时间
                follow_probability: 0.3,    // 私信用户时点关注的概率
                first_msg: '你好',           // 私信用户时的第一句话
                max_count: 30,              // 私信用户最大数量
            }
        },

    },
    ai_config: {    // 自动回复 配置
        state: true,
        api_key: 'sk-JR7GvNphi2cj3vfLyobpUYoRIdflA6qh7I6xQo2J6PPFtz1n',
        robot_name: '李老师',
        robot_gender: '男',
        robot_role: '外汇专家',
        product_name: '专业外汇咨询',
        phone_number: '13896888321', // 允许为空
        company_name: '外汇交易研究所',    // 允许为空
        company_addr: '重庆',     // 允许为空
        company_values: '',      // 允许为空
        goal_description: '引导客户留下电话号码/微信',
        wechat_number: '373136032',
        speaking_style: '干练',
        product_detail: '', // 允许为空

    }
}
function 更新到新配置(string_device_task) {
    if(string_device_task && string_device_task !== null && string_device_task !== undefined && string_device_task !== ''){
        try {
            const device_task = JSON.parse(string_device_task)
            if (!device_task.hasOwnProperty('app_type')){
                脚本运行配置 = null
            }else {
                脚本运行配置 = device_task
                // 日志打印_warning(`[脚本运行配置] ：${JSON.stringify(脚本运行配置)}`)
                return
            }
        }
        catch (e) {
            脚本运行配置 = null
        }
    }
    脚本运行配置 = null
    日志打印_warning(`[脚本运行配置] 为空`)
}

function 更新软件() {
    let updateResult = hotupdater.updateReq("iecup://76786b686b6270657c337c667370794b", device_local_version);
    日志打印_debug("【服务器是否有新版本】: " + updateResult);
    if (!updateResult) {
        日志打印_error("【请求失败错误信息】: " + hotupdater.getErrorMsg());
    } else {
        日志打印_debug("【更新请求数据】: " + hotupdater.getUpdateResp());
        //有更新得情况下进行下载新的版本
        let path = hotupdater.updateDownload();
        日志打印_debug("【下载路径为】: " + path);
        if (!path) {
            日志打印_error("【下载IEC文件错误信息】: " + hotupdater.getErrorMsg());
        } else {
            restartScript(path, true, 1)
        }
    }
}