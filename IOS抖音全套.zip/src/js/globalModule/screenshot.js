//   ======================================== 该模块为屏幕截图相关封装函数 ======================================== //



/**
 * @description  【带私信检测】屏幕截图
 * @return {null|AutoImage}
 */
function 屏幕截图(Mat=true){
    不间断打开代理();
    定时关闭()
    while(true){
        if(isScriptExit()){break }
        返回应用页面2()
        if(Mat){ image.useOpencvMat(1) }
        else { image.useOpencvMat(0) }
        const 截图 = image.captureFullScreenEx();
        if(!(截图 === null || 截图 === undefined || 截图.uuid === null || 截图.uuid === undefined || 截图.uuid === "" )){
            if(!私信检测(截图) || !代理页面判断()){
                return 截图
            }else {
                sleep(300)
            }
        }
        image.recycle(截图);
    }
}



/**
 * @description  获取屏幕区域截图的base64编码
 * @param x {left}
 * @param y {top}
 * @param ex {right}
 * @param ey {bottom}
 * @returns {string}
 */
function 区域截图base64(x=0, y=0, ex=ScreenWidth, ey=ScreenHeight) {
    const 截图 = 屏幕截图(false);
    const clipFirstImage = image.clip(截图, x, y, ex, ey);
    const firstBase64String = image.toBase64(clipFirstImage);
    image.recycle(clipFirstImage);
    image.recycle(截图);
    return firstBase64String
}


/**
 * @description  检测在一定时间内，屏幕是否发生变化
 * @param time {检测的间隔时间}
 * @param x {x起始坐标}
 * @param y {y起始坐标}
 * @param ex {终点X坐标}
 * @param ey {终点Y坐标}
 * @returns {boolean}
 */
function 屏幕区域变化检测(time, x, y, ex, ey){
    // logi('执行【screenChanges】')
    time = time || 1000;
    const firstBase64String = 区域截图base64(x, y, ex, ey);
    iSleep(time);
    const secondBase64String = 区域截图base64(x, y, ex, ey);
    return secondBase64String===firstBase64String

}

/**
 * @description  屏幕截图并保存
 * @param x {x起始坐标}
 * @param y {y起始坐标}
 * @param ex {终点X坐标}
 * @param ey {终点Y坐标}
 * @returns {boolean}
 */
function 截图保存(x, y, ex, ey, dir='douyin-img'){
    let 重试次数 = 3;
    const dirPath = file.getSandBoxFilePath(dir)
    let 文件夹创建 = file.mkdirs(dirPath);
    while(!文件夹创建 && 重试次数 > 0){
        if(isScriptExit()){ break}

        文件夹创建 = file.mkdirs(dirPath);
        重试次数--;
    }
    if(!文件夹创建){
        scriptError(`文件夹创建失败：${dirPath}`)
    }

    let 图片存储路径 = file.getSandBoxFilePath(`${dir}/${获取当前时间()}.png`);
    while (重试次数 > 0){
        if(isScriptExit()){ break };

        重试次数--;
        let aimage = 屏幕截图();

        let saveImage = null;
        if( x === null || y === null || ex === null || ey === null){
            saveImage = aimage;
        }
        else {
            saveImage = image.clip(aimage, x, y, ex, ey);
        }

        // 保存图片
        let 保存结果 = image.saveTo(saveImage, 图片存储路径);
        let 保存重试次数 = 3;
        while(!保存结果){
            if(isScriptExit()){ break };

            if (保存重试次数 <= 0) {
                日志打印_error('屏幕截图保存 失败！');
                return false;
            }
            保存结果 = image.saveTo(aimage, 图片存储路径);
            保存重试次数--;
        }
        image.recycle(aimage);
        image.recycle(saveImage);
        if (保存结果) {
            break
        }

    }

    return 图片存储路径
}