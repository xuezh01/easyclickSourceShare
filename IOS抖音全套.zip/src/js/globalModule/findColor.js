/**
 * @description  找色
 * @param {图色} mark
 * @param {图片对象} img
 * @param {重试次数} maxCount
 * @returns {{x: *, y: *} || null}
 */
function findColor(mark,img=null) {
    const { name, firstColor, multiColor, x, y, ex, ey, orz } = mark;
    if(multiColor.length < 4){
        scriptError(`${name} -- 节点 属性multiColor 需要最少4个点！`);
    }

    日志打印_debug('【findColor】 执行：' + name)
    const threshold = 0.95;
    for(let i=0; i<2; i++){
        if(isScriptExit()){break}
        if(!img){
            img = 屏幕截图();
        }
        const points = image.findMultiColor(img, firstColor, multiColor, threshold, x, y, ex, ey, 1, orz);
        image.recycle(img)
        if(points){
            return 获取图色的随机点(name, points, multiColor)
        }
        iSleep(100)
    }
    return null
}

function 获取图色的随机点(name, points, multiColor) {
    let min_x = multiColor[0];
    let max_x = multiColor[0];
    let min_y = multiColor[1];
    let max_y = multiColor[1];

    for (let i = 0; i < multiColor.length; i += 4) {
        if(isScriptExit()){ break };
        sleep(10);
        const x = multiColor[i];
        const y = multiColor[i + 1];
        if (x < min_x) {
            min_x = x;
        }
        if (x > max_x) {
            max_x = x;
        }
        if (y < min_y) {
            min_y = y;
        }
        if (y > max_y) {
            max_y = y;
        }
    }
    const random_x = Math.floor(Math.random() * (max_x - min_x + 1)) + min_x;
    const random_y = Math.floor(Math.random() * (max_y - min_y + 1)) + min_y;
    return {name: name,x: points[0].x + random_x , y: points[0].y + random_y ,
        max_y: points[0].y + max_y, max_x: points[0].x + max_x, min_y: points[0].y + min_y, min_x: points[0].x + min_x}

}

function findMultiColor(marks) {
    for(let i=0; i<2; i++){
        if(isScriptExit()){break}
        const img = 屏幕截图()
        for(let j in marks){
            if(isScriptExit()){break}
            const mark = marks[j]
            const { name, firstColor, multiColor, x, y, ex, ey, orz } = mark;
            // 日志打印_debug(`[findMultiColor]${name}`)
            const points = image.findMultiColor(img, firstColor, multiColor, 0.95, x, y, ex, ey, 1, orz);
            if(points){
                image.recycle(img)
                return {index: parseInt(j), point:获取图色的随机点(name, points, multiColor) }
            }
        }
        image.recycle(img)
    }
    return null
}


function 单点找色(mark){
    const { name, firstColor, x, y, ex, ey, orz } = mark;
    const img = 屏幕截图();
    let points = image.findColor(img, firstColor, 0.95, x, y, ex, ey, 1, orz);
    if(points && points.length !== 0){
        return {name: name, x: points[0].x, y:points[0].y}
    }
    return null
}

