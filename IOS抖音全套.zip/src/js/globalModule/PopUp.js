

//   ======================================== 该模块为处理 ios 所有可能的弹窗 低电量提醒 、 位置授权 、通讯录授权、剪切板读取等  ======================================== //


function 检测屏幕异常() {
    const 截图 = 屏幕截图();
    ocr处理弹窗(截图);
    image.recycle(截图)

}

var appBundleId = null;

let 主应用返回时间 = new Date();
function 返回应用页面2() {
    const 当前时间 = new Date()
    const 时间差 = 当前时间 - 主应用返回时间; // 计算时间差，单位是毫秒
    if (时间差 >= 30 * 60 * 1000) { // 10分钟等于10 * 60 * 1000毫秒
        takeMeToFront()
        主应用返回时间 = 当前时间
    }
    if(appBundleId){
        appLaunch(appBundleId, '0');
    }
}

function 返回应用页面() {
    if(appBundleId === 'com.ss.iphone.ugc.Aweme'){

        home()
        sleep(100);
        home();  //返回主页面
        sleep(100);
        let 抖音App = findColor(douyin.抖音App);
        let tyCount = 3;
        while(!抖音App && tyCount > 0){
            if(isScriptExit()) {break}
            home();  //返回主页面
            sleep(100);
            抖音App = findColor(douyin.抖音App);
            tyCount--;
        }
        if(!抖音App){
            日志打印_error('[返回应用页面]抖音App 寻找失败！')
            抖音App = {name: '抖音App', x: random(512,581), y:random(1205,1267)}
        }
        点击(抖音App)
        sleep(100)
        appLaunch(appBundleId, '0');

    }

    // else {
    //     takeMeToFront();
    // }
}
let 代理启动时间 = new Date();

function 打开代理() {
    home();
    sleep(200)
    image.useOpencvMat(1)
    const img = image.captureFullScreen();
    let 找到AIX应用 = image.findMultiColor(img, ios.客易达.firstColor, ios.客易达.multiColor, 0.95,
        ios.客易达.x, ios.客易达.y, ios.客易达.ex, ios.客易达.ey, 1, ios.客易达.orz);
    image.recycle(img);
    while(!找到AIX应用){
        if(isScriptExit()) {break}
        home();
        sleep(200)
        image.useOpencvMat(1)
        const img = image.captureFullScreen();
        找到AIX应用 = image.findMultiColor(img, ios.客易达.firstColor, ios.客易达.multiColor, 0.95,
            ios.客易达.x, ios.客易达.y, ios.客易达.ex, ios.客易达.ey, 1, ios.客易达.orz);
        image.recycle(img);
    }
    点击(ios.代理位置);
    iSleep(2000, false);
    代理启动时间 = new Date();
    返回应用页面2();
}

function 不间断打开代理() {
    const 当前时间 = new Date()
    const 时间差 = 当前时间 - 代理启动时间; // 计算时间差，单位是毫秒
    // ws消息处理()
    // 返回应用页面();
    if (时间差 >= 5 * 60 * 1000) { // 10分钟等于10 * 60 * 1000毫秒
        打开代理()
    }
}

var 开启私信回复 = true;
var 进入实时回复 = false;

function 私信检测(img) {
    if(appBundleId === 'com.ss.iphone.ugc.Aweme'){
        //抖音私信检测
        const 顶部_私信弹窗 = image.findMultiColor(img, douyin.私信弹窗回复标识.firstColor, douyin.私信弹窗回复标识.multiColor, 0.95,
            douyin.私信弹窗回复标识.x, douyin.私信弹窗回复标识.y, douyin.私信弹窗回复标识.ex, douyin.私信弹窗回复标识.ey, 1, douyin.私信弹窗回复标识.orz);

        if(顶部_私信弹窗){
            return true
            // else {
            //     const 私信弹窗_点击位置 = 获取图色的随机点(name, 顶部_私信弹窗, douyin.私信弹窗回复标识.multiColor);
            //     点击(私信弹窗_点击位置);
            //     return true
            // }
        }
        return false
        // else {
        //     const 已展开_私信弹窗_回复页面 = image.findMultiColor(img, douyin.私信弹出页面放大标识.firstColor, douyin.私信弹出页面放大标识.multiColor, 0.95,
        //         douyin.私信弹出页面放大标识.x, douyin.私信弹出页面放大标识.y, douyin.私信弹出页面放大标识.ex, douyin.私信弹出页面放大标识.ey, 1, douyin.私信弹出页面放大标识.orz);
        //
        //     if(已展开_私信弹窗_回复页面){
        //         if(!开启私信回复){
        //             return true
        //         }
        //
        //         进入实时回复 = true;
        //         实时私信回复()
        //         进入实时回复 = false;
        //         return true
        //     }
        //     return false
        // }

    }

}

function 代理页面判断(img) {
    let firstColor = ["#FFFFFF","#101010"];
    let points = image.findColor(img, firstColor, 1, 46, 318, 650, 1280, 1, 4);
    return !!points
}

function ocr处理弹窗(img) {
    const start_time = time()
    const ocr内容 = ocr.ocrImage(img, 2000, {});
    // ocr.releaseAll();
    /*==========系统弹窗==========*/
    if(电池电量不足(ocr内容)){
        日志打印_warning(`【ocr处理弹窗】耗时：${time()-start_time}`)
        return true
    }
    if(ios系统更新弹窗(ocr内容)){
        日志打印_warning(`【ocr处理弹窗】耗时：${time()-start_time}`)
        return true
    }
    if(ios系统未安装弹窗(ocr内容)){
        日志打印_warning(`【ocr处理弹窗】耗时：${time()-start_time}`)
        return true
    }
    if(未安装SIM卡弹窗(ocr内容)){
        日志打印_warning(`【ocr处理弹窗】耗时：${time()-start_time}`)
        return true
    }
    if(位置准确性弹窗(ocr内容)){
        日志打印_warning(`【ocr处理弹窗】耗时：${time()-start_time}`)
        return true
    }
    if(验证AppleID弹窗(ocr内容)){
        日志打印_warning(`【ocr处理弹窗】耗时：${time()-start_time}`)
        return true
    }
    /*===========================*/

    if (appBundleId === 'com.ss.iphone.ugc.Aweme'){
        // 日志打印_debug('******************【启动抖音弹窗检测】******************')
        return douyin.抖音弹窗检测(ocr内容,start_time)
    }else if (appBundleId === 'com.jiangjia.gif'){
        // 日志打印_debug('******************【启动快手弹窗检测】******************')
        return ks.快手弹窗检测(ocr内容,start_time)
    }else if (appBundleId === 'com.tencent.xin'){
        // 日志打印_debug('******************【启动微信弹窗检测】******************')
        return wechat.微信弹窗检测(ocr内容,start_time)
    }
}

function 弹窗匹配结果(ocr内容, 弹窗内容) {
    let 弹窗内容已匹配 = []
    let 匹配成功数量 = 0;
    if(ocr内容){
        for(let i in ocr内容){
            if(isScriptExit()){break}
            const 单行文本 = ocr内容[i];
            for (let j = 0; j < 弹窗内容.textArray.length; j++) {
                if(isScriptExit()){break}
                if (单行文本.label.indexOf(弹窗内容.textArray[j]) !== -1) {
                    if (!弹窗内容已匹配.includes(弹窗内容.textArray[j])){
                        弹窗内容已匹配.push(弹窗内容.textArray[j])
                        匹配成功数量++;
                        // logd("已匹配:{}",JSON.stringify(弹窗内容已匹配))
                        // logd("处理内容:{},处理弹窗:{}",弹窗内容.textArray[j],弹窗内容.name)
                    }
                    if(匹配成功数量 >= 弹窗内容.matchCount){
                        return true
                    }
                }
            }
        }
    }
    return false
}

验证AppleID = {
    name: '验证AppleID',
    textArray: ['验证', '中输入', 'Apple', 'ID', '的密码'],
    matchCount: 3
}
function 验证AppleID弹窗(ocr内容) {
    const 出现验证AppleID弹窗 = 弹窗匹配结果(ocr内容, 验证AppleID);
    if(出现验证AppleID弹窗){
        日志打印_warning('【处理弹窗】 ====验证AppleID=========')
        const 关闭验证AppleID弹窗 = {name: '关闭验证AppleID弹窗', x: random(204, 275), y:random(738, 780)};
        点击(关闭验证AppleID弹窗);
        return true
    }
    return false
}


ios系统更新 = {
    name: 'ios系统更新',
    textArray: ['软件更新', '现在安装', '稍后', '已经可以安装'],
    matchCount: 2
}
function ios系统更新弹窗(ocr内容) {
    const 出现ios系统更新弹窗 = 弹窗匹配结果(ocr内容, ios系统更新);
    if(出现ios系统更新弹窗){
        日志打印_warning('【处理弹窗】 ====ios系统更新弹窗=========')
        const 关闭ios系统更新弹窗 = {name: '关闭ios系统更新弹窗', x: random(460, 560), y:random(720, 770)};
        点击(关闭ios系统更新弹窗);
        return true
    }
    return false
}

ios系统未安装 = {
    name: 'ios系统未安装',
    textArray: ['未安装', '稍后重新尝试更新', '将稍后重新尝试更新'],
    matchCount: 2
}
function ios系统未安装弹窗(ocr内容) {
    const 出现ios系统未安装弹窗 = 弹窗匹配结果(ocr内容, ios系统未安装);
    if(出现ios系统未安装弹窗){
        日志打印_warning('【处理弹窗】 ====ios系统未安装弹窗=========')
        const 关闭ios系统未安装弹窗 = {name: '关闭ios系统更新弹窗', x: random(330, 430), y:random(724, 772)};
        点击(关闭ios系统未安装弹窗);
        return true
    }
    return false
}

低电量弹窗 = {
    name: '低电量弹窗',
    textArray: ['电池电量不足', '低电量模式', '电量'],
    matchCount: 2
}
function 电池电量不足(ocr内容) {
    let 低电量提醒 = 弹窗匹配结果(ocr内容, 低电量弹窗);
    if(低电量提醒){
        日志打印_warning('【处理弹窗】 ====电池电量不足=========')
        const 低电量关闭 = {name: '低电量关闭', x: random(190, 280), y:random(760, 770)};
        点击(低电量关闭);
        return true
    }
    return false
}

未安装SIM卡 = {
    name: '未安装SIM卡',
    textArray: ['未安装SIM卡', '无可用SIM卡'],
    matchCount: 1
}
function 未安装SIM卡弹窗(ocr内容) {
    let 未安装SIM卡_弹窗 = 弹窗匹配结果(ocr内容, 未安装SIM卡);
    if(未安装SIM卡_弹窗){
        日志打印_warning('【处理弹窗】 ====未安装SIM卡弹窗=========')
        const 未安装SIM卡关闭 = {name: '未安装SIM卡关闭', x: random(314, 434), y:random(696, 750)};
        点击(未安装SIM卡关闭);
        return true
    }
    return false
}

位置准确性 = {
    name: '位置准确性',
    textArray: ['打开蓝牙', '提高位置准确性', '设置', '位置准确性'],
    matchCount: 2
}
function 位置准确性弹窗(ocr内容) {
    let 位置准确性_弹窗 = 弹窗匹配结果(ocr内容, 位置准确性);
    if(位置准确性_弹窗){
        日志打印_warning('【处理弹窗】 ====位置准确性弹窗=========')
        const 位置准确性关闭 = {name: '位置准确性', x: random(460, 540), y:random(725, 765)};
        点击(位置准确性关闭);
        return true
    }
    return false
}

