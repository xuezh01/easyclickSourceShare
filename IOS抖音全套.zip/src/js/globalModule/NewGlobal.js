

function 获取设备屏幕宽高() {
    const w_h = device.getScreenWidthHeight()
    if(w_h){
        const w_h_ = w_h.split(',')
        const w = parseInt(w_h_[0])
        const h = parseInt(w_h_[1])
        const ScreenWidth = isNaN(w) ? 750 : w;
        const ScreenHeight = isNaN(h) ? 1334 : h;
        return { ScreenWidth, ScreenHeight }
    }
    const ScreenWidth = 750
    const ScreenHeight = 1334
    return { ScreenWidth, ScreenHeight }

}
/**
 * @description  点击
 * @returns {boolean}
 */
function 点击(points) {
    let x = 0
    let y = 0
    if (points.name !== undefined && points.name !== null){
        // 图色识别点击
        x = points.x
        y = points.y
    }
    else if(points.confidence !== undefined && points.confidence !== null){
        // ocr 识别点击
        x = points.x + points.width/2
        y = points.y + points.height/2
    }
    else {
        日志打印_error('点击失败，参数类型错误 ==》 ' + JSON.stringify(points))
        return false
    }
    var 点击结果 = clickPointPressure(x, y,  Math.random(0.4, 0.6));
    let 重试次数 = 3;
    while(!点击结果 && 重试次数 > 0){
        if(isScriptExit()){ break };
        点击结果 = clickPointPressure(x, y,  Math.random(0.4, 0.6));
        重试次数--;
    }
    // 日志打印_information(`点击坐标：${JSON.stringify(points)}`);
    return 点击结果
}


/**
 * @description  双击
 */
function 双击(points) {
    let i = 100;
    while (i>0){
        if(isScriptExit()){break}
        点击(points);
        i--;
    }
}

/**
 * @description  双击
 */
function 长按(points) {
    longClickPoint(points.x, points.y, random(800,1000))
}

/**
 * @description  清除app内的临时文件缓存
 * @returns {boolean}
 */
function cleanCacheFile(){
    const 临时txt文件 = file.listDir(file.getSandBoxFilePath('douyin'));
    const 评级txt文件 = file.listDir(file.getSandBoxFilePath('alldouyin'));
    const 临时图片文件 = file.listDir(file.getSandBoxFilePath('douyin-img'));
    if(临时txt文件){
        for (var i = 0; i < 临时txt文件.length; i++) {
            if(isScriptExit()){ break };
            日志打印_information(`删除缓存文件：${临时txt文件[i]}`);
            file.deleteAllFile(file.getSandBoxFilePath(`douyin/${临时txt文件[i]}`));
        }
    }
    if(评级txt文件){
        for (var i = 0; i < 评级txt文件.length; i++) {
            if(isScriptExit()){ break };
            日志打印_information(`删除评级文件：${评级txt文件[i]}`);
            file.deleteAllFile(file.getSandBoxFilePath(`alldouyin/${评级txt文件[i]}`));
        }
    }
    if(临时图片文件){
        for (var i = 0; i < 临时图片文件.length; i++) {
            if(isScriptExit()){ break };
            日志打印_information(`删除缓存图片：${临时图片文件[i]}`);
            file.deleteAllFile(file.getSandBoxFilePath(`douyin-img/${临时图片文件[i]}`));
        }
    }
}

function cleanLogFile(){
    var p = file.getInternalDir("documents")+'/jjlogger';
    var data = file.listDir(p);
    if(data){
        for (var i = 0; i < data.length; i++) {
            if(isScriptExit()){return}
            let 文件删除 = file.deleteAllFile(p+'/'+data[i])
            if(文件删除){
                日志打印_debug("日志文件：" + data[i] + '删除成功');
            }
        }
    }
}

/**
 * @description  输入框 输入文本
 * @param {内容} content
 * @param {输入框} inputNode
 * @returns {boolean}
 */
function 文本内容输入(content, inputNode) {
    // 先执行清空输入框内容操作
    日志打印_information(`执行【文本内容输入】： ${content}`)
    let 执行清空内容操作 = ioHIDEvent("0x07", "0x9C", Math.random(0.2, 0.4));
    let 重试次数 = 3;
    while(!执行清空内容操作 && 重试次数>0){
        if(isScriptExit()){ break };

        执行清空内容操作 = ioHIDEvent("0x07", "0x9C", Math.random(0.2, 0.4));
        重试次数--;
    }
    const sendContent = splitStringIntoChunks(content)

    for(let i in sendContent){
        if(isScriptExit()){break}
        inputText(sendContent[i], 150);
        if(sendContent[i].includes('[')){
            iSleep(random(400,600), false);
        }else {
            iSleep(random(400,600), false);
        }
    }
}


function 键盘发送() {
    for(let i=0; i<3; i++) {
        if (isScriptExit()) { break}
        const 键盘发送_结果 = ioHIDEvent("0x07", "0x58", Math.random(0.2, 0.4));
        if (键盘发送_结果) {
            break
        }
    }
}

function splitStringIntoChunks(str) {
    let result = [];
    let currentChunk = '';
    let inBrackets = false;

    for (let char of str) {
        if(isScriptExit()){break}

        if (char === '[' && !inBrackets) {
            // 如果当前chunk长度大于0，则添加到结果数组
            if (currentChunk.length > 0) {
                result.push(currentChunk);
                currentChunk = '';
            }
            // 开始一个新的组
            inBrackets = true;
            currentChunk += char;
        } else if (char === ']' && inBrackets) {
            // 结束一个组
            currentChunk += char;
            inBrackets = false;
            result.push(currentChunk);
            currentChunk = '';
        } else {
            // 如果不是开始或结束符号，就添加到当前chunk
            currentChunk += char;
            // 如果达到了7个字符且不在[]内，就添加到结果数组
            if (currentChunk.length === 7 && !inBrackets) {
                result.push(currentChunk);
                currentChunk = '';
            }
        }
    }

    // 添加最后一个未满7个字符的chunk（如果有的话）
    if (currentChunk.length > 0) {
        result.push(currentChunk);
    }

    return result;
}

/**
 * @description  滚动
 * @param x {x起始坐标}
 * @param y {y起始坐标}
 * @param ex {终点X坐标}
 * @param ey {终点Y坐标}
 * @param ey {终点Y坐标}
 * @param duration  {持续时长单位毫秒}
 * @returns {boolean}
 */
function 滑动(x, y, ex, ey, duration) {
    swipeToPointPressure(x, y, ex, ey, duration, Math.random(0.2, 0.6));
    iSleep(100)
}

function 多点触摸右滑() {
    const startX = random(80,120);
    const middleX = random(100,200);
    const endX = random(550,700);
    const startY = random(600,1000);
    const middleY = startY + random(-20,20);
    const endY = middleY + random(-20,20);
    let touch1 = MultiPoint
        .get()
        .action(0).x(startX).y(startY).pointer(1).delay(random(80,150))
        .next()
        .action(2).x(middleX).y(middleY).pointer(1).delay(random(80,150))
        .next()
        .action(1).x(endX).y(endY).pointer(1).delay(random(80,150));
    const x = multiTouch(touch1, null, null, null, null, 30000);
    return x
}

function 时间格式化(timeString) {
    timeString = timeString.replace(/\s/g, '').replace('．', '•').replace('·', '•');
    timeString = timeString.split('•')[0]
    if(timeString.includes('刚刚')){
        const index = timeString.lastIndexOf('刚')
        let location = ''
        if(index !== -1){
            location = timeString.substring(index+1);
            if(!location.startsWith('•')){
                location = '•' + location
            }
        }
        const newDate = new Date();
        const year = newDate.getFullYear();
        const month = (newDate.getMonth() + 1).toString().padStart(2, '0');
        const day = newDate.getDate().toString().padStart(2, '0');
        const formattedDate = `${year}-${month}-${day}`;
        return formattedDate;
    }
    if (timeString.includes('时前')) {
        const index = timeString.indexOf('前');
        let location = '';
        if (index!== -1) {
            location = timeString.substring(index + 1);
            if (!location.startsWith('•')) {
                location = '•' + location;
            }
        }
        const hoursAgo = parseInt(timeString.split('小时前')[0]);

        const currentDate = new Date();
        const currentYear = currentDate.getFullYear();
        const currentMonth = (currentDate.getMonth() + 1).toString().padStart(2, '0');
        const currentDay = currentDate.getDate();
        const currentHours = currentDate.getHours();

        if (currentHours >= hoursAgo) {
            // 是今天
            const formattedDate = `${currentYear}-${currentMonth}-${currentDay}`;
            return formattedDate;
        } else {
            // 是昨天
            currentDate.setDate(currentDay - 1);
            const formattedDate = `${currentDate.getFullYear()}-${(currentDate.getMonth() + 1).toString().padStart(2, '0')}-${currentDate.getDate().toString().padStart(2, '0')}`;
            return formattedDate;
        }
    }
    if (timeString.includes('分钟前')) {
        const currentDate = new Date();
        const currentYear = currentDate.getFullYear();
        const currentMonth = (currentDate.getMonth() + 1).toString().padStart(2, '0');
        const currentDay = currentDate.getDate();
        const formattedDate = `${currentYear}-${currentMonth}-${currentDay}`;
        return formattedDate;

    }
    if(timeString.includes('昨天')){
        let lastDigitIndex = -1;
        for (let i = 0; i < timeString.length; i++) {
            if(isScriptExit()){break}

            if (!isNaN(timeString[i]) && timeString[i] !== ' ') { // 检查是否为数字
                lastDigitIndex = i; // 更新最后一个数字的位置
            }
        }
        const newDate = new Date(new Date() - (1 * 24 * 60 * 60 * 1000));
        const year = newDate.getFullYear();
        const month = (newDate.getMonth() + 1).toString().padStart(2, '0');
        const day = newDate.getDate().toString().padStart(2, '0');
        const formattedDate = `${year}-${month}-${day}`;
        return formattedDate;
    }
    if(timeString.includes('前天')){
        let lastDigitIndex = -1;
        for (let i = 0; i < timeString.length; i++) {
            if(isScriptExit()){break}

            if (!isNaN(timeString[i]) && timeString[i] !== ' ') { // 检查是否为数字
                lastDigitIndex = i; // 更新最后一个数字的位置
            }
        }
        let location = timeString.substring(lastDigitIndex+1);
        if(!location.startsWith('•')){
            location = '•' + location
        }
        const newDate = new Date(new Date() - (2 * 24 * 60 * 60 * 1000));
        const year = newDate.getFullYear();
        const month = (newDate.getMonth() + 1).toString().padStart(2, '0');
        const day = newDate.getDate().toString().padStart(2, '0');
        const formattedDate = `${year}-${month}-${day}`;
        return formattedDate;
    }

    if (/\d+天前/.test(timeString)) {
        // 提取天数
        const index = timeString.indexOf('前')
        const daysMatch = timeString.match(/(\d+)天前/);
        if (daysMatch) {
            const daysAgo = parseInt(daysMatch[1], 10); // 将提取的天数转换为整数
            // 计算新的日期
            const newDate = new Date(new Date() - (daysAgo * 24 * 60 * 60 * 1000));
            const year = newDate.getFullYear();
            const month = (newDate.getMonth() + 1).toString().padStart(2, '0');
            const day = newDate.getDate().toString().padStart(2, '0');
            const formattedDate = `${year}-${month}-${day}`;
            return formattedDate;
        }
    }
    if(timeString.includes('/')){
        let parts = timeString.split('/');
        let year = new Date().getFullYear();
        let month = parts[0].padStart(2, '0');
        let day = parts[1].padStart(2, '0');
        let formattedDate = `${year}-${month}-${day}`;
        return formattedDate
    }
    if(timeString.includes(':')){
        let currentDate = new Date();
        let year = currentDate.getFullYear();
        let month = (currentDate.getMonth() + 1).toString().padStart(2, '0');
        let day = currentDate.getDate().toString().padStart(2, '0');
        let formattedDate = `${year}-${month}-${day}`;
        return formattedDate
    }
    const match = timeString.match(/^(\d{1,2})-(\d{1,2})[•.](.+)/);
    if (match) {
        // 获取当前年份
        const year = new Date().getFullYear();
        // 构建新的日期格式
        const formattedDate = `${year}-${match[1]}-${match[2]}`;
        return formattedDate;
    }
    const match2 = timeString.match(/^(\d{1,2})-(\d{1,2})([^\d]+)$/);
    if (match2) {
        // 获取当前年份
        const year = new Date().getFullYear();
        // 构建新的日期格式
        const formattedDate = `${year}-${match2[1]}-${match2[2]}`;
        return formattedDate;
    }

    const parts = timeString.split('-');
    // 检查输入是否包含两个部分
    if (parts.length === 2) {
        const month = parseInt(parts[0], 10);
        const day = parseInt(parts[1], 10);

        // 获取当前年份或使用默认年份
        const year = new Date().getFullYear();

        // 使用 padStart 方法来填充前导零
        const formattedMonth = month.toString().padStart(2, '0');
        const formattedDay = day.toString().padStart(2, '0');

        // 返回格式化的日期字符串
        return `${year}-${formattedMonth}-${formattedDay}`;
    }

    function formatCommentTime(commentTime) {
        const date = new Date(commentTime);
        if (isNaN(date)) {
            // 如果时间无效，使用当前日期作为默认值
            return '2024-08-01'; // 获取 'YYYY-MM-DD' 格式
        } else {
            // 返回有效的年月日格式
            return date.toISOString().split('T')[0]; // 获取 'YYYY-MM-DD' 格式
        }
    }

    return formatCommentTime(timeString);
}


function iSleep(delay, 实时检测 = true) {
    const start_time = time();
    let spend_time = time() - start_time;
    while( spend_time <= delay){
        if(isScriptExit()){ break };
        if(实时检测 && getCurrentWorkerName() === 'mainWorker'){
            检测屏幕异常();
        }else {
            返回应用页面2()
            sleep(500);
        }
        spend_time = time() - start_time;
    }
    设备信息同步后台()
}

function 开启副进程(workName) {
    if (getCurrentWorkerName() === "mainWorker"){
        let name = workerThread.newWorker(workName);
        日志打印_warning("开启副进程： " + name)
        iSleep(1000);
        if (!workerThread.isRunning(workName)) {
            日志打印_warning(workName + " 没运行");
            return false
        }
        return true;
    }
    return false
}

function 获取当前时间() {
    return new Date().toISOString();
}


function 字符串相似度计算(str1, str2) {
    function levenshteinDistance(str1, str2) {
        str1 = str1.replace(/\s+/g, ''); // 移除字符串中的所有空格
        str2 = str2.replace(/\s+/g, ''); // 移除字符串中的所有空格

        const len1 = str1.length;
        const len2 = str2.length;
        const matrix = [];

        // Initialize the matrix
        for (let i = 0; i <= len1; i++) {
            if(isScriptExit()){ break };
            matrix[i] = [i];
        }
        for (let j = 0; j <= len2; j++) {
            if(isScriptExit()){ break };
            matrix[0][j] = j;
        }

        // Compute Levenshtein distance
        for (let i = 1; i <= len1; i++) {
            if(isScriptExit()){ break };
            for (let j = 1; j <= len2; j++) {
                if(isScriptExit()){ break };
                if (str1[i - 1] === str2[j - 1]) {
                    matrix[i][j] = matrix[i - 1][j - 1];
                } else {
                    matrix[i][j] = Math.min(
                        matrix[i - 1][j - 1] + 1, // substitution
                        matrix[i][j - 1] + 1,      // insertion
                        matrix[i - 1][j] + 1       // deletion
                    );
                }
            }
        }

        return matrix[len1][len2];
    }

    const distance = levenshteinDistance(str1, str2);
    const maxLen = Math.max(str1.length, str2.length);

    // Similarity is defined as 1 minus the normalized distance
    const similarity = 1 - (distance / maxLen);

    return similarity;
}


var 当前执行模块 = '无模块执行'

function 格式化日志(log) {
    const error = new Error();
    const stack = error.stack.split('\n');
    // 通常第二行包含调用该函数的文件和行号
    const callerInfo = stack[2].trim();
    const msgs = callerInfo.split('///')[1].split(':');
    const result = `(${msgs[0]}#${msgs[1]})【${脚本当前运行阶段}】【${当前执行模块}】${log}`
    // logs.push(result)
    // MQ发送消息列表.push({log: result});
    return result
}
function 日志打印_debug(log) {
    var s = [];
    for (var i = 1; i < arguments.length; i++) {
        if(isScriptExit()){ break };
        s.push(arguments[i] + "");
    }
    ecImporter.logd(formatlog(格式化日志(log)), JSON.stringify(s));
}
function 日志打印_information(log) {
    var s = [];
    for (var i = 1; i < arguments.length; i++) {
        if(isScriptExit()){ break };
        s.push(arguments[i] + "");
    }
    ecImporter.logi(formatlog(格式化日志(log)), JSON.stringify(s));
}
function 日志打印_warning(log) {
    var s = [];
    for (var i = 1; i < arguments.length; i++) {
        if(isScriptExit()){ break };
        s.push(arguments[i] + "");
    }
    ecImporter.logw(formatlog(格式化日志(log)), JSON.stringify(s));

}
function 日志打印_error(log) {
    var s = [];
    for (var i = 1; i < arguments.length; i++) {
        if(isScriptExit()){ break };
        s.push(arguments[i] + "");
    }
    const error_log = 格式化日志(`【error】${log}`)
    ecImporter.loge(formatlog(error_log), JSON.stringify(s));
}


打印日志 = false;
function 开启日志框() {

    let 程序到前台 = takeMeToFront();
    while(!程序到前台){
        if(isScriptExit()) {break}
        程序到前台 = takeMeToFront();
        日志打印_warning('(程序到前台) 执行失败，正在重试！')
    }
    const 寻找_灰色_日志框右侧隐藏按钮 = findColor(ios.日志框_灰色_右侧隐藏按钮, null, 1);
    if(寻找_灰色_日志框右侧隐藏按钮){
        滑动(寻找_灰色_日志框右侧隐藏按钮.x, 寻找_灰色_日志框右侧隐藏按钮.y, 寻找_灰色_日志框右侧隐藏按钮.x, ScreenHeight, 400);
        日志打印_warning('日志框 已开启');
        return
    }

    let 关闭日志框 = closeLogWindow();
    while(!关闭日志框){
        if(isScriptExit()) {break}
        关闭日志框 = closeLogWindow();
        日志打印_warning('(关闭日志框) 执行失败，正在重试！')
    }
    iSleep(2000);

    const m = {
        "x": 0,
        "y": 0,
        "w": 500,
        "h": 500,
        "textSize": 40,
        "backgroundColor": "#6e9833",
        "textColor": "#00000"
    };
    setLogViewSizeEx(m);
    let 日志框打开 = showLogWindow();
    while(!日志框打开){
        日志框打开 = showLogWindow();
        日志打印_warning('(日志框打开) 执行失败，正在重试！')
    }

    iSleep(1000);
    let 找到AGI日志框 = 单点找色(ios.AGI日志框);
    while(!找到AGI日志框){
        if(isScriptExit()) {break}
        showLogWindow();
        setLogViewSizeEx(m);
        iSleep(100);
        找到AGI日志框 = 单点找色(ios.AGI日志框);
        日志打印_warning('(找到AGI日志框) 单点找色失败，正在重试！')
    }

    const startX = 找到AGI日志框.x ;
    const startY = 找到AGI日志框.y ;
    滑动(startX, startY, ScreenWidth, startY, 200)
    iSleep(500);
    let 寻找日志框右侧隐藏按钮 = findColor(ios.日志框_绿色_右侧隐藏按钮, null, 1);
    let i = 1;
    while(!寻找日志框右侧隐藏按钮){
        if(isScriptExit()) {break}
        滑动(startX-i*20, startY, ScreenWidth, startY, 200);
        i++;
        寻找日志框右侧隐藏按钮 = findColor(ios.日志框_绿色_右侧隐藏按钮, null, 1);
        日志打印_warning('(寻找日志框右侧隐藏按钮) 失败，正在重试！')
    }
    滑动(寻找日志框右侧隐藏按钮.x, 寻找日志框右侧隐藏按钮.y, 寻找日志框右侧隐藏按钮.x, ScreenHeight, 400);
    日志打印_warning('开启日志框 成功');
}

function 主线程处理事件() {
    当前执行模块 = '主线程处理事件'
    // douyin.初始化ocr()  // ocr 初始化
    laoleng.EC.init(1)
    laoleng.EC.initOcr()
    laoleng.EC.initNode()
    ios.初始化()
    iSleep(100);
    开启日志框();
    打开代理();
    日志打印_information('【主线程处理事件】处理完毕！')
    // cleanCacheFile();  //清除app内的图片缓存
    // setSaveLogEx(false,"off")
}

function getNowHour() {
    const now = new Date();
    return now.getHours();
}



function stringToHash(key, seed = 0) {
    let length = key.length;
    let h1 = seed ^ length;

    let currentIndex = 0;

    while (length >= 4) {
        let k1 = (key.charCodeAt(currentIndex) & 0xFF)
            | ((key.charCodeAt(currentIndex + 1) & 0xFF) << 8)
            | ((key.charCodeAt(currentIndex + 2) & 0xFF) << 16)
            | ((key.charCodeAt(currentIndex + 3) & 0xFF) << 24);

        k1 = Math.imul(k1, 0xCC9E2D51);
        k1 = (k1 << 15) | (k1 >>> 17); // Rotate left by 15 bits
        k1 = Math.imul(k1, 0x1B873593);

        h1 ^= k1;
        h1 = (h1 << 13) | (h1 >>> 19); // Rotate left by 13 bits
        h1 = Math.imul(h1, 5) + 0xE6546B64;

        currentIndex += 4;
        length = length - 4;
    }

    // Process remaining bytes
    let k1 = 0;
    switch (length) {
        case 3: k1 ^= (key.charCodeAt(currentIndex + 2) & 0xFF) << 16; currentIndex++;
        case 2: k1 ^= (key.charCodeAt(currentIndex + 1) & 0xFF) << 8; currentIndex++;
        case 1: k1 ^= (key.charCodeAt(currentIndex) & 0xFF); currentIndex++;
            k1 = Math.imul(k1, 0xCC9E2D51);
            k1 = (k1 << 15) | (k1 >>> 17); // Rotate left by 15 bits
            k1 = Math.imul(k1, 0x1B873593);
            h1 ^= k1;
    }

    // Finalization
    h1 ^= key.length;

    h1 = h1 ^ (h1 >>> 16);
    h1 = Math.imul(h1, 0x85EBCA6B);
    h1 = h1 ^ (h1 >>> 13);
    h1 = Math.imul(h1, 0xC2B2AE35);
    h1 = h1 ^ (h1 >>> 16);

    // Convert to 32-bit unsigned integer
    return h1 >>> 0;  // Ensure non-negative output
}



