function 微信工作流() {

    wechat.初始化()

    while (true){
        if(isScriptExit()) {break}
        //
        // if(!wechat.wx_启动微信()){
        //     continue;
        // }
        if (!wechat.wx_获取本设备微信号()){
            continue;
        }
        while (true){
            if(isScriptExit()) {break}

            const result = wechat.wx_双击获取未读消息()
            if(result){
                logw(`未读消息结果：${JSON.stringify(result)}`)
                const 回复 = 获取聊天回复(wechat.本设备微信号, result.name, result.msg)
                wechat.wx_聊天消息发送(回复)
            }
            wechat.wx_返回_消息导航页面()
        }

    }



}