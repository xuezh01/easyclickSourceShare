

function main() {
    logd(`*********************** ${([][[]] + [])[+!![]] + ([] + {})[+!![] + +!![]]}  ***********************`)
    setExceptionCallback(function (msg) {
        // takeMeToFront()
        loge(" ***************** 脚本异常停止消息: " + msg);
    });
    setStopCallback(function () {
        // takeMeToFront()
        logd("***************** 脚本已经停" + "止运行 ** * **************")
    });
    // 打印日志 = true
    // ios.初始化()
    // douyin.初始化()
    // const a = findMultiColor([douyin.主页_账号切换_未读消息, douyin.主页_账号切换_倒三角])
    // logd(JSON.stringify(a))
    // return;
    while (!isServiceOk()){
        if (isScriptExit()) { return }
        日志打印_information('自动化服务不正常')
        脚本当前运行阶段 = '自动化服务不正常'
        iSleep(10000, false);
    }

    const response = api_设备uid查询()
    uid = response.uid  //获取当前 uid
    api_设备信息更新(uid)
    更新到新配置(response.device_task)
    日志打印_warning(`【当前设备账号】：${uid}`)
    日志打印_warning(`【当前设备任务】：${JSON.stringify(脚本运行配置)}`)
    主线程处理事件();
    while (true){
        if (isScriptExit()) { return }

        while(true){
            if (isScriptExit()) { return }
            if (脚本运行配置){ break }
            当前执行模块 = '空闲'
            脚本当前运行阶段 = '空闲'
            日志打印_warning('未分配脚本任务！')
            takeMeToFront();
            iSleep(10000);
        }

        while (true){
            if (isScriptExit()){break}
            if (脚本运行配置.app_type.includes('抖音')){
                if (脚本运行配置.dy.task === '关键词检索任务'){
                    抖音关键词检索后私信工作流()
                }
                if (脚本运行配置.dy.task === '昵称检索任务'){
                    抖音_昵称检索()
                }
                if (脚本运行配置.dy.task === '刺客流任务'){
                    抖音关键词检索刺客工作流()
                }
                if (脚本运行配置.dy.task === '持续跟进任务'){
                    抖音跟进流程启动()
                }
                if (脚本运行配置.dy.task === '群聊获客任务'){
                    抖音粉丝群获客()
                }

            }
            if (脚本运行配置.app_type.includes('快手')){
                快手关键词检索后私信工作流()
            }
            iSleep(100)
        }

    }
}

main();


