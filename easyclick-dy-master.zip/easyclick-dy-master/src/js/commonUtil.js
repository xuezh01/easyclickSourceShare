/**
 * 判断是否是国外网络
 * @returns {boolean}
 */
function isForeignNetwork(){
    var url = "https://m.facebook.com";
    var response = http.httpGet(url, {}, 10 * 1000, {});
    if(response == null){
        return false
    }else{
        return true
    }
}

function showDialogMsg(msg){
    ui.alert({"msg": msg})
}

//关闭应用
function closeAppByPkgName(pkgName) {
    logd("关闭app");
    shell.execCommand("am force-stop " + pkgName)
}
//清理应用数据
function removeAppDataByPkgName(pkgName) {
    logd("清理应用数据");
    shell.execCommand("pm clear " + pkgName)
}
//卸载应用
function unInstallPkgName(pkgName){
    shell.uninstallApp(pkgName)
}

function openUrl(url) {
    utils.openActivity({
        action: "android.intent.action.VIEW",
        uri: url,
    })
}
