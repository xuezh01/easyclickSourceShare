function checkConfigInfo(){
    let keyList = readConfigString("keyList")
    if (!keyList) {
        toast("还未填写关键字")
        loge("还未填写关键字")
        exit()
        return false;
    }
    let plList = readConfigString("plList")
    if (!plList) {
        toast("还未填写评论内容")
        loge("还未填写评论内容")
        exit()
        return false;
    }
    return true
}