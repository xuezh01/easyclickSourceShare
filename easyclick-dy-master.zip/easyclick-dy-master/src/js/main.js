/**
 * 常用JS变量:
 * agentEvent = 代理模式下自动点击模块
 * acEvent= 无障碍模式下自动点击模块
 * device = 设备信息模块
 * file = 文件处理模块
 * http = HTTP网络请求模块
 * shell = shell命令模块
 * thread= 多线程模块
 * image = 图色查找模块
 * utils= 工具类模块
 * global = 全局快捷方式模块
 * 常用java变量：
 *  context : Android的Context对象
 *  javaLoader : java的类加载器对象
 * 导入Java类或者包：
 *  importClass(类名) = 导入java类
 *      例如: importClass(java.io.File) 导入java的 File 类
 *  importPackage(包名) =导入java包名下的所有类
 *      例如: importPackage(java.util) 导入java.util下的类
 *
 */

function main() {
    //如果自动化服务正常
    logd("开始执行脚本...")
    init()
    let testFlag = test()
    if(testFlag == true){
        return
    }
    if(!checkConfigInfo()){
        return
    }
    if (!checkCodeInfo()) {
        return;
    }
    startDyTask()
    hotDeployment()
}

//初始化
function init(){
    var result = daemonEnv(true);
    if(result){
        logd("守护自动化环境成功...")
    }
    //如果自动化服务正常
    if (!autoServiceStart(5)) {
        logd("自动化服务启动失败，无法执行脚本")
        exit();
        return;
    }
    var isAgentModeFlag = isAgentMode();
    logd("代理模式", isAgentModeFlag);
    var request = image.requestScreenCapture(10000,0);
    if (!request) {
        request = image.requestScreenCapture(10000,0);
    }
    logd("申请截图结果... "+request)
    if (!request) {
        loge("申请截图权限失败,检查是否开启后台弹出,悬浮框等权限")
        exit()
    }else{
        sleep(500);
    }
    let p = floaty.requestFloatViewPermission(1000)
    logd("是否有浮窗权限: "+p);
    var initOpenCV = image.initOpenCV();
    logd("图像初始化:" + initOpenCV);
    // if(initOpenCV == false){
    //     restartScript(null,true,3)
    //     return
    // }
    let initWord = imageHandler.setDict("word.txt");
    logd("字库设置结果:"+initWord); //true 表示成功 false表示失败
    device.keepScreenOn();
}

function autoServiceStart(time) {
    for (var i = 0; i < time; i++) {
        if (isServiceOk()) {
            return true;
        }
        var started = startEnv();
        logd("第" + (i + 1) + "次启动服务结果: " + started);
        if (isServiceOk()) {
            return true;
        }
    }
    return isServiceOk();
}

main();