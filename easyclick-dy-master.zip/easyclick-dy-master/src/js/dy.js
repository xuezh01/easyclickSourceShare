function startDyTask() {
    toast("项目启动成功");
    home()
    sleep(2000)
    dyTask()
    closeTask()
}

let userLoginFlag = false

function dyTask() {
    var threadTask = thread.execAsync(function () {
        while (true) {
            sleep(1000)
            let pkgName = getRunningPkg()
            let actName = getRunningActivity()
            initEvn()
            if (userLoginFlag) { //在登陆的情况下执行
                logd("执行引流操作");
                if (actName == 'com.ss.android.ugc.aweme.main.MainActivity') {
                    changeVideo() // 切换视频
                    excutePl_mi() // 执行引流操作
                    toast("进入下一个作品引流操作,等待1-5秒");
                    sleep(random(1, 5) * 1000);
                }
            } else {
                let userConfig = readConfigString("userConfig")
                userConfig = JSON.parse(userConfig)
                if(userConfig && userConfig.jmsh == 1){
                    loginDy()
                    userLoginFlag = readConfigString("userLoginFlag")
                } else {
                    userLoginFlag = true
                }
            }
        }
    })
}
function initEvn(){
    let pkgName = getRunningPkg()
    let actName = getRunningActivity()
    logd(pkgName, actName);
    if (pkgName && pkgName != 'com.ss.android.ugc.aweme') {
        logd("打开抖音");
        let node = desc("抖音").getOneNodeInfo(1000)
        clickNode(node)
        // utils.openApp("com.ss.android.ugc.aweme")
        toast("自动打开抖音,等待10秒（如果没有请手动打开）");
        sleep(10 * 1000);
    }
}

//登录抖音
function loginDy() {
    let pkgName = getRunningPkg()
    let actName = getRunningActivity()
    logd("pkgName", pkgName);
    sleep(1000);
    if (pkgName && pkgName != 'com.ss.android.ugc.aweme') {
        // utils.openAppByName("抖音")
        logd("打开抖音");
        let node = desc("抖音").getOneNodeInfo(1000)
        clickNode(node)
        toast("等待10秒");
        sleep(10 * 1000);
    }
    logd('loginDy', pkgName, actName);
    if (pkgName && actName == 'com.ss.android.ugc.aweme.main.MainActivity') {
        let node = text("我").getOneNodeInfo(1000)
        clickNode(node)
    }

    if (pkgName && actName.indexOf('com.ss.android.ugc.aweme.account.business.login') != -1){
        let title = text("登录后即可展示自己").getOneNodeInfo(1000)
        if(title){
            node = id("com.ss.android.ugc.aweme:id/njn").getOneNodeInfo(1000)
            clickNode(node)
            let phoneNode = id("com.ss.android.ugc.aweme:id/mre").getOneNodeInfo(1000)
            if(phoneNode){
                let phoneNumber = getPhoneNumber()
                while(!phoneNumber){
                    sleep(1000);
                    phoneNumber = getPhoneNumber()
                }
                phoneNode.inputText(phoneNumber)
                let loginNode = text("验证并登录").getOneNodeInfo(1000)
                clickNode(loginNode)

                let phoneTitle = text("请输入验证码").getOneNodeInfo(1000)
                while(!phoneTitle){
                    sleep(1000);
                    let sysError = text("系统繁忙，请稍后再试").getOneNodeInfo(1000)
                    if(sysError){
                        toast("手机号码不可用" + phoneNumber + ",切换手机号,拉黑号码");
                        addBlacklist(phoneNumber)
                        closeAppByPkgName("com.ss.android.ugc.aweme")
                        toast("清除数据");
                        removeAppDataByPkgName("com.ss.android.ugc.aweme")
                        toast("清除成功");
                        sleep(3000);
                        return
                    }
                    phoneTitle =  text("请输入验证码").getOneNodeInfo(1000)
                }
                let phoneCode = text("请输入验证码").clz("android.widget.EditText").getOneNodeInfo(1000)
                while(!phoneCode){
                    sleep(1000);
                    phoneCode = text("请输入验证码").clz("android.widget.EditText").getOneNodeInfo(1000)
                }
                let code = getPhoneCode(phoneNumber)
                while(!code){
                    sleep(1000);
                    code =  getPhoneCode(phoneNumber)
                }
                phoneCode.inputText(code)
                let loginBtn = text("登录").getOneNodeInfo(1000)
                clickNode(loginBtn)
            }
        }
    }

}

/**
 * 执行评论操作
 */
function excutePl() {
    let keyList = readConfigString("keyList")
    keyList = JSON.parse(keyList)
    let plList = readConfigString("plList")
    plList = JSON.parse(plList)
    let node = id("com.ss.android.ugc.aweme:id/cue").getOneNodeInfo(1000)
    logd("点击评论按钮", node);
    clickNode(node)
    sleep(2000)
    let avatarNode = id("com.ss.android.ugc.aweme:id/avatar").getNodeInfo(1000)
    let msgNodes = id("com.ss.android.ugc.aweme:id/content").getNodeInfo(1000)
    let targetList = []
    if (msgNodes && msgNodes.length > 0) {
        for (let i = 0; i < msgNodes.length; i++) {
            let nodesKey = msgNodes[i]
            logd(nodesKey.text, JSON.stringify(nodesKey));
            let nodeContent = nodesKey.text
            for (let key of keyList) {
                if (nodeContent.indexOf(key) != -1) {
                    logd('找到目标用户');
                    targetList.push(avatarNode[i])
                    break
                }
            }
        }
        for (let targetNodeItem of targetList) {
            clickNode(targetNodeItem)
            sleep(30000)
        }

    }
}
// 小米引流逻辑
function excutePl_mi() {
    let keyList = readConfigString("keyList")
    keyList = JSON.parse(keyList)
    sleep(3000);
    let node = id("com.ss.android.ugc.aweme:id/dh6").getOneNodeInfo(1000)
    logd("点击评论按钮", node);
    if(node == null){
        back()
        return
    }
    clickNode(node)
    sleep(2000)
    let endPl = true //结束引流标志
    let selectNumber = 0
    let viewNumber = 20
    let userConfig = readConfigString("userConfig")
    userConfig = JSON.parse(userConfig)
    if(userConfig && userConfig.plgs){
        viewNumber = userConfig.plgs
    }
    let hasFindStr = ''
    while(endPl){
        let avatarNode = id("com.ss.android.ugc.aweme:id/avatar").getNodeInfo(500)
        let msgNodes = id("com.ss.android.ugc.aweme:id/content").getNodeInfo(500)
        let titleNodes = id("com.ss.android.ugc.aweme:id/title").getNodeInfo(1000)
        let targetList = []
        let number = 0
        if (msgNodes && msgNodes.length > 0) {
            number = number + msgNodes.length
            for (let i = 0; i < msgNodes.length; i++) {
                let nodesKey = msgNodes[i]
                let title =  titleNodes[i]
                // logd(nodesKey.text);
                let nodeContent = nodesKey.text
                for (let key of keyList) {
                    if (nodeContent && nodeContent.indexOf(key) != -1 && title && hasFindStr.indexOf(title.text) == -1) {
                        logi('找到目标内容---', nodeContent);
                        targetList.push(avatarNode[i])
                        hasFindStr += nodeContent
                        if(userConfig && userConfig.pldz == 1){
                            // clickNode(likeNode[i])
                            doubleClickPoint(nodesKey.bounds.left + 10, nodesKey.bounds.top + 1)
                        }
                        break
                    }
                }
            }
        }
        if(targetList && targetList.length > 0){
            for (let targetNodeItem of targetList) {
                targetNodeItem.click()
                sleep(3000);
                yinliucaozuo()
            }
        }
        if(selectNumber > viewNumber){
            endPl = false
            back()
        } else {
            selectNumber = selectNumber + number
            pl_move()
        }
        let node = text("暂时没有更多了").getOneNodeInfo(1000)
        if(node){
            toast("没有多余的评论了");
            endPl = false
            back()
        }
    }
}



//引流操作
function yinliucaozuo(){
    let userConfig = readConfigString("userConfig")
    userConfig = JSON.parse(userConfig)
    let plList = readConfigString("plList")
    plList = JSON.parse(plList)
    sleep(1000);

    if(userConfig && userConfig.dz == 1){
        //主页头像节点
        let tx_node = id("com.ss.android.ugc.aweme:id/ipa").getOneNodeInfo(1000)
        if(tx_node){
            tx_node.click()
            sleep(1000);
            let node = id("com.ss.android.ugc.aweme:id/l_g").getOneNodeInfo(1000)
            if(node){
                node.click()
                back()
            }
        }
    }
    sleep(1000);
    if(userConfig && userConfig.gz  == 1){
        //关注节点
        let gz_node = id("com.ss.android.ugc.aweme:id/q1y").getOneNodeInfo(1000)
        if(gz_node){
            gz_node.click()
            sleep(1000);
        }
    }

    if(userConfig && userConfig.zpdz == 1){
        if(userConfig.gz  == 1){
            pl_move()
            sleep(1000)
        }
        // 作品数
        let zp_node = id("com.ss.android.ugc.aweme:id/ef1").getNodeInfo(1000)
        let node = text("还没有作品").getOneNodeInfo(1000)
        if(node){
            logd("没有发布作品");
            back()
            return
        }
        if(zp_node && zp_node.length > 0){
            logd("找到作品数量", zp_node.length);
            zp_node[0].click() //点击作品
            sleep(random(5, 10) * 1000);
            if(userConfig && userConfig.zpdz == 1){
                let x = device.getScreenWidth() * 5 / 10;
                let y = device.getScreenHeight() * 8 / 10;
                doubleClickPoint(random(x - 20, x + 20), random(y - 20, y + 20))
            }
            //点击评论按钮
            let pl_node = id("com.ss.android.ugc.aweme:id/dh6").getOneNodeInfo(1000)
            if(pl_node){
                pl_node.click()
                //输入框
                let inputNode = id("com.ss.android.ugc.aweme:id/dg0").getOneNodeInfo(1000)
                if(inputNode){
                    let plIndex = Math.floor((Math.random() * plList.length));
                    let content = plList[plIndex]
                    inputNode.click()
                    sleep(1000)
                    logd(inputNode.imeInputText(content));
                    sleep(1000);
                    let node = text("发送").getOneNodeInfo(1000)
                    clickNode(node)
                    sleep(1000);
                    back() //返回作品
                    sleep(1000);
                    back() //返回作品主页
                }
            }
        }
    }

    back()
}

// 评论上滑
function pl_move(){
    let x = device.getScreenWidth() * 5 / 10;
    let y = device.getScreenHeight() * 8 / 10;
    let x1 = device.getScreenWidth() * 5 / 10;
    let y1 = device.getScreenHeight() * 3 / 10;
    //自定义函数：仿真滑动屏幕，注意避开悬浮窗
    rnd_Swipe(x, y, x1, y1, 100, 100, 100)
    sleep(500);
}

function changeVideo() {
    // 设定坐标，适配全分辨率
    let x = device.getScreenWidth() * 5 / 10;
    let y = device.getScreenHeight() * 8 / 10;
    let x1 = device.getScreenWidth() * 5 / 10;
    let y1 = device.getScreenHeight() * 1.5 / 10;
    //自定义函数：仿真滑动屏幕，注意避开悬浮窗
    rnd_Swipe(x, y, x1, y1, 100, 100, 200)
    sleep(random(3, 5) * 1000);
}


function closeTask() {
    var closeThread = thread.execAsync(function () {
        while (true) {
            let node = findAutoNodeByCombText("同意")
            clickNodeByTextSearch(node)
            let btnText = new Array(
                "允许",
                "我知道了",
                "跳过",
                "好的",
                "确定",
                "接 受",
                "安装",
                "同意",
            );
            for (let i = 0; i < btnText.length; i++) {
                let node = text(btnText[i]).getOneNodeInfo(500);
                clickNode(node)
            }
        }
    })
}