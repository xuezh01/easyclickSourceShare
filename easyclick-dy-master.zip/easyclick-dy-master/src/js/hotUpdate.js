/**
 * 热部署
 */
function hotDeployment() {
    let version = JSON.parse(readIECFileAsString("update.json")).version;
    while (true) {
        logi("没有任务信息，进行版本更新校验")
        //请求服务器是否有新版本
        try {
            let updateResult = hotupdater.updateReq();
            logd("当前版本号: " + version + ", 请求更新是否有: " + updateResult);
            if (!updateResult) {
                logw("请求信息: " + hotupdater.getErrorMsg());
            } else {
                logd("请求数据: " + hotupdater.getUpdateResp());
                //有更新得情况下进行下载新的版本
                let path = hotupdater.updateDownload();
                if (!path) {
                    logw("下载IEC文件错误信息: " + hotupdater.getErrorMsg());
                } else {
                    restartScript(path, true, 3)
                    return;
                }
            }
        } catch (ex) {
            logd(ex)
        }
        sleep(5 * 60 * 1000);
    }
}