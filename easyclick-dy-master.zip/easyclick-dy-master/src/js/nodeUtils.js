
// 根据文本获取节点
function getNodeInfoByContent(content, second) {
    if (!second) {
        second = 500
    }
    let textNode = text(content).getOneNodeInfo(second)
    let descNode = desc(content).getOneNodeInfo(second)
    if (textNode) {
        return textNode
    } else if (descNode) {
        return descNode
    } else {
        return null
    }
}

function clickNode(node){
    if(node && node != false){
        node.click()
    }
}