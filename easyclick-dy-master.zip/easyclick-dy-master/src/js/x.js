
//by冉遗鱼......................

//x轴方向四阶赛贝尔蛇形滑动
//例如   moveFun(126,1442,130,1442+random(-10,10),4000);
function moveFun(qx, qy, zx, zy, time) {
    var xxy = [];
    var points = [];

    //设置控制点极限距离
    var leaveHeightLength=500

    var point1 = {
        "x": qx,
        "y": qy
    };

    //根据偏差距离，应用不同的随机方式
    if(Math.abs(zx-qx)>Math.abs(zy-qy)){
        var my=(qy+zy)/2
        var y2=my+random(0,leaveHeightLength)
        var y3=my-random(0,leaveHeightLength)

        var lx=(qx-zx)/3
        if(lx<0){lx=-lx}
        var x2=qx+lx/2+random(0,lx)
        var x3=qx+lx+lx/2+random(0,lx)
    }else{
        var mx=(qx+zx)/2
        var y2=mx+random(0,leaveHeightLength)
        var y3=mx-random(0,leaveHeightLength)

        var ly=(qy-zy)/3
        if(ly<0){ly=-ly}
        var y2=qy+ly/2+random(0,ly)
        var y3=qy+ly+ly/2+random(0,ly)
    }

    var point2 = {
        "x": x2,
        "y": y2
    };
    var point3 = {
        "x": x3,
        "y": y3,
    };
    var point4 = {
        "x": zx,
        "y": zy
    };


    points.push(point1);
    points.push(point2);
    points.push(point3);
    points.push(point4);

    let targetP;
    for (let i = 0; i < 1; i += 0.08) {
        targetP=bezier_curves(points, i);
        xxy.push([parseInt(targetP.x), parseInt(targetP.y)]);
    }

    let touch1 =[];
    let  _time=time/xxy.length;

    touch1.push({"action": 0, "x": xxy[0][0], "y": xxy[0][1], "pointer": 1, "delay": _time})
    for (let i = 2; i <xxy.length-1 ; i++) {
        touch1.push({"action": 2, "x": xxy[i][0], "y": xxy[i][1], "pointer": 1, "delay": _time})
    }
    touch1.push({"action": 1, "x": xxy[xxy.length-1][0], "y": xxy[xxy.length-1][1], "pointer": 1, "delay": _time})

    let x = multiTouch(touch1, null, null, 30000);
    // logd("群主鸟最大 " + x);
};


function bezier_curves(cp, t) {
    let cx = 3.0 * (cp[1].x - cp[0].x);
    let bx = 3.0 * (cp[2].x - cp[1].x) - cx;
    let ax = cp[3].x - cp[0].x - cx - bx;
    let cy = 3.0 * (cp[1].y - cp[0].y);
    let by = 3.0 * (cp[2].y - cp[1].y) - cy;
    let ay = cp[3].y - cp[0].y - cy - by;

    let tSquared = t * t;
    let tCubed = tSquared * t;
    let result = {
        "x": 0,
        "y": 0
    };
    result.x = (ax * tCubed) + (bx * tSquared) + (cx * t) + cp[0].x;
    result.y = (ay * tCubed) + (by * tSquared) + (cy * t) + cp[0].y;
    return result;
};

