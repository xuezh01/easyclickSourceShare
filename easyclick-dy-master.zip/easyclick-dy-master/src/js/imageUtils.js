/**
 *
 * @param text
 * @param threshold_value 二值化阈值，0 ~ 255
 * @param threshold 阈值 默认 0.9
 * @returns {null|RectEx|boolean}
 */
function findNodeByText(text, threshold_value, threshold){
    let screenHeight = device.getScreenHeight()
    let screenWidth = device.getScreenWidth()
    let bitmap = imageHandler.captureScreenMat("png",0,0,screenWidth,screenHeight ,100);
    if(bitmap){
        threshold = threshold || 0.85
        threshold_value = threshold_value || 140
        let bitmapBinary = imageHandler.binaryzationMat(bitmap,threshold_value);
        let resultNode = imageHandler.findStrEx(bitmapBinary, text, -1, 0, 0, 0, threshold, 1);
        if(resultNode){
            //画出来
            let newSrc=imageHandler.drawRect2(bitmapBinary,resultNode);
            imageHandler.saveMat(newSrc,"/storage/emulated/0/Pictures/result.png");
            imageHandler.recycle(newSrc);
            //回收图片
            imageHandler.recycle(bitmap)
            imageHandler.recycle(bitmapBinary)
            return resultNode[0]
        }else{
            return false
        }
    }else{
        return false
    }
}

/**
 *
 * @param text
 * @param threshold_value 二值化阈值，0 ~ 255
 * @param threshold 阈值 默认 0.9
 * @returns {null|RectEx|boolean}
 */
function findAutoNodeByText(text, threshold){
    let screenHeight = device.getScreenHeight()
    let screenWidth = device.getScreenWidth()
    let bitmap = imageHandler.captureScreenMat("png",0,0,screenWidth,screenHeight,100);
    if(bitmap){
        // logd(imageHandler.saveMat(bitmap,"/storage/emulated/0/Pictures/bitmap.png"));
        threshold = threshold || 0.85
        let  bitmapBinary = imageHandler.adaptiveThreshold(bitmap,0,55,255,0,0);
        let resultNode = imageHandler.findStrEx(bitmapBinary, text, -1, 0, 0, 0, threshold, 1);
        if(resultNode){
            //画出来
            let newSrc=imageHandler.drawRect2(bitmapBinary,resultNode);
            imageHandler.saveMat(newSrc,"/storage/emulated/0/Pictures/autoResult.png");
            imageHandler.recycle(newSrc);
            //回收图片
            imageHandler.recycle(bitmap)
            imageHandler.recycle(bitmapBinary)
            return resultNode[0]
        }else{
            return false
        }
    }else{
        return false
    }
}

function findAutoNodeByCombText(text, threshold){
    let screenHeight = device.getScreenHeight()
    let screenWidth = device.getScreenWidth()
    let bitmap = imageHandler.captureScreenMat("png",0,0,screenWidth,screenHeight,100);
    if(bitmap){
        threshold = threshold || 0.85
        let  bitmapBinary = imageHandler.adaptiveThreshold(bitmap,0,55,255,0,0);
        let resultNode = imageHandler.findStrComb(bitmapBinary, text, -1, 0, 0, 0, threshold, 1);
        if(resultNode){
            //画出来
            let newSrc=imageHandler.drawRect2(bitmapBinary,resultNode);
            imageHandler.saveMat(newSrc,"/storage/emulated/0/Pictures/autoResult.png");
            imageHandler.recycle(newSrc);
            //回收图片
            imageHandler.recycle(bitmap)
            imageHandler.recycle(bitmapBinary)
            return resultNode[0]
        }else{
            return false
        }
    }else{
        return false
    }
}

function clickNodeByTextSearch(nodeInfo){
    if(nodeInfo != false){
        clickPoint(nodeInfo.left, nodeInfo.top)
    }
}