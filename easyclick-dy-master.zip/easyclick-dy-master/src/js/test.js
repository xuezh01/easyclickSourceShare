function test(){
    let pkgName = getRunningPkg()
    let actName = getRunningActivity()
    logd('test', pkgName, actName);
    logd(agentEvent.setCurrentIme());
    // let inputNode = id("com.ss.android.ugc.aweme:id/dg0").getOneNodeInfo(1000)
    // logd(inputNode);
    // inputNode.click()
    // sleep(1000)
    // logd(inputNode.imeInputText("归福建，下一个"));
    // sleep(1000);
    // // inputNode.imeInputText("笔芯")
    // let node = text("发送").getOneNodeInfo(1000)
    // clickNode(node)
    // return true
    // pl_move()
    // utils.openApp("com.ss.android.ugc.aweme")
    // return true
    // removeAppDataByPkgName("com.hainansg.ywrs")
    // unInstallPkgName("com.ss.android.ugc.aweme")
    // return true
    // shell.uninstallApp("com.netease.party.kuaishou")
    // return true
    // let x = shell.execCommand("am force-stop com.smile.gifmaker")
    // logd(x);
    // return true
    // step()
    // return true
    // var result = isAgentMode();
    // logd("代理模式", result);
    // closeFishApp()
    // ui.toast("我是JS控制的UI");
    //  主页  money.orzmake.rnfish.MainActivity
    // 广告页面 com.unity3d.services.ads.adunit.AdUnitActivity
    // com.applovin.adview.AppLovinFullscreenActivity
    // return true
    return false
}