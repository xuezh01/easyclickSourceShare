
function checkCodeInfo(){
    let userConfig = readConfigString("userConfig")
    userConfig = JSON.parse(userConfig)
    if(userConfig && userConfig.jmsh == 1){ // 接码上号
        let username = readConfigString("username")
        let password = readConfigString("password")
        let project_id = readConfigString("project_id")
        logd("checkCodeInfo", username, password, project_id);
        if (!username) {
            toast("请输入并保存接码平台的用户名")
            loge("请输入并保存接码平台的用户名")
            exit()
            return false;
        }
        if (!password) {
            toast("请输入并保存接码平台的密码")
            loge("请输入并保存接码平台的密码")
            exit()
            return false;
        }
        if (!project_id) {
            toast("请输入并保存接码平台的项目id")
            loge("请输入并保存接码平台的项目id")
            exit()
            return false;
        }
    }

    return true
}

/**
 * 获取手机号码
 */
let host = "api.haozhuma.com"
function getPhoneNumber(){
    let token = readConfigString("token")
    if(!token){
        token = login()
    }
    let project_id = readConfigString("project_id")
    let getPhoneUrl = 'http://' + host + '/sms/?api=getPhone&author=wsk0524&token='+token+'&sid=' + project_id
    logd('getPhoneUrl', getPhoneUrl)
    let res = http.httpGet(getPhoneUrl, {},  10 * 1000)
    logd(res);
    let data = JSON.parse(res)
    if(data.code == -1){
        toast("接码平台" + data.msg)
        loge("接码平台" + data.msg)
        exit()
        return false;
    }
    return data.phone
}

function login(){
    try {
        let username = readConfigString("username")
        let password = readConfigString("password")
        let loginUrl = 'http://' + host + '/sms/?api=login&user='+ username +'&pass=' + password
        logd('loginUrl', loginUrl)
        let res = http.httpGet(loginUrl, {},  10 * 1000)
        logd(res);
        let data = JSON.parse(res)
        logd(data.token);
        updateConfig("token", data.token)
        return data.token
    }catch (e){
        return null
    }
}

/**
 * 拉黑手机号
 * @param phoneNumber
 */
function addBlacklist(phoneNumber){
    if(!phoneNumber){
        return
    }
    let token = readConfigString("token")
    if(!token){
        token = login()
    }
    let project_id = readConfigString("project_id")
    let url = 'http://' + host +  '/sms/?api=addBlacklist&token=' + token + '&sid=' + project_id + '&phone=' +phoneNumber
    let res = http.httpGet(url, {},  10 * 1000)
    logd(res);
}


/**
 * 获取手机验证码
 */
function getPhoneCode(phoneNumber){
    let token = readConfigString("token")
    if(!token){
        token = login()
    }
    let project_id = readConfigString("project_id")
    logd("项目id", project_id);
    let url = 'http://' + host +  '/sms/?api=getMessage&token=' + token+'&sid='+project_id + '&phone=' + phoneNumber
    logd("getPhoneCode", phoneNumber, url);
    let res = http.httpGet(url, {},  10 * 1000)
    logd(res);
    let data = JSON.parse(res)
    if(data.code ==  0){
        return data.yzm
    }
    return false
}


function checkLogin(userName, password){
    logd("start checkLogin");
}