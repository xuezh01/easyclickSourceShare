function main() {
    // 参数设置 = main.html
    // 使用说明 = intr.html
    // 定时任务 = timer.html
    // 其他 = other.html
    ui.layout("参数设置", "main.html");
    // ui.layout("定时任务", "timer.html");
    ui.layout("接码设置", "receive_code.html");
    ui.registeH5Function("clearAppData",function(pkgName){
        //返回给网页的数据
        console.log(pkgName)
        shell.execCommand("pm clear " + pkgName)
        return pkgName
    });
}

main();