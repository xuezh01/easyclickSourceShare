/**
 * 该文件由EasyClick开发工具自动创建
 */
function main() {
    ui.layout("云控设置", "main.xml");

}

main();