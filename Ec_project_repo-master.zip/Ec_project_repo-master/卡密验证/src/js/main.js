let nodes = {
    "首页搜索":[desc("搜索").pkg("com.ss.android.ugc.aweme"),2],
    "搜索框":[clz("android.widget.EditText")],
    "搜索输入框":[desc("搜索")],
    "首页":[desc("首页，按钮")],
    "用户":[text("用户")],
    "用户列表":[clz("com.lynx.tasm.behavior.ui.LynxFlattenUI")],
    "第一个视频":[id("com.ss.android.ugc.aweme:id/mxk")],
    "点赞":[descMatch(".*点赞，喜欢.*")],
    "打开私信第一步":[desc("更多")],
    "打开私信第二步":[text("发私信")],
    "发送消息框":[clz("android.widget.EditText")],
    "发送消息":[desc("发送")],
    "会话入口":[desc("会话入口")],
    "网名":[descMatch(".*, 按钮"),0,[1,0,0,0]],
    "滚动框":[clz("androidx.recyclerview.widget.RecyclerView")]
}
let ui1content;

let letters;
let cardId;

/**
 * 测试函数
 */
function test() {
    // back();
    // clickNode(nodes["打开私信第一步"])
    // exit()
    waitBack(5,nodes["首页"])
}

/**
 * 初始化函数
 */
function init(){
    setData();

    initQYSDK("xwALX7ME9TdwjL0Wta","upoO9Evs5yg8zWjrXqDAZglq26Zsviuh",cardId)
    settings();
    setLogLevel("debug",true);
    setNodeTime(2);

    tLogi("脚本初始化3秒钟...")
    sSleep(3);
    closeLogWindow();
}

/**
 * 主函数
 */
function main(){
    openApp("com.ss.android.ugc.aweme")
    clickNode(nodes["首页搜索"])
    for (let i = 0; i < ui1content.length; i++) {
        inputSelector(nodes["搜索框"], ui1content[i])
        clickNode(nodes["搜索输入框"])
        clickNode(nodes["用户"])
        userList()
        waitBack(3)
    }
    tLogd("搜索关键词已经全部搜索完毕");
    inputSelector(nodes["搜索框"],"脚本完成")
}

/**
 * 设置ui数据
 */
function setData(){
    ui1content = readConfigString("keywords").split("\n");
    letters = readConfigString("letters").split("\n");
    cardId = readConfigString("cardId");
}

/**
 * 设置环境
 */
function settings() {
    // hotUpdate();


    checkApkVersion9();
    scriptConfig(2);
    if (!hasFloatViewPermission()) {
        let result = requestFloatViewPermission(5);
        if (!result) {
            toast2("设备没有悬浮窗权限,请打开后再启动脚本!");
            exit();
        }
    }

    // let json =  {
    //     "x":500,
    //     "y":100,
    //     "w":800,
    //     "h":900,
    //     "textSize":12,
    //     "title":"我是日志",
    //     "showTitle":false
    // }
    // setLogViewSizeEx(json);

    setFetchNodeMode(1,false,true,"nsf");
    // showLogWindow();
    // setStopCallback(function () {
    //
    //     showLogWindow();
    // })
    //
    // setExceptionCallback(function (msg) {
    //     showLogWindow();
    // });



}

function userList(){
    let users = clz("com.lynx.tasm.behavior.ui.LynxFlattenUI").getNodeInfo(1000)
    if (users){
        tLogd("找到了"+users.length.toString()+"个店铺");
        for (let i = 0; i < users.length; i++) {
            if (users[i].text==="直播按钮"){
                continue
            }
            users[i].click()
            sleep(1000)
            let zuoping1 = id("android:id/text1").getOneNodeInfo(0)
            if (zuoping1){
                zuoping1.click()
                tLogd("找到第一个作品");
                sleep(1500)
                let zuoping2 = id("com.ss.android.ugc.aweme:id/jn+").getOneNodeInfo(0)
                if (zuoping2){
                    zuoping1.click()
                    logw("111111");
                    sleep(2000)
                }
            }
            sSleep(5)
            let node1 = getNode(nodes["第一个视频"]);
            let bounds = node1.bounds;
            logd(JSON.stringify(bounds));
            clickPoint(bounds.right-10,bounds.bottom-10);
            tLogd("等待7秒")
            sleep(7000)
            clickNode(nodes["点赞"])
            waitBack()
            clickNode(nodes["打开私信第一步"])
            clickNode(nodes["打开私信第二步"])
            let name = getNode(nodes["网名"]).text;
            let node = getNode(nodes["发送消息框"],2000);


            if(!node){
                clickNode(nodes["会话入口"]);
            }
            inputSelector(nodes["发送消息框"],name+","+letters[random(0,letters.length-1)])
            clickNode(nodes["发送消息"])
            waitBack(2)

        }

    }



}
function backs(times, delay) {
    times = times || 1
    delay = delay || 1000
    for (let i = 0; i < times; i++) {
        back()
        sleep(delay)
    }
}




init();
test()
main();
// main();