

let nodes = {

    "主界面":[text(" 助力红包 ")],
    "主界面判断":[text("助力红包"),1],

    "助力":[text(" 助力 "),2],
    "红包":[textMatch(" 仅剩.+元 "),1,[3]]
}

let reFlashTime1
let reFlashTime2

// let judge
// let judgeY


function settings() {
    // hotUpdate();

    checkApkVersion9();
    scriptConfig(2);
    if (!hasFloatViewPermission()) {
        let result = requestFloatViewPermission(5);
        if (!result) {
            toast2("设备没有悬浮窗权限,请打开后再启动脚本!");
            exit();
        }
    }

    // let json =  {
    //     "x":500,
    //     "y":100,
    //     "w":800,
    //     "h":900,
    //     "textSize":12,
    //     "title":"我是日志",
    //     "showTitle":false
    // }
    // setLogViewSizeEx(json);

    setFetchNodeMode(1,false,true,"nsf");
    showLogWindow();
    setStopCallback(function () {

        showLogWindow();
    })

    setExceptionCallback(function (msg) {
        showLogWindow();
    });



}

function init(){
    settings();
    setLogLevel("info",true);
    setNodeTime(3);

    tLogi("脚本初始化3秒钟...")
    sSleep(1);
    closeLogWindow();
    setData();
}

function setData(){
    reFlashTime1 = readConfigString("reFlashTime1");
    reFlashTime2 = readConfigString("reFlashTime2");

    if(reFlashTime1 == ""){
        reFlashTime1 = 60
    }

    if(reFlashTime2 == ""){
        reFlashTime2 = 60
    }
}

function test() {
    let node2 = getAllNode(nodes["助力"],1000)

    logi(node2)
    logi(node2.length)
}


function main(){
    let tid =thread.execAsync(function() {
        while (true){
            // if(text("对方不是你的好友").getOneNodeInfo(0)){
            //     logi("非好友弹窗")
            //     let oneNodeInfo = text("继续支付").getOneNodeInfo(0);
            //     if(oneNodeInfo){
            //         oneNodeInfo.clickCenter();
            //     }
            // }
            // if(text("是否放弃本次付款？").getOneNodeInfo(0)){
            //     logi("放弃支付")
            //     let oneNodeInfo = text("放弃").getOneNodeInfo(0);
            //     if(oneNodeInfo){
            //         oneNodeInfo.clickCenter();
            //     }
            // }
            // if(textMatch(".*开通亲情卡").getOneNodeInfo(0)){
            //     logi("亲情卡弹窗")
            //     let oneNodeInfo = text("跳过").getOneNodeInfo(0);
            //     if(oneNodeInfo){
            //         oneNodeInfo.clickCenter();
            //     }
            // }
            sleep(500)
        }
    });

    openApp("com.kyk.world")

    try{
        redbag();
    }catch(e){
        loge(e);
        tLoge("脚本报错了");

        //回到主界面
        waitBack(5,nodes["主界面"])
        //回到顶部
        let node = scrollable(true)
        if(node != null){
            let result = true
            while(result){
                logi("正在返回顶部")
                result = scrollBackward(node);
                sSleep(0.5)
            }
            logi("返回完成")
        }

        main();

    }


    thread.cancelThread(tid);
}


function redbag(){
    //指定刷新时间
    // let nowTime = random(reFlashTime1,reFlashTime2);
    let swipeCount = 0;


    //用于计时
    // let secondCount =thread.execAsync(function() {
    //     while(true){
    //         second++;
    //         sSleep(1)
    //         // logi("当前是" + second + "秒")
    //     }
    // });

    while(true){
        var myDate = new Date();
        let second = myDate.getSeconds();
        toast("当前：" + second);


        if(second == 57){
            toast("到达临界值 刷新界面")

            //回到主界面
            waitBack(5,nodes["主界面"])
            //回到顶部
            // let node = scrollable(true)
            // if(node != null){
            //     let result = true
            //     while(result){
            //         toast("正在返回顶部")
            //         result = scrollBackward(node);
            //         sSleep(0.5)
            //     }
            //     toast("返回完成")
            // }

            clickNode(nodes["主界面判断"])
            // sSleep(0.2)

            toast("刷新")

            let Width = device.getScreenWidth()
            let Height = device.getScreenHeight()

            let qx = random(Width*0.4, Width*0.6)
            let zx = random(qx-100, qx+100)
            let qy = random(Height*0.4 , Height*0.5)
            let zy = random(Height*0.7 , Height*0.9)

            swipeToPoint(qx,qy,zx,zy,800)
            sSleep(1)

            //更新参数
            swipeCount = 0
            // second = 0
            // nowTimeime = random(reFlashTime1,reFlashTime2);
            // toast("下一轮刷新时间：" + nowTime)
        }

        if(swipeCount < 1){
            let node = scrollable(true)
            let result = scrollForward(node);
            swipeCount++;
            sSleep(1)

            // judge = getNodeAttrs(nodes["主界面判断"][0],"bounds")[0];
            // judgeY = judge.bottom
            // logi(judgeY)
        }

        let node = getAllNode(nodes["助力"],500)
        if(node == false){
            // toast("没有红包")

            continue;
        }else{
            //  抢红包

            // if(length == 1){
            //     // 第一个不抢
            //     logi("11111")
            //     continue
            // }

            toast("抢红包")
            // let node2 = getAllNode(nodes["助力"],1000)
            let length = node.length
            node[length-1].click();

            // let node1 = hasNode(nodes["红包"],2000)
            // if(node1){
            //     toast("有红包")
            //     clickNode(nodes["红包"])
            // }

            // if(node2[length-1].bounds.top > judgeY){
            //     node2[length-1].click();

            // }
            // clickNodeIfExist(nodes["助力"],0)

            // toast("panduan")
            clickNodeIfExist(nodes["红包"],1000)
            // toast("panduan")
            clickNodeIfExist(nodes["红包"],1000)

            //回到主界面
            waitBack(5,nodes["主界面"])
        }
    }
}

function test1(){
    // let node2 = getAllNode(nodes["助力"],1000)
    // let length = node2.length
    // node2[0].click()

    // clickNodeIfExist(nodes['助力'],1000)

    let node2 = getAllNode(nodes["助力"],1000)
    let length = node2.length

    logi()

}


init();
// test();
main();
// test1()
