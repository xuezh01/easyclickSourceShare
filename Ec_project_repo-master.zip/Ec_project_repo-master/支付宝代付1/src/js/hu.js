/**
 * 判断string类型值是否为空
 * @param value string类型值
 * @param name 变量名称
 * @param end 不存在是否结束脚本
 * @return string string类型值
 */

let sleepTime = 2;


strIsEmpty=function(value,name,end){

    name = name == null ? "string类型" : name;

    if(value == null || value.trim() === ""){
        loge(name+"变量值为空!");

        if(end){
            exit();
        }
        return null;
    }

    return value;
}



/**
 * 休息(秒)
 */
sSleep=function(sec) {
    sleep(sec * 1000);
}

/**
 * 返回停留
 */
waitBack=function(count,selector) {
    let c = count === undefined ? 1 : count;
    for (let i = 0; i < c; i++) {
        let node = selector === undefined ? null : getNode(selector,50);
        if(node != null){
            break;
        }
        back();
        sSleep(1.5);
    }
}

/**
 * 打开app包
 * @param pkg app包
 */
openApp = function (pkg) {
    logd("打开app:"+pkg);
    utils.openApp(pkg);
    sSleep(10);
};


/**
 * 日志与弹窗
 */
tLogi=function(msg) {
    logi(msg);
    toast2(msg);
}

/**
 * 日志与弹窗
 */
tLogd=function(msg) {
    logd(msg);
    toast2(msg);
}

/**
 * 日志与弹窗
 */
tLogw=function(msg) {
    logw(msg);
    toast2(msg);
}

/**
 * 日志与弹窗
 */
tLoge=function(msg) {
    loge(msg);
    toast2(msg);
}


/**
 * 脚本热更新
 */
hotUpdate=function() {
    //请求服务器是否有新版本
    let updateResult = hotupdater.updateReq();
    tLogd("请求更新是否有: " + updateResult);
    if (!updateResult) {
        tLogw("请求失败错误信息: " + hotupdater.getErrorMsg());
    } else {
        tLogd("请求数据: " + hotupdater.getUpdateResp());
        //有更新得情况下进行下载新的版本
        let path = hotupdater.updateDownload();
        tLogd("下载路径为: " + path);
        if (!path) {
            tLogw("下载IEC文件错误信息: " + hotupdater.getErrorMsg());
        } else {
            restartScript(path, true, 3)
            return;
        }
    }

    sleep(1000);
    for (var i = 0; i < 5; i++) {
        tLogd(time());
        sleep(5000)
    }
}


/**
 * 申请截图权限
 * @param timeout 超时时间，单位是毫秒
 * @param type 截屏的类型，0 自动选择，1 代表授权模式，2 代表无需权限模式（该模式前提条件：运行模式为代理模式）
 */
requestScreenCapture = function (timeout,type){
    let request = image.requestScreenCapture(timeout,type);
    logd("申请截图结果:"+request);
    if(!request){
        return false;
    }
    //申请完权限至少等1s(垃圾设备多加点)再截图,否则会截不到图
    sleep(2000);

    return true;
}


/**
 * 截图指定范围图片
 * @param sx 最左坐标
 * @param sy 最上坐标
 * @param ex 最右坐标
 * @param ey 最下坐标
 * @return AutoImage 图片
 */
captureScreen = function (sx,sy,ex,ey){
    let rImage = image.captureScreen(5, sx,sy,ex,ey);
    if(rImage == null){
        loge("截图出错!,截图范围:",sx,sy,ex,ey);
        throw new Error("截图出错!");
    }

    return rImage;
}



/**
 * 开启自动服务
 * @param count 重复开启次数
 */
autoServiceStart = function (count){

    let isSuccess = false;
    for (let i = 0; i < count; i++) {
        if (isServiceOk()) {
            isSuccess = true;
            break;
        }
        logi("尝试第"+(i+1)+"次启动环境...");
        startEnv();
    }

    if(isSuccess){
        logi("环境启动成功!");
    }else{
        loge("环境启动失败!");
        exit();
    }
}


/**
 * 添加脚本配置
 * @param runMode 运行模式：1=代理模式，2=无障碍模式
 * @param logType 日志等级：值分别是 debug,info,warn,error,off，排序分别是debug<info<warn<error<off off等于关闭所有日志
 */
scriptConfig = function (runMode,logType){

    logType = logType == null ? "debug" : logType;

    setLogLevel(logType,false);
    let rm = runMode === 1 ? "代理" : "无障碍";
    ui.setRunningMode(runMode);

    logd("运行模式:",rm);
    logd("日志等级:", logType);

    let json = {
        "node_service":"需要",
        "proxy_service":"需要",
        "auto_start_service":"否",
        "daemon_service":"是",
        "volume_start_tc":"是",
        "log_float_window":"是",
        "ctrl_float_window":"是"
    };
    ui.setECSystemConfig(json);

}


/**
 * 使用output stream输出字符串,不需要加\n
 * @param outputStream 输出流
 * @param str 输出的字符串
 */
writeStream = function(outputStream, str) {
    let str2 = new java.lang.String(str + "\n");
    outputStream.write(str2.getBytes());
}


/**
 * 使用input stream输入流读取字符串
 * @param inputStream 输入流
 * @return {null|java.lang.String} 读取到的字符串
 */
readStream = function(inputStream) {

    let arr = [];
    let i =0;
    let n;
    while(true){
        try{
            n = inputStream.read(); // 反复调用read()方法，直到返回-1
        }catch (e){
            return null;
        }

        // 这里的10表示\n
        if (n === 10) {
            break;
        }
        arr[i++] = n;
    }
    return new java.lang.String(new java.lang.String(java.lang.String.valueOf(arr)).getBytes("ISO8859-1"), "UTF-8");
}


/**
 * 返回到指定节点位置
 * @param uiSelector 指定节点
 * @param timeout 检查是否存在节点延迟时间
 */
toBack = function (uiSelector,timeout) {

    let res = false;
    for (let i = 0; i < 10; i++) {
        if(uiSelector.getOneNodeInfo(timeout) == null) {
            back();
        }else{
            res = true;
            break;
        }
    }

    if(!res){
        loge("未找到指定返回的节点,脚本结束");
        exit();
    }
}


/**
 * 输入节点输入内容
 */
inputNode = function (node,str){
    node.inputText(str);
    sSleep(sleepTime)
}

/**
 * 输入节点输入内容
 */
inputSelector = function (condition,str){
    let node = getNode(condition,5000);
    node.inputText(str);
    sSleep(sleepTime)
}


/**
 * 查找节点,没有返回null
 * @param selector 查询节点条件
 * @param timeout 等待时间
 * @return {NodeInfo} 节点信息
 */
findNode = function (selector,timeout){
    timeout = timeout === undefined ? 5000 : timeout;
    let node = null;
    let count = timeout / 500;


    count = count === 0 ? 1 : count;
    for (let i = 0; i < count; i++) {
        node = selector.getOneNodeInfo(450);
        if(node){
            break;
        }
    }

    return node;
}


/**
 * 是否存在某个节点
 * @param selectCondition 查询条件
 * @param timeout 延时
 * @return {boolean} true存在
 */
hasNode = function(selectCondition,timeout){
    sleep(100);
    let selector = selectCondition[0];
    let node = findNode(selector,timeout);
    return node != null;
}


/** 获取完整节点
 */
getAllNode = function(selectCondition,timeout){
    let selector = selectCondition[0];
    timeout = timeout === undefined || timeout == null ? 5000 : timeout;
    let parentCount = selectCondition[1] === undefined || selectCondition[1] == null ? 0 : selectCondition[1];
    let childArr = selectCondition[2] === undefined || selectCondition[2] == null ? [] : selectCondition[2];
    let arr = selector.getNodeInfo(timeout);


    let nodeArr = [];
    if(arr.length > 0){
        for (let i = 0; i < arr.length; i++) {
            let node = arr[i];
            for(let i=0;i < parentCount;i++){
                node = node.parent();
            }

            for(let i =0;i < childArr.length;i++){
                node = node.child(childArr[i]);
            }
            nodeArr.push(node);
        }
    }



    return nodeArr;
}


setNodeTime = function (time){
    sleepTime = time;
}


/**
 * 获取匹配节点
 * @param selectCondition 节点查找条件
 * @param timeout 点击后停留等待的时间(毫秒)
 * @param desc 描述
 */
getNode = function(selectCondition,timeout,desc){
    let selector = selectCondition[0];
    let parentCount = selectCondition[1] === undefined || selectCondition[1] == null ? 0 : selectCondition[1];
    let childArr = selectCondition[2] === undefined || selectCondition[2] == null ? [] : selectCondition[2];
    let node = findNode(selector,timeout);

    desc = desc === undefined ? selectCondition[0].toJSONString() :desc;
    if(node){
        logd("找到节点:"+desc);
        for(let i=0;i < parentCount;i++){
            node = node.parent();
        }

        for(let i =0;i < childArr.length;i++){
            node = node.child(childArr[i]);
        }
    }else{
        logd("未找到节点:"+desc);
    }



    return node;
}


/**
 * 如果节点存在就点击,不存在不点
 * @param selectCondition 节点查找条件
 * @param waitTime 点击后停留等待的时间(毫秒)
 * @param desc 描述
 */
clickNodeIfExist=function(selectCondition,waitTime,desc){
    let node = getNode(selectCondition,waitTime);
    desc = desc === undefined ? selectCondition[0].toJSONString() :desc;
    if(node){
        logd("点击节点:"+ desc);
        node.click();
        sSleep(sleepTime);
    }
}


/**
 * 点击节点，直到成功
 * @param selectCondition 节点查找条件
 * @param waitTime 点击后停留等待的时间(毫秒)
 * @param desc 描述
 *
 */
clickNode = function(selectCondition,waitTime,desc){
    let node = getNode(selectCondition,waitTime);
    desc = desc === undefined ? selectCondition[0].toJSONString() :desc;
    logd("点击节点:"+ desc);
    node.click();
    sSleep(sleepTime);
}

/**
 * 等待到指定时间
 * @param hour 时
 * @param min 分
 * @param waitTime 等待的秒数
 */
waitForTime = function (hour,min,waitTime){
    let date = new Date();
    date.setHours(hour);
    date.setMinutes(min);
    date.setSeconds(0);
    while(new Date().getTime() < date.getTime()){
        sSleep(waitTime);
    }
}


/**
 * 是否到指定时间
 * @param hour 时
 * @param min 分
 */
timeForTarget = function (hour,min){
    let date = new Date();
    date.setHours(hour);
    date.setMinutes(min);
    date.setSeconds(0);
    return new Date().getTime() >= date.getTime();
}


/**
 * 通过范围识别文字
 * @param x1
 * @param y1
 * @param x2
 * @param y2
 */
rangeOcr =function (x1,y1,x2,y2) {
    let imgPath = "/sdcard/ocr.png";
    image.captureToFile(3,x1,y1,x2,y2,imgPath);
    let bitmap = image.readBitmap(imgPath);
    if (!bitmap) {
        loge("读取图片失败");
        return "";
    }


    let inputImage = new org.opencv.core.Mat();
    org.opencv.android.Utils.bitmapToMat(bitmap, inputImage);
    let outputImage = new org.opencv.core.Mat();
    org.opencv.imgproc.Imgproc.resize(inputImage, outputImage, new org.opencv.core.Size(inputImage.width() * 2, inputImage.height() * 2));
    let bitmap2 = android.graphics.Bitmap.createBitmap(outputImage.cols(), outputImage.rows(), android.graphics.Bitmap.Config.ARGB_8888);
    org.opencv.android.Utils.matToBitmap(outputImage, bitmap2);


    // 对图片进行识别
    let result = ocr.ocrBitmap(bitmap2, 20 * 1000, {});
    logd(result)
    let r = "";
    if (result) {
        logd("ocr结果-》 " + JSON.stringify(result));
        for (let i = 0; i < result.length; i++) {
            let value = result[i];
            logd(value.label);
            r += value.label;
        }
    } else {
        logw("未识别到结果");
    }

    image.recycle(bitmap);
    image.recycle(bitmap2);
    return r;
}


/**
 * 判读时间是否超过targetDate
 * @param targetDate 2023-09-18
 * @return {boolean}
 */
function isDatePast(targetDate) {
    // 将传入的日期字符串解析为 Date 对象
    const targetDateObj = new Date(targetDate);

    // 获取当前日期
    const currentDate = new Date();

    // 使用 getTime 方法获取日期的时间戳，然后比较
    if (currentDate.getTime() > targetDateObj.getTime()) {
        toast("脚本已到期！！！");
        exit();
        return true; // 当前日期在传入日期之后
    } else {
        return false; // 当前日期在传入日期之前或相等
    }
}