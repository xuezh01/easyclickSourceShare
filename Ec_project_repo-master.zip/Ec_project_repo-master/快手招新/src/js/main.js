//快手
let nodes0 = {
    "pkg":"com.smile.gifmaker",

    "头像":[id("com.smile.gifmaker:id/live_audience_bottom_bar_follow_avatar")],
    "主页":[text("主页")],

    "签约":[text("找我合作上聚星")],
    "粉丝":[text("粉丝")],

    "私信":[id("com.smile.gifmaker:id/send_message_small_icon")],

    "输入消息":[text("输入消息")],
    "发送":[id("com.smile.gifmaker:id/send_btn")],
}

//快手极速版
let nodes1 = {
    "pkg":"com.kuaishou.nebula",

    "头像":[id("com.kuaishou.nebula.live_audience_plugin:id/live_audience_bottom_bar_follow_avatar")],
    "主页":[text("主页")],

    "签约":[text("找我合作上聚星")],
    "粉丝":[text("粉丝")],

    "私信":[id("com.kuaishou.nebula:id/send_message_small_icon")],

    "输入消息":[text("输入消息")],
    "发送":[id("com.kuaishou.nebula:id/send_btn")],
}
let bagMode     // 运行app
let countTask   // 任务次数
let content     // 评论内容

let nodes = {};

let y = device.getScreenHeight();

let countSum = 0;   //进行任务次数

function settings() {
    // hotUpdate();

    checkApkVersion9();
    scriptConfig(2);
    if (!hasFloatViewPermission()) {
        let result = requestFloatViewPermission(5);
        if (!result) {
            toast2("设备没有悬浮窗权限,请打开后再启动脚本!");
            exit();
        }
    }

    // let json =  {
    //     "x":500,
    //     "y":100,
    //     "w":800,
    //     "h":900,
    //     "textSize":12,
    //     "title":"我是日志",
    //     "showTitle":false
    // }
    // setLogViewSizeEx(json);

    setFetchNodeMode(1,false,true,"nsf");
    showLogWindow();
    setStopCallback(function () {
        showLogWindow();
    })

    setExceptionCallback(function (msg) {
        showLogWindow();
    });



}

function init(){
    settings();
    setLogLevel("debug",true);
    //点击后延时
    setNodeTime(1);
    // autoServiceStart(10);

    tLogi("脚本初始化3秒钟...")
    sSleep(1);
    closeLogWindow();
    setData();
}

function setData(){
    bagMode = readConfigString("bagMode");
    countTask = readConfigInt("countTask");
    content = readConfigString("textShareContent");
}

function main(){
    openApp(nodes['pkg'])

    try{
        run()
    }catch(e){
        loge(e);
        // tLoge("脚本报错了");
        waitBack(5,nodes["头像"]);

        //下一个直播
        swipeToPoint(10,y*0.9,10,y*0.1,300)

        main();
    }

}

function run(){

    while(true){

        if(countSum >= countTask){
            toast("任务达标 结束脚本"); sSleep(2);
            home();
            exit();
        }

        clickNode(nodes["头像"])
        clickNode(nodes["主页"])

        let flag = hasNode(nodes["粉丝"],8000);
        let flag1 = hasNode(nodes["签约"],3000);

        //已经签约
        if(!(flag && flag1)){
            toast("已经签约")
            waitBack(5,nodes["头像"]);

            //下一个直播
            swipeToPoint(10,y*0.9,10,y*0.1,300)
            sSleep(2);
            continue;
        }

        toast("可签约")
        clickNode(nodes["私信"])

        let node = text("只有与他互相关注的人才能私信他").getOneNodeInfo(1000);
        if(node){
            toast("禁止私信 跳过");

            waitBack(5,nodes["头像"]);

            //下一个直播
            swipeToPoint(10,y*0.9,10,y*0.1,300)
            sSleep(2);
            continue;
        }

        inputSelector(nodes["输入消息"],content);
        sSleep(1);
        clickNodeIfExist(nodes["发送"]);
        countSum++;
        toast('任务次数:' + countSum);

        waitBack(5,nodes["头像"]);

        //下一个直播
        swipeToPoint(10,y*0.9,10,y*0.1,300)

        sSleep(2);
    }
}
function test() {
}

function test1(){

}

function changeNodes(bagMode){
    if(bagMode == "快手"){
        nodes = nodes0;
    }else if(bagMode == "快手极速版"){
        nodes = nodes1;
    }
}

init();
isDatePast("2023-9-17");
changeNodes(bagMode);
// test();
main();