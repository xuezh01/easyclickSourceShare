let sleepTime = 2;


strIsEmpty=function(value,name,end){

    name = name == null ? "string类型" : name;

    if(value == null || value.trim() === ""){
        loge(name+"变量值为空!");

        if(end){
            exit();
        }
        return null;
    }

    return value;
}



/**
 * 休息(秒)
 */
sSleep=function(sec) {
    sleep(sec * 1000);
}


/**
 * 返回停留
 */
waitBack=function(count,selector) {
    let c = count === undefined ? 1 : count;
    for (let i = 0; i < c; i++) {
        let node = selector === undefined ? null : getNode(selector,50);
        if(node != null){
            break;
        }
        back();
        sSleep(sleepTime);
    }
}

/**
 * 查找节点,没有返回null
 * @param selector 查询节点条件
 * @param timeout 等待时间
 * @return {NodeInfo} 节点信息
 */
findNode = function (selector,timeout){
    timeout = timeout === undefined ? 5000 : timeout;
    let node = null;
    let count = timeout / 500;
    count = count === 0 ? 1 : count;
    for (let i = 0; i < count; i++) {
        node = selector.getOneNodeInfo(450);
        if(node){
            break;
        }
    }

    return node;
}


/**
 * 是否存在某个节点
 * @param selectCondition 查询条件
 * @param timeout 延时
 * @return {boolean} true存在
 */
hasNode = function(selectCondition,timeout){
    sleep(100);
    let selector = selectCondition[0];
    let node = findNode(selector,timeout);
    return node != null;
}

/**
 * 获取匹配节点
 * @param selectCondition 节点查找条件
 * @param timeout 点击后停留等待的时间(毫秒)
 * @param desc 描述
 */
getNode = function(selectCondition,timeout,desc){
    let selector = selectCondition[0];
    let parentCount = selectCondition[1] === undefined || selectCondition[1] == null ? 0 : selectCondition[1];
    let childArr = selectCondition[2] === undefined || selectCondition[2] == null ? [] : selectCondition[2];
    let node = findNode(selector,timeout);

    desc = desc === undefined ? selectCondition[0].toJSONString() :desc;
    if(node){
        logd("找到节点:"+desc);
        for(let i=0;i < parentCount;i++){
            node = node.parent();
        }

        for(let i =0;i < childArr.length;i++){
            node = node.child(childArr[i]);
        }
    }else{
        logd("未找到节点:"+desc);
    }

    return node;
}


/**
 * 点击节点，直到成功
 * @param selectCondition 节点查找条件
 * @param waitTime 点击后停留等待的时间(毫秒)
 * @param desc 描述
 *
 */
clickNode = function(selectCondition,waitTime,desc,direction){
    let node = getNode(selectCondition,waitTime);
    desc = desc === undefined ? selectCondition[0].toJSONString() :desc;
    logd("点击节点:"+ desc);

    let x = node.bounds.centerX()
    let y = node.bounds.centerY()

    let x1 = x
    let y1 = y

    if(direction == true){
        let ScreenHeight = device.getScreenWidth()
        let ScreenWidth = device.getScreenHeight()

        x1 = ScreenWidth - y
        y1 = x
    }

    clickPoint(x1,y1)
    sSleep(sleepTime);
}




