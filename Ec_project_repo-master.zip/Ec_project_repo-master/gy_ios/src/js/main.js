
let nodes = {
    //---------------游戏系列---------------
    "切号":[name("UserCenter")],// 刚进游戏界面
    "账号":[name("账号")],
    "切换帐号":[name("切换帐号")],
    "登录":[name("登录")],

    //---------------辅助系列---------------
    "辅助":[bounds(2028,291, 2208,474)],
    "每日必做任务":[name("每日必做目录")],
    "跑图总目录":[name("跑图总目录")],
    "原地跑图":[name("原地跑图")],
    "切图跑图":[name("切图跑图")],

    "每日任务":[name("每日任务")],
    "原地季节蜡烛":[name("原地季节蜡烛")],
    "自动选择季节蜡烛":[name("自动选择季节蜡烛")],

    "回家":[name("回家")],
    "好滴":[name("好滴")]
}

let accSum = {}
let timeRun
let WechatAccount

let length
let firstKey
let firstValue

let jila = readResAutoImage("jila.png");
let jila1 = readResAutoImage("jila1.png");


let firstOpen = 0 //是否首次打开
let i

function setting(){
    setFetchNodeParam({"labelFilter": "1","boundsFilter":"1", "maxDepth": "20", "visibleFilter": "2", "excludedAttributes": ""})

    image.setInitParam({});

}

function setData(){
    let acc_quan = readConfigString("acc_quan").split("\n").map(String);
    let acc_si = readConfigString("acc_si").split("\n").map(String);
    let acc_ren = readConfigString("acc_ren").split("\n").map(String);

    accSum = mergeArraysToDictionary(acc_quan,acc_si,acc_ren)
    timeRun = readConfigString("timeRun")
    WechatAccount = readConfigString("WechatAccount")
}

function autoServiceStart(time) {
    for (let i = 0; i < time; i++) {
        if (isServiceOk()) {
            return true;
        }
        let started = startEnv();
        logd("第" + (i + 1) + "次启动服务结果: " + started);
        if (isServiceOk()) {
            return true;
        }
    }
    return isServiceOk();
}

/**
 * 合并账号数据
 * @param acc_quan
 * @param acc_si
 * @param acc_ren
 * @returns {{}}
 */
function mergeArraysToDictionary(acc_quan, acc_si, acc_ren) {
    const acc_sum = {};

    for (const value of acc_quan) {
        acc_sum[value] = "全";
    }

    for (const value of acc_si) {
        acc_sum[value] = "四";
    }

    for (const value of acc_ren) {
        acc_sum[value] = "任";
    }

    return acc_sum;
}

function main() {
    logd("检查自动化环境...")
    if (!autoServiceStart(3)) {
        logd("自动化服务启动失败，无法执行脚本")
        exit();
        return;
    }
    logd("开始执行脚本...")

    //账号字典长度
    length = Object.keys(accSum).length;


    openGame()

    i = 0
    for(i;i<length;i++){
        firstKey = Object.keys(accSum)[i];// 跑图类型
        firstValue = accSum[firstKey]; // 跑图账号

        AccountChange(firstOpen,firstValue)

        firstOpen = firstOpen === 0 ? 1 : 1;

        switch (firstKey){
            case "全":
                quan();
                break;
            case "四":
                logi("还没适配")
                break;
            case "任":
                ren()
                break;
            default:
                logi("还未适配")
                continue;
        }
    }

    //收蜡烛
    clickPoint(1104,154)
    sSleep(15)
    clickPoint(1104,154)
    sSleep(15)

    clickPoint(1104,154)
    sSleep(1)

}

function test() {
    let req = startEnv();
    if (!req) {
        logd("申请权限失败");
        return;
    }
//申请完权限至少等1s(垃圾设备多加点)再截图,否则会截不到图
    sleep(1000)
    //从工程目录下res文件夹下读取sms.png文件
    let sms = readResAutoImage("renwu1.png");
    sms1 = image.binaryzation(sms, 10);
    //抓取屏幕
    let aimage = image.captureFullScreen();
    aimage = image.binaryzation(aimage, 10);

    logd("aimage " + aimage);
    if (aimage != null) {
        //在图片中查找
        let points = image.findImageByColor(aimage, sms1, 0, 0, 0, 0, 0.7, 1);
        logd("points " + JSON.stringify(points));
        //这玩意是个数组
        if (points && points.length > 0) {
            for (let i = 0; i < points.length; i++) {
                logd(points[i])
                let x = points[i].x
                let y = points[i].y
                //点击坐标
                clickPoint(x, y)
            }
        }
        //图片要回收
        image.recycle(aimage)
    }
    //图片要回收
    image.recycle(sms)
}

function test1(){

    let sms = image.captureFullScreen();

    // let sms = readResAutoImage("renwu1.png");
    let sms1 = image.binaryzation(sms, 250);

    let r = utils.saveImageToAlbum(sms1);
    logi(r)
    image.recycle(sms)

}
/**
 * 任务
 */
function ren(){
    clickPoint(256,1958) //JUMP
    sSleep(4)

    clickPoint(256,1958) //JUMP


    clickNode(nodes["每日必做任务"],3000,"",true)
    clickNode(nodes["每日任务"],3000,"",true)


    clickNode(nodes["辅助"],3000,"",true)
    clickNode(nodes["每日必做任务"],3000,"",true)
    clickNode(nodes["跑图总目录"],3000,"",true)
    clickNode(nodes["原地季节蜡烛"],3000,"",true)
    sSleep(60)

    clickNode(nodes["辅助"],3000,"",true)
    clickNode(nodes["回家"],3000,"",true)
    clickPoint(1,1)
}

/**
 * 全图
 * @param time 填入的时间
 */
function quan(time){
    clickNode(nodes["辅助"],3000,"",true)
    clickNode(nodes["每日必做任务"],3000,"",true)
    clickNode(nodes["跑图总目录"],3000,"",true)
    clickNode(nodes["原地跑图"],3000,"",true)
    clickNode(nodes["原地跑图"],3000,"",true)
    clickNode(nodes["切图跑图"],3000,"",true)

    inputText(time, 100);
    sSleep(2)

    clickNode(nodes["好滴"],3000,"",true)
}

/**
 * 切换账号
 * 开始页
 * 结束页 为点击开始游戏图标
 * @param type 切号类型：0首次进入 1游戏进入
 * @param account 账号参数（手机号、邮箱号）
 * @constructor
 */
function AccountChange(type, account){
    if(type === 0){
        clickNode(nodes["切号"], 2000,"",true)
    }else{
        while(!hasNode(nodes["账号"], 1000)){
            clickPoint(1140,2130)
            sSleep(1)
        }

        clickNode(nodes["账号"], 2000,"",true)
    }

    clickNode(nodes["切换帐号"], 2000,"",true)
    sSleep(2)
    clickPoint(device.getScreenHeight()/2,device.getScreenWidth()/2)
    sSleep(1)

    while(1){

    }
}

function openGame(){
    appLaunch("com.netease.sky");
    sSleep(20)
}



setting();
setData()

test();