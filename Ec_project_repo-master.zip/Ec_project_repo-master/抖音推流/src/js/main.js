

let nodes = {
    "关注":[descMatch(".*关注，按钮")],

    "头像":[id("com.ss.android.ugc.aweme:id/user_avatar")],
    "头像1":[desc("用户头像")],
    "点赞头像":[text("头像"),,2],

    "视频":[desc("视频")],
    "评论滚动框":[descMatch(".+的头像"),3],

    "点赞":[descMatch("^未点赞，喜欢.+，按钮")],
    "已点赞":[descMatch("^已点赞，喜欢.+，按钮")],

    "收藏":[descMatch("未选中，收藏.+，按钮")],
    "已收藏":[descMatch("已选中，收藏.+，按钮")],

    "评论":[descMatch("^评论.+，按钮")],
    "评论框":[desc("at"),1,[0]],
    "发送":[text("发送").pkg("com.ss.android.ugc.aweme"),1],


    "视频1":[id("com.ss.android.ugc.aweme:id/mlu")],
    "粉丝":[text("粉丝"),,1],
    "更多":[desc("更多")],
    "私信":[text("私信"),,1],
    "发送消息":[text("发送消息")],
    "发送1":[desc("发送")],
}

function settings() {
    // hotUpdate();

    checkApkVersion9();
    scriptConfig(2);
    if (!hasFloatViewPermission()) {
        let result = requestFloatViewPermission(5);
        if (!result) {
            toast2("设备没有悬浮窗权限,请打开后再启动脚本!");
            exit();
        }
    }

    // let json =  {
    //     "x":500,
    //     "y":100,
    //     "w":800,
    //     "h":900,
    //     "textSize":12,
    //     "title":"我是日志",
    //     "showTitle":false
    // }
    // setLogViewSizeEx(json);

    setFetchNodeMode(1,false,true,"nsf");
    showLogWindow();
    setStopCallback(function () {
        showLogWindow();
    })

    setExceptionCallback(function (msg) {
        showLogWindow();
    });



}

function init(){
    settings();
    setLogLevel("debug",true);
    //点击后延时
    setNodeTime(2);
    // autoServiceStart(10);

    tLogi("脚本初始化3秒钟...")
    sSleep(1);
    closeLogWindow();
    setData();
}

function setData(){
    // bagMode = readConfigString("bagMode");
}

function main(){

    try{

    }catch(e){
        loge(e);
        tLoge("脚本报错了");
        // waitBack(5,nodes["首页"]);
        main();
    }

}

function test() {

}

function test1(){

}


function main1(){


    auto(1);

    //进入个人主页
    clickNode(nodes["头像"]);
    clickNode(nodes["头像1"]);
    clickNode(nodes["点赞头像"]);
    waitBack(1,nodes["头像1"]);

    let node = getAllNode(nodes["视频1"],3000);
    // 点击第一个视频
    node[node.length-1].clickEx();

    auto(0);
    logi("下一个视频")
    getNode(nodes["视频"]).scrollForward();
    auto(0);
    waitBack(1,nodes["头像1"])
    clickNode(nodes["粉丝"]);
    let node1 = getNode(nodes["头像1"],2000)
    if(!node1){
        logi("进不去粉丝列表")

        //TODO 进行粉丝操作
    }

    // 发私信
    clickNode(nodes["更多"]);
    clickNode(nodes["私信"]);
    let content = ""    //TODO 主播私信内容
    inputSelector(nodes["发送消息"],content);
    clickNodeIfExist(nodes["发送1"]);
    //TODO waitBack 同城




}


//点赞-打开评论区-间隔点赞评论区评论(statu == 1)-发送随机评论-返回
function auto(statu){
    clickNodeIfExist(nodes["点赞"]);
    clickNode(nodes["评论"]);

    if(statu == 1){
        // TODO 间隔点赞评论区评论
    }

    let content = "" // TODO 随机选取一个评论
    inputSelector(nodes["评论框"],content)
    clickNodeIfExist(nodes["发送"])
    waitBack(1,nodes["头像1"]);
}

init();
// test();
main();
