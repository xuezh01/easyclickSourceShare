

let nodes = {
    "我的":[text("我的")],
    "设置":[id("com.jingmai.video.live:id/iv_rightbar")],
    "设置1":[text("设置"),2],
    "退出登录":[text("退出登录"),2],

    "密码登陆":[text("密码登录")],
    "账号":[text("输入手机号")],
    "密码":[text("输入密码")],
    "用户协议":[text("已阅读并同意"),1,[0]],
    "确认":[text("确认")],
    "跳过":[text("跳过")],

    "搜索":[id('com.jingmai.video.live:id/iv_search').visible(true)],
    "搜索框":[text("关键词搜索")],
    "搜索按钮":[text("搜索")],

    "用户名":[text(userName).id("com.jingmai.video.live:id/tv_nick_name")],

    "送礼":[id("com.jingmai.video.live:id/iv_watcher_gift")],
    "金币":[id("com.jingmai.video.live:id/tv_coin_num")],
    "赠送":[text("赠送")],

    "用户":[desc("用户")],
    "全部":[desc("全部")],

}

let accountSum = []
let account;
let password;
let userName;

let length;
let i;

function settings() {
    // hotUpdate();


    checkApkVersion9();
    scriptConfig(2);
    if (!hasFloatViewPermission()) {
        let result = requestFloatViewPermission(5);
        if (!result) {
            toast2("设备没有悬浮窗权限,请打开后再启动脚本!");
            exit();
        }
    }

    // let json =  {
    //     "x":500,
    //     "y":100,
    //     "w":800,
    //     "h":900,
    //     "textSize":12,
    //     "title":"我是日志",
    //     "showTitle":false
    // }
    // setLogViewSizeEx(json);

    setFetchNodeMode(1,true,true,"nsf");
    showLogWindow();
    setStopCallback(function () {

        showLogWindow();
    })

    setExceptionCallback(function (msg) {
        showLogWindow();
    });



}

function init(){
    settings();
    setLogLevel("info",true);
    setNodeTime(1);

    tLogi("脚本初始化5秒钟...")
    sSleep(1);
    closeLogWindow();
    setData();
}

/**
 * 获取ui数据
 */
function setData(){
    accountSum = readConfigString("outWord").split("\n").map(String);
    userName = readConfigString("userName");
}

function test() {
    clickNodeIfExist(nodes["用户"],2000);
    clickNodeIfExist(nodes["全部"],2000);
    clickNodeIfExist(nodes["用户"],2000);
    clickNodeIfExist(nodes["全部"],2000);
    clickNodeIfExist(nodes["全部"],2000);
}

function main(){
    openApp("com.jingmai.video.live")
    length = accountSum.length;
    password = "zzz123456"
    i = i==undefined?0:i;

    while(i<length){
        account = accountSum[i];
        logi("当前账号：")
        logi(account)
        logi(account)
        logi(account)
        logi(account)
        logi(account)
        logi(account)
        logi(account)
        logi(account)
        logi(account)
        logi(account)
        logi(account)
        logi(account)
        logi(account)

        clickNode(nodes["我的"],4000)

        clickNode(nodes["密码登陆"],4000)
        inputSelector(nodes["账号"],account);
        inputSelector(nodes["密码"],password);
        clickNode(nodes["用户协议"],4000)
        clickNode(nodes["确认"],4000);
        clickNodeIfExist(nodes["跳过"],2000);

        clickNode(nodes["搜索"],4000);
        inputSelector(nodes["搜索框"],userName);
        clickNode(nodes["搜索按钮"],4000);

        let node = getNode(nodes["用户名"],10000)
        if(node!= null){
            node.parent().child(0).click();  sSleep(5);
        }else{
            toast("刷新");

            clickNodeIfExist(nodes["用户"],2000);
            clickNodeIfExist(nodes["全部"],2000);
            clickNodeIfExist(nodes["用户"],2000);
            clickNodeIfExist(nodes["全部"],2000);
            clickNodeIfExist(nodes["全部"],2000);


            let node = getNode(nodes["用户名"],10000)
            if(node!= null){
                node.parent().child(0).click();  sSleep(5);
            }else{
                logi("没有用户")
                exit();
            }
        }


        clickNode(nodes["送礼"],10000);

        sSleep(2);
        let numCoin = getNodeAttrs(nodes["金币"][0],"text").toString();
        numCoin = parseInt(numCoin)
        let count = ~~(numCoin / 10);


        if(count == 0){
            toast("金币不足");
        }

        setNodeTime(2);
        for(let j=0;j<count;j++){
            logi("赠送")
            clickNode(nodes["赠送"],4000);
            clickNode(nodes["送礼"],4000);
        }
        setNodeTime(1);


        i++;
        waitBack(7,nodes["我的"])

        clickNode(nodes["我的"],4000)
        clickNode(nodes["设置"],4000)
        clickNode(nodes["设置1"],4000)
        clickNode(nodes["退出登录"],4000)
    }




}

function main1(){
    let tid =thread.execAsync(function() {
        while(true){
            if(text("立即关注").getOneNodeInfo(0)){
                logi("立即关注")
                sSleep(0.5);
                back();
            }
            sleep(200)
        }
    });

    try{
        main()
    }catch(e){
        loge(e);
        tLoge("脚本报错了");
        waitBack(5,nodes["我的"]);

        clickNode(nodes["我的"],4000)
        if(hasNode(nodes["设置"],2000)) {
            clickNode(nodes["设置"], 4000)
            clickNode(nodes["设置1"], 4000)
            clickNode(nodes["退出登录"], 4000)
        }else{
            back();
        }
        main1();
    }

    thread.cancelThread(tid);
}

init()
main1()
// test()