//正常版
let nodes0 = {
    "消息":[text("消息"),1],
    "群聊":[text("群聊"),1],
    "群聊广场":[text("群聊广场"),1],
    "群聊广场滑动":[text("推荐"),5,[1,0]],
    "群聊标题":[id("com.xingin.xhs:id/exr")],
    "群聊1":[textMatch("^\\d+人")],
    "加入":[text("立即加入")],
    "已申请":[text("已申请")],

    "首页":[text("首页"),1],
    "首页滑动":[id("com.xingin.xhs:id/e0a")],    // text("发现"),7,[1,0,0,0,0,0,0,0]
    "首页标题":[id("com.xingin.xhs:id/gnq")],
    "评论按钮":[id("com.xingin.xhs:id/evt")],
    "评论按钮0":[id("com.xingin.xhs:id/commentLayout")],
    "评论按钮1":[id("com.xingin.xhs:id/dw_")],
    "评论":[text("说点什么...")],
    "评论图片":[id("com.xingin.xhs:id/e20")],
    "图片列表":[id("com.xingin.xhs:id/cpp")],
    "下一步":[text("下一步")],
    "输入内容":[id("com.xingin.xhs:id/dw_")],
    "发送":[text("发送")],

    "消息滑动":[id("com.xingin.xhs:id/ek2")],
    "更多":[id("com.xingin.xhs:id/aia")],
    "退出":[text("删除并退出"),1],
    "确定":[text("确定")],

    "置顶":[id("com.xingin.xhs:id/h_r")],
    "分享":[text("分享群邀请"),1],
    "私信":[text("私信好友"),2],
    "我的群聊":[text("我的群聊"),1],
    "群聊勾选":[id("com.xingin.xhs:id/hwx")],
    "群聊名称":[id("com.xingin.xhs:id/hws")],
    "群聊滑动":[text("搜索群聊"),3,[2,0]],
    "分享内容":[id("com.xingin.xhs:id/gev")],
    "分别发送":[text("分别发送")],
    "发送1":[text("发送")],
}


//三星版
//samsung
let nodes1= {
    "消息":[text("消息"),1],
    "群聊":[text("群聊"),1],
    "群聊广场":[text("群聊广场"),1],
    "群聊广场滑动":[text("推荐"),5,[1,0]],
    "群聊标题":[id("com.xingin.xhs:id/exr")],
    "群聊1":[textMatch("^\\d+人")],
    "加入":[text("立即加入")],
    "已申请":[text("已申请")],

    "首页":[text("首页"),1],
    "首页滑动":[id("com.xingin.xhs:id/cuh")],    // text("发现"),7,[1,0,0,0,0,0,0,0]
    "首页标题":[id("com.xingin.xhs:id/gnq")],
    "评论按钮":[id("com.xingin.xhs:id/evt")],
    "评论按钮0":[id("com.xingin.xhs:id/commentLayout")],
    "评论按钮1":[id("com.xingin.xhs:id/evt")],
    "评论":[text("说点什么...")],
    "评论图片":[id("com.xingin.xhs:id/e20")],
    "图片列表":[id("com.xingin.xhs:id/cpp")],
    "下一步":[text("下一步")],
    "输入内容":[id("com.xingin.xhs:id/dw_")],
    "发送":[text("发送")],

    "消息滑动":[id("com.xingin.xhs:id/cuh")],
    "更多":[id("com.xingin.xhs:id/aia")],
    "退出":[text("删除并退出"),1],
    "确定":[text("确定")],

    "置顶":[id("com.xingin.xhs:id/h_r")],
    "分享":[text("分享群邀请"),1],
    "私信":[text("私信好友"),2],
    "我的群聊":[text("我的群聊"),1],
    "群聊勾选":[id("com.xingin.xhs:id/hwx")],
    "群聊名称":[id("com.xingin.xhs:id/hws")],
    "群聊滑动":[text("搜索群聊"),3,[2,0]],
    "分享内容":[id("com.xingin.xhs:id/gev")],
    "分别发送":[text("分别发送")],
    "发送1":[text("发送")],
}

let nodes2 = {
    "消息":[text("消息"),1],
    "群聊":[text("群聊"),1],
    "群聊广场":[text("群聊广场"),1],
    "群聊广场滑动":[text("推荐"),5,[1,0]],
    "群聊标题":[id("com.xingin.xhs:id/exr")],
    "群聊1":[textMatch("^\\d+人")],
    "加入":[text("立即加入")],
    "已申请":[text("已申请")],

    "首页":[text("首页"),1],
    "首页滑动":[id("com.xingin.xhs:id/cuh")],    // text("发现"),7,[1,0,0,0,0,0,0,0]
    "首页标题":[id("com.xingin.xhs:id/gnq")],
    "评论按钮":[id("com.xingin.xhs:id/evt")],
    "评论按钮0":[id("com.xingin.xhs:id/commentLayout")],
    "评论按钮1":[id("com.xingin.xhs:id/evt")],
    "评论":[text("说点什么...")],
    "评论图片":[id("com.xingin.xhs:id/e20")],
    "图片列表":[id("com.xingin.xhs:id/cpp")],
    "下一步":[text("下一步")],
    "输入内容":[id("com.xingin.xhs:id/dw_")],
    "发送":[text("发送")],

    "消息滑动":[id("com.xingin.xhs:id/ek2")],
    "更多":[id("com.xingin.xhs:id/aia")],
    "退出":[text("删除并退出"),1],
    "确定":[text("确定")],

    "置顶":[id("com.xingin.xhs:id/h_r")],
    "分享":[text("分享群邀请"),1],
    "私信":[text("私信好友"),2],
    "我的群聊":[text("我的群聊"),1],
    "群聊勾选":[id("com.xingin.xhs:id/hwx")],
    "群聊名称":[id("com.xingin.xhs:id/hws")],
    "群聊滑动":[text("搜索群聊"),3,[2,0]],
    "分享内容":[id("com.xingin.xhs:id/gev")],
    "分别发送":[text("分别发送")],
    "发送1":[text("发送")],
}


let cardId;

let nodes
let count
let bagMode
let countTask
let textShareContent
let textInputContent
let numPicture
let RandomContent
let randomTime1
let randomTime2
let istextShareContent
let istextInputContent
let isnumPicture

let arrName = []    //用于去重

function settings() {
    // hotUpdate();

    checkApkVersion9();
    scriptConfig(2);
    if (!hasFloatViewPermission()) {
        let result = requestFloatViewPermission(5);
        if (!result) {
            toast2("设备没有悬浮窗权限,请打开后再启动脚本!");
            exit();
        }
    }

    // let json =  {
    //     "x":500,
    //     "y":100,
    //     "w":800,
    //     "h":900,
    //     "textSize":12,
    //     "title":"我是日志",
    //     "showTitle":false
    // }
    // setLogViewSizeEx(json);

    setFetchNodeMode(1,false,true,"nsf");
    showLogWindow();
    setStopCallback(function () {
        showLogWindow();
    })

    setExceptionCallback(function (msg) {
        showLogWindow();
    });



}

function init(){
    setData();

    initQYSDK("ksFfRH5ExDdnXAttuo","7X1ZHh1hThVC8iuUkpIozvFkfmkEFVJr",cardId)

    settings();
    setLogLevel("debug",true);
    setNodeTime(2);
    // autoServiceStart(10);

    tLogi("脚本初始化3秒钟...")
    sSleep(1);
    closeLogWindow();
}

function setData(){
    bagMode = readConfigString("bagMode");
    countTask = readConfigString("countTask");
    textShareContent = readConfigString("textShareContent");
    textInputContent = readConfigString("textInputContent");
    numPicture = readConfigString("numPicture");
    RandomContent = readConfigString("RandomContent");
    randomTime1 = readConfigString("randomTime1");
    randomTime2 = readConfigString("randomTime2");
    istextShareContent = readConfigString("istextShareContent");
    istextInputContent = readConfigString("istextInputContent");
    isnumPicture = readConfigString("isnumPicture");

    cardId = readConfigString("cardId");

    RandomContent = RandomContent.split("#");


    if(countTask == ""){
        countTask = 99999;
    }

    if(randomTime1 == ""){
        randomTime1 = 0
    }

    if(randomTime2 == ""){
        randomTime2 = 0
    }
}



/**
 * 测试
 */
function test() {
    // let node = getAllNode(nodes["置顶"]);
    //
    // node[0].click()
    // waitBack(7,nodes["首页标题"])
    // clickNodeIfExist(nodes["评论按钮0"])
    // commentPicture()



}

function test1(){
    inputText(nodes["分享内容"][0],"1111")
}

function main(){

    openApp();

    try{
        switch (bagMode){
            case "自动加群":
                autoAddQun();
                break;
            case "分享群组":
                shareQun();
                break;
            case "分享群组到群组":
                shareQunToQun();
                break;
            case "退出群组":
                exitQun();
                break;
            case "评论发图":
                commentPicture();
                break;
        }
    }catch(e){
        loge(e);
        tLoge("脚本报错了");
        waitBack(5,nodes["首页"]);
        main();
    }

}

function openApp(){
    utils.openApp("com.xingin.xhs")
    sSleep(7)
}


/**
 * 自动加群
 */
function autoAddQun(){
    count = 0

    clickNode(nodes["消息"])
    clickNode(nodes["群聊"])
    clickNode(nodes["群聊广场"])

    sSleep(2)

    while(true){
        // let node = getNode(nodes["群聊广场滑动"],2000)
        // let node1 = node.allChildren();
        // let length = node1.length

        let node = getAllNode(nodes["群聊标题"],2000);
        let length = node.length;

        let i
        for(i=0;i<length;i++){

            let node1 = node[i].parent().parent()
            node1.click();

            sSleep(2)
            clickNode(nodes["群聊1"]);

            if(!hasNode(nodes["加入"],2000)){
                waitBack(4,nodes["群聊广场滑动"])
                continue;
            }

            clickNode(nodes["加入"]);

            // 判断是否加入成功
            if(!hasNode(nodes["群聊1"],2000)){
                UIWrapper.prototype.toast("加入成功")

                count++

                if(count >= countTask){
                    UIWrapper.prototype.toast("任务完成 结束脚本")
                    exit();
                }
            }else{
                clickNode(nodes["群聊1"]);
                if(hasNode(nodes["已申请"],2000)){
                    UIWrapper.prototype.toast("加入成功 等待审核")
                }
            }

            waitBack(4,nodes["群聊广场滑动"])

            let timeWait = random(randomTime1,randomTime2);
            sSleep(timeWait)
        }

        node = getNode(nodes["群聊广场滑动"],2000)
        node.scrollForward();
        sSleep(2)
    }
}

/**
 * 退出群聊
 */
function exitQun(){
    count = 0

    clickNode(nodes["消息"])

    let node = getNode(nodes["消息滑动"], 2000)

    //  node1[0]不是消息框！！！
    let node1 = node.allChildren();
    let length = node1.length

    let touch = 1;
    while(true) {
        //超出点击范围
        if(touch+1 == length){
            node = getNode(nodes["消息滑动"],2000)
            let result = node.scrollForward();   sSleep(1);
            if(!result){
                UIWrapper.prototype.toast("删除完毕 结束脚本")
                exit();
            }

            let node1 = node.allChildren();
            let length = node1.length;
            touch = 0;
        }

        node1[touch].click()

        let flag = hasNode(nodes["更多"],2000);
        if(!flag){
            UIWrapper.prototype.toast("不是群聊")
            touch++
            waitBack(4,nodes["消息"])
            continue
        }

        clickNode(nodes["更多"])
        let result = scrollable(true).getOneNodeInfo(10000).scrollForward();;

        let flag1 = hasNode(nodes["退出"],2000)
        if(!flag1){
            UIWrapper.prototype.toast("不是群聊")
            touch++
            waitBack(4,nodes["消息"])
            continue
        }

        clickNode(nodes["退出"]);
        clickNode(nodes["确定"]);
        count++

        if(count >= countTask){
            UIWrapper.prototype.toast("任务完成 结束脚本")
            exit();
        }

        waitBack(4,nodes["消息"])

        let timeWait = random(randomTime1,randomTime2);
        sSleep(timeWait)
    }
}

/**
 * 评论发图
 */
function commentPicture(){
    count = 0

    clickNode(nodes["首页"])

    while(true){
        let node = getNode(nodes["首页滑动"],2000)
        // let node1 = node.allChildren();
        // let length = node1.length

        let node1 = getAllNode(nodes["首页标题"],2000);
        let length = node1.length
        let i
        for(i=0;i<length;i++){
            node1[i].parent().parent().parent().click();
            sSleep(1.5)
            clickNodeIfExist(nodes["评论按钮"],0)
            clickNodeIfExist(nodes["评论按钮0"],0)
            clickNodeIfExist(nodes["评论按钮"],0)
            clickNodeIfExist(nodes["评论按钮0"],0)

            if(isnumPicture == "on"){
                clickNode(nodes["评论图片"])

                let pictureAll = getAllNode(nodes["图片列表"])
                pictureAll[numPicture-1].click();   sSleep(1);
                clickNode(nodes["下一步"]);
            }


            if(istextInputContent == "on"){
                inputSelector(nodes["输入内容"],textInputContent)
                sSleep(1)
            }

            if(isnumPicture == "on" || istextInputContent == "on"){
                clickNode(nodes["发送"]);
            }

            waitBack(3,nodes["首页"])

            count++

            if(count >= countTask){
                UIWrapper.prototype.toast("任务完成 结束脚本")
                exit();
            }

            let timeWait = random(randomTime1,randomTime2);
            sSleep(timeWait)
        }

        // node = getNode(nodes["首页滑动"],2000)
        node.scrollForward();
        sSleep(2)
    }

}

/**
 * 分享群到群
 */
function shareQunToQun(){
    count = 0;
    let j;
    let length;
    let swipeCount = 0;
    let countSum = 0;
    let fini = 3;

    clickNode(nodes["消息"])
    let node = getAllNode(nodes["置顶"]);
    let i = 0
    while(i<node.length) {
        if(fini == 3){
            node[i].parent().parent().click();    sSleep(1);
            clickNode(nodes["更多"])
        }
        fini = 3;

        clickNode(nodes["分享"])
        clickNode(nodes["私信"])
        clickNode(nodes["我的群聊"])

        swipeCount = swipeCount==0?0:swipeCount+1;
        for(j=0;j<swipeCount;j++){
            logi("滑动")
            let node2 = getNode(nodes["群聊滑动"],2000)
            if(node2 == null){
                UIWrapper.prototype.toast("一页群聊 选择完毕")
                fini = 1
                break;
            }
            let result = node2.scrollForward();
            if(!result){
                UIWrapper.prototype.toast("滑动到底 选择完毕")
                fini = 1
                break;
            }
            sSleep(0.5);
        }
        if(fini == 1){
            i++;
            waitBack(6,nodes["消息"]);
            continue;
        }


        //选择所有群聊
        while(true){
            let node1 = getAllNode(nodes["群聊勾选"]);
            node1[0].click()
            sSleep(0.5)
            node1 = getAllNode(nodes["群聊勾选"]);
            node1[0].click()
            sSleep(0.5)

            length = node1.length>5?5:node1.length;

            for(j=0;j<length;j++){
                count++;    countSum++;
                node1[j].click();   sSleep(0.1);

                if(count >= countTask){
                    UIWrapper.prototype.toast("任务完成")
                    fini = 2;
                    break;
                }
                if(countSum == 9){
                    fini = 1
                    break;
                }
            }

            if(fini != 3){
                break;  //  出去发消息
            }

            logi("滑动")
            let node2 = getNode(nodes["群聊滑动"],2000)
            if(node2 == null){
                UIWrapper.prototype.toast("一页群聊 选择完毕")
                fini = 3
                break;
            }
            let result = node2.scrollForward();
            if(!result){
                UIWrapper.prototype.toast("滑动到底 选择完毕")
                fini = 3
                break;
            }
            swipeCount++;
            sSleep(0.5);
        }

        //发送
        if(istextShareContent == "on"){
            inputSelector(nodes["分享内容"],textShareContent)
            sSleep(1)
        }

        // logi("发送")
        // waitBack(6,nodes["分享"]);
        clickNodeIfExist(nodes["分别发送"],0);
        clickNodeIfExist(nodes["发送1"],0);

        if(fini == 3){
            waitBack(6,nodes["消息"]);
            i++
            let timeWait = random(randomTime1,randomTime2);
            sSleep(timeWait)
        }else if(fini == 2){
            exit();
        }
    }
}

/**
 * 分享群
 */
function shareQun() {
    shareQunToQun()
}

function changeNodes(){
    let brands = device.getBrand();
    switch (brands){
        case "samsung":
            nodes = nodes1;
            break;
        case "HONOR" || "HUAWEI" || "huawei":
            nodes = nodes2;
            break;
        default:
            nodes = nodes0;
            break;
    }
}

init();
// isDatePast('2023-09-10')
changeNodes()
// test();
main();
// shareQunToQun()

