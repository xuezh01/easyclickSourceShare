

let nodes = {
    "用户":[text("[代付]已发起代付").clz("android.widget.TextView")],

    "代付":[text("请你快来帮我付个款~"),2],
    "确认付款2":[textMatch("^确认付款.*")],
    "确认付款":[text("确认付款")],
    "完成本次付款":[text("完成本次付款")],
    "确认付款1":[text("确认交易")],
    "代付成功":[text("代付成功")],
    "订单信息":[text("订单信息")],

    "主界面":[text("朋友").pkg("com.eg.android.AlipayGphone").selected(true)],
    "滑动":[id("com.alipay.mobile.socialwidget:id/recent_list").scrollable(true)],
}

let password
let relativePosition = [5,[0,0,1,0]]
let i,j
let count
let swipe_count = 0

function settings() {
    // hotUpdate();

    checkApkVersion9();
    scriptConfig(2);
    if (!hasFloatViewPermission()) {
        let result = requestFloatViewPermission(5);
        if (!result) {
            toast2("设备没有悬浮窗权限,请打开后再启动脚本!");
            exit();
        }
    }

    // let json =  {
    //     "x":500,
    //     "y":100,
    //     "w":800,
    //     "h":900,
    //     "textSize":12,
    //     "title":"我是日志",
    //     "showTitle":false
    // }
    // setLogViewSizeEx(json);

    setFetchNodeMode(1,false,true,"nsf");
    showLogWindow();
    setStopCallback(function () {

        showLogWindow();
    })

    setExceptionCallback(function (msg) {
        showLogWindow();
    });



}

function init(){
    settings();
    setLogLevel("info",true);
    setNodeTime(3);

    tLogi("脚本初始化3秒钟...")
    sSleep(1);
    closeLogWindow();
    setData();
}

function setData(){
    password = readConfigString("password");
}



/**
 * 测试
 */
function test() {
    let node4 = getOneNodeInfo(nodes["确认付款1"][0],8000)
    if(node4){
        node4.click();
    }
}


function main(){
    let tid =thread.execAsync(function() {
        while (true){
            if(text("对方不是你的好友").getOneNodeInfo(0)){
                logi("非好友弹窗")
                let oneNodeInfo = text("继续支付").getOneNodeInfo(0);
                if(oneNodeInfo){
                    oneNodeInfo.clickCenter();
                }
            }
            if(text("是否放弃本次付款？").getOneNodeInfo(0)){
                logi("放弃支付")
                let oneNodeInfo = text("放弃").getOneNodeInfo(0);
                if(oneNodeInfo){
                    oneNodeInfo.clickCenter();
                }
            }
            if(textMatch(".*开通亲情卡").getOneNodeInfo(0)){
                logi("亲情卡弹窗")
                let oneNodeInfo = text("跳过").getOneNodeInfo(0);
                if(oneNodeInfo){
                    oneNodeInfo.clickCenter();
                }
            }
            sleep(500)
        }
    });

    try{
        pay()
    }catch(e){
        loge(e);
        tLoge("脚本报错了");
        waitBack(4,nodes["主界面"]);
        pay();
    }


    thread.cancelThread(tid);
}

/**
 * 主函数
 */
function pay(){
    tLogi("打开支付宝");
    utils.openApp("com.eg.android.AlipayGphone");
    sSleep(5)

    while(true){
        if(!hasNode(nodes["用户"],2000)){
            logi("当前页没有代付项")

            let node3 = getNode(nodes["滑动"], 2000)
            if(node3 == null && getRunningPkg() == "com.eg.android.AlipayGphone"){
                logi("一页消息")
                logi("运行结束")
                exit();
            }

            logi("返回顶部")
            while(true){
                let result = node3.scrollBackward();
                sSleep(0.5)
                if(!result){
                    logi("到达顶部 继续检测")
                    break;
                }
            }
            continue;
        }

        let node = getAllNode(nodes["用户"],2000)
        let length = node.length

        for(i=0;i<length;i++){
            let node1 = isNewMsg(node[i],relativePosition)

            //不是未读消息
            if(node1 == null){
                continue;
            }
            count = parseInt(node1["text"]) // 代付数量
            // logi(count)
            // count =2;

            node[i].click()
            if(hasNode(nodes["代付"],6000)){
                logi("有代付订单")
                let node1 = getAllNode(nodes["代付"],2000)

                for(j=1;j<=count;j++){

                    if(j != 1){
                        sSleep(1)
                        node1 = getAllNode(nodes["代付"],2000)
                    }
                    node1[node1.length-j].click() // 点击订单
                    sSleep(2)

                    clickNodeIfExist(nodes["确认付款"],0)
                    clickNodeIfExist(nodes["完成本次付款"],0)

                    let node2 = getNode(nodes["订单信息"],3000);
                    if(!node2){
                        waitBack(3,nodes["代付"])
                        continue;
                    }

                    let oneNodeInfo = text("跳过").getOneNodeInfo(0);
                    if(oneNodeInfo){
                        oneNodeInfo.clickCenter();
                    }

                    let node4 = getOneNodeInfo(nodes["确认付款1"][0],4000)
                    if(node4){
                        logi("--------确认付款--------")
                        node4.click();
                    }
                    clickNodeIfExist(nodes["确认付款2"],0)
                    sSleep(1)



                    enterPassword(password)
                    sSleep(2)
                    hasNode(nodes["代付成功"],4000)
                    waitBack(3,nodes["代付"])
                    logi("好友界面")
                }
            }
            sSleep(1)
            waitBack(1,nodes["主界面"])
            logi("主界面")
        }

        let node3 = getNode(nodes["滑动"], 2000)
        if(node3 == null && getRunningPkg() == "com.eg.android.AlipayGphone"){
            logi("一页消息")
            logi("运行结束")
            exit();
        }
        let result = node3.scrollForward();
        sSleep(2)

        if(!result){
            logi("到达底部 运行结束")
            exit();
        }
    }

}

/**
 * 判断是否存在消息红点
 */
function isNewMsg(node,relativePosition){
    let node1 = node
    let parentCount = relativePosition[0]
    let childArr = relativePosition[1]

    for(let i=0;i < parentCount;i++){
        node = node.parent();
    }

    for(let i =0;i < childArr.length;i++){
        node = node.child(childArr[i]);
        if(node == null){
            return null;
        }
    }

    return node;
}

/**
 * 支付界面输入密码
 * @param {string} password
 */
function enterPassword(password){
    let arr = password.split("");
    // logi(arr)
    let i=0

    for(i=0;i<arr.length;i++){
        let selector = id("com.alipay.android.phone.safepaybase:id/key_num_" + arr[i]);
        click(selector);
        sleep(100)
    }

}

init();
// test();
main();
