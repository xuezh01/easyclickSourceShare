let nodes = {

}

function settings() {
    // hotUpdate();

    checkApkVersion9();
    scriptConfig(2);
    if (!hasFloatViewPermission()) {
        let result = requestFloatViewPermission(5);
        if (!result) {
            toast2("设备没有悬浮窗权限,请打开后再启动脚本!");
            exit();
        }
    }

    // let json =  {
    //     "x":500,
    //     "y":100,
    //     "w":800,
    //     "h":900,
    //     "textSize":12,
    //     "title":"我是日志",
    //     "showTitle":false
    // }
    // setLogViewSizeEx(json);

    setFetchNodeMode(1,false,true,"nsf");
    showLogWindow();
    setStopCallback(function () {
        showLogWindow();
    })

    setExceptionCallback(function (msg) {
        showLogWindow();
    });



}

function init(){
    settings();
    setLogLevel("debug",true);
    //点击后延时
    setNodeTime(2);
    // autoServiceStart(10);

    tLogi("脚本初始化3秒钟...")
    sSleep(1);
    closeLogWindow();
    setData();
}

function setData(){
    // bagMode = readConfigString("bagMode");
}

function main(){

    try{

    }catch(e){
        loge(e);
        tLoge("脚本报错了");
        // waitBack(5,nodes["首页"]);
        main();
    }

}

function test() {

}

function test1(){

}

init();
// test();
main();
