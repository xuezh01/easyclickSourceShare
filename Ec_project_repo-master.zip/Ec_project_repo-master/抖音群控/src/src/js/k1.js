/* 抖音
视频分享按钮内没有微信
 */

let nodes0 = {
    "pkg":"com.ss.android.ugc.aweme",

    "搜索":[desc("搜索，按钮"),1],
    "搜索1":[clz("android.widget.EditText")],
    "搜索2":[desc("搜索")],
    "用户":[text("用户"),2],

    "第一个直播间":[descMatch(".+直播中").clickable(true)],
    "直播房":[text("点击进入直播间")],

    "用户关注":[desc("关注")],

    "关注":[descMatch(".*关注，按钮")],
    "推荐":[text("推荐"),1,null],

    "视频":[desc("视频")],
    "评论滚动框":[descMatch(".+的头像"),3],

    "点赞":[descMatch(".*点赞，喜欢.*")],
    "已点赞":[descMatch(".*已点赞，喜欢.*")],

    "收藏":[descMatch(".*选中，收藏.*")],
    "已收藏":[descMatch(".*已选中，收藏.*")],

    "评论":[descMatch("评论.*按钮")],
    "评论框":[desc("at"),1,[0]],
    "发送":[text("发送").pkg("com.ss.android.ugc.aweme"),1],

    "分享":[descMatch("分享.*按钮")],
    "分享1":[text("复制链接"),2],
    "分享2":[text("发送")],

    //------------直播--------------
    "直播主播":[id("com.ss.android.ugc.aweme:id/user_name")],
    "直播间人数":[descMatch(".*在线观众")],

    "点赞范围":[id("com.ss.android.ugc.aweme:id/caj")],
    "评论1":[desc("说点什么...")],
    "评论框1":[clz("android.widget.EditText")],
    "发送1":[desc("发送").clickable(true)],

    "更多":[desc("更多面板 按钮")],
    "分享11":[text("分享"),1],
    "分享微信2":[desc("微信好友")],
    "去微信粘贴":[text("去微信粘贴")],

    "直播房2":[descMatch(".+直播中")],
    "直播间滚动框":[id("com.ss.android.ugc.aweme:id/viewpager")],
    "直播间主播名":[id("com.ss.android.ugc.aweme:id/user_name")],
    "倒计时":[textMatch("\\d{1,2}:\\d{2}").pkg("com.ss.android.ugc.aweme")],
    "关注主播":[text("关注")],
    "直播已结束":[text("直播已结束")],
    "滚动框":[text("私信给朋友"),3,[1]],
    "好友列表滚动框":[clz("androidx.recyclerview.widget.RecyclerView")],
    "我":[text("所有朋友"),1,[1,2]],
    "视频描述":[id("com.ss.android.ugc.aweme:id/desc")],
    "福袋1": [descMatch("超级福袋.*按钮").clz("com.lynx.tasm.behavior.ui.LynxFlattenUI")],
    "参与人数1":[textMatch("^\\d+人已参与")],
    "加入粉丝团1":[desc("加入粉丝团")],
    "发表评论1":[desc("一键发表评论")],
    "福袋数1":[textMatch("共\\d+份")],
    "参与任务":[desc("参与任务")],


    "参与人数2":[textMatch("^\\d+人已参加")],
    "福袋数2":[textMatch("^\\d+个福袋")],
    "发表评论2":[text("去发表评论").clickable(true)],
    "去微信粘贴2":[text("去微信粘贴")],
    "加入粉丝团2":[textMatch("加入粉丝团.+").clickable(true)],
    "点亮粉丝团2":[textMatch("点亮粉丝团.+").clickable(true)],
    "确认并不再提醒2":[text("确认并不再提醒")],
    "分享直播间2":[text("分享直播间").clickable(true)],
    "福袋2":[descMatch(".*福袋.*").clz("android.widget.Button")],
    "条件2":[text("参与条件")],
    "发送评论":[text("发送")],

    "红包":[descMatch("红包.*").clickable(true).clz("android.widget.Button")],
    "红包剩余秒数":[clz("android.widget.TextView").textMatch("倒计时.+").pkg("com.ss.android.ugc.aweme")],
    "红包价值":[textMatch("价值\\d+抖币").pkg("com.ss.android.ugc.aweme")],
    "关闭":[desc("关闭").clickable(true)],
    // "红包框":[id("com.ss.android.ugc.aweme:id/dialog_view")],
    "抢红包":[desc("抢，按钮")],
    "红包已过期":[textMatch(".*红包已过期.*")],
    "抖币":[textMatch("总\\d+抖币")],
}

let exclusionConditionArr = ["仅会员可参与","1到20级","下载","唱歌", "游戏", "注册", "达到2级及以上", "达到3级及以上", "达到4级及以上", "达到5级及以上", "达到6级及以上", "达到7级及以上", "达到8级及以上", "达到9级及以上", "达到10级及以上"];


function test() {
    // commentLive1()
    // clickNode(nodes2["去微信粘贴"]);
}

function init(){
    settings();
    setLogLevel("info",true);
    setNodeTime(2);

    tLogi("脚本初始化3秒钟...")
    sSleep(3);
    closeLogWindow();
    setData();
}

function setData(){
    deviceIp = readConfigString("deviceIp");
    deviceId = readConfigString("deviceId");
}

function settings() {
    // hotUpdate();


    checkApkVersion9();
    scriptConfig(2);
    if (!hasFloatViewPermission()) {
        let result = requestFloatViewPermission(5);
        if (!result) {
            toast2("设备没有悬浮窗权限,请打开后再启动脚本!");
            exit();
        }
    }

    // let json =  {
    //     "x":500,
    //     "y":100,
    //     "w":800,
    //     "h":900,
    //     "textSize":12,
    //     "title":"我是日志",
    //     "showTitle":false
    // }
    // setLogViewSizeEx(json);

    setFetchNodeMode(1,false,true,"nsf");
    showLogWindow();
    setStopCallback(function () {

        showLogWindow();
    })

    setExceptionCallback(function (msg) {
        showLogWindow();
    });



}

/**
 * 对指定视频点赞，收藏，随机评论，分享
 * @param videoId 视频id
 */
function videoWatch0(videoId){
    let content = getRandomContent(contentVideo);


    openVideo(videoId)
    sSleep(5)
    logi("等待5秒")

    clickNodeIfExist(nodes0["点赞"])
    //火山版没有收藏
    clickNodeIfExist(nodes0["收藏"])
    clickNode(nodes0["评论"])
    inputNode(getNode(nodes0["评论框1"]),content);
    clickNodeIfExist(nodes0["发送"])
    waitBack(1,nodes0["分享"])
    clickNode(nodes0["分享"])
    clickNodeIfExist(nodes0["分享1"],3000)
    sSleep(1);
    waitBack(1,nodes0["分享"]);
}

/**
 *
 * @param videoIds
 */
function runvideoWatch(videoIds){
    let arrId = videoIds.split("\n");
    let i;
    i = i==undefined?0:i;

    try{
        while(i<arrId.length) {
            logd(arrId[i]);
            videoWatch0(arrId[i]);
            // videoWatch0("7271152805774216509")
            i++;
        }
    }catch(e){
        loge(e);
        tLoge("脚本报错了");
        waitBack(5,nodes0["推荐"]);

        runvideoWatch(videoIds)
    }
}

/**
 * 随机刷视频 随机停留时间[a-b,a+b] 点赞 刷评论
 * @param initValue 初值a
 * @param range 范围b
 * @param probabilty1 点赞概率 0-100
 * @param probabilty2 评论概率
 * @param probabilty3 关注概率
 * @param probabilty4 分享概率
 * @param probabilty5 收藏概率
 */
function autoWatch0(initValue,range,probabilty1,probabilty2,probabilty3,probabilty4,probabilty5){

    waitBack(7,nodes0["推荐"])
    clickNode(nodes0["推荐"])
    clickNode(nodes0["推荐"])
    while(true){
        logi("下一个视频")
        getNode(nodes0["视频"]).scrollForward();

        if(!hasNode(nodes0["分享"],2000)){
            logi("不是视频")
            continue;
        }

        let a = getRandomNumber(initValue,range)
        let p1 = getRandomBoolean(probabilty1)
        let p2 = getRandomBoolean(probabilty2)
        let p3 = getRandomBoolean(probabilty3)
        let p4 = getRandomBoolean(probabilty4)
        let p5 = getRandomBoolean(probabilty5)
        logi("等待" + a + "秒")

        if(p1 || p2 || p3 || p4 || p5){
            let waitTime = a-10>=0 ? a-10 : a;
            sSleep(waitTime)

            if(p1) clickNodeIfExist(nodes0["点赞"]);  //有可能点赞过 IfExist
            if(p3) clickNodeIfExist(nodes0["用户关注"]);
            if(p5) clickNodeIfExist(nodes0["收藏"]);
            if(p2){
                /* 随机翻评论
                logi("打开评论区")
                clickNode(nodes0["评论"])

                // 随机次数滑动评论区
                let count = random(0,3)
                logi("翻动" + count + "次")
                for(let i=0;i<count;i++){
                    getNode(nodes0['评论滚动框']).scrollForward()
                    sSleep(2)
                }
                waitBack(1)
                */

                let content = getRandomContent(contentGrow);

                clickNode(nodes0["评论"])
                inputNode(getNode(nodes0["评论框1"]),content);
                clickNodeIfExist(nodes0["发送"])
                waitBack(1,nodes0["分享"])
            }
            if(p4){
                clickNode(nodes0["分享"])
                clickNodeIfExist(nodes0["分享1"],3000)
                sSleep(1);
                waitBack(1,nodes0["分享"]);
            }

            sSleep(10)
        }else{
            sSleep(a)
        }
    }
}



/** 养号
 * json 数据
 */
function runautoWatch(json){
    try{
        autoWatch0(json.startTiming,5,json.followProbability,json.shareProbability,json.likeProbability,json.commentProbability,json.collectProbability);
    }catch(e){
        loge(e);
        tLoge("脚本报错了");
        waitBack(5,nodes0["推荐"]);

        autoWatch0(json.startTiming,5,json.followProbability,json.shareProbability,json.likeProbability,json.commentProbability,json.collectProbability);
    }
}

function commentLive0(min,max){

    let content = getRandomContent(contentLive);

    let flag = hasNode(nodes0["直播主播"],2000)
    if(!flag){
        logi("当前不在直播间")
        return false;
    }

    clickNode(nodes0["评论1"])
    inputNode(getNode(nodes0["评论框1"]),content)
    clickNode(nodes0["发送1"])
    sSleep(random(min,max))

    return true
}

/**
 * 运行函数
 * 直播界面 随机区域点赞
 * @param type 0 随机 1手动
 * @param tapX x
 * @param tapY y
 * @return {boolean}
 */
function likeLive0(type,tapX,tapY){

    let flag = hasNode(nodes0["直播主播"],2000)
    if(!flag){
        logi("当前不在直播间")
        return false;
    }

    clickRandom(tapX,tapY)

    return true
}


/**
 * 随机区域点击
 * @param x x坐标
 * @param y y坐标
 */
function clickRandom(x,y){
    let offset = 50;
    for (let i = 0; i < 15; i++) {
        let tX = random(x-offset,x+offset);
        let tY = random(y-offset,y+offset);
        doubleClickPoint(tX,tY);
        sSleep(random(0.6,1.5));
    }
}


/**
 * 运行函数
 * 直播界面 分享直播间
 * @return {boolean}
 */
function shareLive0(min,max){

    let flag = hasNode(nodes0["直播主播"],2000)
    if(!flag){
        logi("当前不在直播间")
        return false;
    }

    clickNode(nodes0["更多"])
    clickNode(nodes0["分享11"])
    clickNodeIfExist(nodes0["分享1"],3000)
    sSleep(1);
    waitBack(2,nodes0["直播间人数"]);
    sSleep(random(min,max))

    return true;
}

/**
 * 跳转视频界面
 * @param videoId
 */
function openVideo(videoId){
    let map={
        "uri":"snssdk1128://detail?id=" + videoId +"&gd_label=click_schema_yingyongbao",
    };
    utils.openActivity(map);
}

/**
 * 运行函数
 * 跳转到用户主页关注
 * @param userId 抖音号
 *
 */
function addFollow0(userId){
    // let map={
    //     "uri":"snssdk1128://user/profile/" + userId + "?refer=web&gd_label=click_wap_download_follow&type=need_follow&needlaunchlog=1",
    // };
    // utils.openActivity(map);
    waitBack(7,nodes0["推荐"])
    clickNode(nodes0["搜索"])
    inputNode(getNode(nodes0["搜索1"]),userId)
    clickNode(nodes0["搜索2"])
    clickNode(nodes0["用户"])

    let node = [descMatch(".+抖音号：" + userId + "按钮")]
    let node1 = [descMatch(".+抖音号：" + userId + "按钮"),1,[1]]
    if(!hasNode(node, 5000)){
        logi("没有此用户")
        return false
    }
    clickNode(node1)
    waitBack(4,nodes0["分享"])
}

/**
 * 运行函数
 * 在关注列表 识别用户名进入直播间
 * @param userId
 * @return {boolean}
 */
function openLive(userId){
    waitBack(7,nodes0["推荐"])
    clickNode(nodes0["搜索"])
    inputNode(getNode(nodes0["搜索1"]),userId)
    clickNode(nodes0["搜索2"])
    clickNode(nodes0["用户"])


    let node = [descMatch(".+抖音号：" + userId + "按钮")]

    clickNodeIfExist([desc("直播按钮")],3000);
    sSleep(2);

    return true
}

/**
 * 观看直播
 * @param json 数据
 */
function watchLive0(json){
    openLive(json.dyUsername)

    let lessTime = -1;   //福袋剩余目标时间戳
    let likeUseTime = 15; //点赞使用时间（秒）
    let json2 = {
        mode: 1,
        sleepTime: 10,
        onlinePeoplesMin: 0,
        onlinePeoplesMax: 10000,
        grapPeoplesMin: 0,
        grapPeoplesMax: 10000,
        bagTotalsMin: 0,
        bagTotalsMax: 10000,
        bagsMin: 0,
        bagsMax: 10000
    }
    while(true) {
        let time = new Date().getTime();
        likeLive0(json.likeMode, 600, 700);
        if(lessTime > 0 && time >= lessTime){
            sSleep(12);
            tLogi("福袋开奖了");
            waitBack(2,nodes0["直播间人数"]);
            lessTime = -1;
        }
        sSleep(waitTime)

        if(lessTime === -1){
            lessTime = neckBrag(json2);
            commentLive0(json.commentMinDelay, json.commentMaxDelay)
            shareLive0(json.shareMinDelay, json.shareMaxDelay)
        }
    }
}



/**
 *  抢红包
 *
 * @param json
 * @returns {number} 0:没有红包 1:抢到红包 -1:当两个都抢时,红包时间太大会先抢福袋
 *
 */
function neckRedPacket(json){
    let packetNode = getNode(nodes0["红包"],0);
    if(!packetNode){
        return 0;
    }

    let numNode = getNode(nodes0["直播间人数"],0);
    packetNode.clickCenter(); sSleep(2)
    let lessNodes = getAllNode(nodes0["红包剩余秒数"],0);
    let expiredRedEnvelopeNode = getNode(nodes0["红包已过期"],0);
    if(expiredRedEnvelopeNode != null){
        logw("红包已过期,下一个");
        return 0;
    }

    let lessNode = lessNodes == null ? null :lessNodes[lessNodes.length-1];
    if(lessNode != null && (lessNode.text.search("可抢") > -1 || lessNode.text.search("^\\d+$") > -1)) {
        let priceNode = getNode(nodes0["红包价值"], 0);
        let total = parseInt(priceNode.text.replace("价值","").replace("抖币",""));       //福袋价值
        let zbNum = parseInt(numNode.text);         //直播间人数量
        if (numNode.text.search("万") > -1) {
            zbNum = zbNum * 10000;
        }

        let numStr = lessNode.text;
        logd(numStr)
        let search = numStr.search("分");
        let lessSec;
        if (search > -1) {
            let mIdx = numStr.search("\\d+分");
            let sIdx = numStr.search("\\d+秒");
            logd(mIdx)
            logd(sIdx)
            lessSec = parseInt(numStr.substring(mIdx)) * 60 + parseInt(numStr.substring(sIdx));
        } else {
            lessSec = parseInt(numStr);
        }
        if (lessSec > 30 && json.mode === 2) {
            tLogw("当前剩余时间为30秒以上,先开福袋");
            waitBack(1);
            return -1;
        }

        let flag = true;

        if (json.onlinePeoplesMin > zbNum || json.onlinePeoplesMax < zbNum) {
            flag = false;
        }else if(json.bagTotalsMin > total || json.bagTotalsMax < total){
            flag =false;
        }else{
            waitTime = 1;
            tLogw("符合红包条件")
        }

        if(!flag){
            return 0;
        }

        logi(lessSec);
        lessSec = lessSec < 4 ? 4 :lessSec;

        for (let i = 0; i < lessSec*10 - 30; i++) {
            sSleep(0.1);
        }


        for (let i = 0; i < 12; i++) {
            clickPoint((bounds.left +bounds.right)/2,(bounds.top+bounds.bottom)/2);
            sSleep(0.5)
        }

    }else{
        let allNode = getAllNode(nodes0["抢红包"],0);
        if(allNode != null){

            let element = allNode[allNode.length-1];
            element.clickCenter();
        }else{
            waitBack(1, nodes0["直播间人数"]);
            return 0;
        }
    }



    sSleep(2)
    waitBack(1, nodes0["直播间人数"]);
    sSleep(2);
    packetNode = getNode(nodes0["红包"],0);
    if(packetNode){
        neckRedPacket(json);
    }
    return 1;
}


/**
 * 抢福袋
 *
 * @param json
 *  * @returns {boolean} false没有 true符合条件抢了
 *
 *
 */
function waitNeckBrag(json) {
    let num = 0;
    let node1 = getNode(nodes0["福袋1"],0);
    let node2 = getNode(nodes0["福袋2"], 0);
    let roomPeoplesNode = getNode(nodes0["直播间人数"], 0);
    if(node1){
        node1.clickCenter();
        num = 1;
    }else if(node2){
        node2.clickCenter();
        num = 2;
    }else {
        return -1;
    }

    tLogi("开始抢福袋");
    sSleep(5)
    let peoplesNode = getNode(nodes0["参与人数" + num], 0);
    let luckyBagsNode = getNode(nodes0["福袋数" + num], 0);
    let node4 = getNode(nodes0["倒计时"], 0);
    // 福袋剩余时间
    let times = node4 == null ? 0 : convertToTimestamp(Number(node4.text.split(":")[0]), Number(node4.text.split(":")[1]))
    let numberOfPeoples = parseInt(roomPeoplesNode.desc);
    if (roomPeoplesNode.desc.search("万") > -1) {
        numberOfPeoples = numberOfPeoples * 10000;      //直播间人数
    }
    let inPeoples = peoplesNode == null ? 0 : parseInt(peoplesNode.text);   //参与福袋人数
    let bags = 0;       //福袋个数
    if (luckyBagsNode != null) {
        let arr = luckyBagsNode.text.match(/\d+/);
        bags = parseInt(arr[0]);
    }

    let node6 = getNode(nodes0["抖币"]);
    let bagsTotal = 0;
    if(node6){
        let text = node6.text;
        let array = text.match(/\d+/);
        bagsTotal = parseInt(array[0]);
    }


    let delay = json.sleepTime;

    if (json.onlinePeoplesMin > numberOfPeoples || json.onlinePeoplesMax < numberOfPeoples) {
        delay = -1;
    } else if (json.grapPeoplesMin > inPeoples || json.grapPeoplesMax < inPeoples) {
        delay = -1;
    } else if (json.bagTotalsMin > bagsTotal || json.bagTotalsMax < bagsTotal) {
        delay = -1;
    } else if (json.bagsMin > bags || json.bagsMax < bags) {
        delay = -1;
    } else {
        waitTime = 1;
    }

    if (delay === -1) {
        tLogw("当前直播间不符合人数条件,下一个");
        return false;
    }


    let node, nodeArr;
    if (num === 1) {
        let allNode = getAllNode(nodes0["参与任务"]);
        let idx = allNode[allNode.length - 1].index;
        nodeArr = [];
        for (let i = 1; i < 7; i++) {
            let nodeInfo = clz("com.lynx.tasm.behavior.ui.text.FlattenUIText").index(idx + i).getOneNodeInfo(100);
            if (nodeInfo != null) {
                nodeArr.push(nodeInfo);
            }
        }

        for (let i = 0; i < nodeArr.length; i++) {
            let node3 = nodeArr[i];
            for (let j = 0; j < exclusionConditionArr.length; j++) {
                if (node3.text.indexOf(exclusionConditionArr[j]) > -1) {
                    tLogw("条件中包含" + exclusionConditionArr[j] + ",下一家")
                    return false;
                }
            }
        }

        for (let i = 0; i < 2; i++) {


            let n1 = getNode(nodes0["发表评论1"], 0);
            let n2 = getNode(nodes0["加入粉丝团1"], 0);
            if (n1) {
                n1.click();
                sSleep(2);
            } else if (n2) {
                n2.click();
                sSleep(2);
            } else {
                break;
            }

            clickNode(nodes0["福袋1"])
        }

        clickNode(nodes0["福袋1"])
    } else if (num === 2) {
        node = getNode(nodes0["条件2"], 1000);
        for (let k = 1; k <= 2; k++) {
            try {
                let node4 = node.parent().child(node.index + k);
                nodeArr = node4.allChildren();
                for (let i = 0; i < nodeArr.length; i++) {
                    let node3 = nodeArr[i];
                    logd(node3.text);
                    for (let j = 0; j < exclusionConditionArr.length; j++) {
                        if (node3.text.indexOf(exclusionConditionArr[j]) > -1) {
                            tLogw("条件中包含" + exclusionConditionArr[j] + ",下一家")
                            return false;
                        }
                    }
                }
            } catch (e) {
                return false;
            }
        }

        for (let i = 0; i < 3; i++) {


            let n1 = getNode(nodes0["发表评论2"], 0);
            let n2 = getNode(nodes0["加入粉丝团2"], 0);
            let n3 = getNode(nodes0["点亮粉丝团2"], 0);
            let n4 = getNode(nodes0["分享直播间2"], 0);
            if (n1) {
                n1.click();
                sSleep(2);
                clickNode(nodes0["发送评论"])
            } else if (n2) {
                n2.click();
                sSleep(2);
                let node5 = getNode(nodes0["确认并不再提醒2"], 0);
                if (node5) {
                    node5.click();
                    sSleep(2);
                }
            } else if (n3) {
                n3.click();
                sSleep(2);
                let node5 = getNode(nodes0["确认并不再提醒2"], 0);
                if (node5) {
                    node5.click();
                    sSleep(2);
                }
            } else if (n4) {
                n4.click();
                sSleep(2);

                clickNode(nodes0["分享微信2"]);
                clickNode(nodes0["去微信粘贴2"]);
                sSleep(2);
                utils.openApp("com.ss.android.ugc.aweme");
                sSleep(2);
                waitBack(2, nodes0["直播间人数"]);
            } else {
                break;
            }

            clickNodeIfExist(nodes0["福袋2"])

        }

        clickNodeIfExist(nodes0["福袋2"])


    }

    node4 = getNode(nodes0["倒计时"]);
    let time2 = node4.text;
    if (time2.indexOf("倒计时 ") > -1) {
        time2 = time2.split(" ")[1];
    }

    logi(time2);
    let min = parseInt(time2.split(":")[0]);
    let sec = parseInt(time2.split(":")[1]);
    let number = convertToTimestamp(min, sec);
    while (new Date().getTime() <= number) {
        tLogi("等待中...");
        sSleep(5);
    }
    sSleep(5);
    tLogi("福袋开奖了");
    sSleep(delay);

    if (num === 1) {
        waitBack(2);
    } else {
        waitBack(1);
    }


    return true;
}


function neckBrag(json){
    let num = 0;
    let node1 = getNode(nodes0["福袋1"],0);
    let node2 = getNode(nodes0["福袋2"],0);
    let roomPeoplesNode = getNode(nodes0["直播间人数"],0);
    if(node1){
        node1.clickCenter();
        num = 1;
    }else if(node2){
        node2.clickCenter();
        num = 2;
    }else {
        return -1;
    }

    tLogi("开始抢福袋");
    sSleep(5)
    let peoplesNode = getNode(nodes0["参与人数"+num],0);
    let luckyBagsNode = getNode(nodes0["福袋数"+num],0);
    let node4 = getNode(nodes0["倒计时"],0);
    // 福袋剩余时间
    let times = node4 == null ? 0 : convertToTimestamp(Number(node4.text.split(":")[0]),Number(node4.text.split(":")[1]))
    let numberOfPeoples = parseInt(roomPeoplesNode.desc);
    if(roomPeoplesNode.desc.search("万") >-1){
        numberOfPeoples = numberOfPeoples * 10000;      //直播间人数
    }
    let inPeoples = peoplesNode == null ? 0 : parseInt(peoplesNode.text);   //参与福袋人数
    let bags = 0;       //福袋个数
    if(luckyBagsNode != null){
        let arr = luckyBagsNode.text.match(/\d+/);
        bags = parseInt(arr[0]);
    }

    let node6 = getNode(nodes0["抖币"]);
    let bagsTotal = 0;
    if(node6){
        let text = node6.text;
        let array = text.match(/\d+/);
        bagsTotal = parseInt(array[0]);
    }


    let delay = json.sleepTime;

    if (json.onlinePeoplesMin > numberOfPeoples || json.onlinePeoplesMax < numberOfPeoples) {
        delay = -1;
    } else if (json.grapPeoplesMin > inPeoples || json.grapPeoplesMax < inPeoples) {
        delay = -1;
    } else if (json.bagTotalsMin > bagsTotal || json.bagTotalsMax < bagsTotal) {
        delay = -1;
    } else if (json.bagsMin > bags || json.bagsMax < bags) {
        delay = -1;
    } else {
        waitTime = 1;
    }

    if(delay === -1){
        tLogw("当前直播间不符合人数条件,下一个");
        return -1;
    }


    let node,nodeArr;
    if(num === 1){
        let allNode = getAllNode(nodes0["参与任务"]);
        let idx = allNode[allNode.length-1].index;
        nodeArr = [];
        for (let i = 1; i < 7; i++) {
            let nodeInfo = clz("com.lynx.tasm.behavior.ui.text.FlattenUIText").index(idx + i).getOneNodeInfo(100);
            if(nodeInfo != null){
                nodeArr.push(nodeInfo);
            }
        }

        for (let i = 0; i < nodeArr.length; i++) {
            let node3 = nodeArr[i];
            for (let j = 0; j < exclusionConditionArr.length; j++) {
                if (node3.text.indexOf(exclusionConditionArr[j]) > -1) {
                    tLogw("条件中包含"+exclusionConditionArr[j]+",下一家")
                    return -1;
                }
            }
        }

        for (let i = 0; i < 2; i++) {


            let n1 = getNode(nodes0["发表评论1"], 0);
            let n2 = getNode(nodes0["加入粉丝团1"], 0);
            if (n1) {
                n1.click();
                sSleep(2);
            } else if (n2) {
                n2.click();
                sSleep(2);
            } else {
                break;
            }

            clickNode(nodes0["福袋1"])
        }

        clickNode(nodes0["福袋1"])
    }else if(num === 2){
        node  = getNode(nodes0["条件2"],1000);
        for (let k = 1; k <= 2; k++) {
            try {
                let node4 = node.parent().child(node.index + k);
                nodeArr = node4.allChildren();
                for (let i = 0; i < nodeArr.length; i++) {
                    let node3 = nodeArr[i];
                    logd(node3.text);
                    for (let j = 0; j < exclusionConditionArr.length; j++) {
                        if (node3.text.indexOf(exclusionConditionArr[j]) > -1) {
                            tLogw("条件中包含" + exclusionConditionArr[j] + ",下一家")
                            return -1;
                        }
                    }
                }
            }catch (e){
                return -1;
            }
        }

        for (let i = 0; i < 3; i++) {


            let n1 = getNode(nodes0["发表评论2"], 0);
            let n2 = getNode(nodes0["加入粉丝团2"], 0);
            let n3 = getNode(nodes0["点亮粉丝团2"], 0);
            let n4 = getNode(nodes0["分享直播间2"], 0);
            if (n1) {
                n1.click();
                sSleep(2);
                clickNode(nodes0["发送评论"])
            } else if (n2) {
                n2.click();
                sSleep(2);
                let node5 = getNode(nodes0["确认并不再提醒2"], 0);
                if (node5) {
                    node5.click();
                    sSleep(2);
                }
            } else if (n3) {
                n3.click();
                sSleep(2);
                let node5 = getNode(nodes0["确认并不再提醒2"], 0);
                if (node5) {
                    node5.click();
                    sSleep(2);
                }
            } else if (n4) {
                n4.click();
                sSleep(2);

                clickNode(nodes0["分享微信2"]);
                clickNode(nodes0["去微信粘贴2"]);
                sSleep(2);
                utils.openApp("com.ss.android.ugc.aweme");
                sSleep(2);
                waitBack(2,nodes0["直播间人数"]);
            }else{
                break;
            }

            clickNodeIfExist(nodes0["福袋2"])

        }

        clickNodeIfExist(nodes0["福袋2"])


    }

    node4 = getNode(nodes0["倒计时"]);
    let time2 = node4.text;
    if(time2.indexOf("倒计时 ") > -1){
        time2 = time2.split(" ")[1];
    }

    logi(time2);
    let min = parseInt(time2.split(":")[0]);
    let sec = parseInt(time2.split(":")[1]);

    sSleep(5);
    waitBack(1);
    return convertToTimestamp(min, sec);
}

function waitSleep(time) {
    tLogi("等待"+time+"秒领取红包福袋");
    sSleep(time);
}


/**
 * 推荐页直播抢红包福袋
 * @param json
 */
function recommendBag0(json){
    clickNode(nodes0["推荐"]);
    clickNode(nodes0["推荐"]);
    while (true){
        getNode(nodes0["视频"]).scrollForward();
        sSleep(2);
        let node = getNode(nodes0["直播房"],0);
        // let zbNode = getNode(nodes0["直播房2"],0);
        if (node) {
            node.click(); sSleep(0.5);

            while(true) {
                while (getGrabBag(json)) {
                    waitSleep(waitTime);
                }

                waitBack(2,nodes0["直播间人数"]);
                if(getNode(nodes0["直播间人数"],0) == null){
                    break;
                }

                getNode(nodes0["直播间滚动框"]).scrollForward();
                sSleep(3);

                let node3 = getNode(nodes0["直播间人数"],0);
                let node4 = getNode(nodes0["直播已结束"], 0);
                if(node3){

                }else if (node4) {
                    while (true) {
                        getNode(nodes0["直播间滚动框"]).scrollForward();
                        sSleep(3);
                        node4 = getNode(nodes0["直播已结束"], 0);
                        if (node4 == null) {
                            break;
                        }
                    }
                } else{
                    break;
                }
            }
        }
    }
}

function getGrabBag(json){
    getNode(nodes0["直播间人数"],10000);
    if(getNode(nodes0["直播已结束"],0)){
        tLogw("直播已结束");
        return false;
    }

    if(json.mode === 0){
        return neckRedPacket(json) === 1;
    }else if(json.mode === 1){
        return waitNeckBrag(json)
    }else{
        let num = neckRedPacket(json);
        let b;
        if(num === 1){
            b = waitNeckBrag(json);
        }else if(num === 0){
            waitNeckBrag(json);
            return false;
        }else{
            b = waitNeckBrag(json);
            neckRedPacket(json);
        }

        return b;
    }


}
