
let liveJson = {}

let growJson = {}

let watchJson = {}

let bagJson = {}

let contentGrow ;
let contentVideo;
let contentLive;
let deviceIp,deviceName;
let runningTime; // 运行时间(秒) 0不启用
let waitTime=5;    //  间隔时间
let delayTime;   //  延时时间
let secondNow = 0; // 当前运行时间
let jsonData = {};
let runningApp;

//本地测试
let appMode
let runMode

let Timewait
let probabilty1
let probabilty2
let probabilty3
let probabilty4
let probabilty5

let videoIds
let userId
let userId1
let commentDelay
let shareDelay
let execAsync
let ws;

function test() {
    let num = 0;
    let node1 = getNode(nodes0["福袋1"],0);
    let node2 = getNode(nodes0["福袋2"],0);
    if(node1){
        node1.clickCenter();
        num = 1;
    }else if(node2){
        node2.clickCenter();
        num = 2;
    }else {
        return -1;
    }

    tLogi("开始抢福袋");
    sSleep(5)



    let node,nodeArr;
    if(num === 1){
        let allNode = getAllNode(nodes0["参与任务"]);
        let idx = allNode[allNode.length-1].index;
        nodeArr = [];
        for (let i = 1; i < 7; i++) {
            let nodeInfo = clz("com.lynx.tasm.behavior.ui.text.FlattenUIText").index(idx + i).getOneNodeInfo(100);
            if(nodeInfo != null){
                nodeArr.push(nodeInfo);
            }
        }

        for (let i = 0; i < nodeArr.length; i++) {
            let node3 = nodeArr[i];
            for (let j = 0; j < exclusionConditionArr.length; j++) {
                if (node3.text.indexOf(exclusionConditionArr[j]) > -1) {
                    tLogw("条件中包含"+exclusionConditionArr[j]+",下一家")
                    return -1;
                }
            }
        }

        for (let i = 0; i < 2; i++) {


            let n1 = getNode(nodes0["发表评论1"], 0);
            let n2 = getNode(nodes0["加入粉丝团1"], 0);
            if (n1) {
                n1.click();
                sSleep(2);
            } else if (n2) {
                n2.click();
                sSleep(2);
            } else {
                break;
            }

            clickNode(nodes0["福袋1"])
        }

        clickNode(nodes0["福袋1"])
    }else if(num === 2){
        node  = getNode(nodes0["条件2"],1000);
        for (let k = 1; k <= 2; k++) {
            try {
                let node4 = node.parent().child(node.index + k);
                nodeArr = node4.allChildren();
                for (let i = 0; i < nodeArr.length; i++) {
                    let node3 = nodeArr[i];
                    logd(node3.text);
                    for (let j = 0; j < exclusionConditionArr.length; j++) {
                        if (node3.text.indexOf(exclusionConditionArr[j]) > -1) {
                            tLogw("条件中包含" + exclusionConditionArr[j] + ",下一家")
                            return -1;
                        }
                    }
                }
            }catch (e){
                return -1;
            }
        }

        for (let i = 0; i < 3; i++) {


            let n1 = getNode(nodes0["发表评论2"], 0);
            let n2 = getNode(nodes0["加入粉丝团2"], 0);
            let n3 = getNode(nodes0["点亮粉丝团2"], 0);
            let n4 = getNode(nodes0["分享直播间2"], 0);
            if (n1) {
                n1.click();
                sSleep(2);
                clickNode(nodes0["发送评论"])
            } else if (n2) {
                n2.click();
                sSleep(2);
                let node5 = getNode(nodes0["确认并不再提醒2"], 0);
                if (node5) {
                    node5.click();
                    sSleep(2);
                }
            } else if (n3) {
                n3.click();
                sSleep(2);
                let node5 = getNode(nodes0["确认并不再提醒2"], 0);
                if (node5) {
                    node5.click();
                    sSleep(2);
                }
            } else if (n4) {
                n4.click();
                sSleep(2);

                clickNode(nodes0["分享微信2"]);
                clickNode(nodes0["去微信粘贴2"]);
                sSleep(2);
                utils.openApp("com.ss.android.ugc.aweme");
                sSleep(2);
                waitBack(2,nodes0["直播间人数"]);
            }else{
                break;
            }

            clickNodeIfExist(nodes0["福袋2"])

        }

        clickNodeIfExist(nodes0["福袋2"])


    }

    node4 = getNode(nodes0["倒计时"]);
    let time2 = node4.text;
    if(time2.indexOf("倒计时 ") > -1){
        time2 = time2.split(" ")[1];
    }

    logi(time2);
    let min = parseInt(time2.split(":")[0]);
    let sec = parseInt(time2.split(":")[1]);

    sSleep(5);
    waitBack(1);
    return convertToTimestamp(min, sec);
}

function init(){
    settings();
    setLogLevel("debug",true);
    setNodeTime(1);

    tLogi("脚本初始化3秒钟...")
    sSleep(3);
    closeLogWindow();
    setData();
}


function handleData() {

//     假数据
    runningApp = 1;


    waitTime = jsonData.intervalTime;
    delayTime = jsonData.delayTime;
    runningTime = jsonData.runTime * 60;
    appMode = jsonData.runningPkg;
    if (jsonData.runningMode === 1){
        liveJson = jsonData;
        contentLive = jsonData.comments
    }else if(jsonData.runningMode === 2){
        watchJson = jsonData;
        contentVideo = jsonData.comments
    }else if(jsonData.runningMode === 3){
        growJson = jsonData;
        contentGrow = jsonData.comments;
    }else if(jsonData.runningMode === 4){
        bagJson = jsonData;
    }

    runMode = jsonData.runningMode;
        
}

function main() {
    let deviceId = device.getAndroidId();
    logd(deviceId);
    let ws2 = http.newWebsocket("ws://" + deviceIp + ":7002/addDevice?deviceId=" + deviceId, null, 1);
    tLogi(ws2.connect(15000));
    let json = {
        name : deviceName,
        deviceId:deviceId
    }

    ws2.sendText(JSON.stringify(json));

    ws = http.newWebsocket("ws://" + deviceIp + ":7002/addDevice?deviceId=" + deviceId, null, 1);
    tLogi(ws.connect(15000));
    ws.setPingInterval(60000);
    ws.setWriteTimeout(10000);
    ws.setReadTimeout(10000);
    ws.setAutoReconnect(true);
    ws.onText(function (data, message) {
        logd(message);
        jsonData = JSON.parse(message);
        if (jsonData.action === "stop") {
            end();
            return;
        }

        if (execAsync != null && !thread.isCancelled(execAsync)) {
            return;
        }


        handleData();
        execAsync = thread.execAsync(function () {
            run();
        });
    });
    ws.onOpen(function () {
        tLogi("连接群控成功");
    })

    let i = 1;
    while (true) {
        try {

            if (i > 6) {
                i = 1;
                ws.sendText("1");
            }
            i++;
            sSleep(10);
        }catch (e){
            logw(e);
        }
    }
}

function setData(){
    deviceName = readConfigString("deviceName");
    deviceIp = readConfigString("deviceIp");

    appMode = readConfigString("appMode");
    runMode = readConfigString("runMode");

    Timewait = readConfigString("waitTime").split(",");
    probabilty1 = readConfigString("probabilty1");
    probabilty2 = readConfigString("probabilty2");
    probabilty3 = readConfigString("probabilty3");
    probabilty4 = readConfigString("probabilty4");
    probabilty5 = readConfigString("probabilty5");
    videoIds = readConfigString("videoIds");

    userId = readConfigString("userId");
    userId1 = readConfigString("userId1");
    commentDelay = readConfigString("commentDelay");
    shareDelay = readConfigString("shareDelay");
}

function settings() {
    // hotUpdate();


    checkApkVersion9();
    scriptConfig(2);
    if (!hasFloatViewPermission()) {
        let result = requestFloatViewPermission(5);
        if (!result) {
            toast2("设备没有悬浮窗权限,请打开后再启动脚本!");
            exit();
        }
    }

    // let json =  {
    //     "x":500,
    //     "y":100,
    //     "w":800,
    //     "h":900,
    //     "textSize":12,
    //     "title":"我是日志",
    //     "showTitle":false
    // }
    // setLogViewSizeEx(json);

    setFetchNodeMode(1,false,true,"nsf");
    showLogWindow();
    setStopCallback(function () {
        end();
        ws.close();
        showLogWindow();
    })

    setExceptionCallback(function (msg) {
        end();
        ws.close();
        showLogWindow();
    });



}


function end() {
    if(execAsync != null){
        thread.cancelThread(execAsync);
    }
    showLogWindow();
}

function run(){
    tLogi("接收到数据,开始执行脚本");
    logi("runningMode:"+runMode);
    logi("runningApp:"+appMode);
    let selectors = [text("检测到更新"),text("打开看看"),text("朋友推荐"),text("青少年模式"),text("发现通讯录朋友"),text("取消将无法在火山看到通讯录朋友，建议授权发现更多老朋友")]
    let clickSelectors = [text("以后再说"),desc("关闭"),desc("关闭"),text("我知道了"),id("com.ss.android.ugc.live:id/iv_close"),text("残忍拒绝")]
    let tid = closeAlert(selectors,clickSelectors);

    // 计算程序运行时间
    let calcSecond = thread.execAsync(function(){
        while(true){
            secondNow++;
            sSleep(1)

            // 判断运行时间
            if(secondNow >= runningTime && runningTime > 0){
                toast("运行时间结束")
                end();
            }
        }

    });

    if(appMode === 0){
        openApp("com.ss.android.ugc.aweme")
        waitBack(10,nodes0["推荐"]);

        if(runMode === 1){
            watchLive0(liveJson)
        }else if(runMode === 2){
            runvideoWatch(watchJson.videoIds)
        }else if(runMode === 3) {
            runautoWatch(growJson);
        }else if(runMode === 4){
            recommendBag0(bagJson);
        }else if(runMode === 5) {
            addFollow0(userId)
        }
    }else if(appMode === 1){
        openApp("com.ss.android.ugc.aweme.lite")
        waitBack(10,nodes1["推荐"]);

        if(runMode === 1){
            watchLive1(liveJson)
        }else if(runMode === 2){
            runvideoWatch1(watchJson.videoIds)
        }else if(runMode === 3) {
            runautoWatch1(growJson);
        }else if(runMode === 4){
            recommendBag0(bagJson);
        }else if(runMode === 5) {
            addFollow1(userId)
        }

    }else if(appMode === 2){
        openApp("com.ss.android.ugc.live")
        waitBack(10,nodes2["推荐"]);

        if(runMode === 1){
            watchLive2(liveJson)
        }else if(runMode === 2){
            runvideoWatch2(watchJson.videoIds)
        }else if(runMode === 3) {
            runautoWatch2(growJson);
        }else if(runMode === 4){
            recommendBag0(bagJson);
        }else if(runMode === 5) {
            addFollow2(userId)
        }


    }

    thread.cancelThread(tid);
    thread.cancelThread(secondNow);
}

init();
// test()
main();