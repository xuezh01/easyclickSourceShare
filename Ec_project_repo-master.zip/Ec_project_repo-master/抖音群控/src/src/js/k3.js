/* 抖音火山版
视频页没有收藏按钮
 */

let nodes2 = {
    "pkg": "com.ss.android.ugc.live",

    "搜索": [desc("搜索，按钮")],
    "搜索1": [desc("扫一扫"), 1, [0]],
    "搜索2": [desc("搜索")],
    "用户": [text("用户"), 2],

    "第一个直播间": [descMatch(".+直播中").clickable(true)],
    "直播房": [text("点击进入直播间")],

    "用户关注": [desc("关注")],

    "关注": [descMatch(".*关注，按钮")],
    "推荐": [text("推荐"), 1, null],

    "视频": [desc("视频")],
    "评论滚动框": [descMatch(".+的头像"), 3],

    "点赞": [descMatch("^未点赞，喜欢.+，按钮")],
    "已点赞": [descMatch("^已点赞，喜欢.+，按钮")],

    // "收藏":[descMatch("未选中，收藏.+，按钮")],
    // "已收藏":[descMatch("已选中，收藏.+，按钮")],

    "评论": [descMatch("^评论.+，按钮")],
    "评论框": [desc("at"), 1, [0]],
    "发送": [text("发送").pkg("com.ss.android.ugc.live"), 1],

    "分享": [descMatch("^分享.+，按钮")],
    // "分享滚动框":[id("com.ss.android.ugc.live:id/e5")],
    "分享1": [text("分享给朋友"), 3, [1, 0, 0, 0]],
    "分享2": [text("私信发送")],

    //------------直播--------------
    "直播主播": [id("com.ss.android.ugc.live:id/user_name")],
    "直播间人数": [descMatch(".*在线观众")],

    "点赞范围": [id("com.ss.android.ugc.live:id/b36")],
    "评论1": [desc("说点什么...")],
    "评论框1": [text("说点什么...")],
    "发送1": [desc("发送").clickable(true)],

    "更多": [id("com.ss.android.ugc.live:id/mz7")],
    "分享11": [text("分享"), 1],
    "去微信粘贴": [text("去微信粘贴")]
}

function test() {
    // commentLive1()
    // clickNode(nodes2["去微信粘贴"]);

}

function init() {
    settings();
    setLogLevel("info", true);
    setNodeTime(2);

    tLogi("脚本初始化3秒钟...")
    sSleep(3);
    closeLogWindow();
    setData();
}

function setData() {
    deviceIp = readConfigString("deviceIp");
    deviceId = readConfigString("deviceId");
}

function settings() {
    // hotUpdate();


    checkApkVersion9();
    scriptConfig(2);
    if (!hasFloatViewPermission()) {
        let result = requestFloatViewPermission(5);
        if (!result) {
            toast2("设备没有悬浮窗权限,请打开后再启动脚本!");
            exit();
        }
    }

    // let json =  {
    //     "x":500,
    //     "y":100,
    //     "w":800,
    //     "h":900,
    //     "textSize":12,
    //     "title":"我是日志",
    //     "showTitle":false
    // }
    // setLogViewSizeEx(json);

    setFetchNodeMode(1, false, true, "nsf");
    showLogWindow();
    setStopCallback(function () {

        showLogWindow();
    })

    setExceptionCallback(function (msg) {
        showLogWindow();
    });


}

/**
 * 对指定视频点赞，收藏，随机评论，分享
 * @param videoId 视频id
 */
function videoWatch2(videoId) {

    let content = getRandomContent(contentVideo);

    openVideo3(videoId)
    sSleep(5)
    logi("等待5秒")

    clickNodeIfExist(nodes2["点赞"])
    //火山版没有收藏
    clickNode(nodes2["评论"])
    inputSelector(nodes2["评论框"], content)
    clickNodeIfExist(nodes2["发送"])
    waitBack(1, nodes2["分享"])
    clickNode(nodes2["分享"], 2000)
    clickNodeIfExist(nodes2["分享1"], 3000)
    clickNodeIfExist(nodes2["分享2"], 2000)
    sSleep(1);
    waitBack(1, nodes2["分享"]);
}


function runvideoWatch2(videoIds) {
    let arrId = videoIds.split("\n");
    let i;
    i = i == undefined ? 0 : i;

    try {
        while (i < arrId.length) {
            videoWatch2(arrId[i]);
            i++;
        }
    } catch (e) {
        loge(e);
        tLoge("脚本报错了");
        waitBack(5, nodes2["推荐"]);

        runvideoWatch3(videoIds)
    }
}

/**
 * 随机刷视频 随机停留时间[a-b,a+b] 点赞 刷评论
 * @param initValue 初值a
 * @param range 范围b
 * @param probabilty1 点赞概率    0.1为100个视频点赞10个左右
 * @param probabilty2 (翻)评论概率
 * @param probabilty3 关注概率
 * @param probabilty4 分享概率
 */
function autoWatch2(initValue, range, probabilty1, probabilty2, probabilty3, probabilty4) {
    waitBack(7, nodes2["推荐"])

    clickNode(nodes2["推荐"])
    while (true) {
        logi("下一个视频")
        getNode(nodes2["视频"]).scrollForward();

        if (!hasNode(nodes2["分享"], 2000)) {
            logi("不是视频")
            continue;
        }

        let a = getRandomNumber(initValue, range)
        let p1 = getRandomBoolean(probabilty1)
        let p2 = getRandomBoolean(probabilty2)
        let p3 = getRandomBoolean(probabilty3)
        let p4 = getRandomBoolean(probabilty4)

        logi("等待" + a + "秒")

        if (p1 || p2 || p3 || p4) {
            let waitTime = a - 10 >= 0 ? a - 10 : a;
            sSleep(waitTime)

            if (p1) clickNodeIfExist(nodes2["点赞"]);  //有可能点赞过 IfExist
            if (p3) clickNodeIfExist(nodes2["用户关注"]);
            if (p2) {
                /* 随机翻评论
                logi("打开评论区")
                clickNode(nodes2["评论"])

                // 随机次数滑动评论区
                let count = random(0,3)
                logi("翻动" + count + "次")
                for(let i=0;i<count;i++){
                    getNode(nodes2['评论滚动框']).scrollForward()
                    sSleep(2)
                }
                waitBack(1)
                */

                let content = getRandomContent(contentGrow);

                clickNode(nodes2["评论"])
                inputSelector(nodes2["评论框"], content)
                clickNodeIfExist(nodes2["发送"])
                waitBack(1, nodes2["分享"])
            }
            sSleep(2)
            if (p4) {
                clickNode(nodes2["分享"])
                clickNodeIfExist(nodes2["分享1"], 3000)
                clickNodeIfExist(nodes2["分享2"], 2000)
                sSleep(1);
                waitBack(1, nodes2["分享"]);
            }

            sSleep(10)
        } else {
            sSleep(a)
        }
    }
}


function runautoWatch2(json) {

    try {
        autoWatch2(json.startTiming, 5, json.followProbability, json.shareProbability, json.likeProbability, json.commentProbability, json.collectProbability);
    } catch (e) {
        loge(e);
        tLoge("脚本报错了");
        waitBack(5, nodes2["推荐"]);
        getNode(nodes2["视频"]).scrollForward();

        runautoWatch2(json);
    }
}

/**
 * 直播界面 随机评论内容
 * @return {boolean}
 */
function commentLive2(commentDelay) {

    let content = getRandomContent(contentLive);

    let flag = hasNode(nodes2["直播主播"], 2000)
    if (!flag) {
        logi("当前不在直播间")
        return false;
    }

    clickNode(nodes2["评论1"])
    clickNode(nodes2["评论框1"])
    let node = getNode(nodes2["评论框1"])
    node.imeInputText(content)
    sSleep(0.5)
    clickNodeIfExist(nodes2["发送1"])
    sSleep(commentDelay)

    return true
}

/**
 * 直播界面 随机区域点赞
 * @param type 0 随机 1手动
 * @param tapX x
 * @param tapY y
 * @return {boolean}
 */
function likeLive2(type, tapX, tapY) {

    let flag = hasNode(nodes2["直播主播"], 2000)
    if (!flag) {
        logi("当前不在直播间")
        return false;
    }

    sSleep(5)
    if (type == 0) {
        let node1 = nodes2["点赞范围"][0]
        let result1 = getNodeAttrs(node1, "bounds")[0];

        // 随机点击边界
        let topValue = result1.top;
        let bottomValue = result1.bottom;
        let leftValue = result1.left;
        let rightValue = result1.right;

        let tapX = random(rightValue * 0.313 + 1, rightValue - 1)
        let tapY = random(topValue + 1, bottomValue - 1)

        // TODO 可能点到莫名其妙的东西?
        clickPoint(tapX, tapY)
        sSleep(0.2)
        clickPoint(tapX, tapY)
    } else if (type == 1) {
        clickPoint(tapX, tapY)
        sSleep(0.2)
        clickPoint(tapX, tapY)
    }

    return true
}

/**
 * 直播界面 分享直播间
 * @return {boolean}
 */
function shareLive2(shareDelay) {

    let flag = hasNode(nodes2["直播主播"], 2000)
    if (!flag) {
        logi("当前不在直播间")
        return false;
    }

    clickNode(nodes2["更多"])
    clickNode(nodes2["分享11"])
    clickNodeIfExist(nodes2["分享1"], 3000)
    clickNodeIfExist(nodes2["分享2"], 2000)
    sSleep(1);
    waitBack(2, nodes2["直播间人数"]);
    sSleep(shareDelay)

    return true;
}

/**
 * 跳转视频界面
 * @param videoId
 */
function openVideo3(videoId) {
    let map = {
        "uri": "snssdk1112://detail?id=" + videoId + "&gd_label=click_schema_yingyongbao",
    };
    utils.openActivity(map);
}

/**
 * 跳转到用户主页关注
 * @param userId
 * @return {boolean}
 */
function addFollow2(userId) {
    // let map={
    //     "uri":"snssdk1128://user/profile/" + userId + "?refer=web&gd_label=click_wap_download_follow&type=need_follow&needlaunchlog=1",
    // };
    // utils.openActivity(map);
    waitBack(7, nodes2["推荐"])

    clickNode(nodes2["搜索"])
    inputSelector(nodes2["搜索1"], userId)
    clickNode(nodes2["搜索2"])
    clickNode(nodes2["用户"])

    let node = [descMatch(".+抖音号：" + userId + "按钮")]
    let node1 = [descMatch(".+抖音号：" + userId + "按钮"), 1, [1]]
    if (!hasNode(node, 5000)) {
        logi("没有此用户")
        return false
    }
    clickNode(node1)
    waitBack(4, nodes2["分享"])
}

/**
 * 在关注列表 识别用户名进入直播间
 * @param userId
 * @return {boolean}
 */
function openLive3(userId) {

    waitBack(7, nodes2["分享"])
    clickNode(nodes2["搜索"])
    inputSelector(nodes2["搜索1"], userId)
    clickNode(nodes2["搜索2"])
    clickNode(nodes2["用户"])

    let node = [descMatch(".+抖音号：" + userId + "按钮")]
    if (!hasNode(node, 5000)) {

        clickNodeIfExist([desc("直播按钮")], 3000)
        logi("没有此用户")
        return false
    }
    let node1 = getNode(node, 2000).parent().child(0)
    if (node1.text != "直播按钮") {
        logi("用户没有在直播");
        return false
    }

    node1.click();
    sSleep(2);

    return true


    // clickNode(nodes2["关注"])
    // let i = 1;
    //
    // while(true){
    //     let node = nodes2["第一个直播间"][0]
    //     let liveName = getNodeAttrs(node,"text");
    //
    //     if(liveName == "@"+userName){
    //         break;
    //     }else if(i == 50){
    //         logi("未发现直播间")
    //         return false;
    //     }
    //
    //     getNode(nodes2["视频"]).scrollForward();
    //     sSleep(1);
    //     i++
    // }
    //
    // clickNode(nodes2["直播房"])
    // sSleep(2);
    // return true;
}


/**
 * 观看直播
 * @param json 数据
 */
function watchLive2(json) {
    openLive3(json.dyUsername)
    sSleep(waitTime)
    likeLive2(json.likeMode, json.point.x, json.point.y);
    sSleep(waitTime)
    commentLive2(json.commentDelay)
    shareLive2(json.shareDelay)
}


