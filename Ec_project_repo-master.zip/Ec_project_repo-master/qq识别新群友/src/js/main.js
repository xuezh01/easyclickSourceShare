

let nodes = {
    "主界面":[desc("快捷入口"),4,[2,0]],

    "消息":[text("消息").id("com.tencent.mobileqq:id/kbi")],
    "消息按钮":[text("消息").id("com.tencent.mobileqq:id/kbi"),1],
    "发消息":[desc("发消息")], // 个人资料界面
    "个人资料":[desc("发消息"),5,[3]],
    "qqnum1":[id("com.tencent.mobileqq:id/gmx")], // 进去就看见的普通qq号
    "qqnum2":[id("com.tencent.mobileqq:id/info")], // 隐藏在下方的qq号

    "输入1":[desc("搜索")],
    "输入11":[text("搜索").id("com.tencent.mobileqq:id/tyt")],
    "子账号":[text("联系人"),4,[1,0,0]],
    "输入2":[text("发送"),3,[0,0]],
    "发送":[text("发送")],

    "群消息":[id("com.tencent.mobileqq:id/unreadmsg"),3],
    "群员":[textMatch(".*加入了.*").id("com.tencent.mobileqq:id/graybar")],

    "群详细":[desc("群聊设置")],
    // "群聊成员":[text("群聊成员").pkg("com.tencent.mobileqq"),1],
    // "搜索3":[desc("搜索").clz("android.widget.EditText")],
    // "搜索31":[text("搜索").pkg("com.tencent.mobileqq")],
    // "取消":[text("取消").pkg("com.tencent.mobileqq")]


}

let inputNumbers
let flyModeNum
let runTimeNum
let swipeCount = 0
let len
let arrName = []
let nowName = []
let arrNum = []
let outWord = []


function settings() {
    // hotUpdate();


    checkApkVersion9();
    scriptConfig(2);
    if (!hasFloatViewPermission()) {
        let result = requestFloatViewPermission(5);
        if (!result) {
            toast2("设备没有悬浮窗权限,请打开后再启动脚本!");
            exit();
        }
    }

    // let json =  {
    //     "x":500,
    //     "y":100,
    //     "w":800,
    //     "h":900,
    //     "textSize":12,
    //     "title":"我是日志",
    //     "showTitle":false
    // }
    // setLogViewSizeEx(json);

    setFetchNodeMode(1,true,true,"nsf");
    showLogWindow();
    setStopCallback(function () {

        showLogWindow();
    })

    setExceptionCallback(function (msg) {
        showLogWindow();
    });



}

function init(){
    settings();
    setLogLevel("info",true);
    setNodeTime(2);

    tLogi("脚本初始化5秒钟...")
    sSleep(1);
    closeLogWindow();
    setData();
}

/**
 * 获取ui数据
 */
function setData(){

    inputNumbers = readConfigString("inputNumbers");
    inputNumbers = inputNumbers.split("\n").map(Number);

    flyModeNum = readConfigInt("flyModeNum");
    runTimeNum = readConfigInt("runTimeNum");
    outWord = readConfigString("outWord").split("\n").map(String);

}

function test() {
    // let node = getNode(nodes["个人资料"]);
    // node.scrollForward();


}

function main(){

    tLogi("打开QQ");
    utils.openApp("com.tencent.mobileqq");
    sSleep(5);

    try{
        run_qq()
    }catch (e) {
        loge(e);
        tLoge("脚本报错了");
        waitBack(5,nodes["消息"]);
        main();
    }
}

function run_qq(){
    while(true){
        // 发送到子账号
        if(arrNum.length !== 0){
            for(let i = 0; i < inputNumbers.length; i++){
                clickNode(nodes["输入1"], 2000)
                let SubAccounts = inputNumbers[i] // 要发送的子账号
                inputSelector(nodes["输入11"], SubAccounts)
                sSleep(2)
                let node = getNode([text("(" + SubAccounts + ")").clz("android.widget.TextView")],4000)
                logi(node)
                if(node){
                    node.parent().parent().click()
                    sSleep(2)

                    for(let j; j < arrNum.length; j++){
                        inputSelector(nodes["输入2"], arrNum[i])
                        clickNode(nodes["发送"], 4000)
                        logi(i+1 + "发送成功")
                    }
                }
                waitBack(2,nodes["消息"])
            }

            arrNum = []
        }

        if(hasNode(nodes["群消息"],6000) === true){
            logi("进入群")
            clickNode(nodes["群消息"],2000)

            if(hasNode(nodes["群员"],6000) === true){
                logi("有人加群") // 获取新群员

                let node1 = id("com.tencent.mobileqq:id/rlCommenTitle")
                let node2 = id("com.tencent.mobileqq:id/listView1")

                let result1 = getNodeAttrs(node1,"bounds")[0];
                let result2 = getNodeAttrs(node2,"bounds")[0];

                // 识图边界
                const topValue = result1.bottom;
                const bottomValue = result2.bottom;

                len = getAllNode(nodes["群员"],5000).length

                for(let i = 0; i < len; i++){


                    let str = getText(nodes["群员"][0])[i] + ""
                    str = extractUserName(str)

                    let node1 = getNodeAttrs(nodes["群员"][0],"bounds")[i]
                    
                    if(parseInt(node1.top) > parseInt(topValue) && parseInt(node1.bottom) < parseInt(bottomValue)){


                        //起始坐标
                        let dx = (parseInt(node1.left) + parseInt(node1.right)) / 2
                        let dy = (parseInt(node1.top) + parseInt(node1.bottom)) / 2

                        let step = (parseInt(node1.right) - parseInt(node1.left)) / 8
                        let k = 0
                        while(k < 4){
                            clickPoint(dx, dy)
                            sSleep(1)
                            if(hasNode(nodes["发消息"], 2000)){
                                break
                            }
                            dx -= step
                            k++
                        }

                        //进入到个人资料页
                        let node = getNode(nodes["发消息"],100)

                        if(node){
                            let judge1 = hasNode(nodes["qqnum1"],100)
                            let judge2 = hasNode(nodes["qqnum2"],100)
                            if(judge1){
                                let str1 = getText(nodes["qqnum1"][0]) + ""
                                arrNum.push(str1)
                            }else if(judge2){
                                let str1 = getText(nodes["qqnum2"][0]) + ""
                                arrNum.push(str1)
                            }else{
                                swipeToPoint(device.getScreenWidth()/2,device.getScreenHeight()-200,device.getScreenWidth()/2,device.getScreenHeight()-600,200);
                            }

                            waitBack(1,nodes["群详细"])
                        }

                    }
                }
                logi("检查完毕,返回主界面")
                waitBack(1,nodes["消息"])
            }else{
                logi("没人加群")
                back()
            }
        }else{
            logi("当前页没有消息")
            if(swipeCount !== 10){
                let node = getNode(nodes["主界面"])
                node.scrollForward();
                swipeCount++
            }else{
                swipeCount = 0
                clickNode(nodes["消息按钮"])
                logi("返回顶部")
            }

        }
    }
}

/**
 * 提取新群员名称
 * @param str
 * @returns {*|null}
 */
function extractUserName(str) {
    const regex1 = /邀请(.+?)加入了群聊/;
    const regex2 = /(.+?)加入了本群/;
    const match1 = str.match(regex1);
    const match2 = str.match(regex2);

    if (match1) {
        return match1[1];
    } else if (match2) {
        return match2[1];
    } else {
        return null; // 如果没有匹配到a邀请b或者b加入的模式，则返回null或其他适当的值
    }
}


/**
 * 判断是否查询过新群员
 * @param arrName 已获得群员名称
 * @param text 新群员名称
 * @returns {boolean}
 */
function isNameUnique(arrName, text) {
    // 判断text是否在arrName数组中出现过
    if (arrName.includes(text)) {
        return false;
    } else {
        // 将text添加进arrName数组
        arrName.push(text);
        return true;
    }
}

/**
 * 判断用户名是否包含违禁词
 * @param text 已获得群员名称
 * @param outWord 违禁词数组
 * @returns {boolean}
 */
function isTextContainsOutWord(text, outWord) {
    return !outWord.some(word => text.includes(word));
}




init();
test();

