//全民k歌
let nodes0 = {
    "pkg":"com.tencent.karaoke",

    "搜索":[desc("搜索").clz("android.widget.ImageView")],

    "输入号码":[pkg("com.tencent.karaoke").clz("android.widget.EditText").focusable(true)],
    "搜索1":[desc("搜索").clz("android.view.View")],

    "用户":[descMatch(".+用户")],
    "用户1":[descMatch(".+粉丝.+作品")],

    "关注":[text("关注").clz("android.widget.TextView"),1,],

    "关注1":[descMatch("关注|已关注").depth(15).clz("android.view.ViewGroup")],

    "动态":[desc("动态")],
    "动态时间":[id("com.tencent.karaoke:id/oe7")],
    "个人信息":[textMatch(".+｜.+").pkg("com.tencent.karaoke")],
    "粉丝数":[text("粉丝").clz("android.widget.TextView"),1,[0]],
    "歌号":[textMatch("K歌号：.+")],

    "加载完毕":[desc("加载完毕")],
    "他的关注":[desc("已选中，TA的关注"),1],

    "主界面":[id("com.tencent.karaoke:id/i5x")],

}

let sex
let age1
let age2
let numFan
let groupId

let userId

let nowAge
let nowSex
let nowFan

function settings() {
    // hotUpdate();

    checkApkVersion9();
    scriptConfig(2);
    if (!hasFloatViewPermission()) {
        let result = requestFloatViewPermission(5);
        if (!result) {
            toast2("设备没有悬浮窗权限,请打开后再启动脚本!");
            exit();
        }
    }

    let  request = image.requestScreenCapture(10000,0);
    if (!request) {
        request = image.requestScreenCapture(10000,0);
    }
    logd("申请截图结果... "+request)
    if(!request){
        loge("申请截图权限失败,检查是否开启后台弹出,悬浮框等权限")
        exit()
    }

    // let json =  {
    //     "x":500,
    //     "y":100,
    //     "w":800,
    //     "h":900,
    //     "textSize":12,
    //     "title":"我是日志",
    //     "showTitle":false
    // }
    // setLogViewSizeEx(json);

    setFetchNodeMode(1,false,true,"nsf");
    showLogWindow();
    setStopCallback(function () {
        showLogWindow();
    })

    setExceptionCallback(function (msg) {
        showLogWindow();
    });



}

function init(){
    settings();
    setLogLevel("debug",true);
    //点击后延时
    setNodeTime(0.5);
    // autoServiceStart(10);

    tLogi("脚本初始化5秒钟...")
    initOcr();
    sSleep(5);
    closeLogWindow();
    setData();
}

function setData(){
    sex = readConfigString("sex");
    age1 = readConfigInt("age1");
    age2 = readConfigInt("age2");
    numFan = readConfigInt("numFan");
    groupId = readConfigString("groupId");
}

function main(){
    openApp(nodes['pkg'])

    try{
        run()
    }catch(e){
        loge(e);
        // tLoge("脚本报错了");
        waitBack(10,nodes["主界面"])

        main();
    }

}

function run(){

    clickNodeIfExist(nodes["搜索"]);

    while(true){

        userId = getUserId(groupId);

        inputSelector(nodes["输入号码"],userId)
        clickNode(nodes["搜索1"])
        sSleep(2)
        clickNode(nodes["用户"])

        let node = getAllNode(nodes["用户1"]);
        let length = node.length>2?2:node.length;

        //搜索多结果
        for(let i=0;i<length;i++){
            //判断每个用户是否符合性别 符合就点击
            let nowNode = node[i].siblings();
            let nowSex = nowNode[nowNode.length-2].desc
            if (!nowSex.includes(sex)) {
                continue;
            }
            nowNode[0].parent().clickEx()
            sSleep(1)

            clickNode(nodes["关注"])


            //遍历关注列表
            while(true){

                let nowNode = getAllNode(nodes["关注1"]);

                if(nowNode === false){
                    tLogi("没有关注")
                    waitBack(2,nodes["用户1"])
                    break
                }

                let xx = getNode(nodes["他的关注"]).bounds.bottom + 10

                let imagePath = "/sdcard/ocr.png"
                let cap = image.captureToFile(3,0,0,device.getScreenWidth(),device.getScreenHeight(),imagePath);
                sleep(300)
                let imageX = image.readImage(imagePath);

                //遍历每页关注用户
                for (let j = 0; j < nowNode.length; j++) {

                    if(nowNode[j].bounds.top < xx){
                        continue;
                    }

                    let nowNode1 = nowNode[j].siblings();
                    let nowNode2 = nowNode1[nowNode1.length - 1].allChildren();
                    // 每个用户 性别年龄按钮范围
                    let nodeBounds = nowNode2[nowNode2.length - 2].bounds;

                    //-4370 女 -1051394 男
                    let r = image.pixel(imageX,(nodeBounds.left + nodeBounds.right)/2,(nodeBounds.top+nodeBounds.bottom)/2);
                    if(r == "-4370"){
                        nowSex = "女"
                    }else{
                        nowSex = "男"
                    }

                    //不满足条件跳过
                    if(nowSex != sex){
                        logi("条件不符")
                        continue;
                    }

                    nowAge = rangeOcr1((nodeBounds.left + nodeBounds.right)/2, nodeBounds.top, nodeBounds.right, nodeBounds.bottom)
                    nowAge = parseInt(nowAge)

                    //不满足条件跳过
                    if(nowSex != sex || (!isNaN(nowAge) && nowAge > age1 && nowAge < age2)){
                            logi("条件不符")
                            continue;
                    }

                    nowNode1[nowNode1.length-1].clickEx();
                    sSleep(1)

                    if(!hasNode(nodes["动态"],1500)){
                        tLogi("用户异常")
                        waitBack(1,nodes["关注1"])
                        continue;
                    }
                    clickNodeIfExist(nodes["动态"]);

                    //没有动态
                    if(!hasNode(nodes["动态时间"],1000)){
                        tLogi("没有动态")
                        waitBack(1,nodes["关注1"])
                        continue;
                    }
                    let timeDt = getNode(nodes["动态时间"]).text;

                    // 判断动态是否在一个月内
                    if(!judgeTime(timeDt)){
                        tLogi("动态不在一个月内")
                        waitBack(1,nodes["关注1"])
                        continue;
                    }

                    nowFan = getNode(nodes["粉丝数"]).text
                    let str = getNode(nodes["个人信息"]).text.split("｜")
                    nowSex = str[1]
                    nowAge = parseInt(str[0])

                    // 判断个人信息是否符合条件
                    if(!judgeCondition(nowSex,nowAge,nowFan)){
                        tLogi("个人信息不符合")
                        waitBack(1,nodes["关注1"])
                        continue;
                    }

                    userId = getNode(nodes["歌号"]).text.substring(4)
                    // logi(userId)
                    // logi(typeof(userId))
                    logi("符合!!!!!!")
                    uploadUserId(groupId,userId)
                    waitBack(1,nodes["关注1"])
                }
                image.recycle(imageX)

                if(hasNode(nodes["加载完毕"],2000)){
                    tLogi("检索完成")
                    waitBack(2,nodes["用户1"],)
                    break
                }

                let node = clz("androidx.recyclerview.widget.RecyclerView").scrollable(true).getOneNodeInfo(1000);
                node.scrollForward()
                sSleep(1.5)
            }
        }
        waitBack(1,nodes["搜索1"])




    }

}


function test() {
    let node = clz("androidx.recyclerview.widget.RecyclerView").scrollable(true).getOneNodeInfo(1000);
    node.scrollForward()
}


function changeNodes(){
    nodes = nodes0;
}

/**
 * 获取服务器用户id
 * @param groupId
 */
function getUserId(groupId){
    var url = "http://124.220.68.31:8088/system/userInfo/getUser";
    var pa = {"groupId": groupId};
    var x = http.httpGet(url, pa, 10 * 1000, {"User-Agent": "test"});

    return x;
}

/**
 * 上传userId
 * @param {string} groupId
 * @param {string} userId
 * @return {boolean}
 */
function uploadUserId(groupId,userId){
    let url = 'http://124.220.68.31:8088/system/userInfo/addUser';

    let pa = {
        "groupId":groupId,
        "userId":userId
    }
    let res = http.httpPost(url, pa, null, 5 * 1000, {"User-Agent": "test"});

    logi(res)

    if (res != "false") {
        // logi("上传成功");
        return true
    } else {
        tLogi("上传失败，请联系作者！");
        return false
    }
}

/**
 * 判断个人信息是否符合条件
 * @param nowSex
 * @param nowAge
 * @param nowFan
 * @return {boolean}
 */
function judgeCondition(nowSex,nowAge,nowFan){
    return nowSex == sex && (nowAge <= age1 || nowAge >= age2) && nowFan <= numFan;
}

/**
 * 判断动态时间是否为一个月内
 * @param str_time
 * @return {boolean}
 */
function judgeTime(str_time){
    var position_1 = str_time.search("转发")
    var position_2 = str_time.search("与")
    if(position_1 != -1){
        str_time = str_time.slice(0,position_1-1)
    }
    if(position_2 != -1){
        str_time = str_time.slice(0,position_2-1)
    }
    let now_time = new Date()
    if(str_time.search("昨天") != -1){
        return true
    }else if(str_time.search(/^\d\d:\d\d$/g) != -1){
        return true
    }
    if(str_time.search(/[年]/g) != -1){
        var start_time = str_time.replace(/[年月]/g,"/")
        start_time = start_time.replace(/日/g,"")
    }else{
        var start_time = str_time.replace("月","/")
        start_time = now_time.getFullYear() + "/" + start_time.replace(/日/g," ")
    }
    // toastLog(start_time)
    var sTime = new Date(start_time)
    if((now_time - sTime)/ (1000 * 3600 * 24) <= 30){
        return true
    }else{
        return false
    }
}


init();
isDatePast("2023-11-04");
changeNodes();

main();
// run()
