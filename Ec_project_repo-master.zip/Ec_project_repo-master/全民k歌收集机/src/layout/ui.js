function main() {
    // 参数设置 = main.html
    // 使用说明 = intr.html
    // 定时任务 = timer.html
    // 其他 = other.html
    ui.layout("参数设置", "main.html");
    ui.layout("使用说明", "intr.html");
    ui.layout("定时任务", "timer.html");
    ui.layout("其他", "other.html");
}

main();