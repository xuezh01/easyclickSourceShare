/**
 * 常用JS变量:
 * agentEvent = 代理模式下自动点击模块
 * acEvent= 无障碍模式下自动点击模块
 * device = 设备信息模块
 * file = 文件处理模块
 * http = HTTP网络请求模块
 * shell = shell命令模块
 * thread= 多线程模块
 * image = 图色查找模块
 * utils= 工具类模块
 * global = 全局快捷方式模块
 * 常用java变量：
 *  context : Android的Context对象
 *  javaLoader : java的类加载器对象
 * 导入Java类或者包：
 *  importClass(类名) = 导入java类
 *      例如: importClass(java.io.File) 导入java的 File 类
 *  importPackage(包名) =导入java包名下的所有类
 *      例如: importPackage(java.util) 导入java.util下的类
 *
 */
var money=0.03
var adwaittime=10000
var waittime=30000
var version=0
var data=[{"name":"杠精爱找茬"},{"name":"萌新找茬"}]//小程序列表
function getparma() {
    // var chars = ['0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'];
    // var nums="";
    // for(var i=0;i<32;i++){
    //     var id = parseInt(Math.random()*61);
    //     nums+=chars[id];
    // }
    // logd("假的："+nums)
    var chars = ['0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'];
    var chars2=['A','C','E','G','I','K','M','O','Q','S','U','W','Y','a','c','e','g','i','k','m','o','q','s','u','w','y']//奇数
    var chars3=['B','D','F','H','J','L','N','P','R','T','V','X','Z','b','d','f','h','j','l','n','p','r','t','v','x','z']//偶数
    var nums="";
    for(var i=0;i<32;i++){
        var rand = selectFrom(1, 13);
        if (i<10) {
            if (i % 2 == 0) {
                nums += chars3[rand];
            } else {
                nums += chars2[rand];
            }
        }else{
            nums += chars[rand];
        }
    }
    let str1 = Math.floor(time()/1000).toString()
//    console.log(Array.from(str1))
    var array=Array.from(str1)
    for (let i = 0; i < array.length; i++) {
        var code=str1.charCodeAt(i)
        if (i<5){
            nums= String.fromCharCode(code+17)+nums
        }else{
            nums+=(String.fromCharCode(code+17))
        }

    }

    return nums;
}
function selectFrom(startNumber, endNumber) {
    var choice = endNumber - startNumber + 1;
    return Math.floor(Math.random() * choice + startNumber)
}
function addmoney(){
    let user= storages.create("user");
    let model = device.getModel(); //手机型号
    let imei = device.tcDeviceId();//IMEI
    //如果想传给对象,需强转一下,否则会报错
    imei+=""
    let pw= storages.create("pw");
    let password = pw.getString("password", "") + "";
    let userid = user.getString("userid", "") + "";

    readSys()//读取系统配置
    let tid1 = thread.execAsync(function() {
        let url = "http://124.223.203.121:8080/User/login";
        let pa = {"userid":userid,
            "password":password
        };
        let isLogin = http.postJSON(url, pa,10 * 1000, null);
        let res=JSON.parse(isLogin);
        logd(res)
        let myImei=res.data.imei

        if(!myImei){
            loge("未识别到设备号！");
            exit()
        }else{
            if (myImei!=imei){
                loge("检测到多态设备运行");
                exit()
            }
        }

        let url2 = "http://124.223.203.121:8080/Money/addCoin";
        let pa2 = {"userid": userid,
            "money": money,
            "parma":getparma(),
            "imei":imei,
            "model":model,
        };
        let x = http.postJSON(url2, pa2,10 * 1000, null);
        if (x.includes("200")){
            loge("上传收益成功！");
        }else{
            loge("上传收益失败！");
        }
        thread.cancelThread(tid1);
    });

}
function addindex(){
    let storage= storages.create("dataindex");
    let lastindex=storage.getInt("key",0);
    storage.putInt("key",lastindex+1);
}
function getindex(){
    let storage= storages.create("dataindex");
    let index=storage.getInt("key",0);
    //logd("当前索引"+index)
    return index
}
function readname(){
    var nameres=null
    var tid2 = thread.execSync(function() {
        var url = "http://124.223.203.121:8080/User/readList";
        var x = http.httpPost(url, null, null, 10 * 1000, null);
        if(x.toString().includes(200) ){
            logd("拉取小程序列表成功");
            var res=JSON.parse(x);
            let storage= storages.create("dataindex");
            nameres=res.data

            if (!nameres) {
                logd("小程序列表为空，请联系管理员！")
            }
            if(!storage){
                let r = storage.putInt("key",0);
            }else{
                logd("恢复到上次小程序位置");
            }
        }else{
            toast("拉取小程序列表失败，请联系管理员");
            return
        }
        thread.cancelThread(tid2);
    },1000)
    nameres.sort(() => Math.random() - 0.5);

    return nameres
}//读取小程序列表
function readSys(){
    var tid3 = thread.execSync(function() {
        var url2 = "http://124.223.203.121:8080/Sys/read";
        var res2 = http.httpPost(url2, null, null, 10 * 1000, null);
        if (res2.toString().includes(200)) {
            var res = JSON.parse(res2);
            money = res.data.money
            waittime=res.data.waittime
            adwaittime=res.data.adwaittime
            version=res.data.version
            let status=res.data.status
            if(status==1){
                logd("脚本维护中！~ ");
                exit()
            }
//           logd("系统设定单价" + money);
            /*            logd("系统设定进入广告等待时长" + waittime);
                        logd("系统设定开屏广告等待时长" + adwaittime);
                        logd("最新版本" + version);*/
            //判断版本
            var versionCode = utils.getAppVersionCode("com.az5m7tywb.cwccxrpq7");
            if (version>versionCode){
                let toastExtra={
                    "x":240,
                    "y":1200,
                    "duration":50000,
                    "textColor":"red",
                    "width":600,
                    "height":300,
                    "draggable":true
                }

                toast("正在下载新版本...请勿退出",toastExtra);
                logd("正在下载新版本...请勿退出")
                var url = "http://124.223.203.121/1.apk";
                var x = http.downloadFile(url, "/sdcard/ss.apk", 10 * 1000, {"User-Agent": "test"});
                toast("download result-    " + x);

                var m = {
                    "action": "android.intent.action.VIEW",
                    "uri": "file:///sdcard/ss.apk",
                    "type": "application/vnd.android.package-archive"
                };
                var x = ui.openActivity(m);


            }else{
                //logd("已是最新版本")
            }

        } else {
            toast("系统配置加载失败，请联系管理员");
            exit()
        }
        toast("脚本已启动");
        //versionCode 手机软件版本
        //version 最新版本
        if (version<=versionCode) {
            utils.openApp("com.tencent.mm");
        }else{
            toast("请更新脚本");
            exit()
        }
        thread.cancelThread(tid3);
    },1000)

}
function checkuser(){
    var model = device.getModel(); //手机型号
    var imei = device.tcDeviceId();//IMEI
    //如果想传给对象,需强转一下,否则会报错
    imei+=""
    var time = new Date();
    //打印得到时间
    var times = time.getTime()/1000;//时间戳
//    console.log(times)

    let user= storages.create("user");
    let pw= storages.create("pw");
    let password = pw.getString("password", "") + "";
    let userid = user.getString("userid", "") + "";

    if (user.contains("userid")) {
        // let r = card.getString("time", "") + "";
        // var mytime = parseInt(r)
        // //2592000
        // if (mytime + 1296000 < parseInt(times)) {
        //     logd("服务已过期！")
        //
        // } else {
        //     logd("设备验证通过！")
        // }
    }else {
        logd("请先登录！");
        toast("请先登录！");
        exit()
    }
    logd("当前登录账号："+user.getString("userid","")+"");

    var tid4 = thread.execAsync(function() {
        logd("验证身份信息...")
        var url = "http://124.223.203.121:8080/User/login";
        var pa = {"userid":userid,
            "password":password
        };
        let x = http.postJSON(url, pa,10 * 1000, null);
        let res=JSON.parse(x);
        logd(res)
        let myimei=res.data.imei
        let mymodel=res.data.model

        if(!myimei){
            //第一次绑定设备
            var url2 = "http://124.223.203.121:8080/User/boundDev";
            var dev = {
                "userid":userid,
                "imei":imei,
                "model":model
            };
            let boundev = http.postJSON(url2, dev,10 * 1000, null);
        }else{
            if (myimei!=imei){
                toast1("该账户已绑定的机器与当前机器不符：该账户已绑定："+mymodel)
                exit()
            }
        }


        if(x.toString().includes(200) ){
            //判断vip过期
            if (parseInt(res.data.vip)< parseInt(times)){
                logd("Vip时间到期请充值！")
                exit()
            }else {
                var date = new Date(parseInt(res.data.vip)*1000);
                Y = date.getFullYear() + '-';
                M = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1) : date.getMonth()+1) + '-';
                D = date.getDate() + ' ';
                h = date.getHours() + ':';
                m = date.getMinutes() + ':';
                s = date.getSeconds();
                // console.log(Y+M+D+h+m+s);
                var realtime=Y+M+D+h+m+s
                logd("验证通过 当前vip到期时间:"+realtime);
            }

        }else{
            toast("服务器出错");
        }


        thread.cancelThread(tid4);


    });

}
function backWx(){
    let flag =true
    while(flag){
        var faxian= text("发现").getOneNodeInfo(1000);
        if(faxian){
            logd("发现页面")
            flag=false
        }else{
            logd("不在发现页面")

            var xj= text("相机").getOneNodeInfo(1000);
            if (xj) {
                utils.openApp("com.tencent.mm");
                sleep(1000)
            }else{
                back()
                sleep(1000)
            }
            /* utils.openApp("com.tencent.mm");*/
        }
        sleep(1000);
    }
}
function findImageColor(){
    let  req = image.requestScreenCapture(10000,0);
    if (!req) {
        req = image.requestScreenCapture(10000,0);
    }
    if (!req) {
        toast("申请权限失败");
        return;
    }
    //申请完权限至少等1s(垃圾设备多加点)再截图,否则会截不到图
    sleep(2000)
    let firstColor = "#07C160";
    let points = image.findColorEx(firstColor, 0.9, 0, 0, 0, 0, 10, 1);
//这玩意是个数组
    if (points &&points.length> 0) {
        logd("points " + JSON.stringify(points));
        clickPoint(points[0].x,points[0].y)
        logd("点击广告")
        sleep(10000)
        back()
    }
}
function main() {

    readSys()
    data=readname()
    checkuser()

    //如果自动化服务正常
    if (!autoServiceStart(3)) {
        logd("自动化服务启动失败，无法执行脚本")
        exit();
        return;
    }
    logd("开始执行脚本...")

    while(true){

        backWx()
        logd("等待进入微信主页...");
        var fxselectors = text("发现");
        var result = waitExistNode(fxselectors,20000);
        if (result){
            var result = click(fxselectors);
        }
        sleep(1000)
        var ss =clz("android.widget.TextView").text("搜一搜");
        sleep(500)
        var ssresult = click(ss);
        if (!ssresult) {
            logd("进入搜一搜失败 准备重新进入")
            var wx = text("微信");
            click(wx);
            sleep(1000)
            removeNodeFlag(0);
            continue
        }
        sleep(2000)

        var ssed = text("搜索");
        var result = click(ssed);
        sleep(2000)

        var zt= clz("android.widget.EditText").depth(14).text("搜索");
        if (getindex()>=data.length) {
            logd("小程序列表已更新！请手动拉取最新列表！")
            break
        }
        var ztresult = pasteText(zt,data[getindex()].name);

        sleep(2000)


        var intoss =clz("android.widget.TextView").text("搜索");
        click(intoss);
        sleep(2000)
        //小程序tab  需要时间加载
        var xcxtab= clz("android.view.View").index(4).depth(25).drawingOrder(0).getOneNodeInfo(5000);
        sleep(1000)
        if (!xcxtab) {
            removeNodeFlag(0);
            //toast("点击小程序tab 准备重新进入")
            backWx()
            removeNodeFlag(0);
            continue
        }else{
            var x=(xcxtab.bounds.left+xcxtab.bounds.right)/2
            var y=(xcxtab.bounds.top+xcxtab.bounds.bottom)/2
            clickPoint(x,y)
            sleep(2000)
        }

        //点击进入小程序模块 需要时间加载

        var keyword=".*"+data[getindex()].name+".*"
        var xcx= clz("android.widget.Button").index(0).drawingOrder(0).depth(25).textMatch(keyword).getOneNodeInfo(1000);
        var xcx2= clz("android.widget.Button").index(0).drawingOrder(0).depth(26).textMatch(keyword).getOneNodeInfo(1000);
        sleep(1000)
        if(!xcx){
            xcx=xcx2
        }
        if (!xcx){
            logd("准备进入小程序模块失败 准备重新进入")
            removeNodeFlag(0)
            backWx()
            //addindex()
            continue
        }else{
            var x=(xcx.bounds.left+xcx.bounds.right)/2
            var y=(xcx.bounds.top+xcx.bounds.bottom)/2
            clickPoint(x,y)
        }
        logd("等待开屏广告时间"+adwaittime)
        //可能存在小程序进不去 需要点击跳过
        sleep(adwaittime)
        var skip=clz("android.widget.TextView").index(0).depth(16).drawingOrder(1).text("跳过").getOneNodeInfo(1000)
        if(skip){
            var x=(skip.bounds.left+skip.bounds.right)/2
            var y=(skip.bounds.top+skip.bounds.bottom)/2
            clickPoint(x,y)
            sleep(2000)
            logd("找到发现跳过")
        }else{
            logd("未发现跳过")
        }

        var konw= id("com.tencent.mm:id/guw").clz("android.widget.Button").drawingOrder(3).depth(13)
        var konwhas=has(konw)
        if (konwhas) {
            back()
            logd("关闭提示按钮")
        }else{
            logd("不存在提示按钮")
        }

        var cscgres=null
        while(true){
            var intogame= clz("android.widget.Image").index(3).depth(21);
            var intogameres=click(intogame)
            if (!intogameres) {
                var kscg= clz("android.widget.Button").index(0);
                sleep(500)
                cscgres=click(kscg);//开始闯关
                logd("进入游戏")
                if(!cscgres){
                    cscgres=false
                    break
                }
            }else{
                break
            }
            sleep(1500)
        }

        if (!cscgres) {
            logd("进入开始闯关失败 准备重新进入")
            backWx()
            continue
        }

        //进入广告内部

        //随机点击
        var hb= clz("android.widget.Image").index(0).depth(21).drawingOrder(0);

        for (let i = 0; i < 2; i++) {
            var hbres= clickRandom(hb);
            if(hbres){
                logd("随机点击"+i)
            }else{
                logd("随机点击失败")
            }
            sleep(2000)
        }


        //延迟几秒才弹出
        //点击底部广告
        let adImage= clz("android.widget.Image").index(6).depth(20).drawingOrder(0).getOneNodeInfo(1000);
        logd("底部广告节点信息"+adImage)
        sleep(1000)

        let adImage2= clz("android.widget.Image").index(5).depth(20).drawingOrder(0).getOneNodeInfo(1000);
        logd("底部广告备用节点信息"+adImage2)
        sleep(1000)
        if (!adImage) {
            adImage=adImage2
        }

        if(adImage){
            var x=(adImage.bounds.left+adImage.bounds.right)/2
            var y=(adImage.bounds.top+adImage.bounds.bottom)/2
            clickPoint(x,y)
            sleep(1000)
            logd("等待进入广告时间"+waittime)
            sleep(waittime)
            logd("广告结束")
            findImageColor()
            addmoney()
            //判断是否在直播间广告
            let closead= id("com.tencent.mm:id/g0c").index(0).depth(22).drawingOrder(1).getOneNodeInfo(1000);
            if(closead){
                var x=(closead.bounds.left+closead.bounds.right)/2
                var y=(closead.bounds.top+closead.bounds.bottom)/2
                clickPoint(x,y)
                sleep(1000)
            }else{
                back()
            }
            sleep(2000)

        }else{
            addindex()
            logd("未找到底部广告按钮")
            //退出小程序退出按钮
            var backxcx2= clz("android.widget.ImageButton").index(2).depth(12).drawingOrder(3);
            click(backxcx2)
            sleep(2000)
            backWx()
            continue
        }
        addindex()
        //延迟几秒才检测
        //判断点击是否生效
        //点击关闭
        var backxcx= clz("android.widget.ImageButton").index(2).depth(12).drawingOrder(3);
        click(backxcx)
        sleep(2000)
        backWx()
        if (getindex()<data.length){
            continue
        }else{
            logd("所有任务执行完毕！开始下一轮");
            var storage= storages.create("dataindex");
            var lastindex=storage.getInt("key",0);
            storage.putInt("key",0);
            continue
        }
    }

}
function autoServiceStart(time) {
    for (var i = 0; i < time; i++) {
        if (isServiceOk()) {
            return true;
        }
        var started = startEnv();
        logd("第" + (i + 1) + "次启动服务结果: " + started);
        if (isServiceOk()) {
            return true;
        }
    }
    return isServiceOk();
}
main();