/**
 * 该文件由EasyClick开发工具自动创建
 */
function main() {

    var set = ui.layout("参数设置", "main.xml");
    ui.layout("其他说明", "main2.xml");
   // ui.logd("设置UI结果: " + set);




    ui.run(1000,function (){
        setLogViewSize(550,200,10,"#336699")
    })


    //监听Activity的事件设置
    ui.onActivityEvent("onResume", function (eventType) {
        // 可以在这里判断服务是否正常
        ui.logd("activity onResume " + ui.isServiceOk());
    });

    ui.onActivityEvent("onPause", function (eventType) {
        ui.logd("activity onPause");
    });

    ui.onActivityEvent("onStop", function (eventType) {
        ui.logd("activity onStop");
    });
    ui.onActivityEvent("onDestroy", function (eventType) {
        ui.logd("activity onDestroy");
    });


    //Switch 开关按钮的用法
    var auto_env = ui.getViewValue(ui.auto_env);
    ui.logd("tag为 auto_env 的值: " + auto_env);
    //开关按钮的事件
    ui.setEvent(ui.auto_env, "checkedChange", function (view, isChecked) {
        ui.logd("tag为 auto_env isChecked " + isChecked);
        if (isChecked) {
            startAutoEnv();
        }
    });
    if (ui.isServiceOk()) {
        ui.auto_env.setChecked(true);
    } else {
        ui.auto_env.setChecked(false);
    }


    //saveAllBtn 保存参数事件
    ui.setEvent(ui.saveAllBtn, "click", function (view) {
        var s = ui.saveAllConfig();
        ui.logd("保存所有参数结果 " + s)
    });

    //系统设置按钮
    ui.setEvent(ui.systemSetting, "click", function (view) {
        ui.openECSystemSetting();

    });
    //启动脚本按钮

    //拉取小程序列表
    ui.setEvent(ui.loginBtn, "click", function (view) {
        let mes=""
        var tid6 = thread.execAsync(function() {
            var url = "http://124.223.203.121:8080/User/login";
            var pa = {"userid": ui.getViewValue(ui.userid),
                "password":ui.getViewValue(ui.password)
            };
            let x = http.postJSON(url, pa,10 * 1000, null);
            // loge("result -    " + x);
            let res=JSON.parse(x);//展示时间
            if(x.toString().includes(200) ){
                var userid=res.data.userid
                var password=res.data.password
                toast("登录成功");
              ui.time.setText("登录成功");
                let storage= storages.create("user");
                let storage2= storages.create("pw");
                storage.putString("userid",userid);
                storage2.putString("password",password);
                // logd(storage.getString("userid","")+"");
            }else{
                toast("登录失败,请检查账号密码");
            }
            thread.stopAll();
        });
    });
    ui.setEvent(ui.clearuser, "click", function (view) {

        let user= storages.create("user");
        let card= storages.create("card");

        logd(user.remove("userid"));
        logd(card.remove("time"));

    })
    ui.setEvent(ui.czcard, "click", function (view) {

        var tid7 = thread.execAsync(function() {
            var time = new Date();
            //打印得到时间
            var times = time.getTime()/1000;//时间戳
//    console.log(times)
            let user= storages.create("user");
            let pw= storages.create("pw");
            let password = pw.getString("password", "") + "";
            let userid = user.getString("userid", "") + "";
            if (!ui.getViewValue(ui.card)){
                toast("请输入卡密！")
                return
            }
            var url = "http://124.223.203.121:8080/Card/delCard";
            var pa = {
                "userid":userid,
                "time":parseInt(times)+2592000,
                "card":ui.getViewValue(ui.card)
            };
            var x = http.postJSON(url, pa,10 * 1000, null);
            logd("result -    " + x);
            var res=JSON.parse(x);//
            if(x.toString().includes(200) ){
                // var now = new Date();
                // var time = new Date( now.getTime() + 2592000000);
                // var times = time.getTime()/1000;//时间戳
                // console.log(time.toLocaleString());
                // let storage= storages.create("card");
                // let r = storage.putString("time",times.toString());
                toast("激活成功！")
                //  ui.time.setText("到期时间："+time.toLocaleDateString());
            }else{
                toast("激活失败！");
            }
            thread.cancelThread(tid7);
            //判断是否充值

        });

    })
    ui.setEvent(ui.pushdata, "click", function (view) {
        let storage= storages.create("dataindex");
        let r = storage.putInt("key",0);

    })
    ui.setEvent(ui.startBtn, "click", function (view) {
      ui.start();
    });
    //启动环境按钮
    ui.setEvent(ui.envBtn, "click", function (view) {
        //异步启动环境，如果成功了就设置auto_env 按钮的状态
        startAutoEnv();
    });
    //获取所有的UI参数
//    ui.logd("获取所有的UI参数：" + ui.getConfigJSON());
    //设置值的用法，这里先注释掉
    // ui.setViewValue(ui.name, "我是设置的");
    // ui.setViewValue(ui.auto_env, false);
    // ui.setViewValue(ui.sex, "男生|女生");
    // ui.setViewValue(ui.three, true);
    // ui.setViewValue(ui.dance, false)

}

function startAutoEnv() {
    ui.startEnvAsync(function (r) {
        ui.logd("启动环境结果: " + r);
        ui.auto_env.setChecked(r);
    });
}

main();